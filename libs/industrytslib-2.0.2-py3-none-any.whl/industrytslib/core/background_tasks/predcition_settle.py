import polars as pl

from industrytslib.utils.database import database_builder
from industrytslib.utils.logutils import get_logger

def calculate_predict_index(row: pl.DataFrame) -> tuple[pl.Datetime, float]:
    """Calculate prediction index based on real and predicted values.
    计算公式：
    predict_index = (1 - (abs(real_value - pred_value) / abs(real_value))) * 100

    Args:
        row: DataFrame containing DateTime, 真实值 (real value) and AI预测值 (predicted value)

    Returns:
        tuple: (DateTime, prediction index value)
    """
    # 获取第一行的值
    real_value = row.select('真实值').item()
    pred_value = row.select('AI预测值').item()
    datetime = row.select('DateTime').item()

    if real_value == 0:
        predict_index = 0
    else:
        if (abs(real_value - pred_value) / abs(real_value)) > 1:
            predict_index = 0
        else:
            predict_index = 1 - (abs(real_value - pred_value) / abs(real_value))
    
    predict_index = predict_index * 100
    return datetime, predict_index



class PredictionSettle:
    def __init__(self, config: dict):
        self.logger = get_logger("PredictionSettle", "database")
        self.rt_mssql_client = database_builder(config["mssql"]["realtimepredict"])

        self.column_name_list = ["DateTime", "真实值", "软测量预测值", "3分钟预测值", "5分钟预测值", 
                                 "30分钟预测值", "AI预测值", "AI预测指标"]
        
        self.predict_table_list = self.rt_mssql_client.query_rt_project_list()
        self.logger.info(f"预测表列表: {self.predict_table_list}")
        
    def update_ai_predict_value(self, table_name: str) -> None:
        """
        更新AI预测值和AI预测指标
        """
        latest_predict_records = self.rt_mssql_client.query_latest_predict_value(table_name)
        # self.logger.info(f"latest_predict_records: {latest_predict_records}")

        # 遍历数据，根据时间窗口整合预测值
        # 根据列名筛选非空值
        soft_measurement_notnull = latest_predict_records.select(["DateTime", "软测量预测值"]).drop_nulls()
        three_minute_notnull = latest_predict_records.select(["DateTime", "3分钟预测值"]).drop_nulls()
        five_minute_notnull = latest_predict_records.select(["DateTime", "5分钟预测值"]).drop_nulls()
        thirty_minute_notnull = latest_predict_records.select(["DateTime", "30分钟预测值"]).drop_nulls()

        # 获取Top N数据
        soft_measurement_top = soft_measurement_notnull  # 软测量预测值的Top 3
        three_minute_top = three_minute_notnull.head(3)  # 3分钟预测值的Top 3
        five_minute_top = five_minute_notnull.head(2)  # 5分钟预测值的Top 2
        thirty_minute_top = thirty_minute_notnull.head(25)  # 30分钟预测值的Top 25

        # soft_measurement_top.columns = [""] * len(soft_measurement_top.columns)
        # three_minute_top.columns = [""] * len(three_minute_top.columns)
        # five_minute_top.columns = [""] * len(five_minute_top.columns)
        # thirty_minute_top.columns = [""] * len(thirty_minute_top.columns)  
        # 将列名都改为DateTime和AI预测值，方便concat
        soft_measurement_top = soft_measurement_top.rename({"DateTime": "DateTime", "软测量预测值": "AI预测值"})
        three_minute_top = three_minute_top.rename({"DateTime": "DateTime", "3分钟预测值": "AI预测值"})
        five_minute_top = five_minute_top.rename({"DateTime": "DateTime", "5分钟预测值": "AI预测值"})
        thirty_minute_top = thirty_minute_top.rename({"DateTime": "DateTime", "30分钟预测值": "AI预测值"})

        # 创建非空DataFrame列表
        dfs_to_concat = []
        for df in [thirty_minute_top, five_minute_top, three_minute_top, soft_measurement_top]:
            if not df.is_empty():
                dfs_to_concat.append(df)
        
        # 只在有非空DataFrame时进行拼接
        if dfs_to_concat:
            new_df = pl.concat(dfs_to_concat, how="vertical")
            # 计算滑动平均
            new_df.columns = ["DateTime", "AI预测值"]
            # 计算后30分钟平均值
            head_df = new_df.head(30)
            head_df = head_df.with_columns(
                [pl.col(column).rolling_mean(window_size=5, min_periods=1).alias(column)
                 for column in head_df.columns if column != "DateTime"]
            )
            new_df = pl.concat([head_df, new_df.tail(new_df.height - 30)], how="vertical")
            # 将计算结果根据DateTime写入到数据库
            self.rt_mssql_client.update_ai_predict_value(table_name, new_df)
        else:
            self.logger.warning(f"No valid data to concatenate for table {table_name}")
            return

        # 计算AI预测指标
        try:
            index_df = (latest_predict_records
                    .select(['DateTime', '真实值', 'AI预测值'])
                    .drop_nulls()
                    .head(1))
            
            if not index_df.is_empty():
                index_time, predict_index = calculate_predict_index(index_df)
                self.rt_mssql_client.update_ai_predict_index(table_name, index_time, predict_index)
                self.logger.info(f"Update AI predict index successfully! {table_name}")
            else:
                # self.logger.warning(f"No valid data for index calculation in table {table_name}")
                pass
        except Exception as e:
            self.logger.warning(f"质量指标没有及时更新！{e}")

    def main(self):
        self.predict_table_list = self.rt_mssql_client.query_rt_project_list()
        self.logger.info(f"预测表列表: {self.predict_table_list}")
        for table_name in self.predict_table_list:
            self.update_ai_predict_value(table_name)
        self.logger.info("======================更新AI预测值和AI预测指标成功!======================")
        