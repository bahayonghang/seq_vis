import re
from datetime import datetime
from typing import Tuple, List

import polars as pl

from .postgres_base import PostgreSQLConnection
from industrytslib.utils.logutils import get_logger
from industrytslib.utils.basefunc import prediction_parameter_parser, name_list_parser


class PostgreSQLWeb(PostgreSQLConnection):
    """
    PostgreSQL Web database interface class.
    
    Implements web-specific database operations for the industry time series library.
    """
    
    def __init__(self, config: dict) -> None:
        """
        Initialize PostgreSQL Web connection.

        Args:
            config: Database configuration dictionary
        """
        super().__init__(config)
        self.logger = get_logger("PostgreSQLWeb", "database")

    def get_prediction_info(self, project_name: str) -> Tuple[str, str]:
        """
        Get prediction info for a project from yunxing table.

        Args:
            project_name: Name of the project

        Returns:
            Tuple containing:
                - sample_name: Name of the sample
                - model_name: Name of the model
        """
        sql = """
            SELECT yangben, moxing 
            FROM yunxing 
            WHERE sampletable_name = %s
        """
        rows = self.query(sql, (project_name,))
        sample_name = rows["yangben"].item()
        model_name = rows["moxing"].item()
        self.logger.info(f"Sample name: {sample_name}, model name: {model_name}")
        return sample_name, model_name

    def get_rt_info(self, project_name: str) -> pl.DataFrame:
        """
        Get realtime info for a project from yunxing table.

        Args:
            project_name: Name of the project

        Returns:
            pl.DataFrame: Realtime prediction information
        """
        sql = "SELECT * FROM yunxing WHERE sampletable_name = %s"
        return self.query(sql, (project_name,))

    def get_model_parameter(self, model_name: str) -> Tuple[str, dict]:
        """
        Get model parameters from algoone table.

        Args:
            model_name: Name of the model

        Returns:
            Tuple containing:
                - algorithm_name: Name of the algorithm
                - parameter: Dictionary of model parameters
        """
        sql = "SELECT model_name, parameter FROM algoone WHERE project_name = %s"
        rows = self.query(sql, (model_name,))
        
        algorithm_name = rows["model_name"].item()
        parameter_str = rows["parameter"].item()
        parameter = prediction_parameter_parser(parameter_str)
        
        self.logger.info(f"Parameters for model {model_name}: {parameter}")
        return algorithm_name, parameter

    def get_sample_table_information(self, sample_name: str) -> pl.DataFrame:
        """
        Get sample table information from sampletablezong.

        Args:
            sample_name: Name of the sample table

        Returns:
            pl.DataFrame: Sample table information
        """
        sql = """
            SELECT * FROM sampletablezong 
            WHERE sample_table = %s
        """
        sample_table_info = self.query(sql, (sample_name,))
        self.logger.info(f"Sample table information for {sample_name}: {sample_table_info}")
        return sample_table_info

    def _get_sample_table_input_name(self, sample_name: str) -> List[str]:
        """
        Get input variable names for a sample table.

        Args:
            sample_name: Name of the sample table

        Returns:
            List[str]: List of input variable names
        """
        sample_table_info = self.get_sample_table_information(sample_name)
        input_name_str = sample_table_info["column_namein"].item()
        return name_list_parser(input_name_str)

    def get_optimization_info(
            self, 
            project_name: str
        ) -> Tuple[pl.DataFrame, pl.DataFrame, List[str], List[str], List[List[str]]]:
        """
        Get optimization information for a project.

        Args:
            project_name: Name of the project

        Returns:
            Tuple containing:
                - optimization_arguments: Optimization model parameters
                - optimization_constraints: Optimization constraints
                - prediction_model_table_list: List of prediction model table names
                - prediction_model_list: List of prediction model names
                - input_name_list: List of input variable names for each model
        """
        # Get optimization arguments
        sql = """
            SELECT * FROM optimization 
            WHERE optimization_project_name = %s
        """
        optimization_arguments = self.query(sql, (project_name,))
        
        # Get constraints
        constraints_str = optimization_arguments["bianliang"].item()
        pattern = re.compile(r'([^, ]+?): min: (-?\d+\.?\d*) max: (-?\d+\.?\d*)', re.UNICODE)
        constraint_data = [
            {
                'variable': match.group(1),
                'min': float(match.group(2)),
                'max': float(match.group(3))
            }
            for match in pattern.finditer(constraints_str)
        ]
        optimization_constraints = pl.DataFrame(constraint_data)

        # Get prediction models
        optimization_prediction_model = optimization_arguments["prediction_model"].item().split(',')
        prediction_model_table_list = []
        prediction_model_list = []
        
        for model in optimization_prediction_model:
            parts = model.strip().split('_')
            prediction_model_table_list.append(parts[0])
            prediction_model_list.append(f"{parts[1]}_{parts[2]}")

        # Get input names for each model
        input_name_list = [
            self._get_sample_table_input_name(sample_name)
            for sample_name in prediction_model_table_list
        ]

        self.logger.info(f"Input names for {project_name}: {input_name_list}")
        return (
            optimization_arguments,
            optimization_constraints,
            prediction_model_table_list,
            prediction_model_list,
            input_name_list
        )

    def ensure_table_exist_operation_status(self) -> None:
        """
        Ensure operation_status table exists in database.
        """
        sql = """
            CREATE TABLE IF NOT EXISTS operation_status (
                DateTime timestamp,
                project_name VARCHAR(255) PRIMARY KEY,
                project_type VARCHAR(255),
                operation_status integer
            );
        """
        self.execute(sql)

    def init_operation_status(self) -> None:
        """Initialize operation_status table by clearing all data."""
        self.execute("TRUNCATE TABLE operation_status")

    def update_operation_status(
            self, 
            update_time: datetime, 
            project_name: str, 
            project_type: str
        ) -> None:
        """
        Update operation status for a project.

        Args:
            update_time: Time of update
            project_name: Name of the project
            project_type: Type of the project
        """
        sql = """
            INSERT INTO operation_status 
            (DateTime, project_name, project_type, operation_status)
            VALUES (%s, %s, %s, 1)
        """
        self.execute(sql, (update_time, project_name, project_type))

    def write_device_status(self, project_name: str, device_status: int) -> None:
        """
        Write device status to TagDatabase.

        Args:
            project_name: Name of the project/device
            device_status: Status value to write
        """
        try:
            # Check if record exists
            sql = "SELECT COUNT(*) FROM TagDatabase WHERE TagName = %s"
            count = self.query(sql, (project_name,)).item()
            
            if count > 0:
                sql = "UPDATE TagDatabase SET TagVal = %s WHERE TagName = %s"
                self.execute(sql, (device_status, project_name))
            else:
                sql = "INSERT INTO TagDatabase (TagName, TagVal) VALUES (%s, %s)"
                self.execute(sql, (project_name, device_status))
        except Exception as e:
            self.logger.error(f"Error updating device status: {e}")

    def insert_device_status(self, project_name: str, device_status: int) -> None:
        """
        Insert device status with current timestamp.

        Args:
            project_name: Name of the project/device
            device_status: Status value to insert
        """
        sql = """
            INSERT INTO device_status (DateTime, device_name, device_status)
            VALUES (%s, %s, %s)
        """
        try:
            self.execute(sql, (datetime.now(), project_name, device_status))
        except Exception as e:
            self.logger.error(f"Error inserting device status: {e}")
