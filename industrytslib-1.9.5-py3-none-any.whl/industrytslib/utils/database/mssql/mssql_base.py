import datetime
import pyodbc
import time

import polars as pl

from industrytslib.utils.database.base import Database
from industrytslib.utils.logutils import get_logger


class MSSQLConnection(Database):
    def __init__(self, config: dict) -> None:
        self.config = config
        self.logger = get_logger("MSSQL", "database")

        self.server = self.config['server']
        self.username = self.config['username']
        self.password = self.config['password']
        self.database = self.config['database']

        # Set the maximum number of retries and the delay between retries
        self.max_retries = 9999
        self.retry_delay = 60  # seconds

        self.connect_db()

    def connect(self) -> None:
        """
        connect to mssql database
        """
        # self.connection = pyodbc.connect(
        #     f'DRIVER=ODBC Driver 18 for SQL Server;SERVER={self.server};DATABASE={self.database};UID={self.username};PWD={self.password};TrustServerCertificate=yes;'
        # )
        self.connection = pyodbc.connect(
            f'DRIVER=ODBC Driver 17 for SQL Server;SERVER={self.server};DATABASE={self.database};UID={self.username};PWD={self.password};TrustServerCertificate=yes;'
        )
        self.cursor = self.connection.cursor()
        self.logger.info(f"Connect to {self.server} {self.database} as {self.username} Successfully!")
        
    def connect_db(self) -> None:
        """
        pipline of connect to mssql database, including error handling and retry
        """
        for attempt in range(self.max_retries):
            try:
                self.connect()
                self.logger.info(f"""
                                 username: {self.username}, password: {self.password} | 连接{self.server}数据库成功
                                 """)
                self.max_retries = 9999
                return
            except pyodbc.Error as e:
                self.logger.warning(f"""
                                    username: {self.username}, password: {self.password}, Database: {self.database} 
                                    | 连接{self.server}尝试 {attempt + 1} 失败: {str(e)}
                """)
                if attempt < self.max_retries - 1:
                    self.logger.info(f"等待 {self.retry_delay} 秒后重试...")
                    time.sleep(self.retry_delay)
                else:
                    self.logger.error(f"""
                                      username: {self.username}, password: {self.password}, Database: 
                                      {self.database} | 无法连接到{self.server}数据库，已达到最大重试次数!
                                      """)
                    raise Exception(f"""
                                    username: {self.username}, password: {self.password}, 
                                    Database: {self.database} | 无法连接到{self.server}数据库，已达到最大重试次数!
                                    """) from e
                
    def close(self) -> None:
        """
        close the connection to the database
        """
        self.cursor.close()
        self.connection.close()
        self.logger.info("数据库连接已关闭!")

    # 判断数据库中表/视图是否存在
    def is_table_exist(self, table_name: str) -> bool:
        """
        check if the table/view exists in the database
        Args:
            table_name (str): the name of the table/view
        Returns:
            bool: True if the table/view exists, False otherwise
        """
        table_exist_sql = f"""
            SELECT *
            FROM sys.objects
            WHERE object_id = OBJECT_ID('{table_name}')
        """
        self.cursor.execute(table_exist_sql)
        return self.cursor.fetchone() is not None

    def query(self, sql: str) -> pl.DataFrame:
        """
        query the data from the database
        Args:
            sql (str): the sql query
        Returns:
            pl.DataFrame: the data from the database
        """
        self.cursor.execute(sql)
        rows = self.cursor.fetchall()
        columns = [column[0] for column in self.cursor.description]
        df = pl.DataFrame({col: [row[i] for row in rows] for i, col in enumerate(columns)})
        return df

    def execute(self, sql: str) -> None:
        """
        execute the sql
        """
        self.cursor.execute(sql)
        self.connection.commit()
    
    def truncate_table(self, table_name: str) -> None:
        """
        清空表中的数据
        """
        sql = f"TRUNCATE TABLE {table_name}"
        self.execute(sql)

    def add_column(self, table_name: str, column_name: str, column_type: str) -> None:
        """
        add a column to the table
        """
        sql = f"ALTER TABLE {table_name} ADD COLUMN {column_name} {column_type}"
        self.execute(sql)

    def update_list(self, table_name: str, time_update: datetime.datetime, 
                    name_list: list[str], value_list: list[float]) -> None:
        """
        根据列表更新数据库

        Args:
            table_name (str): 表名
            time_update (datetime.datetime): 更新时间
            name_list (list[str]): 变量名列表
            value_list (list[float]): 值列表
        """
        update_sql = f"UPDATE [{table_name}] SET"
        i = 0
        for var_name in name_list:
            update_sql += f" [{var_name}_true] = '{value_list[i]}',"
            i += 1
        update_sql += " WHERE DateTime = ?"
        self.cursor.execute(update_sql, (time_update,))
        self.connection.commit()

    def insert_list(self, table_name: str, time_insert: datetime.datetime, 
                    name_list: list[str], value_list: list[float]) -> None:
        """
        根据列表插入数据库

        Args:
            table_name (str): 表名
            time_insert (datetime.datetime): 插入时间
            name_list (list[str]): 变量名列表
            value_list (list[float]): 值列表
        """
        insert_sql = f"INSERT INTO [{table_name}] (DateTime,"
        i = 0
        for var_name in name_list:
            insert_sql += f" [{var_name}_true],"
            i += 1
        insert_sql += ") VALUES (?, "
        for _ in name_list:
            insert_sql += "?,"
        insert_sql += ")"
        self.cursor.execute(insert_sql, (time_insert, *value_list))
        self.connection.commit()
    
    def insert_sequence_value(
            self, table_name: str, time_insert: datetime.datetime, 
            name_list: list[str], value_list: list[float]
        ) -> None:
        """
        插入sequence预测值

        Args:
            table_name (str): 表名
            time_update (datetime.datetime): 更新时间
            name_list (list[str]): 变量名列表
            value_list (list[float]): 值列表
        """
        # 构建列名部分，包含DateTime和用户提供的列
        columns = ['DateTime'] + [f"[{name}]" for name in name_list]
        column_str = ', '.join(columns)
        
        # 构建参数占位符
        placeholders = ', '.join(['?' for _ in range(len(columns))])
        
        # 构建完整的INSERT语句
        insert_sql = f"""
            INSERT INTO [{table_name}] 
            ({column_str}) 
            VALUES ({placeholders})
        """
        
        # 组合参数值
        parameters = (time_insert, *value_list)

        self.cursor.execute(insert_sql, parameters)
        self.connection.commit()
    
    def clear_table_data_by_columns(
            self, table_name: str, 
            columns_to_clear: list[str]
        ) -> int:
        """
        根据列名清空表中的数据
        Args:
            table_name (str): 表名
            columns_to_clear (list[str]): 列名列表
        Returns:
            int: 受影响的行数
        """
         # Validate input
        if not columns_to_clear:
            raise ValueError("columns_to_clear list cannot be empty")
            
        # Create the SET clause for UPDATE statement
        set_clause = ", ".join([f"[{col}] = NULL" for col in columns_to_clear])
        
        # Construct the UPDATE query
        update_query = f"""
            UPDATE [{table_name}]
            SET {set_clause}
            WHERE {' IS NOT NULL OR '.join([f'[{col}]' for col in columns_to_clear])} IS NOT NULL
        """
        self.cursor.execute(update_query)
        self.connection.commit()
        return self.cursor.rowcount
    
    def query_rt_project_list(self) -> list:
        """
        ! 只有在实时预测表中才能使用
        查询数据库中所有的实时预测表
        """
        sql = "SELECT name FROM sys.tables"
        self.cursor.execute(sql)
        rows = self.cursor.fetchall()
        project_list = [row[0] for row in rows]
        # 去除一些不需要的表
        remove_list = ["能源消耗样本总表", "质量样本总表", "ErrorMetrics", "真实值_AI预测值_指标_窑",
                       "二线窑长序列多入多出样本_二线窑长序列多入多出样本_informer", "窑孪生样本_窑孪生样本_informer"]
        for remove_table in remove_list:
            try:
                project_list.remove(remove_table)
            except ValueError:
                # self.logger.warning(f"Table {remove_table} not found in project list")
                pass
        return project_list
