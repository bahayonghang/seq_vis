import torch.nn as nn

from industrytslib.models.aimodels.layers.KANS import KANLinear


class LSTMKAN(nn.Module):
    # def __init__(self, input_dim, hidden_dim, output_dim, n_layers, drop_prob=0.2):
    def __init__(self, configs):
        super(LSTMKAN, self).__init__()
        self.input_dim = configs.in_channels
        self.hidden_dim = configs.hidden_size
        self.n_layers = configs.num_layers
        self.output_dim = configs.output_size
        self.drop_prob = configs.drop_prob

        self.lstm = nn.LSTM(
            self.input_dim, self.hidden_dim, self.n_layers, batch_first=True, dropout=self.drop_prob
        )
        self.fc = KANLinear(self.hidden_dim, self.output_dim)
        self.relu = nn.ReLU()

    def forward(self, x):
        h = self.init_hidden(x.size(0))
        h = tuple([e.data for e in h])
        out, h = self.lstm(x, h)
        out = self.fc(self.relu(out[:, -1]))
        return out

    def init_hidden(self, batch_size):
        weight = next(self.parameters()).data
        # Initialize h_0, c_0 with zeros
        hidden = (
            weight.new(self.n_layers, batch_size, self.hidden_dim).zero_(),  # h_0
            weight.new(self.n_layers, batch_size, self.hidden_dim).zero_(),
        )
        return hidden
