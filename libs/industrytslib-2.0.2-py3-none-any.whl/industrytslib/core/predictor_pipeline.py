from .realtime_predictors import (
    RealtimePredictor, 
    RealtimePredictorAll, 
    SequenceRealtimePredictor, 
    AsyncRealtimePredictorAll,
    QualityRealtimePredictor,
    SequenceSoftPredictor
)
from industrytslib.core.base import ScheduledTask, AsyncScheduledTask


def get_realtime_predictor(
        project_name: str, 
        dbconfig: dict, 
        predictor_type: str
    ) -> ScheduledTask|AsyncScheduledTask:
    """
    获取实时预测器
    Args:
        project_name: 项目名称
        dbconfig: 数据库配置
        predictor_type: 预测器类型
    Returns:
        RealtimePredictor|AsyncRealtimePredictorAll
    Examples:
        >>> from industrytslib.utils.readconfig import read_config_toml
        >>> config = read_config_toml("config/dbconfig.toml")
        >>> get_realtime_predictor("二线窑长序列多入多出样本_二线窑长序列多入多出样本_TimesMamba", config, "sequence")
    """
    match predictor_type:
        case "basic":
            return RealtimePredictor(project_name, dbconfig)
        case "classic":
            return RealtimePredictorAll(project_name, dbconfig)
        case "async_classic":
            return AsyncRealtimePredictorAll(project_name, dbconfig)
        case "sequence":
            return SequenceRealtimePredictor(project_name, dbconfig)
        case "quality":
            return QualityRealtimePredictor(project_name, dbconfig)
        case "sequence_soft":
            return SequenceSoftPredictor(project_name, dbconfig)
        case _:
            raise ValueError(f"Invalid predictor type: {predictor_type}")
        