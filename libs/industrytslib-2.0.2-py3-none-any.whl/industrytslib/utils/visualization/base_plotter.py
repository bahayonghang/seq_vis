import pathlib
import polars as pl

from abc import ABC, abstractmethod


class BasePlotter(ABC):
    def __init__(self, project_name: str) -> None:
        super().__init__()
        self.project_name = project_name

    @abstractmethod
    def plot_train_result(
        self, 
        time_now: str, 
        epoch: int, 
        true_list: list, 
        pred_list: list, 
        save_path: pathlib.Path
    ) -> None:
        """
        绘制训练结果的平滑曲线图并保存为PNG和HTML文件。

        Args:
            project_name (str): 项目名称,用于设置图表的标题。
            train_result_path (pathlib.Path): 训练结果保存的路径,用于指定输出PNG和HTML文件的路径。
            time_now (str): 当前时间字符串,用于生成文件名。
            epoch (int): 当前训练的轮次,用于生成文件名。
            true_list (list): 真实值列表,用于绘制平滑曲线图。
            pred_list (list): 预测值列表,用于绘制平滑曲线图。

        Returns:
            None: 无返回值,函数执行后将生成PNG和HTML文件并保存到指定路径。
        """
        raise NotImplementedError

    @abstractmethod
    def plot_loss(
        self, 
        time_now: str, 
        train_loss_list: list, 
        vali_loss_list: list, 
        save_path: pathlib.Path
    ) -> None:
        """
        绘制训练损失和验证损失的平滑曲线图并保存为PNG和HTML文件。

        Args:
            project_name (str): 项目名称,用于设置图表的标题。
            train_result_path (pathlib.Path): 训练结果保存的路径,用于指定输出PNG和HTML文件的路径。
            time_now (str): 当前时间字符串,用于生成文件名。
            train_loss_list (list): 训练损失列表,用于绘制平滑曲线图。
            vali_loss_list (list): 验证损失列表,用于绘制平滑曲线图。

        Returns:
            None: 无返回值,函数执行后将生成PNG和HTML文件并保存到指定路径。
        """
        raise NotImplementedError

    @abstractmethod
    def plot_test_result(
        self, 
        time_now: str, 
        true_list: list, 
        pred_list: list, 
        save_path: pathlib.Path
    ) -> None:
        """
        绘制测试结果的平滑曲线图并保存为PNG和HTML文件。

        Args:
            project_name (str): 项目名称,用于设置图表的标题。
            test_result_path (pathlib.Path): 训练结果保存的路径,用于指定输出PNG和HTML文件的路径。
            time_now (str): 当前时间字符串,用于生成文件名。
            true_list (list): 真实值列表,用于绘制平滑曲线图。
            pred_list (list): 预测值列表,用于绘制平滑曲线图。

        Returns:
            None: 无返回值,函数执行后将生成PNG和HTML文件并保存到指定路径。
        """
        raise NotImplementedError
    
    @abstractmethod
    def plot_input_curve(
        self, 
        input_df: pl.DataFrame, 
        save_path: pathlib.Path
    ) -> None:
        """
        绘制输入曲线图并保存为PNG和HTML文件。

        Args:
            project_name (str): 项目名称,用于设置图表的标题。
            input_curve_path (pathlib.Path): 输入曲线保存的路径,用于指定输出PNG和HTML文件的路径。
            input_df (pl.Dataframe): 输入值Dataframe,用于绘制曲线图。

        Returns:
            None: 无返回值,函数执行后将生成PNG和HTML文件并保存到指定路径。
        """
        raise NotImplementedError
    
    @abstractmethod
    def plot_output_curve(
        self, 
        output_df: pl.DataFrame, 
        save_path: pathlib.Path
    ) -> None:
        """
        绘制输出曲线图并保存为PNG和HTML文件。

        Args:
            project_name (str): 项目名称,用于设置图表的标题。
            output_curve_path (pathlib.Path): 输出曲线保存的路径,用于指定输出PNG和HTML文件的路径。
            output_df (pl.Dataframe): 输出值Dataframe,用于绘制曲线图。

        Returns:
            None: 无返回值,函数执行后将生成PNG和HTML文件并保存到指定路径。
        """
        raise NotImplementedError
    