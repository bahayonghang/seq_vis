import gc
import json
import pickle
import progressbar
import time
import torch

import numpy as np

from pathlib import Path
from typing import Tuple
from tqdm import trange
from torch.utils.data import DataLoader, Dataset
from torchinfo import summary

from .basic_trainer import ModelTrainer
from industrytslib.utils.basefunc import get_current_time
from industrytslib.utils.data_processing.data_provider import data_provider_builder
# from industrytslib.models.model_builder import build_model
from industrytslib.models.aimodels.utils.tools import EarlyStopping, adjust_learning_rate
from industrytslib.models.aimodels.utils.metrics import metric_sequence
from industrytslib.utils.data_processing.data_preprocess import TransformerDataFramePreprocess



class TransformerTrainer(ModelTrainer):
    """
    Trainer for transformer like models, including informer, etc.
    """
    def __init__(self, project_name: str, dbconfig: dict) -> None:
        super().__init__(project_name, dbconfig)

    def _get_data(self, flag) -> Tuple[Dataset, DataLoader]:
        data_set, data_loader = data_provider_builder(self.project_name, self.data_input, "transformer", 
                                              self.model_parameter, flag)
        return data_set, data_loader

    def _process_one_batch_time(self, batch_x: torch.Tensor, batch_y: torch.Tensor,
                                batch_x_mark: torch.Tensor, batch_y_mark: torch.Tensor
                                ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        处理一个batch的数据。加载data_input, data_output,输出预测值与真实值。

        Args:
            batch_x (torch.Tensor): 特征数据。
            batch_y (torch.Tensor): 标签数据。

        Returns:
            Tuple[torch.Tensor, torch.Tensor]: 包含两个元素的元组,分别是预测值和真实值。
        """
        batch_x = batch_x.float().to(self.device)
        batch_y = batch_y.float()

        batch_x_mark = batch_x_mark.float().to(self.device)
        batch_y_mark = batch_y_mark.float().to(self.device)

        # dec_inp = torch.zeros([batch_y.shape[0], self.model_parameter["pred_len"], batch_y.shape[-1]]).float().to(self.device)
        dec_inp = torch.zeros([batch_y.shape[0], self.model_parameter["pred_len"], batch_y.shape[-1]]).float()
        dec_inp = torch.cat([batch_y[:, :self.model_parameter["label_len"], :], dec_inp], 
                            dim=1).float().to(self.device)

        # encoder - decoder
        if "TimeMachine" in self.algorithm_name:
            outputs = self.model(batch_x)
        else:
            outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark)

        f_dim = -1 if self.model_parameter["features"] == "MS" else 0
        outputs = outputs[:, -self.model_parameter["pred_len"]:, f_dim:].to(self.device)
        batch_y = batch_y[:, -self.model_parameter["pred_len"]:, f_dim:].to(self.device)

        return outputs, batch_y
    
    
    def vali(self, vali_data: Dataset, vali_loader: DataLoader, criterion: torch.nn.Module) -> float:
        """
        Validate the model.
        Args:
            vali_data (Dataset): Validation dataset.
            vali_loader (DataLoader): Validation data loader.
        Returns:
            float: Validation loss.
        """
        self.model.eval()
        vali_loss_list = []

        with torch.no_grad():
            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(vali_loader):
                outputs, batch_y = self._process_one_batch_time(batch_x, batch_y, batch_x_mark, batch_y_mark)
                loss = criterion(outputs, batch_y)
                vali_loss_list.append(loss.item())

        vali_loss = np.mean(vali_loss_list)
        return vali_loss

    def train(self):
        """
        train the model.
        """
        # split data into train, vali and test
        train_data, train_loader = self._get_data("train")
        vali_data, vali_loader = self._get_data("val")
        test_data, test_loader = self._get_data("test")
        self.logger.debug(f"Get train, vali and test data of {self.project_name} successfully!!!")

        with open(self.scaler_y_path, "rb") as f:
            self.scaler_y = pickle.load(f)


        # # 检查当前操作系统是否为Linux
        # is_linux = platform.system() == 'Linux'
        # # 在Linux上使用torch.compile优化模型
        # if is_linux:
        #     self.model = torch.compile(self.model, mode="max-autotune")
        #     self.logger.info("在Linux上使用torch.compile优化模型成功!")
        # set the criterion and optimizer
        self.criterion = self._set_criterion(self.model_parameter)
        self.optimizer = self._set_optimizer(self.model_parameter)

        # path for saving trained model
        trained_model_path = Path(f"resource/models/{self.project_name}")
        # judge if the trained model exists, if not then create the folder
        if not trained_model_path.exists():
            trained_model_path.mkdir(parents=True, exist_ok=True)

        train_bar = progressbar.ProgressBar(maxval=self.model_parameter["num_epochs"]).start()

        time_train_start = time.time()  # 开始训练的时间,用于计算训练所用的时间

        # early_stopping = EarlyStopping(patience=self.model_parameter["patience"], verbose=True)

        train_steps = len(train_loader)  # 计算训练用的步数

        train_loss_total_list = []  # 记录训练损失的列表,后续用于绘制训练损失曲线
        vali_loss_total_list = []  # 记录验证损失的列表,后续用于绘制验证损失曲线

        for epoch in trange(self.model_parameter["num_epochs"]):
            iter_count = 0  # 记录迭代次数
            train_loss_list = []  # 记录训练损失

            self.model.train()
            epoch_time_start = time.time()  # 记录每个epoch开始的时间

            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(train_loader):
                iter_count += 1
                self.optimizer.zero_grad()
                pred, true = self._process_one_batch_time(batch_x, batch_y, batch_x_mark, batch_y_mark)

                loss = self.criterion(pred, true)
                train_loss_list.append(loss.item())
                self.optimizer.zero_grad()

                if iter_count % 100 == 0:
                    self.logger.debug(
                        f"Epoch {epoch + 1} / {self.model_parameter['num_epochs']} Iteration {iter_count} "
                        f"/ {train_steps}, Loss: {loss.item():.4f}")

                loss.backward()
                self.optimizer.step()

            train_bar.update(epoch + 1)

            epoch_time_end = time.time()  # 记录每个epoch结束的时间
            epoch_cost_time = epoch_time_end - epoch_time_start  # 计算每个epoch所用的时间
            self.logger.debug(f"Epoch {epoch + 1} / {self.model_parameter['num_epochs']} cost time: {epoch_cost_time:.2f}s!")

            train_loss = np.average(train_loss_list)  # 计算训练损失
            vali_loss = self.vali(vali_data=vali_data, vali_loader=vali_loader, criterion=self.criterion)  # 计算验证损失

            # record loss of every epoch
            self.logger.info(f"""
                {self.project_name}:Epoch {epoch + 1} / {self.model_parameter['num_epochs']} 
                cost time: {epoch_cost_time:.2f}
                train loss: {train_loss:.4f}, vali loss: {vali_loss:.4f}
            """)

            self.writer.add_scalar("Loss/train", train_loss, epoch)
            self.writer.add_scalar("Loss/vali", vali_loss, epoch)

            train_loss_total_list.append(train_loss)  # 将训练损失加入到列表中
            vali_loss_total_list.append(vali_loss)  # 将验证损失加入到列表中

            # early_stopping(vali_loss, self.model, trained_model_path.joinpath("checkpoint.pth"))
            # if early_stopping.early_stop:
            #     print("Early stopping")
            #     break

            # adjust_learning_rate(self.optimizer, epoch + 1, self.model_parameter)

            torch.save(self.model.state_dict(), 
                       trained_model_path.joinpath(f"checkpoint_{epoch+1}_{get_current_time()}.pth"))
        
        time_train_end = time.time()  # 结束训练的时间
        time_train = time_train_end - time_train_start  # 计算训练所用的时间
        self.logger.info(f"训练{self.project_name}模型成功,用时{time_train}s!")

        train_bar.finish()

        self.plotter.plot_loss(time_now=get_current_time(),
                  train_loss_list=train_loss_total_list,
                  vali_loss_list=vali_loss_total_list,
                  save_path=self.train_result_path)
        self.logger.info(f"成功绘制{self.project_name}训练、验证损失曲线图！")

        # 清空占用的显存
        torch.cuda.empty_cache()

        return
    
    def train_with_big_batch(self):
        """
        train the model.
        """
        # split data into train, vali and test
        train_data, train_loader = self._get_data("train")
        vali_data, vali_loader = self._get_data("val")
        test_data, test_loader = self._get_data("test")
        self.logger.debug(f"Get train, vali and test data of {self.project_name} successfully!!!")

        with open(self.scaler_y_path, "rb") as f:
            self.scaler_y = pickle.load(f)


        # # 检查当前操作系统是否为Linux
        # is_linux = platform.system() == 'Linux'
        # # 在Linux上使用torch.compile优化模型
        # if is_linux:
        #     self.model = torch.compile(self.model, mode="max-autotune")
        #     self.logger.info("在Linux上使用torch.compile优化模型成功!")
        # set the criterion and optimizer
        self.criterion = self._set_criterion(self.model_parameter)
        self.optimizer = self._set_optimizer(self.model_parameter)

        # path for saving trained model
        trained_model_path = Path(f"resource/models/{self.project_name}")
        # judge if the trained model exists, if not then create the folder
        if not trained_model_path.exists():
            trained_model_path.mkdir(parents=True, exist_ok=True)

        train_bar = progressbar.ProgressBar(maxval=self.model_parameter["num_epochs"]).start()

        time_train_start = time.time()  # 开始训练的时间,用于计算训练所用的时间

        early_stopping = EarlyStopping(patience=self.model_parameter["patience"], verbose=True)

        train_steps = len(train_loader)  # 计算训练用的步数

        train_loss_total_list = []  # 记录训练损失的列表,后续用于绘制训练损失曲线
        vali_loss_total_list = []  # 记录验证损失的列表,后续用于绘制验证损失曲线

        for epoch in trange(self.model_parameter["num_epochs"]):
            iter_count = 0  # 记录迭代次数
            train_loss_list = []  # 记录训练损失

            self.model.train()
            epoch_time_start = time.time()  # 记录每个epoch开始的时间

            scaler = torch.amp.GradScaler()

            # accumulation_steps = 8

            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(train_loader):
                iter_count += 1
                train_loss_batch_list = []
                batch_size = batch_x.shape[0]
                mini_batch_size = int(batch_size / 8)

                self.optimizer.zero_grad()
                for j in range(0, len(batch_x), mini_batch_size):
                    end = min(j + mini_batch_size, batch_x.shape[0])
                    # 将数据移动到GPU
                    mini_batch_x = batch_x[j:end].to(self.device)
                    mini_batch_y = batch_y[j:end].to(self.device)
                    mini_batch_x_mark = batch_x_mark[j:end].to(self.device)
                    mini_batch_y_mark = batch_y_mark[j:end].to(self.device)

                    pred, true = self._process_one_batch_time(
                        mini_batch_x,
                        mini_batch_y,
                        mini_batch_x_mark,
                        mini_batch_y_mark
                    )

                    loss = self.criterion(pred, true)
                    train_loss_batch_list.append(loss.item())
                    # 清理这个小批次的内存
                    del mini_batch_x, mini_batch_y, mini_batch_x_mark, mini_batch_y_mark
                    del pred, true, loss
                    torch.cuda.empty_cache()
                    gc.collect()
                
                # 计算平均 loss 并反向传播
                avg_loss = np.mean(train_loss_batch_list)
                scaler.scale(torch.tensor(avg_loss, device=self.device, requires_grad=True)).backward()
                scaler.step(self.optimizer)
                scaler.update()
                train_loss_list.append(avg_loss)
                self.optimizer.zero_grad()

                if iter_count % 100 == 0:
                    self.logger.debug(
                        f"Epoch {epoch + 1} / {self.model_parameter['num_epochs']} Iteration {iter_count} "
                        f"/ {train_steps}, Loss: {avg_loss:.4f}")

                # loss.backward()
                # self.optimizer.step()

            train_bar.update(epoch + 1)

            epoch_time_end = time.time()  # 记录每个epoch结束的时间
            epoch_cost_time = epoch_time_end - epoch_time_start  # 计算每个epoch所用的时间

            train_loss = np.average(train_loss_list)  # 计算训练损失
            vali_loss = self.vali(vali_data=vali_data, vali_loader=vali_loader, criterion=self.criterion)  # 计算验证损失

            # record loss of every epoch
            self.logger.info(f"{self.project_name}:Epoch {epoch + 1} / {self.model_parameter['num_epochs']} cost time: {epoch_cost_time:.2f}")
            self.logger.info(f"{self.project_name}:Epoch {epoch + 1} / {self.model_parameter['num_epochs']} "
                             f"train loss: {train_loss:.4f}, vali loss: {vali_loss:.4f}")

            self.writer.add_scalar("Loss/train", train_loss, epoch)
            self.writer.add_scalar("Loss/vali", vali_loss, epoch)

            train_loss_total_list.append(train_loss)  # 将训练损失加入到列表中
            vali_loss_total_list.append(vali_loss)  # 将验证损失加入到列表中

            early_stopping(vali_loss, self.model, trained_model_path.joinpath("checkpoint.pth"))
            if early_stopping.early_stop:
                print("Early stopping")
                break

            adjust_learning_rate(self.optimizer, epoch + 1, self.model_parameter)

            torch.save(self.model.state_dict(), trained_model_path.joinpath("checkpoint.pth"))
        
        time_train_end = time.time()  # 结束训练的时间
        time_train = time_train_end - time_train_start  # 计算训练所用的时间
        self.logger.info(f"训练{self.project_name}模型成功,用时{time_train}s!")

        train_bar.finish()

        self.plotter.plot_loss(time_now=get_current_time(),
                  train_loss_list=train_loss_total_list,
                  vali_loss_list=vali_loss_total_list,
                  save_path=self.train_result_path)
        self.logger.info(f"成功绘制{self.project_name}训练、验证损失曲线图！")

        # 清空占用的显存
        torch.cuda.empty_cache()

        return

    def test(self, test=0, **kwargs):
        """
        Test model.
        """
        test_data, test_loader = self._get_data("test")
        if kwargs.get("pth_name"):
            pth_name = kwargs.get("pth_name")
        else:
            pth_name = "checkpoint.pth"

        if test == 1:
            self.logger.info("loading existing model!")
            self.model.load_state_dict(
                torch.load(
                    Path(f"resource/models/{self.project_name}").joinpath(pth_name), 
                    weights_only=True
                    )
                )

        self.model.eval()

        preds = []
        trues = []

        for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(test_loader):
            pred, true = self._process_one_batch_time(batch_x, batch_y, batch_x_mark, batch_y_mark)
            # inverse transform
            pred_ndarray = np.zeros((pred.shape[0], pred.shape[1], pred.shape[2]))
            true_ndarray = np.zeros((true.shape[0], true.shape[1], true.shape[2]))

            match self.model_parameter["features"]:
                case "MS" | "S":
                    for j in range(pred.shape[0]):
                        pred_ndarray[j] = test_data.inverse_transform_y(pred[j].detach().cpu().numpy())
                        true_ndarray[j] = test_data.inverse_transform_y(true[j].detach().cpu().numpy())
                case "M":
                    for j in range(pred.shape[0]):
                        pred_ndarray[j] = test_data.inverse_transform_x(pred[j].detach().cpu().numpy())
                        true_ndarray[j] = test_data.inverse_transform_x(true[j].detach().cpu().numpy())
                case _:
                    raise ValueError(f"Invalid features: {self.model_parameter['features']}")
            # preds.append(pred.detach().cpu().numpy())
            # trues.append(true.detach().cpu().numpy())
            preds.append(pred_ndarray)
            trues.append(true_ndarray)

        preds = np.array(preds)
        trues = np.array(trues)
        preds = preds.reshape(-1, preds.shape[-2], preds.shape[-1])
        trues = trues.reshape(-1, trues.shape[-2], trues.shape[-1])
        self.logger.info('test shape:', preds.shape, trues.shape)

        # result save
        result_save_path = Path(f"resource/results/test_results/{self.project_name}/{get_current_time()}_test")
        if not result_save_path.exists():
            result_save_path.mkdir(parents=True, exist_ok=True)

        mae, mse, rmse, mape, mspe = metric_sequence(
            torch.from_numpy(preds), 
            torch.from_numpy(trues)
        )
        self.logger.info(f"""
                        mae={mae:.4f}, mse={mse:.4f}, rmse={rmse:.4f}, 
                        mape={mape:.4f}, mspe={mspe:.4f}
                        """)

        np.save(result_save_path.joinpath('pred.npy'), preds)
        np.save(result_save_path.joinpath('true.npy'), trues)
        np.save(result_save_path.joinpath('metrics.npy'), np.array([mae, mse, rmse, mape, mspe]))

        # 将self.name_list_input写入result_save_path
        with open(result_save_path.joinpath('name_list.txt'), 'w') as f:
            for name in self.input_name_list:
                f.write(f"{name}\n")
        
        # 将self.model_parameter写入result_save_path
        with open(result_save_path.joinpath('model_parameter.json'), 'w') as f:
            json.dump(self.model_parameter, f)

        # save model
        torch.save(self.model.state_dict(), result_save_path.joinpath('checkpoint.pth'))
        return
    
    def test_train(self, test=0):
        """
        Test model.
        """
        train_data, train_loader = self._get_data("train")
        if test == 1:
            self.logger.info("loading existing model!")
            self.model.load_state_dict(
                torch.load(
                    Path(f"resource/models/{self.project_name}").joinpath("checkpoint.pth"),
                    weights_only=True
                    )
                )

        self.model.eval()

        preds = []
        trues = []

        for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(train_loader):
            pred, true = self._process_one_batch_time(batch_x, batch_y, batch_x_mark, batch_y_mark)
            # inverse transform
            pred_ndarray = np.zeros((pred.shape[0], pred.shape[1], pred.shape[2]))
            true_ndarray = np.zeros((true.shape[0], true.shape[1], true.shape[2]))
            
            match self.model_parameter["features"]:
                case "MS" | "S":
                    for j in range(pred.shape[0]):
                        pred_ndarray[j] = train_data.inverse_transform_y(pred[j].detach().cpu().numpy())
                        true_ndarray[j] = train_data.inverse_transform_y(true[j].detach().cpu().numpy())
                case "M":
                    for j in range(pred.shape[0]):
                        pred_ndarray[j] = train_data.inverse_transform_x(pred[j].detach().cpu().numpy())
                        true_ndarray[j] = train_data.inverse_transform_x(true[j].detach().cpu().numpy())
                case _:
                    raise ValueError(f"Invalid features: {self.model_parameter['features']}")
                
            # preds.append(pred.detach().cpu().numpy())
            # trues.append(true.detach().cpu().numpy())
            preds.append(pred_ndarray)
            trues.append(true_ndarray)

        preds = np.array(preds)
        trues = np.array(trues)
        self.logger.info('test shape:', preds.shape, trues.shape)
        preds = preds.reshape(-1, preds.shape[-2], preds.shape[-1])
        trues = trues.reshape(-1, trues.shape[-2], trues.shape[-1])
        self.logger.info('test shape:', preds.shape, trues.shape)

        # result save
        result_save_path = \
            Path(f"resource/results/test_train_results/{self.project_name}/{get_current_time()}_test_train")
        if not result_save_path.exists():
            result_save_path.mkdir(parents=True, exist_ok=True)

        mae, mse, rmse, mape, mspe = metric_sequence(
            torch.from_numpy(preds), 
            torch.from_numpy(trues)
        )
        self.logger.info(f"""
                        mae={mae:.4f}, mse={mse:.4f}, rmse={rmse:.4f}, 
                        mape={mape:.4f}, mspe={mspe:.4f}
                        """)

        np.save(result_save_path.joinpath('pred_train.npy'), preds)
        np.save(result_save_path.joinpath('true_train.npy'), trues)
        np.save(result_save_path.joinpath('metrics_train.npy'), np.array([mae, mse, rmse, mape, mspe]))

        # 将self.name_list_input写入result_save_path
        with open(result_save_path.joinpath('name_list.txt'), 'w') as f:
            for name in self.input_name_list:
                f.write(f"{name}\n")

        return
    
    def print_model_info_transformer(self):
        freq_map = {"h": 4, "t": 5, "s": 6, "m": 1, "a": 1, "w": 2, "d": 3, "b": 3}
        time_embedding_size = freq_map[self.model_parameter['freq']]
        input_size1 = (self.model_parameter['batch_size'], self.model_parameter['seq_len'], 
                       self.model_parameter['enc_in'])
        input_size2 = (self.model_parameter['batch_size'], self.model_parameter['seq_len'], 
                       time_embedding_size)
        input_size3 = (self.model_parameter['batch_size'], 
                       self.model_parameter['label_len'] + self.model_parameter['pred_len'],
                         self.model_parameter['dec_in'])
        input_size4 = (self.model_parameter['batch_size'], 
                       self.model_parameter['label_len'] + self.model_parameter['pred_len'], 
                       time_embedding_size)
        self.logger.info(f"""
                        input_size1: {input_size1}, input_size2: {input_size2}, 
                        input_size3: {input_size3}, input_size4: {input_size4}
                        """)

        if "TimeMachine" in self.algorithm_name:
            summary(self.model, input_size=(input_size1))
        else:
            summary(self.model, input_size=(input_size1, input_size2, input_size3, input_size4))
    
    def main(self) -> None:
        # connect to database and get trainer information
        self.database_connection()
        self.get_trainer_information()
        self.ensure_path()
        self.build_model()

        # 打印模型信息
        self.print_model_info_transformer()

        # Get data from database or local csv files
        self.data_input, self.data_output = self.get_train_data()
        data_process_client = TransformerDataFramePreprocess(self.data_input, self.data_output)
        self.data_input, self.data_output = data_process_client.run()

        # 绘制输入输出曲线
        self.plotter.plot_input_curve(input_df=self.data_input, save_path=self.train_result_path)
        self.plotter.plot_output_curve(output_df=self.data_output, save_path=self.train_result_path)
        self.logger.info(f"{self.project_name}的输入数据为：{self.data_input}")
        self.logger.info(f"{self.project_name}的输出数据为：{self.data_output}")
        # self.data = pl.concat([self.data_input, self.data_output], how="horizontal")

        # data pipline
        # self.data = self.data_input

        self.logger.info(f"model: {self.model}")
        self.logger.info(f"model_parameter: {self.model_parameter}")
        # self.logger.info(f"model summary: {summary(self.model, input_size=(self.model_parameter['batch_size'], self.model_parameter['seq_len'], self.model_parameter['feature_dim']))}")

        self.train()
        # self.train_with_big_batch()  # 使用大batch训练,降低loss变化幅度

        self.test()

        # self.test(test=1)
        self.test_train()

    def main_test(self, **kwargs):
        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        # connect to database and get trainer information
        self.database_connection()
        self.get_trainer_information()
        self.ensure_path()
        self.build_model()

        # Get data from database or local csv files
        self.data_input, self.data_output = self.get_train_data()
        data_process_client = TransformerDataFramePreprocess(self.data_input, self.data_output)
        self.data_input, self.data_output = data_process_client.run()

        self.test(test=1, pth_name=kwargs.get("pth_name"))
