import sys
from pathlib import Path

from loguru import logger


# 移除默认的 logger
logger.remove()

# 添加一个写入 stdout 的 logger
logger.add(sys.stdout, format="{time} - {name} - {level} - {message}", level="WARNING")


def get_logger(logger_name: str, logger_type: str):
    """
    获取指定名称的 logger,并将其日志输出到对应的文件中。

    Args:
        logger_name (str): Logger 的名称
        logger_type (str): Logger 的类型
    """
    log_dir = Path(f"logs/{logger_type}")
    log_dir.mkdir(exist_ok=True)
    log_file = log_dir / f"{logger_name}.log"
    
    # 为这个 logger 添加一个文件处理器
    logger.add(
        str(log_file),
        rotation="00:00",
        format="{time} - {name} - {level} - {message}",
        level="DEBUG",
        filter=lambda record: record["extra"].get("name") == logger_name,
        # 保存2周时间
        retention="14 days"
    )
    
    return logger.bind(name=logger_name)
