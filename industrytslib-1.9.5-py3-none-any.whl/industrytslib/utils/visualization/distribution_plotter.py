"""
分布图绘制模块,包括UMap
"""
import umap

import numpy as np
import matplotlib.pyplot as plt

from sklearn.manifold import TSNE
from pathlib import Path


def tsne_plotter(
        data: np.ndarray,
        labels: np.ndarray,
        perplexity: float = 30.0,
        n_iter: int = 1000,
        random_state: int = 42,
        save_path: Path = None
) -> None:
    """
    使用t-SNE对数据进行降维并可视化。

    Args:
        data: 输入数据，形状为(n_samples, n_features)。
        labels: 数据标签，形状为(n_samples,)。
        perplexity: t-SNE算法的perplexity参数,默认为30.0。
        n_iter: t-SNE算法的迭代次数,默认为1000。
        random_state: 随机种子,默认为42。

    Returns:
        None

    Examples:
        >>> from sklearn import datasets
        >>> digits = datasets.load_digits()
        >>> tsne_plotter(digits.data, digits.target)
    """
    # 使用t-SNE将数据降到2维
    tsne = TSNE(n_components=2, random_state=random_state, perplexity=perplexity, n_iter=n_iter)
    X_tsne = tsne.fit_transform(data)

    # 可视化 t-SNE 的 2D 降维结果
    plt.figure(figsize=(8, 6))
    plt.scatter(X_tsne[:, 0], X_tsne[:, 1], c=labels, cmap="jet")
    plt.title('t-SNE 2D Projection')
    plt.xlabel('t-SNE 1')
    plt.ylabel('t-SNE 2')
    plt.colorbar()
    plt.show()

    if save_path:
        plot_save_path = save_path / "tsne_plot.png"
        plt.savefig(plot_save_path, dpi=600)


def umap_plotter(
    data: np.ndarray, 
    labels: np.ndarray,
    n_neighbors: int = 15,
    min_dist: float = 0.1,
    n_components: int = 2,
    metric: str = 'euclidean',
    random_state: int = 42,
    save_path: Path = None
) -> None:
    """
    使用UMAP对数据进行降维并可视化。

    Args:
        data: 输入数据，形状为(n_samples, n_features)。
        labels: 数据标签，形状为(n_samples,)。
        n_neighbors: UMAP算法的邻居数量参数，默认为15。较小的值关注局部结构，较大的值关注全局结构。
        min_dist: UMAP算法的最小距离参数，默认为0.1。控制嵌入点的紧密程度。
        n_components: 降维后的维度，默认为2。
        metric: 距离度量方式，默认为'euclidean'。可选：'euclidean', 'manhattan', 'cosine'等。
        random_state: 随机种子，默认为42。

    Returns:
        None

    Examples:
        >>> from sklearn import datasets
        >>> iris = datasets.load_iris()
        >>> umap_plotter(iris.data, iris.target)
    """
    # 使用UMAP将数据降维
    reducer = umap.UMAP(
        n_neighbors=n_neighbors,
        min_dist=min_dist,
        n_components=n_components,
        metric=metric,
        random_state=random_state
    )
    
    # 执行降维
    embedding = reducer.fit_transform(data)

    # 可视化UMAP的降维结果
    plt.figure(figsize=(8, 6))
    scatter = plt.scatter(
        embedding[:, 0], 
        embedding[:, 1], 
        c=labels, 
        cmap="jet"
    )
    plt.title('UMAP Projection')
    plt.xlabel('UMAP 1')
    plt.ylabel('UMAP 2')
    plt.colorbar(scatter)
    plt.show()

    if save_path:
        plot_save_path = save_path / "umap_plot.png"
        plt.savefig(plot_save_path, dpi=600)
