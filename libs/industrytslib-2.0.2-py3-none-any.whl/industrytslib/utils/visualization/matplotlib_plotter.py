import numpy as np
import pathlib
import math


import polars as pl
import matplotlib.pyplot as plt

from pathlib import Path
from .base_plotter import BasePlotter


font_name = "simhei"
plt.rcParams['font.family']= font_name # 指定字体，实际上相当于修改 matplotlibrc 文件　只不过这样做是暂时的　下次失效
plt.rcParams['axes.unicode_minus']=False # 正确显示负号，防止变成方框


def plot_npy(result_path: pathlib.Path) -> None:
    """
    plot true and prediction in npy format
    Args:
        result_path (pathlib.Path): path of result
    Examples:
        >>> plot_npy("result")
    """
    true_path = result_path.joinpath("true.npy")
    pred_path = result_path.joinpath("pred.npy")
    true_ndarray = np.load(true_path)
    pred_ndarray = np.load(pred_path)

    # 随机取一个length范围内的ndarray可视化
    length = true_ndarray.shape[0]
    random_index = np.random.randint(0, length)
    print(random_index)
    true = true_ndarray[random_index, :, -1]
    pred = pred_ndarray[random_index, :, -1]
    plt.figure(figsize=(20, 10), dpi=600)
    plt.plot(true, label='True')
    plt.plot(pred, label='Prediction')
    plt.legend()
    # plt.show()
    plt.savefig(result_path.joinpath("true_pred.png"), dpi=600)


def plot_npy_train(result_path: pathlib.Path) -> None:
    """
    plot true and prediction in npy format
    Args:
        result_path (pathlib.Path): path of result
    Examples:
        >>> plot_npy_train("result")
    """
    true_path = result_path.joinpath("true_train.npy")
    pred_path = result_path.joinpath("pred_train.npy")
    true_ndarray = np.load(true_path)
    pred_ndarray = np.load(pred_path)

    # 随机取一个length范围内的ndarray可视化
    length = true_ndarray.shape[0]
    random_index = np.random.randint(0, length)
    print(random_index)
    true = true_ndarray[random_index, :, -1]
    pred = pred_ndarray[random_index, :, -1]
    plt.figure(figsize=(20, 10), dpi=600)
    plt.plot(true, label='True')
    plt.plot(pred, label='Prediction')
    plt.legend()
    # plt.show()
    plt.savefig(result_path.joinpath("true_pred_train.png"), dpi=600)


def plot_npy_all(result_path: pathlib.Path) -> None:
    """
    plot all true and prediction in npy format
    Args:
        result_path (pathlib.Path): path of result
    Examples:
        >>> plot_npy_all("result")
    """
    true_path = result_path.joinpath("true.npy")
    pred_path = result_path.joinpath("pred.npy")
    true_ndarray = np.load(true_path)
    pred_ndarray = np.load(pred_path)

    print(f'true_ndarray shape: {true_ndarray.shape}')
    print(f'pred_ndarray shape: {pred_ndarray.shape}')

    # 如果存在name_list.txt，则读取name_list
    name_list_path = result_path.joinpath("name_list.txt")
    if name_list_path.exists():
        with open(name_list_path, 'r') as f:
            name_list = [line.strip() for line in f.readlines()]
    
    assert len(name_list) == true_ndarray.shape[2] == pred_ndarray.shape[2], "name_list的长度与true_ndarray和pred_ndarray的维度不一致"

    # 随机取一个length范围内的ndarray可视化
    length = true_ndarray.shape[0]
    random_index = np.random.randint(0, length)
    print(random_index)
    
    # 将指定索引的最后一个维度的所有数据可视化，并绘制在一张图中
    # 计算需要的行数和列数
    n_cols = min(3, true_ndarray.shape[2])  # 最多3列
    n_rows = math.ceil(true_ndarray.shape[2] / n_cols)

    # 创建一个自适应的子图网格
    fig, axs = plt.subplots(n_rows, n_cols, figsize=(4*n_cols, 3*n_rows))
    fig.suptitle('Visualization of test results for multi-dimensional data', fontsize=16)
    # 确保 axs 总是一个二维数组
    if true_ndarray.shape[2] == 1:
        axs = np.array([[axs]])
    elif n_rows == 1:
        axs = axs.reshape(1, -1)
    elif n_cols == 1:
        axs = axs.reshape(-1, 1)

    if name_list is not None:
        for i in range(true_ndarray.shape[2]):
            row = i // n_cols
            col = i % n_cols
            ax = axs[row, col]
            true = true_ndarray[random_index, :, i]
            pred = pred_ndarray[random_index, :, i]
            ax.plot(pred, label='Pred')
            ax.plot(true, label='True')
            ax.set_title(f'{name_list[i]}')
            ax.set_xlabel('Time steps')
            ax.set_ylabel('Values')
            ax.grid(True)
            ax.legend()
            print(f'True_{i} and Pred_{i} have been plotted')
    else:
        for i in range(true_ndarray.shape[2]):
            row = i // n_cols
            col = i % n_cols
            ax = axs[row, col]
            true = true_ndarray[random_index, :, i]
            pred = pred_ndarray[random_index, :, i]
            ax.plot(true, label='True')
            ax.plot(pred, label='Pred')
            ax.set_title(f'Dimension {i+1}')
            ax.set_xlabel('Time steps')
            ax.set_ylabel('Values')
            ax.grid(True)
            ax.legend()
            print(f'True_{i} and Pred_{i} have been plotted')

    # 移除多余的子图
    for i in range(true_ndarray.shape[2], n_rows * n_cols):
        row = i // n_cols
        col = i % n_cols
        fig.delaxes(axs[row, col])

    # 调整子图之间的间距
    plt.tight_layout()

    # 显示图形
    # plt.show()
    plt.savefig(result_path.joinpath("true_pred_all.png"), dpi=600)


def plot_npy_all_train(result_path: pathlib.Path) -> None:
    """
    plot all true and prediction in npy format
    Args:
        result_path (pathlib.Path): path of result
    Examples:
        >>> plot_npy_all_train("result")
    """
    true_path = result_path.joinpath("true_train.npy")
    pred_path = result_path.joinpath("pred_train.npy")
    true_ndarray = np.load(true_path)
    pred_ndarray = np.load(pred_path)

    print(f'true_ndarray shape: {true_ndarray.shape}')
    print(f'pred_ndarray shape: {pred_ndarray.shape}')

    # 如果存在name_list.txt，则读取name_list
    name_list_path = result_path.joinpath("name_list.txt")
    if name_list_path.exists():
        with open(name_list_path, 'r') as f:
            name_list = [line.strip() for line in f.readlines()]

    assert len(name_list) == true_ndarray.shape[2] == pred_ndarray.shape[2], "name_list的长度与true_ndarray和pred_ndarray的维度不一致"

    # 随机取一个length范围内的ndarray可视化
    length = true_ndarray.shape[0]
    random_index = np.random.randint(0, length)
    print(random_index)
    
    # 将指定索引的最后一个维度的所有数据可视化，并绘制在一张图中
    # 计算需要的行数和列数
    n_cols = min(3, true_ndarray.shape[2])  # 最多3列
    n_rows = math.ceil(true_ndarray.shape[2] / n_cols)

    # 创建一个自适应的子图网格
    fig, axs = plt.subplots(n_rows, n_cols, figsize=(4*n_cols, 3*n_rows))
    fig.suptitle('Visualization of test(train) results for multi-dimensional data', fontsize=16)
    # 确保 axs 总是一个二维数组
    if true_ndarray.shape[2] == 1:
        axs = np.array([[axs]])
    elif n_rows == 1:
        axs = axs.reshape(1, -1)
    elif n_cols == 1:
        axs = axs.reshape(-1, 1)

    if name_list is not None:
        for i in range(true_ndarray.shape[2]):
            row = i // n_cols
            col = i % n_cols
            ax = axs[row, col]
            true = true_ndarray[random_index, :, i]
            pred = pred_ndarray[random_index, :, i]
            ax.plot(pred, label='Pred')
            ax.plot(true, label='True')
            ax.set_title(f'{name_list[i]}')
            ax.set_xlabel('Time steps')
            ax.set_ylabel('Values')
            ax.grid(True)
            ax.legend()
            print(f'True_{i} and Pred_{i} have been plotted')
    else:
        for i in range(true_ndarray.shape[2]):
            row = i // n_cols
            col = i % n_cols
            ax = axs[row, col]
            true = true_ndarray[random_index, :, i]
            pred = pred_ndarray[random_index, :, i]
            ax.plot(true, label='True')
            ax.plot(pred, label='Pred')
            ax.set_title(f'Dimension {i+1}')
            ax.set_xlabel('Time steps')
            ax.set_ylabel('Values')
            ax.grid(True)
            ax.legend()
            print(f'True_{i} and Pred_{i} have been plotted')

    # 移除多余的子图
    for i in range(true_ndarray.shape[2], n_rows * n_cols):
        row = i // n_cols
        col = i % n_cols
        fig.delaxes(axs[row, col])

    # 调整子图之间的间距
    plt.tight_layout()

    # 显示图形
    # plt.show()
    plt.savefig(result_path.joinpath("true_pred_all_train.png"), dpi=600)


class MatplotlibPlotter(BasePlotter):
    def __init__(self, project_name: str) -> None:
        """Initialize MatplotlibPlotter.

        Args:
            project_name (str): Name of the project
        """
        super().__init__(project_name)
        plt.style.use('ggplot')  # Use seaborn style for better visuals
        
    def plot_train_result(
        self, 
        time_now: str, 
        epoch: int, 
        true_list: list, 
        pred_list: list, 
        save_path: Path
    ) -> None:
        """Plot training results comparing true and predicted values.

        Args:
            time_now (str): Current timestamp
            epoch (int): Current epoch number
            true_list (list): List of true values
            pred_list (list): List of predicted values
            save_path (Path): Path to save the plot
        """
        train_result_fig_png_name = f"train_result_{time_now}_epoch{epoch}.png"
        train_result_fig_png_path = save_path.joinpath(train_result_fig_png_name)
        
        plt.figure(figsize=(16, 9))
        plt.plot(range(len(true_list)), true_list, label='True', linestyle='-')
        plt.plot(range(len(pred_list)), pred_list, label='Predict', linestyle='--')
        plt.title(f"{self.project_name} Training Results", fontsize=14)
        plt.xlabel('Index', fontsize=12)
        plt.ylabel('Value', fontsize=12)
        plt.legend(fontsize=12)
        plt.grid(True)
        plt.tight_layout()
        plt.savefig(train_result_fig_png_path, dpi=600, bbox_inches='tight')
        plt.close()

    def plot_loss(
        self, 
        time_now: str, 
        train_loss_list: list, 
        vali_loss_list: list, 
        save_path: Path
    ) -> None:
        """Plot training and validation loss curves.

        Args:
            time_now (str): Current timestamp
            train_loss_list (list): List of training losses
            vali_loss_list (list): List of validation losses
            save_path (Path): Path to save the plot
        """
        train_loss_fig_png_name = f"train_loss_{time_now}.png"
        train_loss_fig_png_path = save_path.joinpath(train_loss_fig_png_name)
        
        plt.figure(figsize=(16, 9))
        plt.plot(range(len(train_loss_list)), train_loss_list, label='Train Loss', linestyle='-')
        plt.plot(range(len(vali_loss_list)), vali_loss_list, label='Validation Loss', linestyle='--')
        plt.title(f"{self.project_name} Training and Validation Loss", fontsize=14)
        plt.xlabel('Epoch', fontsize=12)
        plt.ylabel('Loss', fontsize=12)
        plt.legend(fontsize=12)
        plt.grid(True)
        plt.tight_layout()
        plt.savefig(train_loss_fig_png_path, dpi=600, bbox_inches='tight')
        plt.close()

    def plot_test_result(
        self, 
        time_now: str, 
        true_list: list, 
        pred_list: list, 
        save_path: Path
    ) -> None:
        """Plot test results comparing true and predicted values.

        Args:
            time_now (str): Current timestamp
            true_list (list): List of true values
            pred_list (list): List of predicted values
            save_path (Path): Path to save the plot
        """
        test_result_fig_png_name = f"test_result_{time_now}.png"
        test_result_fig_png_path = save_path.joinpath(test_result_fig_png_name)
        
        plt.figure(figsize=(16, 9))
        plt.plot(range(len(true_list)), true_list, label='True', linestyle='-')
        plt.plot(range(len(pred_list)), pred_list, label='Predict', linestyle='--')
        plt.title(f"{self.project_name} Test Results", fontsize=14)
        plt.xlabel('Index', fontsize=12)
        plt.ylabel('Value', fontsize=12)
        plt.legend(fontsize=12)
        plt.grid(True)
        plt.tight_layout()
        plt.savefig(test_result_fig_png_path, dpi=600, bbox_inches='tight')
        plt.close()

    def plot_input_curve(
        self, 
        input_df: pl.DataFrame, 
        save_path: Path
    ) -> None:
        """Plot input curves for all features.

        Args:
            input_df (pl.DataFrame): Input DataFrame with DateTime and feature columns
            save_path (Path): Path to save the plot
        """
        input_curve_fig_png_name = "input_curve.png"
        input_curve_fig_png_path = save_path.joinpath(input_curve_fig_png_name)
        
        n_cols = len(input_df.columns) - 1  # Exclude DateTime column
        n_rows = math.ceil(n_cols / 2)
        
        fig, axs = plt.subplots(n_rows, 2, figsize=(16, 6*n_rows))
        fig.suptitle(f'Historical Data Visualization of {self.project_name}', fontsize=16)
        
        # Ensure axs is always 2D
        if n_rows == 1:
            axs = axs.reshape(1, -1)
        
        for i, column in enumerate(input_df.columns[1:]):
            row = i // 2
            col = i % 2
            axs[row, col].plot(range(len(input_df)), input_df[column], linewidth=1)
            axs[row, col].set_title(column, fontsize=12)
            axs[row, col].set_xlabel('DateTime', fontsize=10)
            axs[row, col].set_ylabel('Value', fontsize=10)
            axs[row, col].grid(True)
            
        # Remove empty subplots
        for i in range(n_cols, n_rows * 2):
            row = i // 2
            col = i % 2
            fig.delaxes(axs[row, col])
            
        plt.tight_layout()
        plt.savefig(input_curve_fig_png_path, dpi=600, bbox_inches='tight')
        plt.close()

    def plot_input_boxplot(self, input_df: pl.DataFrame, save_path: Path) -> None:
        """Plot boxplots for input features.

        Args:
            input_df (pl.DataFrame): Input DataFrame
            save_path (Path): Path to save the plot
        """
        plt.figure(figsize=(16, 9))
        plt.boxplot([input_df[col].to_numpy() for col in input_df.columns],
                   labels=input_df.columns,
                   vert=True)
        plt.title(f"{self.project_name} Input Variables Boxplot", fontsize=14)
        plt.xticks(rotation=45, ha='right')
        plt.ylabel('Value', fontsize=12)
        plt.grid(True)
        plt.tight_layout()
        plt.savefig(save_path.joinpath(f"{self.project_name}_input_boxplot.png"), 
                   dpi=600, bbox_inches='tight')
        plt.close()

    def plot_output_boxplot(self, output_df: pl.DataFrame, save_path: Path) -> None:
        """Plot boxplots for output features.

        Args:
            output_df (pl.DataFrame): Output DataFrame
            save_path (Path): Path to save the plot
        """
        plt.figure(figsize=(16, 9))
        plt.boxplot([output_df[col].to_numpy() for col in output_df.columns],
                   labels=output_df.columns,
                   vert=True)
        plt.title(f"{self.project_name} Output Variables Boxplot", fontsize=14)
        plt.xticks(rotation=45, ha='right')
        plt.ylabel('Value', fontsize=12)
        plt.grid(True)
        plt.tight_layout()
        plt.savefig(save_path.joinpath(f"{self.project_name}_output_boxplot.png"), 
                   dpi=600, bbox_inches='tight')
        plt.close()

    def plot_output_curve(self, output_df: pl.DataFrame, save_path: Path) -> None:
        """Plot output curves over time.

        Args:
            output_df (pl.DataFrame): Output DataFrame with DateTime and value columns
            save_path (Path): Path to save the plot
        """
        output_curve_fig_png_name = "output_curve.png"
        output_curve_fig_png_path = save_path.joinpath(output_curve_fig_png_name)
        
        value_column = output_df.columns[-1]
        
        plt.figure(figsize=(16, 9))
        plt.plot(range(len(output_df)), output_df[value_column], linewidth=1)
        plt.title(f'{value_column} Over Time of {self.project_name}', fontsize=14)
        plt.xlabel('Time', fontsize=12)
        plt.ylabel(value_column, fontsize=12)
        plt.grid(True)
        plt.tight_layout()
        plt.savefig(output_curve_fig_png_path, dpi=600, bbox_inches='tight')
        plt.close()
    


