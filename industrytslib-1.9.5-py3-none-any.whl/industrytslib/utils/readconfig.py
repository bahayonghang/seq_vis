import chardet
import toml


def read_config_toml(config_path: str) -> dict:
    """Read configuration of toml file

    Args:
        config_path (str): path of toml file

    Returns:
        dict: configuration
    Examples:
        >>> read_config_toml("config.toml")
        {'a': 1, 'b': 2, 'c': 3}
    """
    # 检测文件编码
    with open(config_path, "rb") as f:
        raw_data = f.read()
        result = chardet.detect(raw_data)
        encoding = result["encoding"]
    with open(config_path, 'r', encoding=encoding) as f:
        config = toml.load(f)
    return config


def read_parameter_toml(config_path: str, project_name: str) -> dict:
    """Read parameter of toml file

    Args:
        config_path (str): path of toml file
        project_name (str): project name

    Returns:
        dict: parameter
    Examples:
        >>> read_parameter_toml("config.toml", "project_name")
        {'a': 1, 'b': 2, 'c': 3}
    """
    with open(config_path, 'r', encoding='utf-8') as file:
        data = toml.load(file)

    # 遍历 data 节点，查找匹配的 project_name 项
    for item in data.get('data', []):
        if item.get('project_name') == project_name:
            return item

    # 如果没有找到匹配项，返回 None
    return None


def read_model_parameter_toml(config_path: str) -> dict:
    """
    Read model parameter from toml file according to project_name

    Args:
        config_path (str): path of toml file

    Returns:
        dict: model parameter
    Examples:
        >>> read_model_parameter_toml("config.toml")
        {'a': 1, 'b': 2, 'c': 3}
    """
    with open(config_path, 'r', encoding='utf-8') as file:
        model_parameter = toml.load(file)

    return model_parameter

