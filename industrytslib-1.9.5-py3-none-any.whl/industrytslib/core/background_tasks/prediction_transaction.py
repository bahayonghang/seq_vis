import time

from industrytslib.utils.database import database_builder
from industrytslib.utils.logutils import get_logger

class PredictionTransaction:
    def __init__(self, config: dict):
        self.logger = get_logger("PredictionTransaction", "database")
        self.source_mssql_client = database_builder(config["mssql"]["predict_transaction_source"])
        self.target_mssql_client = database_builder(config["mssql"]["predict_transaction_target"])

        self.target_mssql_client.check_table_predict_transaction_exist()

        self.predict_table_list = self.source_mssql_client.query_rt_project_list()
    
    def copy_predict_transaction(self):
        """
        复制预测值

        Raises:
            e: 异常
        """
        time_start = time.time()
        self.predict_table_list = self.source_mssql_client.query_rt_project_list()
        for predict_table in self.predict_table_list:
            try:
                latest_record = self.source_mssql_client.query_table_latest_value(predict_table)
                # self.logger.info(f"latest_record: {latest_record}")
                # 如果latest_record为空，则跳过
                if latest_record.is_empty():
                    self.logger.warning(f"latest_record为空,跳过{predict_table}的predict transaction更新")
                    continue
                self.target_mssql_client.update_predict_transaction(predict_table, latest_record)
            except Exception as e:
                self.logger.error(f"Error: {e}")
                raise e
        time_end = time.time()
        self.logger.info(f"predict_transaction表更新完成,用时{time_end - time_start}s!!!")
    
    def main(self):
        self.copy_predict_transaction()
        self.logger.info("============================predict_transaction表更新完成!============================")

    