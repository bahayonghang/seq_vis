import numpy as np
import torch
import torchmetrics


def RSE(pred, true):
    return np.sqrt(np.sum((true - pred) ** 2)) / np.sqrt(np.sum((true - true.mean()) ** 2))


def CORR(pred, true):
    u = ((true - true.mean(0)) * (pred - pred.mean(0))).sum(0)
    d = np.sqrt(((true - true.mean(0)) ** 2 * (pred - pred.mean(0)) ** 2).sum(0))
    return (u / d).mean(-1)


def MAE(pred, true):
    return np.mean(np.abs(pred - true))


def MSE(pred, true):
    return np.mean((pred - true) ** 2)


def RMSE(pred, true):
    return np.sqrt(MSE(pred, true))


def MAPE(pred, true):
    return np.mean(np.abs((pred - true) / true))


def MSPE(pred, true):
    return np.mean(np.square((pred - true) / true))

def abs_error(target: np.ndarray, forecast: np.ndarray) -> float:
    r"""
    .. math::

        abs\_error = sum(|Y - \hat{Y}|)
    """
    return np.sum(np.abs(target - forecast))


def abs_target_sum(target: np.ndarray) -> float:
    r"""
    .. math::

        abs\_target\_sum = sum(|Y|)
    """
    return np.sum(np.abs(target))


def abs_target_mean(target: np.ndarray) -> float:
    r"""
    .. math::

        abs\_target\_mean = mean(|Y|)
    """
    return np.mean(np.abs(target))


# def metric(pred, true):
#     mae = MAE(pred, true)
#     mse = MSE(pred, true)
#     rmse = RMSE(pred, true)
#     mape = MAPE(pred, true)
#     mspe = MSPE(pred, true)

#     return mae, mse, rmse, mape, mspe


def metric_classic(pred: torch.Tensor, true: torch.Tensor) -> tuple:
    """
    计算预测值与实际值之间的多种评估指标。
    
    Args:
        pred (torch.Tensor): 预测值的张量，形状为 (batch_size, *)。
        true (torch.Tensor): 实际值的张量，形状与 pred 相同。
    
    Returns:
        tuple: 包含五个评估指标值的元组，分别是：
        - mae (float): 平均绝对误差。
        - mse (float): 平均平方误差。
        - rmse (float): 均方根误差(Root Mean Squared Error)。
        - mape (float): 平均绝对百分比误差(Mean Absolute Percentage Error)。
        - mspe (float): 平均平方百分比误差(Mean Squared Percentage Error)。
        - r2 (float): 决定系数R2 score(R^2 score)
    """
    mae = torchmetrics.MeanAbsoluteError()
    mse = torchmetrics.MeanSquaredError()
    rmse = torchmetrics.MeanSquaredError(squared=False)
    mape = torchmetrics.MeanAbsolutePercentageError()
    mspe = torchmetrics.MeanSquaredLogError()
    r2 = torchmetrics.R2Score()

    mae_value = mae(pred, true).item()
    mse_value = mse(pred, true).item()
    rmse_value = rmse(pred, true).item()
    mape_value = mape(pred, true).item()
    mspe_value = mspe(pred, true).item()
    r2_value = r2(pred.squeeze(), true.squeeze()).item()

    return mae_value, mse_value, rmse_value, mape_value, mspe_value, r2_value


def metric_sequence(pred: torch.Tensor, true: torch.Tensor) -> tuple:
        """
        计算预测值与实际值之间的多种评估指标。
        
        Args:
            pred (torch.Tensor): 预测值的张量，形状为 (batch_size, *)。
            true (torch.Tensor): 实际值的张量，形状与 pred 相同。
        
        Returns:
            tuple: 包含五个评估指标值的元组，分别是：
            - mae (float): 平均绝对误差。
            - mse (float): 平均平方误差。
            - rmse (float): 均方根误差(Root Mean Squared Error)。
            - mape (float): 平均绝对百分比误差(Mean Absolute Percentage Error)。
            - mspe (float): 平均平方百分比误差(Mean Squared Percentage Error)。
            - r2 (float): 决定系数R2 score(R^2 score)
        """
        mae = torchmetrics.MeanAbsoluteError()
        mse = torchmetrics.MeanSquaredError()
        rmse = torchmetrics.MeanSquaredError(squared=False)
        mape = torchmetrics.MeanAbsolutePercentageError()
        mspe = torchmetrics.MeanSquaredLogError()

        mae_value = mae(pred, true).item()
        mse_value = mse(pred, true).item()
        rmse_value = rmse(pred, true).item()
        mape_value = mape(pred, true).item()
        mspe_value = mspe(pred, true).item()

        return mae_value, mse_value, rmse_value, mape_value, mspe_value


def metric_sequence_alter(pred: torch.Tensor, true: torch.Tensor) -> tuple:
        """
        计算预测值与实际值之间的多种评估指标。
        
        Args:
            pred (torch.Tensor): 预测值的张量，形状为 (batch_size, *)。
            true (torch.Tensor): 实际值的张量，形状与 pred 相同。
        
        Returns:
            tuple: 包含五个评估指标值的元组，分别是：
            - mae (float): 平均绝对误差。
            - mse (float): 平均平方误差。
            - rmse (float): 均方根误差(Root Mean Squared Error)。
            - mape (float): 平均绝对百分比误差(Mean Absolute Percentage Error)。
            - mspe (float): 平均平方百分比误差(Mean Squared Percentage Error)。
            - r2 (float): 决定系数R2 score(R^2 score)
        """
        mae = torchmetrics.MeanAbsoluteError()
        mse = torchmetrics.MeanSquaredError()
        rmse = torchmetrics.MeanSquaredError(squared=False)
        mape = torchmetrics.MeanAbsolutePercentageError()
        mspe = torchmetrics.MeanSquaredLogError()

        mae_value = mae(pred, true).item()
        mse_value = mse(pred, true).item()
        rmse_value = rmse(pred, true).item()
        mape_value = mape(pred, true).item()
        mspe_value = mspe(pred, true).item()

        nmae_value = mae_value / abs_target_sum(true.numpy())
        nrmse_value = rmse_value / abs_target_mean(true.numpy())

        return mae_value, mse_value, rmse_value, mape_value, mspe_value, nmae_value, nrmse_value
