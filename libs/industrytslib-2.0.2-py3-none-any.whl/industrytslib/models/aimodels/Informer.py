import torch
import torch.nn as nn
import torch.nn.functional as F

from industrytslib.models.aimodels.utils.masking import TriangularCausalMask, ProbMask
from industrytslib.models.aimodels.layers.encoder import (
    Encoder, EncoderLayer, ConvLayer, EncoderStack, EncoderAlter
)
from industrytslib.models.aimodels.layers.decoder import (
    Decoder, DecoderLayer, DecoderAlter, DecoderLayerAlter
)
from industrytslib.models.aimodels.layers.attn import (
    FullAttention, ProbAttention, AttentionLayer, 
    ProbAttentionAlter, DynamicAttentionLayer
    )
from industrytslib.models.aimodels.layers.Embed import DataEmbedding
from industrytslib.models.aimodels.layers.RevIN import RevIN

# class Informer(nn.Module):
#     def __init__(self, model_parameter: dict):
#         super(Informer, self).__init__()
#         """
#         :param enc_in: the size of input data
#         :param dec_in: the size of output data
#         :param c_out: the size of output data
#         :param seq_len: the length of input sequence
#         :param label_len: the length of label sequence
#         :param out_len: the length of output sequence
#         :param factor: the factor used in the model, default 5
#         :param d_model: the size of the model, default 512
#         :param n_heads: the number of heads in the model, default 8
#         :param e_layers: the number of encoder layers, default 3
#         :param d_layers: the number of decoder layers, default 2
#         :param d_ff: the size of feed forward layer, default 512
#         :param dropout: the dropout rate, default 0.0
#         :param output_attention: whether output the attention, default False
#         :param activation: the activation function, default 'gelu'
#         :param distil: whether use distilling in encoder, default True
#         """
#         self.enc_in: int = model_parameter["enc_in"]
#         self.dec_in: int = model_parameter["dec_in"]
#         self.c_out: int = model_parameter["c_out"]
#         self.seq_len: int = model_parameter["seq_len"]
#         self.label_len: int = model_parameter["label_len"]
#         self.pred_len: int = model_parameter["pred_len"]
#         self.factor: int = model_parameter["factor"]
#         self.d_model: int = model_parameter["d_model"]
#         self.n_heads: int = model_parameter["n_heads"]
#         self.e_layers: int = model_parameter["e_layers"]
#         self.d_layers: int = model_parameter["d_layers"]
#         self.d_ff: int = model_parameter["d_ff"]
#         self.dropout: float = model_parameter["dropout"]
#         self.output_attention: bool = model_parameter["output_attention"]
#         self.activation: str = model_parameter["activation"]
#         self.distil: bool = model_parameter["distil"]

#         # Encoding
#         self.enc_embedding = DataEmbedding(self.enc_in, self.d_model)
#         self.dec_embedding = DataEmbedding(self.dec_in, self.d_model)
#         # Attention
#         Attn = ProbAttention
#         # Encoder
#         self.encoder = Encoder(
#             [
#                 EncoderLayer(
#                     AttentionLayer(Attn(False, self.factor, attention_dropout=self.dropout, output_attention=self.output_attention),
#                                    self.d_model, self.n_heads, mix=False),
#                     self.d_model,
#                     self.d_ff,
#                     dropout=self.dropout,
#                     activation=self.activation
#                 ) for layer_idx in range(self.e_layers)
#             ],
#             [
#                 ConvLayer(
#                     self.d_model
#                 ) for layer_idx in range(self.e_layers - 1)
#             ] if self.distil else None,
#             norm_layer=torch.nn.LayerNorm(self.d_model)
#         )
#         # Decoder
#         self.decoder = Decoder(
#             [
#                 DecoderLayer(
#                     AttentionLayer(Attn(True, self.factor, attention_dropout=self.dropout, output_attention=False),
#                                    self.d_model, self.n_heads, mix=False),
#                     AttentionLayer(FullAttention(False, self.factor, attention_dropout=self.dropout, output_attention=False),
#                                    self.d_model, self.n_heads, mix=False),
#                     self.d_model,
#                     self.d_ff,
#                     dropout=self.dropout,
#                     activation=self.activation,
#                 )
#                 for layer_idx in range(self.d_layers)  # Changed variable name from 'l' to 'layer_idx'
#             ],
#             norm_layer=torch.nn.LayerNorm(self.d_model)
#         )
#         # self.end_conv1 = nn.Conv1d(in_channels=label_len+out_len, out_channels=out_len, kernel_size=1, bias=True)
#         # self.end_conv2 = nn.Conv1d(in_channels=d_model, out_channels=c_out, kernel_size=1, bias=True)
#         self.projection = nn.Linear(self.d_model, self.c_out, bias=True)

#     def forward(self, x_enc,  x_dec,
#                 enc_self_mask=None, dec_self_mask=None, dec_enc_mask=None):
#         enc_out = self.enc_embedding(x_enc)
#         enc_out, attns = self.encoder(enc_out, attn_mask=enc_self_mask)

#         dec_out = self.dec_embedding(x_dec)
#         dec_out = self.decoder(dec_out, enc_out, x_mask=dec_self_mask, cross_mask=dec_enc_mask)
#         dec_out = self.projection(dec_out)

#         # dec_out = self.end_conv1(dec_out)
#         # dec_out = self.end_conv2(dec_out.transpose(2,1)).transpose(1,2)
#         if self.output_attention:
#             return dec_out[:, -self.pred_len:, :], attns
#         else:
#             return dec_out[:, -self.pred_len:, :]  # [B, L, D]


# class Informer(nn.Module):
#     def __init__(self, enc_in, dec_in, c_out, seq_len, label_len, pred_len,
#                  factor=5, d_model=512, n_heads=8, e_layers=3, d_layers=2, d_ff=512,
#                  dropout=0.0, attn='prob', embed='fixed', freq='h', activation='gelu',
#                  output_attention=False, distil=True, mix=True,
#                  device=torch.device('cuda:0')):
#         super(Informer, self).__init__()
#         self.pred_len = pred_len    
#         self.output_attention = output_attention

#         # Encoding
#         self.enc_embedding = DataEmbedding(enc_in, d_model, embed, freq, dropout)
#         self.dec_embedding = DataEmbedding(dec_in, d_model, embed, freq, dropout)
#         # Attention
#         Attn = ProbAttention if attn == 'prob' else FullAttention
#         # Encoder
#         self.encoder = Encoder(
#             [
#                 EncoderLayer(
#                     AttentionLayer(Attn(False, factor, attention_dropout=dropout, output_attention=output_attention),
#                                    d_model, n_heads, mix=False),
#                     d_model,
#                     d_ff,
#                     dropout=dropout,
#                     activation=activation
#                 ) for _ in range(e_layers)
#             ],
#             [
#                 ConvLayer(
#                     d_model
#                 ) for _ in range(e_layers - 1)
#             ] if distil else None,
#             norm_layer=torch.nn.LayerNorm(d_model)
#         )
#         # Decoder
#         self.decoder = Decoder(
#             [
#                 DecoderLayer(
#                     AttentionLayer(Attn(True, factor, attention_dropout=dropout, output_attention=False),
#                                    d_model, n_heads, mix=mix),
#                     AttentionLayer(FullAttention(False, factor, attention_dropout=dropout, output_attention=False),
#                                    d_model, n_heads, mix=False),
#                     d_model,
#                     d_ff,
#                     dropout=dropout,
#                     activation=activation,
#                 )
#                 for _ in range(d_layers)
#             ],
#             norm_layer=torch.nn.LayerNorm(d_model)
#         )
#         # self.end_conv1 = nn.Conv1d(in_channels=label_len+out_len, out_channels=out_len, kernel_size=1, bias=True)
#         # self.end_conv2 = nn.Conv1d(in_channels=d_model, out_channels=c_out, kernel_size=1, bias=True)
#         self.projection = nn.Linear(d_model, c_out, bias=True)

#     def forward(self, x_enc, x_mark_enc, x_dec, x_mark_dec,
#                 enc_self_mask=None, dec_self_mask=None, dec_enc_mask=None):
#         enc_out = self.enc_embedding(x_enc, x_mark_enc)
#         enc_out, attns = self.encoder(enc_out, attn_mask=enc_self_mask)
#         dec_out = self.dec_embedding(x_dec, x_mark_dec)
#         dec_out = self.decoder(dec_out, enc_out, x_mask=dec_self_mask, cross_mask=dec_enc_mask)
#         dec_out = self.projection(dec_out)

#         # dec_out = self.end_conv1(dec_out)
#         # dec_out = self.end_conv2(dec_out.transpose(2,1)).transpose(1,2)
#         if self.output_attention:
#             return dec_out[:, -self.pred_len:, :], attns
#         else:
#             return dec_out[:, -self.pred_len:, :]  # [B, L, D]


class Informer(nn.Module):
    """
    Informer with Propspare attention in O(LlogL) complexity
    Paper link: https://ojs.aaai.org/index.php/AAAI/article/view/17325/17132
    """

    def __init__(self, configs):
        super(Informer, self).__init__()
        self.configs = configs
        if self.configs.revin==1:
            self.revin_layer_in = RevIN(self.configs.enc_in)
            self.revin_layer_out = RevIN(self.configs.dec_in)

        self.pred_len = self.configs.pred_len
        self.label_len = self.configs.label_len

        if self.configs.channel_independence:
            self.enc_in = 1
            self.dec_in = 1
            self.c_out = 1
        else:
            self.enc_in = self.configs.enc_in
            self.dec_in = self.configs.dec_in
            self.c_out = self.configs.c_out

        # Embedding
        self.enc_embedding = DataEmbedding(self.enc_in, self.configs.d_model, self.configs.embed, self.configs.freq,
                                           self.configs.dropout)
        self.dec_embedding = DataEmbedding(self.dec_in, self.configs.d_model, self.configs.embed, self.configs.freq,
                                           self.configs.dropout)

        # Encoder
        self.encoder = Encoder(
            [
                EncoderLayer(
                    AttentionLayer(
                        ProbAttention(
                            False, self.configs.factor, attention_dropout=self.configs.dropout,
                            output_attention=self.configs.output_attention
                        ),
                        self.configs.d_model, self.configs.n_heads
                    ),
                    self.configs.d_model,
                    self.configs.d_ff,
                    dropout=self.configs.dropout,
                    activation=self.configs.activation
                ) for l in range(self.configs.e_layers)
            ],
            [
                ConvLayer(
                    self.configs.d_model
                ) for l in range(self.configs.e_layers - 1)
            ] if self.configs.distil else None,
            norm_layer=torch.nn.LayerNorm(self.configs.d_model)
        )
        # Decoder
        self.decoder = Decoder(
            [
                DecoderLayer(
                    AttentionLayer(
                        ProbAttention(
                            True, self.configs.factor, attention_dropout=self.configs.dropout, 
                            output_attention=False
                        ),
                        self.configs.d_model, self.configs.n_heads
                    ),
                    AttentionLayer(
                        FullAttention(
                            False, self.configs.factor, attention_dropout=self.configs.dropout,
                            output_attention=False
                        ),
                        self.configs.d_model, self.configs.n_heads
                    ),
                    self.configs.d_model,
                    self.configs.d_ff,
                    dropout=self.configs.dropout,
                    activation=self.configs.activation,
                )
                for l in range(self.configs.d_layers)
            ],
            norm_layer=torch.nn.LayerNorm(self.configs.d_model),
            projection=nn.Linear(self.configs.d_model, self.configs.c_out, bias=True)
        )


    def long_forecast(self, x_enc, x_mark_enc, x_dec, x_mark_dec):
        if self.configs.revin==1:
            x_enc = self.revin_layer_in(x_enc, mode="norm")
            x_dec = self.revin_layer_out(x_dec, mode="norm")
        enc_out = self.enc_embedding(x_enc, x_mark_enc)
        dec_out = self.dec_embedding(x_dec, x_mark_dec)
        enc_out, attns = self.encoder(enc_out, attn_mask=None)

        dec_out = self.decoder(dec_out, enc_out, x_mask=None, cross_mask=None)

        if self.configs.revin==1:
            dec_out = self.revin_layer_out(dec_out, mode="denorm")

        return dec_out  # [B, L, D]


    def forward(self, x_enc, x_mark_enc, x_dec, x_mark_dec, mask=None):
        # print(f"x_enc: {x_enc.shape}, x_mark_enc: {x_mark_enc.shape}, x_dec: {x_dec.shape}, x_mark_dec: {x_mark_dec.shape}")
        dec_out = self.long_forecast(x_enc, x_mark_enc, x_dec, x_mark_dec)
        return dec_out[:, -self.pred_len:, :]  # [B, L, D]


class InformerAlter(nn.Module):
    """
    Informer with Propspare attention in O(LlogL) complexity
    Paper link: https://ojs.aaai.org/index.php/AAAI/article/view/17325/17132
    """

    def __init__(self, configs):
        super(InformerAlter, self).__init__()
        self.configs = configs
        if self.configs.revin==1:
            self.revin_layer_in = RevIN(self.configs.enc_in)
            self.revin_layer_out = RevIN(self.configs.dec_in)

        self.pred_len = self.configs.pred_len
        self.label_len = self.configs.label_len

        if self.configs.channel_independence:
            self.enc_in = 1
            self.dec_in = 1
            self.c_out = 1
        else:
            self.enc_in = self.configs.enc_in
            self.dec_in = self.configs.dec_in
            self.c_out = self.configs.c_out

        # Embedding
        self.enc_embedding = DataEmbedding(self.enc_in, self.configs.d_model, self.configs.embed, self.configs.freq,
                                           self.configs.dropout)
        self.dec_embedding = DataEmbedding(self.dec_in, self.configs.d_model, self.configs.embed, self.configs.freq,
                                           self.configs.dropout)

        # Encoder
        self.encoder = EncoderAlter(
            [
                EncoderLayer(
                    DynamicAttentionLayer(
                        ProbAttentionAlter(
                            False, self.configs.factor, attention_dropout=self.configs.dropout,
                            output_attention=self.configs.output_attention
                        ),
                        self.configs.d_model, self.configs.n_heads
                    ),
                    self.configs.d_model,
                    self.configs.d_ff,
                    dropout=self.configs.dropout,
                    activation=self.configs.activation
                ) for l in range(self.configs.e_layers)
            ],
            [
                ConvLayer(
                    self.configs.d_model
                ) for l in range(self.configs.e_layers - 1)
            ] if self.configs.distil else None,
            norm_layer=torch.nn.LayerNorm(self.configs.d_model)
        )
        # Decoder
        self.decoder = DecoderAlter(
            [
                DecoderLayerAlter(
                    DynamicAttentionLayer(
                        ProbAttentionAlter(
                            True, self.configs.factor, attention_dropout=self.configs.dropout, 
                            output_attention=False
                        ),
                        self.configs.d_model, self.configs.n_heads
                    ),
                    AttentionLayer(
                        FullAttention(
                            False, self.configs.factor, attention_dropout=self.configs.dropout,
                            output_attention=False
                        ),
                        self.configs.d_model, self.configs.n_heads
                    ),
                    self.configs.d_model,
                    self.configs.d_ff,
                    dropout=self.configs.dropout,
                    activation=self.configs.activation,
                )
                for l in range(self.configs.d_layers)
            ],
            norm_layer=torch.nn.LayerNorm(self.configs.d_model),
            projection=nn.Linear(self.configs.d_model, self.configs.c_out, bias=True)
        )


    def long_forecast(self, x_enc, x_mark_enc, x_dec, x_mark_dec):
        if self.configs.revin==1:
            x_enc = self.revin_layer_in(x_enc, mode="norm")
            x_dec = self.revin_layer_out(x_dec, mode="norm")
        enc_out = self.enc_embedding(x_enc, x_mark_enc)
        dec_out = self.dec_embedding(x_dec, x_mark_dec)
        enc_out, attns = self.encoder(enc_out, attn_mask=None)

        dec_out = self.decoder(dec_out, enc_out, x_mask=None, cross_mask=None)

        if self.configs.revin==1:
            dec_out = self.revin_layer_out(dec_out, mode="denorm")

        return dec_out  # [B, L, D]


    def forward(self, x_enc, x_mark_enc, x_dec, x_mark_dec, mask=None):
        # print(f"x_enc: {x_enc.shape}, x_mark_enc: {x_mark_enc.shape}, x_dec: {x_dec.shape}, x_mark_dec: {x_mark_dec.shape}")
        dec_out = self.long_forecast(x_enc, x_mark_enc, x_dec, x_mark_dec)
        return dec_out[:, -self.pred_len:, :]  # [B, L, D]