import datetime
import torch
import pickle
import pyodbc
import time
import polars as pl

from pathlib import Path

# from apscheduler.schedulers.background import BackgroundScheduler

from industrytslib.models.aimodels import build_model
from industrytslib.utils.database import database_builder
from industrytslib.utils.data_processing.polarsoperation import check_device_status, calculate_minute_average
from industrytslib.core.base import (
    ScheduledTask, TrueValueError, TransformInputError, UpdateDatabaseError,
    PredictError, UpdatePredictValueError)
from industrytslib.utils.readconfig import read_model_parameter_toml
from industrytslib.utils.basefunc import split_sample_and_model, name_list_parser
from industrytslib.utils.logutils import get_logger

from industrytslib.utils.share.reader import ReadDataframe


class RealtimePredictorAll(ScheduledTask):
    """
    RealtimePredictor is a class for realtime prediction 
    of electricity consumption/coal consumption and quality index. 
    including 0(soft sensor)、3、5、30 mins prediction
    """
    def __init__(self, project_name: str, dbconfig: dict) -> None:
        super().__init__(project_name, dbconfig)
        self.task_type = "realtime_predict"
        self.project_name = project_name
        self.update_flag = True  # flag to indicate whether to update the database, default is True
        self.logger = get_logger(self.project_name, self.task_type)
        self.read_dataframe = ReadDataframe()

        # database connections based on dbconfig
        self.web_db_client = database_builder(dbconfig["mssql"]["web"])
        self.ts_db_client = database_builder(dbconfig["mssql"]["timeseries"])
        self.realtime_db_client = database_builder(dbconfig["mssql"]["realtimepredict"])  # ! 新的rt使用realtimepredict_alter

        # check realtime predict table existence in database
        self.realtime_db_client.check_table(self.project_name)

        # Get all project names for realtime predict
        # besides the project name in list is set as key in vars dictionary
        self.project_name_list = []
        suffix_list = ["", "_pred3", "_pred5", "_pred30"]  # ! 新的rt使用[""]
        for suffix in suffix_list:
            self.project_name_list.append(self.project_name + suffix)
        self.logger.info(f"All project names for realtime predict: {self.project_name_list}")
        
        try:
            self.sample_name, self.model_name = self.web_db_client.get_prediction_info(self.project_name)
        except Exception as e:
            self.logger.error(f"Get the sample name and model name of {self.project_name} \
                              from web database failed: {e}")
            self.logger.info("使用本地信息!!!")
            self.sample_name, self.model_name = split_sample_and_model(self.project_name)
        self.sample_table_in_name = self.sample_name + "_in"  # input table(view) name
        self.sample_table_out_name = self.sample_name + "_out"  # output table(view) name

        # init sample name dictionary, algorithm name dictionary, sample table dictionary, 
        # model parameter dictionary, model dictionary
        self.sample_name_dict = {}  # project_name对应的样本表名称
        self.model_name_dict = {}  # project_name对应的模型名称
        self.algorithm_name_dict = {}  # project_name对应的算法名称
        self.model_parameter_dict = {}  # project_name对应的模型参数
        self.model_dict = {}  # project_name对应的模型
        self.sample_table_in_name_dict = {}  # project_name对应的输入样本表名称
        self.sample_table_out_name_dict = {}  # project_name对应的输出样本表名称
        self.scaler_x_dict = {}  # project_name对应的输入归一化参数
        self.scaler_y_dict = {}  # project_name对应的输出归一化参数
        self.pred_len_str_dict = {}  # project_name对应的预测长度字符串
        self.pred_time_dict = {}  # project_name对应的预测时间
        
        self.get_basic_info()

        self.logger.info(f"{self.project_name_list} 的预测信息获取完毕, 可以进行实时预测!!!")
    
    def cleanup(self) -> None:
        # close the database connection
        self.web_db_client.close()
        self.ts_db_client.close()
        self.realtime_db_client.close()
        self.output_db_client.close()
        self.logger.info(f"{self.project_name_list} 的实时预测任务结束, 数据库连接关闭!!!")

    def db_reconnect(self) -> None:
        self.logger.warning(f"{self.project_name}数据库连接断开，尝试重新连接...")
        self.web_db_client.connect_db()
        self.ts_db_client.connect_db()
        self.realtime_db_client.connect_db()
        self.output_db_client.connect_db()

    def get_basic_info(self) -> None:
        """
        Get basic information of each project
        """
        for project_name in self.project_name_list:
            self.logger.info(f"正在获取{project_name}的基本信息...")
            # Get sample name and model name
            try:
                sample_name, model_name = self.web_db_client.get_prediction_info(project_name)
            except Exception as e:
                self.logger.error(f"Get the sample name and model name of {project_name} from web database failed: {e}")
                self.logger.info("使用本地信息!!!")
                sample_name, model_name = split_sample_and_model(project_name)
            self.sample_name_dict[project_name] = sample_name
            self.model_name_dict[project_name] = model_name
            self.logger.info(f"{project_name}的样本名称：{sample_name}，模型名称：{model_name}")

            # Get sample table in name and sample table out name
            sample_table_in_name = sample_name + "_in"
            sample_table_out_name = sample_name + "_out"
            self.sample_table_in_name_dict[project_name] = sample_table_in_name
            self.sample_table_out_name_dict[project_name] = sample_table_out_name
            self.logger.info(f"{project_name}的输入样本表名称：{sample_table_in_name}，\
                             输出样本表名称：{sample_table_out_name}")
            # Get model parameter
            # If local model parameter exists, then read local model parameter,
            # else read from web database
            model_parameter_path = Path(f"resource/model_parameter/{model_name}/model_config.toml")
            if model_parameter_path.exists():
                self.logger.info(f"读取本地模型参数: {model_parameter_path}")
                self.model_parameter_dict[project_name] = read_model_parameter_toml(model_parameter_path)
                self.algorithm_name_dict[project_name] = self.model_parameter_dict[project_name]["algorithm_name"]
            else:
                self.logger.info(f"从数据库{self.web_db_client.database}读取在线模型参数")
                self.algorithm_name_dict[project_name], self.model_parameter_dict[project_name] = \
                    self.web_db_client.get_model_parameter(model_name)
            self.logger.info(f"""
            {project_name}的算法名称：{self.algorithm_name_dict[project_name]},
            模型参数：{self.model_parameter_dict[project_name]}
            """)

            # initialize model
            model_path = Path("resource", "models", project_name, "checkpoint.pth")
            model = build_model(self.algorithm_name_dict[project_name], self.model_parameter_dict[project_name])
            model.load_state_dict(torch.load(model_path, map_location=self.device, weights_only=True))
            model.to(self.device)
            self.model_dict[project_name] = model
            self.logger.info(f"{project_name}的模型初始化完毕")
            # load the normalization parameter
            scaler_x_path = Path("resource", "scaler", project_name, "scaler_x.pkl")
            scaler_y_path = Path("resource", "scaler", project_name, "scaler_y.pkl")
            with open(scaler_x_path, "rb") as f:
                self.scaler_x_dict[project_name] = pickle.load(f)
            with open(scaler_y_path, "rb") as f:
                self.scaler_y_dict[project_name] = pickle.load(f)

            # get the prediction length and prediction time
            self.pred_len_str_dict[project_name] = \
                str(self.model_parameter_dict[project_name]["pred_len"]) + "分钟预测值"
            self.pred_time_dict[project_name] = \
                self.model_parameter_dict[project_name]["pred_len"] * datetime.timedelta(minutes=1)
            self.logger.info(f"""
            {project_name}的预测长度字符串：{self.pred_len_str_dict[project_name]}，
            预测时间：{self.pred_time_dict[project_name]}
            """)
        self.logger.info("所有项目的基本信息获取完毕，可以进行实时预测!!!")

        # 根据模型参数创建输出数据库连接
        try:
            match self.model_parameter_dict[project_name]["output_flag"]:
                case "control":
                    self.output_flag = "control"
                    self.output_db_client = self.ts_db_client
                case "quality":
                    self.output_flag = "quality"
                    self.output_db_client = database_builder(self.dbconfig["mssql"]["quality"])
                    self.logger.info(f"{self.project_name}的输出数据库为质量数据库")
                case _:
                    raise ValueError("请检查模型参数中的output_flag是否正确!!!")
        except KeyError as e:
            self.logger.error(f"模型参数中没有output_flag,默认设置为control: {e}")
            self.output_flag = "control"
            self.output_db_client = self.ts_db_client

        # Determine whether real-time prediction is required based on datetime
        self.datetime_past = datetime.datetime.now()

        # feed amount column_name 
        self.feed_amount_column_name: str | list[str] = self.ts_db_client.get_feed_amount_column_name(self.sample_table_in_name)
        self.logger.info(f"{self.project_name}的喂料量列名：{self.feed_amount_column_name}")
        self.get_var_name_list()

    def get_var_name_list(self) -> None:
        """
        Get the input name list and output name list
        """
        # get sample table information
        try:
            self.sample_table_information = self.web_db_client.get_sample_table_information(self.sample_name)
        except Exception as e:
            self.logger.error(f"Get sample table information from web mssql database failed: {e}")
            self.logger.error(f"Please check the sample name {self.sample_name} in web mssql database!!!")
            raise e
        
        # get input name list(input variable name list)  
        try:
            input_name_str = self.sample_table_information["column_namein"][0]
            self.input_name_list = name_list_parser(input_name_str)
            self.logger.info(f"""
                             Get input name list from sample table information successfully:{self.input_name_list}
                            """)
        except Exception as e:
            self.logger.error(f"Get input name list from sample table information failed: {e}")
            self.logger.error(f"Please check the sample table information of {self.sample_name}!!!")
            raise e
        
        # get output name list(output variable name list)
        try:
            output_name_str = self.sample_table_information["column_nameout"][0]
            self.output_name_list = name_list_parser(output_name_str)
            self.logger.info(f"""
                             Get output name list from sample table information successfully:
                             {self.output_name_list}
                            """)
        except Exception as e:
            self.logger.error(f"Get output name list from sample table information failed: {e}")
            self.logger.error(f"Please check the sample table information of {self.sample_name}!!!")
            raise e
        
        # 从样本信息中获取当前设备在TagDatabase运行标志位
        try:
            self.device_operation_flag: str = self.sample_table_information["operationflag"].item()
            self.logger.info(f"{self.project_name}在TagDatabase的运行标志位为: {self.device_operation_flag}")
            # 彩色打印运行标志位信息
            print(f"\033[1;34m================{self.project_name}运行标志位：{self.device_operation_flag}=================\033[0m")
        except Exception as e:
            self.logger.error(f"Get device operation flag from sample table information failed: {e}")
            self.logger.error(f"Please check the sample table information of {self.sample_name}!!!")
            # raise e
            self.device_operation_flag = None
        
    def query_history_data(self) -> tuple[datetime.datetime, pl.DataFrame]:
        # Main realtime prediction pipeline
        current_time = datetime.datetime.now()
        current_time = current_time.replace(second=0, microsecond=0)

        # Get the latest input data from database
        try:
            pred_input = self.ts_db_client.get_latest_input_data_by_column_time(
                    self.input_name_list,
                    self.model_parameter_dict[self.project_name]["x_length"]
                )
        except Exception as e:
            self.logger.error(f"Get the latest input data from database failed: {e}")
            # raise InputDataError(f"Error: {e}")
            return 
        
        # 检测输入数据是否为空
        if pred_input.is_empty():
            self.logger.warning(f"当前时间{current_time}项目{self.project_name}输入数据为空，跳过实时预测!!!")
            self.logger.warning("=================请检查数据库和数据采集软件工作是否正常!!!=================")
            return
            
        # 输入数据预处理
        # 分钟均值
        self.logger.debug(f"before calculate_minute_average: {pred_input}")
        pred_input = calculate_minute_average(pred_input)
        pred_input = pred_input.tail(self.model_parameter_dict[self.project_name]["x_length"])
        self.logger.debug(f"after calculate_minute_average: {pred_input}")

        return current_time, pred_input
    
    def rt_all(self, current_time:datetime.datetime, pred_input:pl.DataFrame) -> None:
        # judge if the device is running
        device_status = check_device_status(pred_input, self.feed_amount_column_name)
        # if device is running, then start realtime predict
        if device_status:
            # Get the latest true value from database
            try:
                true_df = self.output_db_client.get_latest_true_value(self.sample_table_out_name)
                true_series_list = [true_df[col] for col in true_df.columns]
                true_data = [series.item() for series in true_series_list]
                # true_time is the time of the latest true value
                true_time, true_value = true_data[0], true_data[1]  
                self.logger.info(f"{self.project_name} 最新真实值时间：{true_time}，最新真实值：{true_value}")
            except Exception as e:
                raise TrueValueError(f"Error: {e}")

            # Update the latest true value into the database according to the current_time format
            try:
                if isinstance(true_time, datetime.datetime):
                    true_time = true_time.replace(second=0, microsecond=0)
                    self.realtime_db_client.update_realvalue_control(
                        table_name=self.project_name, 
                        realvalue=true_value, 
                        time_real=true_time
                    )
                else:
                    latest_true_quality = self.output_db_client.get_latest_true_value_quality_rt(
                        self.sample_table_out_name
                    )
                    assert len(latest_true_quality) > 0, "质检库中没有数据,请检查质检取数程序是否正常工作!!!"
                    self.realtime_db_client.update_realvalue_quality(
                        table_name=self.project_name, 
                        quality_real=latest_true_quality
                    )
                    # 将true_time转换为datetime格式
                    true_time = current_time
            except pyodbc.Error as e:
                self.logger.error(
                    f"{self.project_name} update realtime value counters database failure {e}, \
                        please check realtime predict database status!!!")
                # self.realtime_db_client.connect_db()
                raise UpdateDatabaseError(f"Error: {e}")
            except Exception as e:
                raise UpdateDatabaseError(f"Error: {e}")
            
            # Transform pred_input into torch
            try:
                pred_input = pred_input[:, 1:]  # 去除时间列
                pred_input = self.scaler_x_dict[self.project_name].transform(pred_input)  # 将输入数据进行归一化
                pred_input = torch.tensor(pred_input).unsqueeze(0).float().to(self.device)
            except Exception as e:
                raise TransformInputError(f"Error: {e}")

            # 循环计算每一个模型实时预测值，并写入数据库
            for project_name in self.project_name_list:
                # # 根据每个模型的x_length，获取最新的x_length个数据
                # try:
                #     query_start_time = time.time()
                #     pred_input = self.ts_db_client.get_latest_input_data_by_column_time(
                #         self.input_name_list, self.model_parameter_dict[project_name]["x_length"]
                #     )
                #     query_end_time = time.time()
                #     print(f"当前时间{current_time}实时预测任务查询输入数据耗时{query_end_time - query_start_time}秒")
                #     assert pred_input.shape[0] == self.model_parameter_dict[project_name]["x_length"], \
                #         f"Error: {project_name}的输入数据维度不正确，应为{self.model_parameter_dict[project_name]\
                #                                              ['x_length']}，实际为{pred_input.shape[0]}!!!"
                # except Exception as e:
                #     self.logger.error(f"查询{project_name}的最新输入数据失败: {e},请检查服务器数据库连接!!!")
                #     raise InputDataError(f"Error: {e}")

                # # Transform the pred_input and true_value into the format of model input
                # # Transform pred_input into torch
                # try:
                #     pred_input = pred_input[:, 1:]  # 去除时间列
                #     pred_input = self.scaler_x_dict[self.project_name].transform(pred_input)  # 将输入数据进行归一化
                #     pred_input = torch.tensor(pred_input).unsqueeze(0).float().to(self.device)
                # except Exception as e:
                #     raise TransformInputError(f"Error: {e}")
                
                # running realtime predict using self.model
                try:
                    with torch.no_grad():
                        pred_value = self.model_dict[project_name](pred_input)  # 将pred_input送入模型进行预测
                    pred_value = self.scaler_y_dict[project_name].inverse_transform(\
                        pred_value.reshape(-1, 1).to(torch.device("cpu")))  # 将预测值进行反归一化
                    time_predict = true_time + self.pred_time_dict[project_name]  # 当前预测值对应的时间
                    time_predict = time_predict.strftime("%Y-%m-%d %H:%M:%S")  # 将时间格式转换为字符串
                    self.logger.info(f"{project_name}在{time_predict}时刻的预测值为：{pred_value.item()}")
                except Exception as e:
                    raise PredictError(f"Error: {e}")

                # write predict value into database
                try:
                    self.realtime_db_client.update_predictvalue(
                        table_name=self.project_name, 
                        predictvalue=pred_value.item(),
                        time_predict=time_predict, 
                        pred_len_str=self.pred_len_str_dict[project_name])
                except pyodbc.Error as e:
                    self.logger.error(
                        f"{project_name} update realtime predict value counters database Error:{e}, \
                            please check realtime predict database status!!!")
                    self.realtime_db_client.connect_db()
                    raise UpdatePredictValueError(f"Error: {e}")
                except Exception as e:
                    raise UpdatePredictValueError(f"Error: {e}")

            self.logger.info(f"当前时间{current_time}实时预测已经全部写入数据库!!!")
        else:
            self.logger.warning(f"Device {self.project_name} is not running at time:{current_time},skip realtime predict.")
            # 真实值和预测值都写0
            self.realtime_db_client.update_realvalue_control(
                    table_name=self.project_name, 
                    realvalue=0, 
                    time_real=current_time
                )
            self.realtime_db_client.update_predictvalue(
                    table_name=self.project_name, 
                    predictvalue=0,
                    time_predict=current_time, 
                    pred_len_str=self.pred_len_str_dict[self.project_name]
                )
    
    def main(self) -> None:
        """
        Main realtime prediction pipeline
        """
        current_time = datetime.datetime.now().replace(second=0, microsecond=0)

        # Get the latest input data from database
        try:
            # pred_input = self.ts_db_client.get_latest_input_data_by_column_time(
            #         self.input_name_list,
            #         self.model_parameter_dict[self.project_name]["x_length"]
            # )
            pred_input = self.read_dataframe.read_dataframe(
                name_list=self.input_name_list, 
                time_length=self.model_parameter_dict[self.project_name]["x_length"]
            )
            # print(f"{self.project_name}的输入数据为：{pred_input}")
            if self.device_operation_flag is None:
                device_status = check_device_status(pred_input, self.feed_amount_column_name)
            else:
                device_status = self.read_dataframe.check_device_status(self.device_operation_flag)
        except Exception as e:
            self.logger.error(f"Get the latest input data from database failed: {e}")
            # raise InputDataError(f"Error: {e}")
            return
        
        # 检测输入数据是否为空
        if pred_input.is_empty():
            self.logger.warning(f"当前时间{current_time}项目{self.project_name}输入数据为空，跳过实时预测!!!")
            self.logger.warning("=================请检查数据库和数据采集软件工作是否正常!!!=================")
            return
            
        # 输入数据预处理
        # 分钟均值
        self.logger.debug(f"before calculate_minute_average: {pred_input}")
        pred_input = calculate_minute_average(pred_input)
        pred_input = pred_input.tail(self.model_parameter_dict[self.project_name]["x_length"])
        self.logger.debug(f"after calculate_minute_average: {pred_input}")

        # Get the latest true value from database
        try:
            true_df = self.output_db_client.get_latest_true_value(self.sample_table_out_name) # important:取质检真实值有问题
            true_series_list = [true_df[col] for col in true_df.columns]
            true_data = [series.item() for series in true_series_list]
            # true_time is the time of the latest true value
            true_time, true_value = true_data[0], true_data[1]  
            self.logger.info(f"{self.project_name} 最新真实值时间：{true_time}，最新真实值：{true_value}")
        except Exception as e:
            # raise TrueValueError(f"Error: {e}")
            self.logger.error(f"Get the latest true value from database failed: {e}")

        # Update the latest true value into the database according to the current_time format
        try:
            if isinstance(true_time, datetime.datetime):
                true_time = true_time.replace(second=0, microsecond=0)
                self.realtime_db_client.update_realvalue_control(
                    table_name=self.project_name, 
                    realvalue=true_value, 
                    time_real=true_time
                )
            else:
                latest_true_quality = self.output_db_client.get_latest_true_value_quality_rt(
                    self.sample_table_out_name)
                assert len(latest_true_quality) > 0, "质检库中没有数据,请检查质检取数程序是否正常工作!!!"
                self.realtime_db_client.update_realvalue_quality(
                    table_name=self.project_name, 
                    quality_real=latest_true_quality
                )
                # 将true_time转换为datetime格式
                true_time = current_time
        except pyodbc.Error as e:
            self.logger.error(
                f"{self.project_name} update realtime value counters database failure {e}, \
                    please check realtime predict database status!!!")
            # self.realtime_db_client.connect_db()
            # raise UpdateDatabaseError(f"Error: {e}")
        except Exception as e:
            # raise UpdateDatabaseError(f"Error: {e}")
            self.logger.error(f"{self.project_name} update realtime value counters database failure {e}, \
                    please check realtime predict database status!!!")

        # judge if the device is running: if running, then start realtime predict
        # device_status = check_device_status(pred_input, self.feed_amount_column_name)
        # if device is running, then start realtime predict
        if device_status:
            # Transform pred_input into torch
            try:
                pred_input = pred_input[:, 1:]  # 去除时间列
                pred_input = self.scaler_x_dict[self.project_name].transform(pred_input)  # 将输入数据进行归一化
                pred_input = torch.tensor(pred_input).unsqueeze(0).float().to(self.device)
            except Exception as e:
                # raise TransformInputError(f"Error: {e}")
                self.logger.error(f"{self.project_name} Transform pred_input into torch failed: {e}")

            # 循环计算每一个模型实时预测值，并写入数据库
            for project_name in self.project_name_list:
                # # 根据每个模型的x_length，获取最新的x_length个数据
                # try:
                #     pred_input = self.ts_db_client.get_latest_input_data_by_column_time(
                #         self.input_name_list, self.model_parameter_dict[project_name]["x_length"]
                #         )
                #     assert pred_input.shape[0] == self.model_parameter_dict[project_name]["x_length"], \
                #         f"Error: {project_name}的输入数据维度不正确，应为{self.model_parameter_dict[project_name]\
                #                                              ['x_length']}，实际为{pred_input.shape[0]}!!!"
                # except Exception as e:
                #     self.logger.error(f"查询{project_name}的最新输入数据失败: {e},请检查服务器数据库连接!!!")
                #     raise InputDataError(f"Error: {e}")

                # # Transform the pred_input and true_value into the format of model input
                # # Transform pred_input into torch
                # try:
                #     pred_input = pred_input[:, 1:]  # 去除时间列
                #     pred_input = self.scaler_x_dict[self.project_name].transform(pred_input)  # 将输入数据进行归一化
                #     pred_input = torch.tensor(pred_input).unsqueeze(0).float().to(self.device)
                # except Exception as e:
                #     raise TransformInputError(f"Error: {e}")
                
                # running realtime predict using self.model
                try:
                    with torch.no_grad():
                        pred_value = self.model_dict[project_name](pred_input)  # 将pred_input送入模型进行预测
                    pred_value = self.scaler_y_dict[project_name].inverse_transform(\
                        pred_value.reshape(-1, 1).to(torch.device("cpu")))  # 将预测值进行反归一化
                    time_predict = true_time + self.pred_time_dict[project_name]  # 当前预测值对应的时间
                    time_predict = time_predict.strftime("%Y-%m-%d %H:%M:%S")  # 将时间格式转换为字符串
                    self.logger.info(f"{project_name}在{time_predict}时刻的预测值为：{pred_value.item()}")
                except Exception as e:
                    # raise PredictError(f"Error: {e}")
                    self.logger.error(f"{self.project_name} running realtime predict using self.model failed: {e}")

                # write predict value into database
                try:
                    self.realtime_db_client.update_predictvalue(
                        table_name=self.project_name, 
                        predictvalue=pred_value.item(),
                        time_predict=time_predict, 
                        pred_len_str=self.pred_len_str_dict[project_name]
                    )
                    # ! 新的rt使用下面的更新方式
                    # self.realtime_db_client.update_predictvalue(
                    #     table_name=self.project_name, 
                    #     predictvalue=pred_value.item(),
                    #     time_predict=time_predict
                    # )
                except pyodbc.Error as e:
                    self.logger.error(
                        f"{project_name} update realtime predict value counters database Error:{e}, \
                            please check realtime predict database status!!!")
                    self.realtime_db_client.connect_db()
                    # raise UpdatePredictValueError(f"Error: {e}")
                    self.logger.error(f"{project_name} update realtime predict value counters database Error:{e}, \
                            please check realtime predict database status!!!")
                except Exception as e:
                    # raise UpdatePredictValueError(f"Error: {e}")
                    self.logger.error(f"{project_name} update realtime predict value counters database Error:{e}, \
                            please check realtime predict database status!!!")

            self.logger.info(f"当前时间{current_time}实时预测已经全部写入数据库!!!")
        else:
            self.logger.warning(f"Device {self.project_name} is not running at time:{current_time},skip realtime predict.")
            # 预测值都写0
            # 循环计算每一个模型实时预测值，并写入数据库
            for project_name in self.project_name_list: 
                time_predict = true_time + self.pred_time_dict[project_name]  # 当前预测值对应的时间
                time_predict = time_predict.strftime("%Y-%m-%d %H:%M:%S")  # 将时间格式转换为字符串
                self.realtime_db_client.update_predictvalue(
                        table_name=self.project_name, 
                        predictvalue=0,
                        time_predict=time_predict, 
                        pred_len_str=self.pred_len_str_dict[project_name]
                    )

    def run(self) -> None:
        """
        classic realtime predictor
        """
        start_time = time.time()
        current_time, history_data = self.query_history_data()
        end_time = time.time()
        print(f"当前时间{current_time}实时预测任务查询历史数据耗时{end_time - start_time}秒")

        start_time = time.time()
        self.rt_all(current_time=current_time, pred_input=history_data)
        end_time = time.time()
        print(f"当前时间{current_time}实时预测任务模型计算耗时{end_time - start_time}秒")
        