import re
import polars as pl

from datetime import datetime
from typing import Tuple

from .mssql_base import MSSQLConnection
from industrytslib.utils.logutils import get_logger
from industrytslib.utils.basefunc import prediction_parameter_parser, name_list_parser


class MSSQLWeb(MSSQLConnection):
    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self.logger = get_logger("MSSQLWeb", "database")

    def get_prediction_info(self, project_name: str) -> Tuple[str, str]:
        """
        Get the prediction info of project name in table yunxing
        return:
            sample_name: sample name
            algorithm_name: algorithm name
        """
        sql_prediction_info = f"SELECT * FROM yunxing WHERE sampletable_name = '{project_name}'"
        rows = self.query(sql_prediction_info)
        sample_name = rows["yangben"].item()
        model_name = rows["moxing"].item()
        self.logger.info(f"Sample name: {sample_name}, algorithm name: {model_name}")
        return sample_name, model_name 
    
    def get_rt_info(self, project_name: str) -> pl.DataFrame:
        """
        Get the realtime info of project name in table yunxing
        Args:
            project_name (str): project name
        Returns:
            pl.DataFrame: realtime prediction information
        """
        sql_rt_info = f"SELECT * FROM yunxing WHERE sampletable_name = '{project_name}'"
        rt_info = self.query(sql_rt_info)
        return rt_info

    def get_model_parameter(self, model_name: str) -> Tuple[str, dict]:
        """Get the parameter of the model

        Args:
            model_name (str): model name

        Returns:
            pd.DataFrame: model parameter
        """
        sql = f"select * from algoone where project_name='{model_name}'"
        rows = self.query(sql)

        algorithm_name = rows["model_name"].to_list()[0]  # TODO 这里数据库列名和实际含义不匹配,需要修改数据库

        parameter_str = rows["parameter"].to_list()[0]
        parameter = prediction_parameter_parser(parameter_str)
        self.logger.info(f"The parameter of model {model_name} is: {parameter}")
        return algorithm_name, parameter
    
    # Get sample table information from web database.
    def get_sample_table_information(self, sample_name) -> pl.DataFrame:
        """
        从Web数据库获取样本表信息。

        Args:
            sample_name (str): 样本名称，用于查询对应的样本表信息。

        Returns:
            pl.DataFrame: 包含样本数据时间范围信息的polars DataFrame对象。

        """
        sql_time_range = f"SELECT * FROM [dbo].[sampletablezong] WHERE sample_table='{sample_name}'"
        sample_table_info = self.query(sql_time_range)
        self.logger.info(f"sample table information of {sample_name}: {sample_table_info}")
        return sample_table_info
    
    def _get_sample_table_input_name(self, sample_name: str) -> list:
        """Get the input name of sample table.
        Args:
            sample_name (str): Sample name.
        Returns:
            list: Input names of sample table.
        """
        sample_table_info = self.get_sample_table_information(sample_name)
        input_name_str = sample_table_info["column_namein"][0]
        input_name_list = name_list_parser(input_name_str)
        return input_name_list

    # optimization information
    def get_optimization_info(
            self, 
            project_name: str
        ) -> tuple[pl.DataFrame, pl.DataFrame, list, list, list]:
        """Get the optimization information of project name in table optimization
        return:
            optimization_arguments: 优化模型使用的参数
            optimization_constraints: 优化模型使用的约束
            optimization_prediction_model: 优化模型使用的预测模型列表
            input_name_list: 优化模型使用的输入变量列表
        """
        # 1. get optimization arguments
        sql_optimization_arguments = f"""
            SELECT * FROM [dbo].[optimization] 
            WHERE optimization_project_name='{project_name}'
        """
        optimization_arguments = self.query(sql_optimization_arguments)
        self.logger.info(f"optimization arguments of {project_name}: {optimization_arguments}")

        # 2. get optimization constraints
        sql_optimization_arguments = f"""
            SELECT bianliang FROM [dbo].[optimization] 
            WHERE optimization_project_name='{project_name}'
        """
        constraints_rows = self.query(sql_optimization_arguments)
        constraints_str = constraints_rows["bianliang"].to_list()[0]
        # 使用正则表达式提取数据
        pattern = re.compile(r'([^, ]+?): min: (-?\d+\.?\d*) max: (-?\d+\.?\d*)', re.UNICODE)
        constraint_data = []
        for match in pattern.finditer(constraints_str):
            name, min_val, max_val = match.groups()
            constraint_data.append({
                'variable': name,
                'min': float(min_val),
                'max': float(max_val)
            })
        optimization_constraints = pl.DataFrame(constraint_data)
        self.logger.info(f"optimization constraints of {project_name}: {optimization_constraints}")

        # get prediction model used by optimization 
        optimization_prediction_model = optimization_arguments["prediction_model"].to_list()[0].split(',')
        prediction_model_table_list = []  # 预测模型的样本表名
        prediction_model_list = []  # 预测模型的模型名
        for i in optimization_prediction_model:
            prediction_model_table_list.append(i.split('_')[0].strip())
            prediction_model_list.append(i.split('_')[1] + '_' + i.split('_')[2])

        # 根据预测模型的样本表名获取要用到的变量名
        input_name_list = []
        for sample_name in prediction_model_table_list:
            input_name = self._get_sample_table_input_name(sample_name)
            input_name_list.append(input_name)

        self.logger.info(f"input name of {project_name}: {input_name_list}")
        return optimization_arguments, optimization_constraints, prediction_model_table_list, \
               prediction_model_list, input_name_list

    def ensure_table_exist_operation_status(self) -> None:
        """
        Ensure the table operation_status exists.
        """
        try:
            self.cursor.execute("""
                IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'operation_status')
                BEGIN
                    CREATE TABLE operation_status (
                        DateTime datetime,
                        project_name NVARCHAR(255) PRIMARY KEY,
                        project_type NVARCHAR(255),
                        operation_status int,
                    );
                END
            """)
            self.connection.commit()
        except Exception as e:
            print(f"Error ensuring the operation_status table exists: {e}")

    def init_operation_status(self) -> None:
        """
        Initialize the operation_status table.
        """
        # Step 1: 清空 operation_status 表的所有数据
        self.cursor.execute("DELETE FROM operation_status")
        self.connection.commit()

    def update_operation_status(self, update_time: datetime, project_name: str, project_type: str) -> None:
        """
        Update the operation status of the project.
        """
        update_time = update_time.strftime("%Y-%m-%d %H:%M:%S")
        sql_update_operation_status = f"""
            INSERT INTO operation_status (DateTime, project_name, project_type, operation_status)
            VALUES ('{update_time}', '{project_name}', '{project_type}', 1)
        """
        self.cursor.execute(sql_update_operation_status)
        self.connection.commit()

    # 将运行状态写入tagDatabase
    def write_device_status(self, project_name: str, device_status: int) -> None:
        """
        Write the device status into the tagdatabase table.
        Args:
            project_name: project name
            device_status: device status
        """
        # 先判断是否存在TagName为name的行
        sql_sentence = f"SELECT COUNT(*) FROM TagDatabase WHERE TagName = '{project_name}'"
        self.cursor.execute(sql_sentence)
        row_count = self.cursor.fetchone()[0]
        try:
            if row_count > 0:
                # 更新数据
                sql_sentence = f"UPDATE TagDatabase SET TagVal = '{device_status}' WHERE TagName = '{project_name}'"
                self.cursor.execute(sql_sentence)
                self.connection.commit()
            else:
                # 插入数据
                sql_sentence = f"INSERT INTO TagDatabase(TagName, TagVal) VALUES('{project_name}','{device_status}')"
                self.cursor.execute(sql_sentence)
                self.connection.commit()
        except Exception as e:
            print(f"更新设备运行状态出现错误：{e}")


    def insert_device_status(self, project_name: str, device_status: int) -> None:
        """
        Insert the device status into the database.
        """
        time_now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        sql_insert = f"""
            INSERT INTO device_status(DateTime, device_name, device_status)
            VALUES('{time_now}', '{project_name}', '{device_status}')
        """
        try:
            self.execute(sql_insert)
        except Exception as e:
            print(f"插入设备运行状态出现错误：{e}")


"""
##########################################################
在线训练信息和其他模型信息更新模块
##########################################################
"""
# 在线训练表设计：数据库OnlineTrainer，表表名为project_name
# DateTime project_name epoch train_loss test_loss 
class MSSQLOnlineTrainer(MSSQLConnection):
    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self.logger = get_logger("MSSQLOnlineTrainer", "database")

    def insert_online_trainer_info(
            self, 
            time_now: str,
            project_name: str, 
            epoch: int, 
            train_loss: float, 
            test_loss: float
        ) -> None:
        """
        Insert the online trainer information into the database.
        Args:
            time_now: 插入时间
            project_name: project name
            epoch: 实时训练的epoch
            train_loss: 实时训练的训练loss
            test_loss: 实时训练的测试loss
        Returns:
            None
        """
        sql_insert = f"""
            INSERT INTO OnlineTrainer(DateTime, project_name, epoch, train_loss, test_loss)
            VALUES('{time_now}', '{project_name}', '{epoch}', '{train_loss}', '{test_loss}')
        """
        self.execute(sql_insert)

    def get_online_trainer_info(self, project_name: str) -> pl.DataFrame:
        """
        Get the online trainer information from the database.
        Args:
            project_name: project name
        Returns:
            pl.DataFrame: online trainer information
        """
        sql_get = f"SELECT TOP 60 * FROM OnlineTrainer WHERE project_name = '{project_name}'"
        return self.query(sql_get)
