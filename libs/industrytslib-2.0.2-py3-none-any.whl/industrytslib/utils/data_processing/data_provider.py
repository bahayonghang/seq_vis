import polars as pl

from torch.utils.data import DataLoader, Dataset
from typing import Tuple

from industrytslib.utils.data_processing.data_loader import (
    InputTimeSeriesDataset,
    OutputTimeSeriesDataset,
    SequenceTimeSeriesDataset,
    RandomSequenceTimeSeriesDataset,
    OperationSequenceTimeSeriesDataset,
    OperationSequenceDatasetTime,   # 用于可视化序列数据集
    TransformerTimeSeriesDataset,
    ClassicControlTimeSeriesDataset,
    ClassicQualityTimeSeriesDataset,
    RandomClassicQualityTimeSeriesDataset
)

data_dict = {
    "transformer": TransformerTimeSeriesDataset,
    "input": InputTimeSeriesDataset,
    "output": OutputTimeSeriesDataset,
    "sequence": SequenceTimeSeriesDataset,
    "random_sequence": RandomSequenceTimeSeriesDataset,
    "operation_sequence": OperationSequenceTimeSeriesDataset,
    "operation_sequence_time": OperationSequenceDatasetTime,
    "quality": ClassicQualityTimeSeriesDataset,
    "control": ClassicControlTimeSeriesDataset,
    "quality_random": RandomClassicQualityTimeSeriesDataset
}

def data_provider_builder(
        project_name:str, 
        data:pl.DataFrame | list[pl.DataFrame], 
        data_type:str, 
        model_parameter:dict, 
        flag:str
    ) -> Tuple[Dataset, DataLoader]:
    """
    Get dataset and dataloader.
    Args:
        project_name (str): 项目名称
        data (pl.DataFrame | list[pl.DataFrame]): 数据
        data_type (str): 数据类型
        model_parameter (dict): 模型参数
        flag (str): "train" or "val" or "test"
    Returns:
        Tuple[Dataset, DataLoader]: 包含两个元素的元组,分别是数据集和数据加载器
    Examples:
        >>> data_provider_builder(project_name, data, data_type, model_parameter, flag)
    """
    match data_type:
        case "transformer":
            data_set, data_loader = data_provider_transformer(project_name, data, data_type, model_parameter, flag)
        case "sequence":
            # ! data[0] is input data, data[1] is output data
            assert isinstance(data, list), "data 必须是 list[pl.DataFrame]"
            assert len(data) == 2, "data 必须是长度为2的list[pl.DataFrame]"
            data_set, data_loader = data_provider_sequence(project_name, data[0], data[1], data_type, model_parameter, flag)
        case "random_sequence":
            data_set, data_loader = data_provider_sequence_random(project_name, data[0], data[1], data_type, model_parameter, flag)
        case "operation_sequence" | "operation_sequence_time":
            data_set, data_loader = data_provider_operation_sequence(project_name, data[0], data[1], data_type, model_parameter, flag)
        case "input":
            data_set, data_loader = data_provider_classic(project_name, data, data_type, model_parameter, flag)
        case "output":
            data_set, data_loader = data_provider_classic(project_name, data, data_type, model_parameter, flag)
        case "control" | "quality" | "quality_random":
            data_set, data_loader = data_provider_classic_alter(project_name, data[0], data[1], data_type, model_parameter, flag)
        case _:
            raise ValueError(f"Invalid data type: {data_type}")
    return data_set, data_loader


def data_provider_transformer(
        project_name: str, 
        data: pl.DataFrame, 
        data_type:str, 
        model_parameter: dict, 
        flag: str
    ) -> Tuple[Dataset, DataLoader]:
    """
    Get dataset and dataloader for transformer model.
    Args:
        project_name (str): 项目名称
        data (pl.DataFrame): 数据
        data_type (str): 数据类型
        model_parameter (dict): 模型参数
        flag (str): "train" or "val" or "test"
    Returns:
        Tuple[Dataset, DataLoader]: 包含两个元素的元组,分别是数据集和数据加载器
    Examples:
        >>> data_provider_transformer(project_name, data, data_type, model_parameter, flag)
    """
    Data = data_dict[data_type]

    try:
        if "scaler_type" in model_parameter:
            scaler_type = model_parameter["scaler_type"]
        else:
            scaler_type = "standard"
    except Exception as e:
        print(f"Scaler type error: {e}")
        scaler_type = "standard"
    
    try:
        if "shuffle" in model_parameter:
            match model_parameter["shuffle"]:
                case 1:
                    shuffle_flag = True
                case 0:
                    shuffle_flag = False
                case _:
                    raise ValueError("shuffle_flag 参数错误,请检查参数列表!!! ")
        else:
            shuffle_flag = False
    except Exception as e:
        print(f"Shuffle flag error: {e}")
        shuffle_flag = True

    match flag:
        case "test":
            shuffle_flag = False
            drop_last = True
            batch_size = model_parameter["batch_size"]
            freq = model_parameter["freq"]
        case "pred":
            shuffle_flag = False
            drop_last = False
            batch_size = 1
            freq = model_parameter["freq"]
        case _:
            shuffle_flag = shuffle_flag
            drop_last = True
            batch_size = model_parameter["batch_size"]
            freq = model_parameter["freq"]

    data_set = Data(
        project_name = project_name,
        tsdata = data,
        size = [model_parameter["seq_len"], model_parameter["label_len"], model_parameter["pred_len"]],
        # scaler_type = "standard",
        scaler_type = scaler_type,
        flag = flag,
        freq = freq
    )
    print(f"flag: {flag}, length: {len(data_set)}")

    data_loader = DataLoader(
        dataset = data_set,
        batch_size = batch_size,
        shuffle = shuffle_flag,
        num_workers = 0,
        drop_last = drop_last
    )
    return data_set, data_loader

def data_provider_sequence(
        project_name: str,
        input_data: pl.DataFrame,
        output_data: pl.DataFrame,
        data_type:str,
        model_parameter: dict,
        flag: str
    ) -> Tuple[Dataset, DataLoader]:
    """
    Get dataset and dataloader for sequence model.
    Args:
        project_name (str): 项目名称
        input_data (pl.DataFrame): 输入数据
        output_data (pl.DataFrame): 输出数据
        data_type (str): 数据类型
        model_parameter (dict): 模型参数
        flag (str): "train" or "val" or "test"
    Returns:
        Tuple[Dataset, DataLoader]: 包含两个元素的元组,分别是数据集和数据加载器
    Examples:
        >>> data_provider_sequence(project_name, input_data, output_data, data_type, model_parameter, flag)
    """
    Data = data_dict[data_type]

    try:
        if "scaler_type" in model_parameter:
            scaler_type = model_parameter["scaler_type"]
        else:
            scaler_type = "standard"
    except Exception as e:
        print(f"Scaler type error: {e}")
        scaler_type = "standard"
    
    try:
        if "shuffle" in model_parameter:
            match model_parameter["shuffle"]:
                case 1:
                    shuffle_flag = True
                case 0:
                    shuffle_flag = False
                case _:
                    raise ValueError("shuffle_flag 参数错误,请检查参数列表!!! ")
        else:
            shuffle_flag = False
    except Exception as e:
        print(f"Shuffle flag error: {e}")
        shuffle_flag = True

    match flag:
        case "test":
            shuffle_flag = False
            drop_last = True
            batch_size = model_parameter["batch_size"]
            freq = model_parameter["freq"]
        case "pred":
            shuffle_flag = False
            drop_last = False
            batch_size = 1
            freq = model_parameter["freq"]
        case _:
            shuffle_flag = shuffle_flag
            drop_last = True
            batch_size = model_parameter["batch_size"]
            freq = model_parameter["freq"]

    data_set = Data(
        project_name = project_name,
        input_data = input_data,
        output_data = output_data,
        size = [model_parameter["seq_len"], model_parameter["label_len"], model_parameter["pred_len"]],
        # scaler_type = "standard",
        scaler_type = scaler_type,
        flag = flag,
        freq = freq
    )
    print(f"flag: {flag}, length: {len(data_set)}")

    data_loader = DataLoader(
        dataset = data_set,
        batch_size = batch_size,
        shuffle = shuffle_flag,
        num_workers = 0,
        drop_last = drop_last
    )
    return data_set, data_loader


def data_provider_sequence_random(
        project_name: str, 
        input_data: pl.DataFrame, 
        output_data: pl.DataFrame, 
        data_type:str, 
        model_parameter: dict, 
        flag: str
    ) -> Tuple[Dataset, DataLoader]:
    """
    Get dataset and dataloader for random sequence model.
    Args:
        project_name (str): 项目名称
        input_data (pl.DataFrame): 输入数据
        output_data (pl.DataFrame): 输出数据
        data_type (str): 数据类型
        model_parameter (dict): 模型参数
        flag (str): "train" or "val" or "test"
    Returns:
        Tuple[Dataset, DataLoader]: 包含两个元素的元组,分别是数据集和数据加载器
    Examples:
        >>> data_provider_sequence_random(project_name, input_data, output_data, data_type, model_parameter, flag)
    """
    Data = data_dict[data_type]

    try:
        if "scaler_type" in model_parameter:
            scaler_type = model_parameter["scaler_type"]
        else:
            scaler_type = "standard"
    except Exception as e:
        print(f"Scaler type error: {e}")
        scaler_type = "standard"
    
    try:
        if "shuffle" in model_parameter:
            match model_parameter["shuffle"]:
                case 1:
                    shuffle_flag = True
                case 0:
                    shuffle_flag = False
                case _:
                    raise ValueError("shuffle_flag 参数错误,请检查参数列表!!! ")
        else:
            shuffle_flag = False
    except Exception as e:
        print(f"Shuffle flag error: {e}")
        shuffle_flag = True

    match flag:
        case "test":
            shuffle_flag = False
            drop_last = True
            batch_size = model_parameter["batch_size"]
            freq = model_parameter["freq"]
        case "pred":
            shuffle_flag = False
            drop_last = False
            batch_size = 1
            freq = model_parameter["freq"]
        case _:
            shuffle_flag = shuffle_flag
            drop_last = True
            batch_size = model_parameter["batch_size"]
            freq = model_parameter["freq"]

    data_set = Data(
        project_name = project_name,
        input_data = input_data,
        output_data = output_data,
        size = [model_parameter["seq_len"], model_parameter["label_len"], model_parameter["pred_len"]],
        # scaler_type = "standard",
        scaler_type = scaler_type,
        flag = flag,
        freq = freq
    )
    print(f"flag: {flag}, length: {len(data_set)}")

    data_loader = DataLoader(
        dataset = data_set,
        batch_size = batch_size,
        shuffle = shuffle_flag,
        num_workers = 0,
        drop_last = drop_last
    )
    return data_set, data_loader


def data_provider_operation_sequence(
        project_name: str, 
        input_data: pl.DataFrame, 
        output_data: pl.DataFrame, 
        data_type:str, 
        model_parameter: dict, 
        flag: str
    ) -> Tuple[Dataset, DataLoader]:
    """
    Get dataset and dataloader for operation sequence model.
    Args:
        project_name (str): 项目名称
        input_data (pl.DataFrame): 输入数据
        output_data (pl.DataFrame): 输出数据
        data_type (str): 数据类型
        model_parameter (dict): 模型参数
        flag (str): "train" or "val" or "test"
    Returns:
        Tuple[Dataset, DataLoader]: 包含两个元素的元组,分别是数据集和数据加载器
    Examples:
        >>> data_provider_operation_sequence(project_name, input_data, output_data, data_type, model_parameter, flag)
    """
    Data = data_dict[data_type]

    try:
        # 如果model_parameter["scaler_type"]为空，则使用scaler_type = "standard"
        if "scaler_type" in model_parameter:
            scaler_type = model_parameter["scaler_type"]
        else:
            scaler_type = "standard"
    except Exception as e:
        print(f"Scaler type error: {e}")
        scaler_type = "standard"
    
    try:
        # 如果model_parameter["shuffle"]为空，则使用shuffle_flag = True
        if "shuffle" in model_parameter:
            match model_parameter["shuffle"]:
                case 1:
                    shuffle_flag = True
                case 0:
                    shuffle_flag = False
                case _:
                    raise ValueError("shuffle_flag 参数错误,请检查参数列表!!! ")
        else:
            shuffle_flag = False
    except Exception as e:
        print(f"Shuffle flag error: {e}")
        shuffle_flag = False

    match flag:
        case "test":
            shuffle_flag = False
            drop_last = True
            batch_size = model_parameter["batch_size"]
            freq = model_parameter["freq"]
        case "pred":
            shuffle_flag = False
            drop_last = False
            batch_size = 1
            freq = model_parameter["freq"]
        case _:
            shuffle_flag = shuffle_flag
            drop_last = True
            batch_size = model_parameter["batch_size"]
            freq = model_parameter["freq"]

    data_set = Data(
        project_name = project_name,
        input_data = input_data,
        output_data = output_data,
        size = [model_parameter["seq_len"], model_parameter["label_len"], model_parameter["pred_len"]],
        # scaler_type = "standard",
        scaler_type = scaler_type,
        flag = flag,
        freq = freq
    )
    print(f"flag: {flag}, length: {len(data_set)}")

    data_loader = DataLoader(
        dataset = data_set,
        batch_size = batch_size,
        shuffle = shuffle_flag,
        num_workers = 0,
        drop_last = drop_last
    )
    return data_set, data_loader


def data_provider_transformer_random(
        project_name: str, 
        data: pl.DataFrame, 
        data_type:str, 
        model_parameter: dict, 
        flag: str
    ) -> Tuple[Dataset, DataLoader]:
    """
    Get dataset and dataloader for transformer random model.
    Args:
        project_name (str): 项目名称
        data (pl.DataFrame): 数据
        data_type (str): 数据类型
        model_parameter (dict): 模型参数
        flag (str): "train" or "val" or "test"
    Returns:
        Tuple[Dataset, DataLoader]: 包含两个元素的元组,分别是数据集和数据加载器
    Examples:
        >>> data_provider_transformer_random(project_name, data, data_type, model_parameter, flag)
    """
    Data = data_dict[data_type]

    try:
        if "scaler_type" in model_parameter:
            scaler_type = model_parameter["scaler_type"]
        else:
            scaler_type = "standard"
    except Exception as e:
        print(f"Scaler type error: {e}")
        scaler_type = "standard"

    try:
        if "shuffle" in model_parameter:
            match model_parameter["shuffle"]:
                case 1:
                    shuffle_flag = True
                case 0:
                    shuffle_flag = False
                case _:
                    raise ValueError("shuffle_flag 参数错误,请检查参数列表!!! ")
        else:
            shuffle_flag = False
    except Exception as e:
        print(f"Shuffle flag error: {e}")
        shuffle_flag = True

    match flag:
        case "test":
            shuffle_flag = False
            drop_last = True
            batch_size = model_parameter["batch_size"]
            freq = model_parameter["freq"]
        case "pred":
            shuffle_flag = False
            drop_last = False
            batch_size = 1
            freq = model_parameter["freq"]
        case _:
            shuffle_flag = shuffle_flag
            drop_last = True
            batch_size = model_parameter["batch_size"]
            freq = model_parameter["freq"]

    data_set = Data(
        project_name = project_name,
        tsdata = data,
        size = [model_parameter["seq_len"], model_parameter["label_len"], model_parameter["pred_len"]],
        # scaler_type = "standard",
        scaler_type = scaler_type,
        flag = flag,
        freq = freq
    )
    print(f"flag: {flag}, length: {len(data_set)}")

    data_loader = DataLoader(
        dataset = data_set,
        batch_size = batch_size,
        shuffle = shuffle_flag,
        num_workers = 0,
        drop_last = drop_last
    )
    return data_set, data_loader


def data_provider_classic(
        project_name: str, 
        data: pl.DataFrame, 
        data_type:str, 
        model_parameter: dict, 
        flag: str
    ) -> Tuple[Dataset, DataLoader]:
    """
    Get dataset and dataloader for classic model.
    Args:
        project_name (str): 项目名称
        data (pl.DataFrame): 数据
        data_type (str): 数据类型
        model_parameter (dict): 模型参数
        flag (str): "train" or "val" or "test"
    Returns:
        Tuple[Dataset, DataLoader]: 包含两个元素的元组,分别是数据集和数据加载器
    Examples:
        >>> data_provider_classic(project_name, data, data_type, model_parameter, flag)
    """
    Data = data_dict[data_type]

    try:
        if "scaler_type" in model_parameter:
            scaler_type = model_parameter["scaler_type"]
        else:
            scaler_type = "minmax"
    except Exception as e:
        print(f"Scaler type error: {e}")
        scaler_type = "minmax"

    try:
        if "shuffle" in model_parameter:
            match model_parameter["shuffle"]:
                case 1:
                    shuffle_flag = True
                case 0:
                    shuffle_flag = False
                case _:
                    raise ValueError("shuffle_flag 参数错误,请检查参数列表!!! ")
        else:
            shuffle_flag = False
    except Exception as e:
        print(f"Shuffle flag error: {e}")
        shuffle_flag = False

    size = [model_parameter["x_length"], model_parameter["y_length"], model_parameter["pred_len"],
                     model_parameter["x_sliding_length"], model_parameter["y_sliding_length"]]
    match flag:
        case "test":
            shuffle_flag = False
            drop_last = True
            batch_size = model_parameter["batch_size"]
        case "pred":
            shuffle_flag = False
            drop_last = False
            batch_size = 1
        case _:
            shuffle_flag = shuffle_flag
            drop_last = True
            batch_size = model_parameter["batch_size"]

    data_set = Data(
        project_name = project_name,
        tsdata = data,
        size = size,
        # scaler_type = "standard",
        scaler_type = scaler_type,
        flag = flag
    )
    print(f"flag: {flag}, length: {len(data_set)}")

    data_loader = DataLoader(
        dataset = data_set,
        batch_size = batch_size,
        shuffle = shuffle_flag,
        num_workers = 0,
        drop_last = drop_last
    )
    return data_set, data_loader


def data_provider_classic_alter(
        project_name: str, 
        input_data: pl.DataFrame, 
        output_data: pl.DataFrame, 
        data_type:str, 
        model_parameter: dict, 
        flag: str
    ) -> Tuple[Dataset, DataLoader]:
    """
    Get dataset and dataloader for classic alter model.
    Args:
        project_name (str): 项目名称
        input_data (pl.DataFrame): 输入数据
        output_data (pl.DataFrame): 输出数据
        data_type (str): 数据类型
        model_parameter (dict): 模型参数
        flag (str): "train" or "val" or "test"
    Returns:
        Tuple[Dataset, DataLoader]: 包含两个元素的元组,分别是数据集和数据加载器
    Examples:
        >>> data_provider_classic_alter(project_name, input_data, output_data, data_type, model_parameter, flag)
    """
    assert data_type in ["control", "quality", "quality_random"], "data_type 必须是 control 或 quality"
    Data = data_dict[data_type]

    try:
        if "scaler_type" in model_parameter:
            scaler_type = model_parameter["scaler_type"]
        else:
            scaler_type = "minmax"
    except Exception as e:
        print(f"Scaler type error: {e}")
        scaler_type = "minmax"

    try:
        if "shuffle" in model_parameter:
            match model_parameter["shuffle"]:
                case 1:
                    shuffle_flag = True
                case 0:
                    shuffle_flag = False
                case _:
                    raise ValueError("shuffle_flag 参数错误,请检查参数列表!!! ")
        else:
            shuffle_flag = False
    except Exception as e:
        print(f"Shuffle flag error: {e}")
        shuffle_flag = False

    size = [model_parameter["x_length"], model_parameter["y_length"], model_parameter["pred_len"],
                     model_parameter["x_sliding_length"], model_parameter["y_sliding_length"]]
    match flag:
        case "test":
            shuffle_flag = False
            drop_last = False
            batch_size = model_parameter["batch_size"]
        case "pred":
            shuffle_flag = False
            drop_last = False
            batch_size = 1
        case _:
            shuffle_flag = shuffle_flag
            drop_last = False
            batch_size = model_parameter["batch_size"]

    data_set = Data(
        project_name = project_name,
        input_data = input_data,
        output_data = output_data,
        size = size,
        # scaler_type = "standard",
        scaler_type = scaler_type,
        flag = flag
    )
    print(f"flag: {flag}, length: {len(data_set)}")

    data_loader = DataLoader(
        dataset = data_set,
        batch_size = batch_size,
        shuffle = shuffle_flag,
        num_workers = 0,
        drop_last = drop_last
    )
    return data_set, data_loader
