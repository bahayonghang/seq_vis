import datetime
import torch
import pickle
import pyodbc

import numpy as np
import pandas as pd
import polars as pl

from pathlib import Path
from typing import Tuple

from industrytslib.models.aimodels import build_model
from industrytslib.utils.database import database_builder
from industrytslib.utils.data_processing.polarsoperation import check_device_status, add_datetime_column
from industrytslib.core.base import ScheduledTask
from industrytslib.utils.readconfig import read_model_parameter_toml
from industrytslib.utils.basefunc import name_list_parser, split_sample_and_model
from industrytslib.utils.logutils import get_logger
from industrytslib.models.aimodels.utils.timefeatures import time_features
from industrytslib.utils.share.reader import ReadDataframe


class SequenceRealtimePredictor(ScheduledTask):
    """
    SequenceRealtimePredictor is a class for realtime prediction of sequence model
    """
    def __init__(self, project_name: str, dbconfig: dict) -> None:
        super().__init__(project_name, dbconfig)
        self.task_type = "realtime_predict_sequence"
        self.project_name = project_name
        self.update_flag = True  # flag to indicate whether to update the database, default is True
        self.logger = get_logger(self.project_name, self.task_type)
        self.read_dataframe = ReadDataframe()

        # ! 默认运行模式为本地模式,用于本地测试,测试完deploy的时候修改为online
        self.run_mode = "online"

        if self.run_mode == "online":
            # database connections based on dbconfig
            self.web_db_client = database_builder(dbconfig["mssql"]["web"])
            self.ts_db_client = database_builder(dbconfig["mssql"]["timeseries"])
            self.realtime_db_client = database_builder(dbconfig["mssql"]["realtimepredict_sequence"])
        elif self.run_mode == "local":
            self.realtime_db_client = database_builder(dbconfig["mssql"]["realtimepredict_sequence"])
        else:
            raise ValueError(f"Invalid run mode: {self.run_mode}")

        try:
            self.sample_name, self.model_name = self.web_db_client.get_prediction_info(self.project_name)
        except Exception as e:
            self.logger.error(
                f"Get the sample name and model name of {self.project_name} from web database failed: {e}"
            )
            self.logger.info("使用本地配置!!!")
            self.sample_name, self.model_name = split_sample_and_model(self.project_name)
        self.sample_table_in_name = self.sample_name + "_in"  # input table(view) name
        self.sample_table_out_name = self.sample_name + "_out"  # output table(view) name
        
        try:
            if self.ts_db_client.is_table_exist(self.sample_table_out_name):
                self.out_db_client = self.ts_db_client
            else:
                self.out_db_client = database_builder(self.dbconfig["mssql"]["quality"])
        except Exception as e:
            self.logger.error(f"Get the output database client failed: {e}")
            # raise e
        
        self.get_basic_info()

    def get_basic_info(self) -> None:
        """
        Get basic information of the project
        """
        # Get model parameter
        # If local model parameter exists, then read local model parameter,
        # else read from web database
        model_parameter_path = Path(f"resource/model_parameter/{self.model_name}/model_config.toml")
        if model_parameter_path.exists():
            self.model_parameter = read_model_parameter_toml(model_parameter_path)
            self.algorithm_name = self.model_parameter["algorithm_name"]
        else:
            self.algorithm_name, self.model_parameter = self.web_mssql_client.get_model_parameter(self.model_name)

        # Get model path and model name according to project name in database   
        self.model_path = Path("resource", "models", self.project_name, "checkpoint.pth")
        self.model = build_model(self.algorithm_name, self.model_parameter)
        self.model.load_state_dict(torch.load(self.model_path, map_location=self.device, weights_only=True))
        self.model.to(self.device)

        # normalization parameter of x
        self.scaler_x_path = Path("resource", "scaler", self.project_name, "scaler_x.pkl")
        # normalization parameter of y
        self.scaler_y_path = Path("resource", "scaler", self.project_name, "scaler_y.pkl")
        # load scaler_x
        with open(self.scaler_x_path, "rb") as f:
            self.scaler_x = pickle.load(f)
        # load scaler_y
        with open(self.scaler_y_path, "rb") as f:
            self.scaler_y = pickle.load(f)

        # parameter about realtime predict
        self.freq = self.model_parameter["freq"]
        self.seq_len = self.model_parameter["seq_len"]
        self.label_len = self.model_parameter["label_len"]
        self.pred_len = self.model_parameter["pred_len"]

        # Determine whether real-time prediction is required based on datetime
        self.datetime_past = datetime.datetime.now()

        if self.run_mode == "online":
            # feed amount column_name 
            self.feed_amount_column_name = self.ts_db_client.get_feed_amount_column_name(self.sample_table_in_name)

            # get sample table information
            try:
                self.sample_table_information = self.web_db_client.get_sample_table_information(self.sample_name)
            except Exception as e:
                self.logger.error(f"Get sample table information from web mssql database failed: {e}")
                self.logger.error(f"Please check the sample name {self.sample_name} in web mssql database!!!")
                raise e
            
            # get input name list(input variable name list)  
            try:
                input_name_str = self.sample_table_information["column_namein"][0]
                self.input_name_list = name_list_parser(input_name_str)
                self.logger.info(f"Get input name list from sample table information successfully:\
                                {self.input_name_list}")
            except Exception as e:
                self.logger.error(f"Get input name list from sample table information failed: {e}")
                self.logger.error(f"Please check the sample table information of {self.sample_name}!!!")
                raise e
            
            # get output name list(output variable name list)
            try:
                output_name_str = self.sample_table_information["column_nameout"][0]
                self.output_name_list = name_list_parser(output_name_str)
                self.logger.info(f"Get output name list from sample table information successfully:\
                                {self.output_name_list}")
            except Exception as e:
                self.logger.error(f"Get output name list from sample table information failed: {e}")
                self.logger.error(f"Please check the sample table information of {self.sample_name}!!!")
                raise e
            
            # 从样本信息中获取当前设备在TagDatabase运行标志位
            try:
                self.device_operation_flag: str = self.sample_table_information["operationflag"].item()
                self.logger.info(f"{self.project_name}在TagDatabase的运行标志位为: {self.device_operation_flag}")
                # 彩色打印运行标志位信息
                print(f"\033[1;34m================{self.project_name}运行标志位：{self.device_operation_flag}=================\033[0m")
            except Exception as e:
                self.logger.error(f"Get device operation flag from sample table information failed: {e}")
                self.logger.error(f"Please check the sample table information of {self.sample_name}!!!")
                # raise e
                self.device_operation_flag = None
        elif self.run_mode == "local":
            input_csv_path = f"resource/datasets/{self.sample_name}/data_in.csv"
            output_csv_path = f"resource/datasets/{self.sample_name}/data_out.csv"
            if Path(input_csv_path).exists() and Path(output_csv_path).exists():
                self.logger.info(f"Get input and output data from local csv file {input_csv_path} and {output_csv_path}.")
                input_data = pl.read_csv(input_csv_path)
                output_data = pl.read_csv(output_csv_path)
                # print(input_data, output_data)
            else:
                self.logger.error(f"Local csv file {input_csv_path} or {output_csv_path} does not exist!!!")
                raise FileNotFoundError(f"Local csv file {input_csv_path} or {output_csv_path} does not exist!!!")
            self.input_name_list = input_data.columns[1:]
            self.output_name_list = output_data.columns[1:]
            del input_data, output_data
        
        else:
            raise ValueError(f"Invalid run mode: {self.run_mode}")
        
        # 根据project_name和output_name_list判断并创建表
        try:
            self.realtime_db_client.check_sequence_table(self.project_name, self.output_name_list)
            # self.realtime_db_client.create_sequence_predict_table(self.project_name, self.output_name_list)
        except Exception as e:
            self.logger.error(f"Check sequence table failed {e}, please check the database connection!")
            # raise f"Check sequence table failed {e}, please check the database connection!"
        
    def get_sequence_model_input(self) -> Tuple[pl.DataFrame, pl.DataFrame]:
        """
        从数据库中根据变量名称列表获取输入
        Returns:
            enc_input: input data of encoder
            dec_input: input data of decoder
        """
        enc_input = self.read_dataframe.read_dataframe(
            name_list = self.input_name_list, 
            time_length = self.seq_len)
        dec_input = self.read_dataframe.read_dataframe(
            name_list = self.output_name_list, 
            time_length = self.label_len)
        
        if enc_input.is_empty() or dec_input.is_empty():
            self.logger.warning("=================从全局dataframe读取到的输入数据为空，从数据库中获取最新数据!!!=================")
            try:
                enc_input = self.ts_db_client.get_latest_input_data_by_column_time(
                    input_name_list = self.input_name_list, 
                    time_length = self.seq_len
                )
                dec_input = self.ts_db_client.get_latest_input_data_by_column_time(
                    input_name_list = self.output_name_list, 
                    time_length = self.label_len
                )
            except Exception as e:
                self.logger.error(f"Get the latest input data from database failed: {e}")
                # raise InputDataError("输入数据为空，请检查数据库和数据采集软件工作是否正常!!!")
                enc_input = pl.DataFrame()
                dec_input = pl.DataFrame()

            if enc_input.is_empty() or dec_input.is_empty():
                raise Exception("输入数据为空，请检查数据库和数据采集软件工作是否正常!!!")
                # 生成seq_len*len(input_name_list)的随机Dataframe和label_len*len(output_name_list)的随机Dataframe
                # self.logger.warning("输入数据为空,生成seq_len*len(input_name_list)的随机Dataframe和label_len*len(output_name_list)的随机Dataframe用于测试!!!")
                # enc_input = pl.DataFrame(np.random.rand(self.seq_len, len(self.input_name_list)))
                # dec_input = pl.DataFrame(np.random.rand(self.label_len, len(self.output_name_list)))
                # enc_input.columns = self.input_name_list
                # dec_input.columns = self.output_name_list
                # # 在dec_input和enc_input中添加时间戳列
                # enc_input = add_datetime_column(enc_input, mode="backward")
                # dec_input = add_datetime_column(dec_input, mode="backward")

        self.logger.info("=================Get the latest input data from database successfully!=================")
        self.logger.info(f"enc_input:{enc_input}")
        self.logger.info(f"dec_input:{dec_input}")
        self.logger.info(f"enc_input columns:{enc_input.columns}")
        self.logger.info(f"dec_input columns:{dec_input.columns}")
        return enc_input, dec_input

    def get_sequence_input_data(
            self, 
            enc_input: pl.DataFrame, 
            dec_input: pl.DataFrame
        ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """
        Get the input data of sequence model according to the seq_len and label_len
        Args:
            enc_input: input data of encoder
            dec_input: input data of decoder
        Returns:
            enc_input_data: input data of encoder
            dec_input_data: input data of decoder
            enc_data_stamp: time features of encoder
            dec_data_stamp: time features of decoder
        """
        # 将dec_input再向后拼接pred_len个时间戳的0数据
        pred_input = pl.DataFrame(np.zeros((self.pred_len, len(self.output_name_list))))
        pred_input.columns = self.output_name_list
        pred_input = add_datetime_column(pred_input, mode="forward")
        dec_input = pl.concat([dec_input, pred_input])
        print(f"\033[1;34mdec_input: {dec_input}\033[0m")
        
        enc_df_stamp = enc_input.select(enc_input.columns[0]).to_pandas()
        enc_df_stamp['DateTime'] = pd.to_datetime(enc_df_stamp.iloc[:, 0])
        enc_data_stamp = time_features(enc_df_stamp, timeenc=1, freq=self.freq)

        dec_df_stamp = dec_input.select(dec_input.columns[0]).to_pandas()
        dec_df_stamp['DateTime'] = pd.to_datetime(dec_df_stamp.iloc[:, 0])
        dec_data_stamp = time_features(dec_df_stamp, timeenc=1, freq=self.freq)

        enc_input_data = enc_input.select(enc_input.columns[1:])
        dec_input_data = dec_input.select(dec_input.columns[1:])

        enc_input_data = self.scaler_x.transform(enc_input_data)
        dec_input_data = self.scaler_y.transform(dec_input_data)

        # 都转换为tensor
        enc_input_data = torch.tensor(enc_input_data).float().to(self.device).unsqueeze(0)
        dec_input_data = torch.tensor(dec_input_data).float().to(self.device).unsqueeze(0)
        enc_data_stamp = torch.tensor(enc_data_stamp).float().to(self.device).unsqueeze(0)
        dec_data_stamp = torch.tensor(dec_data_stamp).float().to(self.device).unsqueeze(0)

        print(f"\033[1;34menc_input_data: {enc_input_data}, dec_input_data: {dec_input_data}, enc_data_stamp: {enc_data_stamp}, dec_data_stamp: {dec_data_stamp}\033[0m")

        return enc_input_data, dec_input_data, enc_data_stamp, dec_data_stamp

    def cleanup(self) -> None:
        """
        Cleanup the resources
        """
        pass

    def main(self) -> None:
        """
        Main sequence realtime prediction pipeline
        """
        current_time = datetime.datetime.now()

        # Get the latest input data from database
        try:
            enc_input, dec_input = self.get_sequence_model_input()
        except pyodbc.Error as e:
            self.logger.error(f"Get the latest input data from database failed: {e}")
            self.ts_db_client.connect_db()
            self.logger.info("Reconnect to the database successfully!!!")
            enc_input, dec_input = self.get_sequence_model_input()
        except Exception as e:
            self.logger.error(f"Get the latest input data from database failed: {e}")
            raise Exception(f"Error: {e}")

        # 检测输入数据是否为空
        if enc_input.is_empty() or dec_input.is_empty():
            self.logger.warning(f"当前时间{current_time}项目{self.project_name}输入数据为空，跳过实时预测!!!")
            self.logger.warning("=================请检查数据库和数据采集软件工作是否正常!!!=================")
            return  
        
        # judge if the device is running
        try:
            if self.device_operation_flag is None:
                device_status = check_device_status(enc_input, self.feed_amount_column_name)
            else:
                if self.read_dataframe.read_dataframe_latest().is_empty():
                    # device_status = True
                    device_status = self.ts_db_client.check_device_running_status(self.device_operation_flag)
                else:
                    device_status = self.read_dataframe.check_device_status(self.device_operation_flag)
        except Exception as e:
            self.logger.error(f"Check device status failed: {e}")
            if self.run_mode == "online":
                self.logger.warning("=================请检查数据库和数据采集软件工作是否正常!!!=================")
                # raise InputDataError(f"Error: {e}")
                return
            elif self.run_mode == "local":
                device_status = True

        print(f"\033[1;34m当前{self.project_name}运行状态为{device_status}\033[0m")
            
        # if device is running, then start realtime predict
        if device_status:
            # Transform the pred_input and true_value into the format of model input
            # Transform pred_input into torch
            try:
                (
                    enc_input_data, 
                    dec_input_data, 
                    enc_data_stamp, 
                    dec_data_stamp
                ) = self.get_sequence_input_data(enc_input, dec_input)
                self.logger.info(
                    f"enc_input_data: {enc_input_data.shape}, dec_input_data: {dec_input_data.shape},enc_data_stamp: {enc_data_stamp.shape}, dec_data_stamp: {dec_data_stamp.shape}"
                    )
            except Exception as e:
                self.logger.error(f"Transform the pred_input into torch failed: {e}")
                return
                # raise TransformInputError(f"Error: {e}")
                             
            # running realtime predict using self.model
            try:
                with torch.no_grad():
                     # encoder - decoder
                    if "TimeMachine" in self.algorithm_name:
                        pred_value = self.model(enc_input_data)
                    else:
                        pred_value = self.model(enc_input_data, enc_data_stamp, dec_input_data, dec_data_stamp)
                     
                # 将预测值进行反归一化 
                pred_value = self.scaler_y.inverse_transform(pred_value.reshape(-1, len(self.output_name_list)).to(torch.device("cpu")))  
            except Exception as e:
                self.logger.error(f"Predict error: {e}")
                raise e
                # return

            self.logger.info(f"{self.project_name}在{current_time}时刻序列实时预测成功!!!")
        else:
            # 如果设备未运行，则将所有的预测值置为0
            pred_value = np.zeros((self.pred_len, len(self.output_name_list)))
            self.logger.warning(f"{self.project_name}在{current_time}时刻关联的设备不在运行，跳过当前时刻的实时预测。")

        # 将历史数据和预测数据先拼接然后更新到数据库中
        if self.update_flag:
            try:
                pred_data = pl.DataFrame(pred_value)
                self.logger.info(f"当前预测值为:{pred_data}")
                pred_data.columns = self.output_name_list
                self.realtime_db_client.update_sequence_predict_table(
                    table_name = self.project_name, 
                    predictvalue = pred_data, 
                    time_predict = current_time
                )
            except pyodbc.Error as e:
                self.logger.error(
                    f"{self.project_name} update realtime predict value counters database Error:{e}, \
                        please check realtime predict database status!!!")
                self.realtime_db_client.connect_db()
                # raise UpdatePredictValueError(f"Error: {e}")
                self.logger.error(f"Update realtime predict value error: {e}")
                return
            except Exception as e:
                self.logger.error(f"Update realtime predict value error: {e}")
                return
            
            try:
                history_data = dec_input.select(self.output_name_list)
                self.logger.info(f"当前历史数据为:{history_data}")
                self.realtime_db_client.update_sequence_real_value_table(
                    table_name = self.project_name, 
                    realvalue = history_data, 
                    time_real = current_time
                )
            except Exception as e:
                self.logger.error(f"{self.project_name} update sequence real value failed:{e}!!!")
        else:
            self.logger.warning(f"{self.project_name}在{current_time}时刻不更新数据库!!!")

