from .decision_agents import DecisionMaking

def get_decision_agent(
        project_name: str, 
        dbconfig: dict
    ) -> DecisionMaking:
    """
    获取决策器
    Args:
        project_name: 项目名称
        dbconfig: 数据库配置
    Returns:
        DecisionMaking
    Examples:
        >>> from industrytslib.utils.readconfig import read_config_toml
        >>> config = read_config_toml("config/dbconfig.toml")
        >>> get_decision_agent("二线窑", config)
    """
    return DecisionMaking(project_name, dbconfig)
