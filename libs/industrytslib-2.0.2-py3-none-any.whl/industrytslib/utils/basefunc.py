import re
import datetime
import platform
import subprocess

from typing import Tuple


def prediction_parameter_parser(parameter_str) -> dict:
    """parser prediction parameter string to dict

    Args:
        parameter_str (_type_): the parameter string in algone of web database 

    Returns:
        prams: the dict of parameter

    Examples:
        >>> prediction_parameter_parser("a:1,b:2,c:3")
        {'a': 1, 'b': 2, 'c': 3}
    """
    params = {}
    for kv in re.split(r',(?=(?:[^"]*"[^"]*")*[^"]*$)', parameter_str):
        k, v = kv.split(':')
        params[k] = v
    pattern = re.compile(r'^\d+(\.\d+)?$')

    for key, value in params.items():
        if pattern.match(value):
            if '.' in value:
                params[key] = float(value)
            else:
                params[key] = int(value)
    print(f"解析出的参数列表为:{params}")
    return params


def name_list_parser(name_str: str) -> list:
    """parser name string to list
    Args:
        name_str str: the name string in algone of web database 
    Returns:
        prams: the list of input column name
    Examples:
        >>> name_list_parser("a,b,c")
        ['a', 'b', 'c']
    """
    name_list = re.split(r',\s*', name_str)
    return name_list


def get_current_time() -> str:
    """get current time in format of yyyymmddHHMMSS
    Returns:
        str: the current time string
    Examples:
        >>> get_current_time()
        '20241207120000'
    """
    return datetime.datetime.now().strftime('%Y%m%d%H%M%S')


def split_sample_and_model(input_string: str) -> Tuple[str, str]:
    """
    将输入字符串分割为样本名和模型名。

    Args:
        input_string (str): 输入字符串，格式为"样本名_模型名"。

    Returns:
        Tuple[str, str]: 包含两个元素的元组,分别是样本名和模型名。
    Examples:
        >>> split_sample_and_model("sample_model")
        ('sample', 'model')
    """
    parts = input_string.split('_', 1)
    sample = parts[0]
    model = '_'.join(parts[1:])
    return sample, model


def ping_address(host: str) -> bool:
    """
    Ping指定的主机地址,如果能ping通则返回True,否则返回False

    Args:
        host (str): 要ping的主机地址,可以是域名或IP地址

    Returns:
        bool: 如果能ping通返回True,否则返回False
    Examples:
        >>> ping_address("192.168.1.1")
        True
    """
    # 根据操作系统选择ping命令参数
    param = '-n' if platform.system().lower() == 'windows' else '-c'

    # 构建ping命令
    command = ['ping', param, '1', host]

    try:
        # 执行ping命令
        output = subprocess.run(command,
                                stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE,
                                timeout=5)  # 5秒超时

        # 如果返回值为0，说明ping成功
        return output.returncode == 0
    except subprocess.TimeoutExpired:
        return False
    except Exception:
        return False
    