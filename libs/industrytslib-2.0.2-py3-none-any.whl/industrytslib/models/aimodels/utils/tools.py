import torch
import numpy as np


def adjust_learning_rate(optimizer: torch.optim.Optimizer, epoch: int, args: dict) -> None:
    """
    Adjusts the learning rate of the optimizer based on the current epoch and specified adjustment strategy.

    This function modifies the learning rate of the provided optimizer according to a predefined strategy defined
    in the `args` dictionary. The adjustment strategies are categorized into different types, each affecting the 
    learning rate in unique ways based on the epoch value.

    Args:
        optimizer: The optimizer instance (e.g., SGD, Adam) whose learning rate will be adjusted.
                   It should contain a `param_groups` attribute which is a list of parameter groups, 
                   each having a 'lr' key representing the learning rate.
        epoch (int): The current training epoch number. This is used to determine which adjustment strategy
                     to apply and how to calculate the new learning rate.
        args (dict): A dictionary containing parameters related to the learning rate adjustment.
                     It should include:
                     - "learning_rate": The base learning rate for training.
                     - "lradj": A string that specifies the learning rate adjustment strategy to use.
                     The supported adjustment strategies (keys) are:
                     - 'type1': Exponential decay every epoch.
                     - 'type2': Predefined specific learning rates at certain epochs.
                     - 'type3': Conditional decay starting from the third epoch.
                     - 'type4': Reduces learning rate after the 10th epoch.
                     - 'type5': Reduces learning rate after the 15th epoch.
                     - 'type6': Reduces learning rate after the 25th epoch.
                     - 'type7': Reduces learning rate after the 10th epoch.
                     - 'type8': A multi-stage adjustment based on epoch ranges.
                     - 'constant': Keeps the learning rate constant throughout training.

    Raises:
        ValueError: If the provided learning rate adjustment strategy (`args['lradj']`) is not recognized.

    Usage:
        Call this function at the beginning of each epoch in your training loop to adjust the learning rate dynamically
        based on the specified strategy. 

        Example:
            for epoch in range(num_epochs):
                adjust_learning_rate(optimizer, epoch, args)
                train_one_epoch(...)
    """

    # lr = args.learning_rate * (0.2 ** (epoch // 2))
    match args["lradj"]:
        case 'type1':
            lr_adjust = {epoch: args["learning_rate"] * (0.5 ** ((epoch - 1) // 1))}
        case 'type2':
            lr_adjust = {
                2: 5e-5, 4: 1e-5, 6: 5e-6, 8: 1e-6,
                10: 5e-7, 15: 1e-7, 20: 5e-8
            }
        case 'type3':
             lr_adjust = {epoch: args["learning_rate"] if epoch < 3 else args.learning_rate * (0.9 ** ((epoch - 3) // 1))}
        case "type4":
            lr_adjust = {epoch: args["learning_rate"] if epoch < 10 else args["learning_rate"]*0.1}
        case "type5":
            lr_adjust = {epoch: args["learning_rate"] if epoch < 15 else args["learning_rate"]*0.1}
        case "type6":
            lr_adjust = {epoch: args["learning_rate"] if epoch < 25 else args["learning_rate"]*0.1}
        case "type7":
            lr_adjust = {epoch: args["learning_rate"] if epoch < 10 else args["learning_rate"]*0.1}
        case "type8":
            if epoch < 20:
                lr_adjust = {epoch: args["learning_rate"]}
            elif epoch < 500:
                lr_adjust = {epoch: args["learning_rate"]*0.1}
            else:
                lr_adjust = {epoch: args["learning_rate"]*0.01}
        case "constant":
            lr_adjust = {epoch: args["learning_rate"]}
        case _:
            raise ValueError(f"Unknown lradj: {args['lradj']}")

    if epoch in lr_adjust.keys():
        lr = lr_adjust[epoch]
        for param_group in optimizer.param_groups:
            param_group['lr'] = lr
        print('Updating learning rate to {}'.format(lr))


class EarlyStopping:
    def __init__(self, patience=7, verbose=False, delta=0):
        self.patience = patience
        self.verbose = verbose
        self.counter = 0
        self.best_score = None
        self.early_stop = False
        self.val_loss_min = np.inf
        self.delta = delta

    def __call__(self, val_loss, model, path):
        score = -val_loss
        if self.best_score is None:
            self.best_score = score
            self.save_checkpoint(val_loss, model, path)
        elif score < self.best_score + self.delta:
            self.counter += 1
            print(f'EarlyStopping counter: {self.counter} out of {self.patience}')
            if self.counter >= self.patience:
                self.early_stop = True
        else:
            self.best_score = score
            self.save_checkpoint(val_loss, model, path)
            self.counter = 0

    def save_checkpoint(self, val_loss, model, path):
        if self.verbose:
            print(f'Validation loss decreased ({self.val_loss_min:.6f} --> {val_loss:.6f}).  Saving model ...')
        # torch.save(model.state_dict(), path+'/'+'checkpoint.pth')
        torch.save(model.state_dict(), path)
        self.val_loss_min = val_loss


class dotdict(dict):
    """dot.notation access to dictionary attributes"""
    __getattr__ = dict.get
    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__


class StandardScaler:
    def __init__(self):
        self.mean = 0.
        self.std = 1.

    def fit(self, data):
        self.mean = data.mean(0)
        self.std = data.std(0)

    def transform(self, data):
        mean = torch.from_numpy(self.mean).type_as(data).to(data.device) if torch.is_tensor(data) else self.mean
        std = torch.from_numpy(self.std).type_as(data).to(data.device) if torch.is_tensor(data) else self.std
        return (data - mean) / std

    def inverse_transform(self, data):
        mean = torch.from_numpy(self.mean).type_as(data).to(data.device) if torch.is_tensor(data) else self.mean
        std = torch.from_numpy(self.std).type_as(data).to(data.device) if torch.is_tensor(data) else self.std
        if data.shape[-1] != mean.shape[-1]:
            mean = mean[-1:]
            std = std[-1:]
        return (data * std) + mean
