import pathlib
import plotly.graph_objects as go
import polars as pl 

from .base_plotter import BasePlotter

from plotly.subplots import make_subplots


class PlotlyPlotter(BasePlotter):
    def __init__(self, project_name: str) -> None:
        super().__init__(project_name)
        
    def plot_train_result(
            self, 
            time_now: str, 
            epoch: int, 
            true_list: list, 
            pred_list: list, 
            save_path: pathlib.Path
        ) -> None:
        """
        Plot training result

        Args:
            time_now (str): current time
            epoch (int): current epoch
            true_list (list): true list
            pred_list (list): predict list
            save_path (pathlib.Path): save path
        """
        # train_result_fig_png_name = f"train_result_{time_now}_epoch{epoch}.png"
        train_result_fig_html_name = f"train_result_{time_now}_epoch{epoch}.html"
        # train_result_fig_png_path = save_path.joinpath(train_result_fig_png_name)
        train_result_fig_html_path = save_path.joinpath(train_result_fig_html_name)

        fig = go.Figure()

        # 添加真实值平滑曲线图
        fig.add_trace(go.Scatter(x=list(range(len(true_list))), y=true_list, mode='lines', name='True'))

        # 添加预测值平滑曲线图
        fig.add_trace(go.Scatter(x=list(range(len(pred_list))), y=pred_list, mode='lines', name='Predict'))

        # 设置图表标题和标签
        fig.update_layout(
            title=f"{self.project_name} 训练结果",
            xaxis_title="Index",
            yaxis_title="Value",
            legend=dict(y=0.5, traceorder='reversed', font_size=16),
            width=1600,
            height=900
        )

        # 保存图表为HTML和PNG文件
        fig.write_html(str(train_result_fig_html_path))
        # fig.write_image(fig, str(train_result_fig_png_path))


    def plot_loss(
            self, 
            time_now: str, 
            train_loss_list: list, 
            vali_loss_list: list, 
            save_path: pathlib.Path
        ) -> None:
        """
        Plot training loss and validation loss

        Args:
            time_now (str): current time
            train_loss_list (list): train loss list
            vali_loss_list (list): validation loss list
            save_path (pathlib.Path): save path
        """
        # train_loss_fig_png_name = f"train_loss_{time_now}.png"
        train_loss_fig_html_name = f"train_loss_{time_now}.html"
        # train_loss_fig_png_path = save_path.joinpath(train_loss_fig_png_name)
        train_loss_fig_html_path = save_path.joinpath(train_loss_fig_html_name)

        fig = go.Figure()

        # 添加训练损失平滑曲线图
        fig.add_trace(go.Scatter(x=list(range(len(train_loss_list))), y=train_loss_list, mode='lines', name='Train Loss'))

        # 添加验证损失平滑曲线图
        fig.add_trace(go.Scatter(x=list(range(len(vali_loss_list))), y=vali_loss_list, mode='lines', name='Vali Loss'))

        # 设置图表标题和标签
        fig.update_layout(
            title=f"{self.project_name} 训练、验证 Loss 曲线",
            xaxis_title="Index",
            yaxis_title="Value",
            legend=dict(y=0.5, traceorder='reversed', font_size=16),
            width=1600,
            height=900
        )

        # 保存图表为HTML和PNG文件
        fig.write_html(str(train_loss_fig_html_path))
        # fig.write_image(fig, str(train_loss_fig_png_path))

    def plot_test_result(
            self, 
            time_now: str, 
            true_list: list, 
            pred_list: list, 
            save_path: pathlib.Path
        ) -> None:
        """
        Plot test result

        Args:
            time_now (str): current time
            true_list (list): true list
            pred_list (list): predict list
            save_path (pathlib.Path): save path
        """
        # test_result_fig_png_name = f"test_result_{time_now}.png"
        test_result_fig_html_name = f"test_result_{time_now}.html"
        # test_result_fig_png_path = save_path.joinpath(test_result_fig_png_name)
        test_result_fig_html_path = save_path.joinpath(test_result_fig_html_name)

        fig = go.Figure()

        # 添加真实值平滑曲线图
        fig.add_trace(go.Scatter(x=list(range(len(true_list))), y=true_list, mode='lines', name='True'))

        # 添加预测值平滑曲线图
        fig.add_trace(go.Scatter(x=list(range(len(pred_list))), y=pred_list, mode='lines', name='Predict'))

        # 设置图表标题和标签
        fig.update_layout(
            title=f"{self.project_name} 测试结果",
            xaxis_title="Index",
            yaxis_title="Value",
            legend=dict(y=0.5, traceorder='reversed', font_size=16),
            width=1600,
            height=900
        )

        # 保存图表为HTML和PNG文件
        fig.write_html(str(test_result_fig_html_path))
        # fig.write_image(fig, str(test_result_fig_png_path))


    def plot_input_curve(
            self, 
            input_df: pl.DataFrame, 
            save_path: pathlib.Path
        ) -> None:
        """
        Plot input curve

        Args:
            input_df (pl.DataFrame): input dataframe
            save_path (pathlib.Path): save path
        """
        # input_curve_fig_png_name = "input_curve.png"
        input_curve_fig_html_name = "input_curve.html"
        # input_curve_fig_png_path = save_path.joinpath(input_curve_fig_png_name)
        input_curve_fig_html_path = save_path.joinpath(input_curve_fig_html_name)

        # 确保第一列是DateTime类型
        try:
            input_df = input_df.with_columns(pl.col(input_df.columns[0]).cast(pl.Datetime))
        except pl.exceptions.InvalidOperationError:
            input_df = input_df.with_columns(
                pl.col(input_df.columns[0]).str.strptime(pl.Datetime, format="%Y-%m-%d %H:%M:%S")
            )
        except Exception as e:
            print(f"Error converting to datetime: {e}")

        # 计算需要的行数和列数
        n_cols = len(input_df.columns) - 1  # 减去DateTime列
        n_rows = (n_cols + 1) // 2  # 每行最多2个子图

        # 计算适当的垂直间距
        vertical_spacing = min(0.1, 0.9 / (n_rows - 1) if n_rows > 1 else 0.1)

        # 创建子图
        fig = make_subplots(rows=n_rows, cols=2,
                            subplot_titles=input_df.columns[1:],
                            vertical_spacing=vertical_spacing,
                            horizontal_spacing=0.05)

        # 为每一列数据添加一个子图
        for i, column in enumerate(input_df.columns[1:], 1):
            row = (i - 1) // 2 + 1
            col = 2 if i % 2 == 0 else 1

            fig.add_trace(
                go.Scatter(
                    x=list(range(len(input_df))),
                    y=input_df[column],
                    mode='lines',
                    name=column
                ),
                row=row, col=col
            )

            # 设置y轴标题
            fig.update_yaxes(title_text=column, row=row, col=col)

            # 设置x轴标题和格式
            fig.update_xaxes(
                title_text='DateTime',
                tickformat='%Y-%m-%d',
                tickangle=45,
                row=row,
                col=col
            )

        # 更新布局
        fig.update_layout(
            title_text=f'Historical Data Visualization of {self.project_name}',
            height=900 * n_rows,  # 增加每个子图的高度
            width=1600,  # 增加整体宽度
            showlegend=False,
            hovermode='closest'
        )

        # 保存图表为HTML和PNG文件
        fig.write_html(str(input_curve_fig_html_path))
        # fig.write_image(fig, str(input_curve_fig_png_path))
    
    def plot_input_boxplot(self, input_df: pl.DataFrame, save_path: pathlib.Path) -> None:
        """
        绘制每一个输入变量的箱线图在一张图中,并保存为html

        Args:
            input_df (pl.DataFrame): input dataframe
            save_path (pathlib.Path): save path
        """
        fig = go.Figure()
        for col in input_df.columns:
            fig.add_trace(go.Box(y=input_df[col], name=col))
        fig.update_layout(title=f"{self.project_name} 输入变量箱线图", xaxis_title="Value", yaxis_title="Index", height=600, width=800)
        fig.write_html(str(save_path.joinpath(f"{self.project_name}_input_boxplot.html")))
    
    def plot_output_boxplot(self, output_df: pl.DataFrame, save_path: pathlib.Path) -> None:
        """
        绘制每一个输出变量的箱线图在一张图中,并保存为html

        Args:
            output_df (pl.DataFrame): output dataframe
            save_path (pathlib.Path): save path
        """
        fig = go.Figure()
        for col in output_df.columns:
            fig.add_trace(go.Box(y=output_df[col], name=col))
        fig.update_layout(title=f"{self.project_name} 输出变量箱线图", xaxis_title="Value", yaxis_title="Index", height=600, width=800)
        fig.write_html(str(save_path.joinpath(f"{self.project_name}_output_boxplot.html")))


    def plot_output_curve(
            self, 
            output_df: pl.DataFrame, 
            save_path: pathlib.Path
        ) -> None:
        """
        Plot output curve

        Args:
            output_df (pl.DataFrame): output dataframe
            save_path (pathlib.Path): save path
        """
        # output_curve_fig_png_name = "output_curve.png"
        output_curve_fig_html_name = "output_curve.html"
        # output_curve_fig_png_path = save_path.joinpath(output_curve_fig_png_name)
        output_curve_fig_html_path = save_path.joinpath(output_curve_fig_html_name)

        time_column = output_df.columns[0]
        value_column = output_df.columns[-1]

        # 创建 Plotly 图表
        fig = go.Figure()

        fig.add_trace(go.Scatter(
            x=list(range(len(output_df))),
            y=output_df[value_column].to_list(),
            mode='lines',
            name=value_column
        ))

        # 更新布局
        fig.update_layout(
            title=f'{value_column} Over Time of {self.project_name}',
            xaxis_title='Time',
            yaxis_title=value_column,
            height=600,
            width=1000,
            hovermode='x unified'
        )

        # 根据时间跨度调整 x 轴格式
        try:
            time_range = (output_df[time_column].max() - output_df[time_column].min()).days
            if time_range > 365:
                dtick = 'M3'  # 每三个月一个刻度
                tickformat = '%Y-%m'
            elif time_range > 30:
                dtick = 'M1'  # 每月一个刻度
                tickformat = '%Y-%m-%d'
            else:
                dtick = 'D1'  # 每天一个刻度
                tickformat = '%Y-%m-%d %H:%M'

            fig.update_xaxes(
                dtick=dtick,
                tickformat=tickformat,
                tickangle=45
            )
        except Exception as e:
            print(f"Error adjusting x-axis format: {e}")
            print("Using default x-axis format...")

        # 保存图表为HTML和PNG文件
        fig.write_html(str(output_curve_fig_html_path))
        # fig.write_image(fig, str(output_curve_fig_png_path))
        