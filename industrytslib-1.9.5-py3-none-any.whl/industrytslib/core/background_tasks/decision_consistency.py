import polars as pl
import pyodbc
import time

from datetime import datetime

from industrytslib.utils.database import database_builder
from industrytslib.utils.logutils import get_logger


def calculate_single_consistency(row: pl.DataFrame) -> float:
    """
    计算单一变量的一致性指标
    Args:
        row: Polars DataFrame containing feedback and AI decision values
    Returns:
        float: The average consistency value for the variable
    """
    # print(f"row: {row}")
    consistency = 0
    feedback = row['反馈值'].item()
    ai_decision = row['AI决策值'].item()
    # assert feedback is not None, f"{row['变量名称'].item()}feedback不能为None"
    # assert ai_decision is not None, f"{row['变量名称'].item()}ai_decision不能为None"
    
    if feedback == 0:
        consistency = 0
    else:
        diff_ratio = abs(feedback - ai_decision) / abs(feedback)
        consistency = 0 if diff_ratio > 1 else (1 - diff_ratio)
    
    # 使用 Polars 的方式创建新列
    result = row.with_columns(
        pl.lit(consistency * 100).alias('consistency')
    )
    
    return result['consistency'].mean()


def calculate_overall_consistency(single_var_mse_list: list[float]) -> float:
    """
    计算综合一致性指标
    Args:
        single_var_mse_list (list[float]): 单一变量的一致性指标列表

    Returns:
        float: 综合一致性指标

    Examples:
        >>> single_var_mse_list = [10, 20, 30]
        >>> calculate_overall_consistency(single_var_mse_list)
        20.0
    """
    # 使用均方差的算术平均作为综合一致性指标
    return sum(single_var_mse_list) / len(single_var_mse_list) if single_var_mse_list else 0


class DecisonHistory:
    """
    决策历史lib
    定期执行copy_decision_realtime_to_decision_history、calculate_consistency这两个函数
    """
    def __init__(self, config: dict) -> None:
        self.decision_history_config = config["mssql"]["decision_history"]
        self.decision_history_mssql = database_builder(self.decision_history_config)
        self.logger = get_logger("MSSQLDecisonHistory", "database")

        self.decision_history_mssql.check_table_optimization_history()
        self.decision_history_mssql.check_table_decision_consistency()

        # 需要写入decision_consistency表的能耗列表 TODO 能耗指标做成可配置的！！！
        self.plant = "合川"
        match self.plant:
            case "合川":
                self.energy_consumption_list = ["生料A磨电耗", "生料B磨电耗", "熟料电耗", "熟料实物煤耗", "煤磨电耗",
                                                "水泥A磨电耗", "水泥B磨电耗"]
            case "三友":
                self.energy_consumption_list = ["原料A磨单位电耗", "原料B磨单位电耗", "窑系统单位电耗", "吨熟料实物煤耗", 
                                                "煤磨电耗", "水泥A磨单位电耗", "水泥B磨单位电耗"]

    # 将decision_realtime这个视图中的数据写入decision_history表中
    def copy_decision_realtime_to_decision_history(self) -> None:
        """
        将decision_realtime这个视图中的数据写入decision_history表中
        """
        # 首先获取decision_realtime视图中的数据
        decision_realtime_df = self.decision_history_mssql.get_decision_realtime()

        # 修改数据结构写入decision_history
        # 获取当前时间，并将其转换为datetime对象
        time_now = datetime.now().replace(microsecond=0, second=0)
        # 遍历decision_realtime_df中的每一行数据
        for index in range(decision_realtime_df.height):
            row = decision_realtime_df[index]
            var_name = row["变量名称"].item()
            project_name = row["optimization_project_name"].item()
            opt_type = row['optimization_type'].item()

            try:
                self.decision_history_mssql.insert_decision_history(time_now, var_name, project_name, opt_type, row)
            except pyodbc.Error as e:
                self.logger.error(f"写入决策历史表失败:{e}!!!")
            except Exception as e:
                self.logger.error(f"写入决策历史表失败:{e}!!!")
                continue

        self.logger.info(f"当前时间{time_now}决策历史表写入成功!!!")

    # 更新实时能耗数据
    def update_energy_consumption_data(self, current_time: datetime) -> None:
        """
        更新实时能耗数据到decision_consistency表中
        """
        # 先根据self.energy_consumption_list从TagDatabase中查询能耗指标
        try:
            energy_consumption_data = \
            self.decision_history_mssql.query_energy_consumption(self.energy_consumption_list)
            self.logger.info(f"当前时间{current_time}能耗数据查询成功,energy_consumption_data:{energy_consumption_data} !!!")
        except Exception as e:
            self.logger.error(f"查询能耗指标失败:{e}!!!")
            raise pyodbc.Error(e)
        
        # 将查询到的能耗数据根据current_time更新decision_consistency中的数据
        try:
            self.decision_history_mssql.update_decision_consistency(current_time, energy_consumption_data)
        except Exception as e:
            self.logger.error(f"更新能耗数据失败:{e}!")
            raise pyodbc.Error(e)
        
        self.logger.info(f"当前时间{current_time}能耗数据更新成功!!!")

    # 计算一致性指标
    def main(self) -> None:
        """
        计算一致性指标
        """
        self.copy_decision_realtime_to_decision_history()

        current_time = datetime.now().replace(microsecond=0, second=0)
        time_consistency_start = time.time()

        # 从决策历史中选取最近的决策数据
        decision_history_data = self.decision_history_mssql.select_recent_decision_data()
        self.logger.info(f"decision_history_data:{decision_history_data}")

        # 按'optimization_project_name', 'optimization_type'分组，并找出每组的最新数据
        for name, group in decision_history_data.group_by(['optimization_project_name', 'optimization_type']):
            project_name, opt_type = name  # 解包分组名称

            history_query = f"""
                                SELECT * FROM decision_realtime
                                where optimization_project_name = '{project_name}'
                                AND optimization_type = '{opt_type}'
                            """
            history_df = self.decision_history_mssql.query(history_query)

            # 在每个组内按照'变量名称'进行分组
            variable_grouped = history_df.group_by('变量名称')
            single_var_mse_list = []  # 用于存储单一变量的一致性指标

            for var_name, var_group in variable_grouped:
                var_name = var_name[0]
                # time_single_start = time.time()
                # 计算单一变量的一致性指标（均方差）
                try:
                    single_var_consistency = calculate_single_consistency(var_group)
                except Exception as e:
                    self.logger.error(f"计算单一变量{var_name}的一致性指标失败:{e}!!!")
                    continue
                single_var_mse_list.append(single_var_consistency)  # 假设你已经定义了这个列表
                # time_single_end = time.time()
                # print(f"单一变量{var_name}一致性指标计算耗时：{time_single_end - time_single_start}秒")

                # 根据varname、gruop将一致性指标写入数据库
                try:
                    self.decision_history_mssql.update_decision_history(single_var_consistency, current_time,
                                                                        var_name, project_name, opt_type)
                except Exception as e:
                    self.logger.error(f"更新单一变量{var_name}的一致性指标失败:{e}!!!")
                    raise pyodbc.Error(e)

            # 计算综合一致性指标（均方差的算术平均）
            overall_consistency = calculate_overall_consistency(single_var_mse_list)

            # 将综合一致性指标更新到数据库
            self.decision_history_mssql.update_overall_consisitency(current_time, project_name, opt_type, 
                                                                     overall_consistency)
        self.logger.debug(f"当前时间{current_time}综合一致性指标计算成功!!!")

        # 更新实时能耗数据
        self.update_energy_consumption_data(current_time)

        time_consistency_end = time.time()
        self.logger.debug(f"当前时间{current_time}综合一致性指标计算耗时：{time_consistency_end - time_consistency_start}秒")

        self.logger.info("======================综合一致性指标计算完成!======================")
        