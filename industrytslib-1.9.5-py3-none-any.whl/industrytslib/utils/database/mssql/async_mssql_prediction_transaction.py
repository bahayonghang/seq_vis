import polars as pl

from .async_mssql_base import AsyncMSSQLConnection
from industrytslib.utils.logutils import get_logger


class AsyncMSSQLPredictionTransactionSource(AsyncMSSQLConnection):
    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self.logger = get_logger("MSSQLPredictionTransactionSource", "database")

    async def query_table_latest_value(self, table_name: str) -> pl.DataFrame:
        """Query the latest non-null value for each column in the specified table.

        Args:
            table_name: The name of the table to query.

        Returns:
            pl.DataFrame: A dataframe containing the latest non-null values for each column.
        """
        query_sql = f"""
            WITH LatestValues AS (
                SELECT TOP 1 [DateTime], [真实值] 
                FROM {table_name}
                WHERE [真实值] IS NOT NULL
                ORDER BY [DateTime] DESC
            ),
            SoftMeasure AS (
                SELECT TOP 1 [DateTime], [软测量预测值]
                FROM {table_name}
                WHERE [软测量预测值] IS NOT NULL
                ORDER BY [DateTime] DESC
            ),
            Pred3min AS (
                SELECT TOP 1 [DateTime], [3分钟预测值]
                FROM {table_name}
                WHERE [3分钟预测值] IS NOT NULL
                ORDER BY [DateTime] DESC
            ),
            Pred5min AS (
                SELECT TOP 1 [DateTime], [5分钟预测值]
                FROM {table_name}
                WHERE [5分钟预测值] IS NOT NULL
                ORDER BY [DateTime] DESC
            ),
            Pred30min AS (
                SELECT TOP 1 [DateTime], [30分钟预测值]
                FROM {table_name}
                WHERE [30分钟预测值] IS NOT NULL
                ORDER BY [DateTime] DESC
            )
            SELECT 
                lv.[DateTime],
                lv.[真实值],
                sm.[软测量预测值],
                p3.[3分钟预测值],
                p5.[5分钟预测值],
                p30.[30分钟预测值]
            FROM LatestValues lv
            LEFT JOIN SoftMeasure sm ON 1=1
            LEFT JOIN Pred3min p3 ON 1=1
            LEFT JOIN Pred5min p5 ON 1=1
            LEFT JOIN Pred30min p30 ON 1=1
        """
        return await self.query(query_sql)
    
    async def query_rt_project_list(self) -> list:
        """
        查询数据库中所有的实时预测表
        """
        sql = "SELECT name FROM sys.tables"
        await self.cursor.execute(sql)
        rows = await self.cursor.fetchall()
        project_list = [row[0] for row in rows]
        # 去除一些不需要的表
        remove_list = ["能源消耗样本总表", "质量样本总表", "ErrorMetrics"]
        for remove_table in remove_list:
            try:
                project_list.remove(remove_table)
            except ValueError:
                self.logger.warning(f"Table {remove_table} not found in project list")
        return project_list

class AsyncMSSQLPredictionTransactionTarget(AsyncMSSQLConnection):
    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self.logger = get_logger("MSSQLPredictionTransactionTarget", "database")

    async def check_table_predict_transaction_exist(self) -> None:
        """
        检测predict_transaction表是否存在,不存在则创建
        """
        await self.execute("""
            IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='predict_transaction' AND xtype='U')
                    CREATE TABLE predict_transaction (
                        [项目名称] nvarchar(255) NOT NULL primary key,
                        [DateTime] datetime NOT NULL,
                        [真实值] float NULL,
                        [软测量预测值] float NULL,
                        [3分钟预测值] float NULL,
                        [5分钟预测值] float NULL,
                        [30分钟预测值] float NULL
                    )
        """)

    async def check_data_exist(self, table_name: str) -> bool:
        query_exist = f"""select count(*) from predict_transaction where [项目名称] = '{table_name}'"""
        await self.cursor.execute(query_exist)
        row_exist = await self.cursor.fetchone()
        return row_exist
    
    async def update_predict_transaction(self, table_name: str, data: pl.DataFrame) -> None:
        """
        将查询到的数据更新到目标数据库的predict_transaction表中
        Args:
            table_name: 项目名称
            data: 查询到的数据
        Returns:
            None
        """
        data_exist = self.check_data_exist(table_name)
        # self.logger.info(f"update data of update predict transaction: {data}")
        if data_exist[0] == 0:
            insert_sql = """insert into predict_transaction ([项目名称], [DateTime], [真实值], [软测量预测值], 
                            [3分钟预测值], [5分钟预测值], [30分钟预测值])
                            values (?, ?, ?, ?, ?, ?, ?)"""
            await self.cursor.execute(insert_sql, 
                                (table_name, data['DateTime'].item(), data['真实值'].item(), 
                                 data['软测量预测值'].item(), data['3分钟预测值'].item(), 
                                 data['5分钟预测值'].item(), data['30分钟预测值'].item()))
            await self.connection.commit()
        else:
            update_sql = """update predict_transaction set [DateTime] = ?, [真实值] = ?, 
                            [软测量预测值] = ?, [3分钟预测值] = ?, 
                            [5分钟预测值] = ?, [30分钟预测值] = ?
                            where [项目名称] = ?"""
            await self.cursor.execute(update_sql,
                                (data['DateTime'].item(), data['真实值'].item(), data['软测量预测值'].item(), 
                                 data['3分钟预测值'].item(), data['5分钟预测值'].item(), data['30分钟预测值'].item(), 
                                 table_name))
            await self.connection.commit()
        