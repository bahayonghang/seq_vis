import datetime
import aioodbc
import asyncio

from typing import Optional, List

import polars as pl

from industrytslib.utils.database.base import Database
from industrytslib.utils.logutils import get_logger

class AsyncMSSQLConnection(Database):
    def __init__(self, config: dict) -> None:
        self.config = config
        self.logger = get_logger("AsyncMSSQL", "database")

        self.server = self.config['server']
        self.username = self.config['username']
        self.password = self.config['password']
        self.database = self.config['database']

        self.max_retries = 9999
        self.retry_delay = 60  # seconds
        
        # Initialize connection and cursor as None
        self.connection: Optional[aioodbc.Connection] = None
        self.cursor: Optional[aioodbc.Cursor] = None

    async def connect(self) -> None:
        """
        Async connect to mssql database
        """
        dsn = f'DRIVER=ODBC Driver 17 for SQL Server;SERVER={self.server};DATABASE={self.database};UID={self.username};PWD={self.password};TrustServerCertificate=yes;'
        self.connection = await aioodbc.connect(dsn=dsn)
        self.cursor = await self.connection.cursor()
        self.logger.info(f"Connect to {self.server} {self.database} as {self.username} Successfully!")

    async def connect_db(self) -> None:
        """
        Async pipeline of connect to mssql database, including error handling and retry
        """
        for attempt in range(self.max_retries):
            try:
                await self.connect()
                self.logger.info(f"username: {self.username}, password: {self.password} | 连接{self.server}数据库成功")
                self.max_retries = 9999
                return
            except Exception as e:
                self.logger.warning(f"""
                                    username: {self.username}, password: {self.password}, Database: {self.database} 
                                    | 连接{self.server}尝试 {attempt + 1} 失败: {str(e)}
                """)
                if attempt < self.max_retries - 1:
                    self.logger.info(f"等待 {self.retry_delay} 秒后重试...")
                    await asyncio.sleep(self.retry_delay)
                else:
                    self.logger.error(f"""
                                      username: {self.username}, password: {self.password}, Database: 
                                      {self.database} | 无法连接到{self.server}数据库，已达到最大重试次数!
                                      """)
                    raise Exception(f"""
                                    username: {self.username}, password: {self.password}, 
                                    Database: {self.database} | 无法连接到{self.server}数据库，已达到最大重试次数!
                                    """) from e

    async def close(self) -> None:
        """
        Async close the connection to the database
        """
        if self.cursor:
            await self.cursor.close()
        if self.connection:
            await self.connection.close()
        self.logger.info("数据库连接已关闭!")

    async def is_table_exist(self, table_name: str) -> bool:
        """
        Async check if the table/view exists in the database
        """
        table_exist_sql = f"""
            SELECT *
            FROM sys.objects
            WHERE object_id = OBJECT_ID('{table_name}')
        """
        await self.cursor.execute(table_exist_sql)
        result = await self.cursor.fetchone()
        return result is not None

    async def query(self, sql: str) -> pl.DataFrame:
        """
        Async query the data from the database.

        Args:
            sql: SQL query string to execute.

        Returns:
            pl.DataFrame: Query results as a Polars DataFrame.
        """
        await self.cursor.execute(sql)
        rows = await self.cursor.fetchall()
        # Add type annotation for cursor description
        columns = [column[0] for column in self.cursor.description]
        df = pl.DataFrame({col: [row[i] for row in rows] for i, col in enumerate(columns)})
        return df

    async def execute(self, sql: str) -> None:
        """
        Async execute the sql
        """
        await self.cursor.execute(sql)
        await self.connection.commit()

    async def add_column(self, table_name: str, column_name: str, column_type: str) -> None:
        """
        Async add a column to the table
        """
        sql = f"ALTER TABLE {table_name} ADD COLUMN {column_name} {column_type}"
        await self.execute(sql)

    async def update_list(self, table_name: str, time_update: datetime.datetime, 
                         name_list: List[str], value_list: List[float]) -> None:
        """
        Async update database based on lists
        """
        update_sql = f"UPDATE [{table_name}] SET"
        for i, var_name in enumerate(name_list):
            update_sql += f" [{var_name}_true] = ?,"
        update_sql = update_sql.rstrip(',')  # Remove trailing comma
        update_sql += " WHERE DateTime = ?"
        
        await self.cursor.execute(update_sql, (*value_list, time_update))
        await self.connection.commit()

    async def insert_list(self, table_name: str, time_insert: datetime.datetime, 
                         name_list: List[str], value_list: List[float]) -> None:
        """
        Async insert into database based on lists
        """
        insert_sql = f"INSERT INTO [{table_name}] (DateTime, {', '.join([f'[{name}_true]' for name in name_list])}) "
        insert_sql += f"VALUES ({', '.join(['?' for _ in range(len(name_list) + 1)])}"
        
        await self.cursor.execute(insert_sql, (time_insert, *value_list))
        await self.connection.commit()
