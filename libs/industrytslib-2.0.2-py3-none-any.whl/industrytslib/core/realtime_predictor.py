"""
Realtime predict of electricity consumption/coal consumption and quality index 
"""
import datetime
import torch
import pickle
import pyodbc

from pathlib import Path

# from industrytslib.models.model_builder import build_model
from industrytslib.models.aimodels import build_model
from industrytslib.utils.database import database_builder
from industrytslib.utils.data_processing.polarsoperation import check_device_status, calculate_minute_average
from industrytslib.core.base import (ScheduledTask,
                                     InputDataError, TrueValueError, TransformInputError, UpdateDatabaseError, PredictError,                    UpdatePredictValueError)
from industrytslib.utils.readconfig import read_model_parameter_toml
from industrytslib.utils.basefunc import name_list_parser, split_sample_and_model
from industrytslib.utils.logutils import get_logger


class RealtimePredictor(ScheduledTask):
    """
    RealtimePredictor is a class for realtime prediction of electricity consumption/coal consumption and quality index 
    including 0(soft sensor)、3、5、30 mins prediction
    """
    def __init__(self, project_name: str, dbconfig: dict) -> None:
        super().__init__(project_name, dbconfig)
        self.task_type = "realtime_predict"
        self.project_name = project_name
        self.update_flag = False  # flag to indicate whether to update the database, default is True
        self.logger = get_logger(self.project_name, self.task_type)

        # database connections based on dbconfig
        self.web_db_client = database_builder(dbconfig["mssql"]["web"])
        self.ts_db_client = database_builder(dbconfig["mssql"]["timeseries"])
        self.realtime_db_client = database_builder(dbconfig["mssql"]["realtimepredict"])

        try:
            self.sample_name, self.model_name = self.web_db_client.get_prediction_info(self.project_name)
        except Exception as e:
            self.logger.error(f"Get the sample name and model name of {self.project_name} from web database failed: {e}")
            self.logger.info("使用本地信息!!!")
            self.sample_name, self.model_name = split_sample_and_model(self.project_name)
        self.sample_table_in_name = self.sample_name + "_in"  # input table(view) name
        self.sample_table_out_name = self.sample_name + "_out"  # output table(view) name
        
        if self.ts_db_client.is_table_exist(self.sample_table_out_name):
            self.out_db_client = self.ts_db_client
        else:
            self.out_db_client = database_builder(self.dbconfig["mssql"]["quality"])
        
        self.get_basic_info()

    def get_basic_info(self) -> None:
        """
        Get basic information of the project
        """
        # Get model parameter
        # If local model parameter exists, then read local model parameter,
        # else read from web database
        model_parameter_path = Path(f"resource/model_parameter/{self.model_name}/model_config.toml")
        if model_parameter_path.exists():
            self.model_parameter = read_model_parameter_toml(model_parameter_path)
            self.algorithm_name = self.model_parameter["algorithm_name"]
        else:
            self.algorithm_name, self.model_parameter = self.web_mssql_client.get_model_parameter(self.model_name)

        # Get model path and model name according to project name in database   
        self.model_path = Path("resource", "models", self.project_name, "checkpoint.pth")
        self.model = build_model(self.algorithm_name, self.model_parameter)
        self.model.load_state_dict(torch.load(self.model_path, map_location=self.device, weights_only=True))
        self.model.to(self.device)

        # normalization parameter of x
        self.scaler_x_path = Path("resource", "scaler", self.project_name, "scaler_x.pkl")
        # normalization parameter of y
        self.scaler_y_path = Path("resource", "scaler", self.project_name, "scaler_y.pkl")
        # load scaler_x
        with open(self.scaler_x_path, "rb") as f:
            self.scaler_x = pickle.load(f)
        # load scaler_y
        with open(self.scaler_y_path, "rb") as f:
            self.scaler_y = pickle.load(f)

        # parameter about realtime predict
        self.pred_len = self.model_parameter["pred_len"]
        self.pred_len_str = str(self.pred_len) + "分钟预测值"
        self.pred_time = self.pred_len * datetime.timedelta(minutes=1)

        # Determine whether real-time prediction is required based on datetime
        self.datetime_past = datetime.datetime.now()

        # feed amount column_name 
        self.feed_amount_column_name = self.ts_db_client.get_feed_amount_column_name(self.sample_table_in_name)

        # get sample table information
        try:
            self.sample_table_information = self.web_db_client.get_sample_table_information(self.sample_name)
        except Exception as e:
            self.logger.error(f"Get sample table information from web mssql database failed: {e}")
            self.logger.error(f"Please check the sample name {self.sample_name} in web mssql database!!!")
            raise e
        
        # get input name list(input variable name list)  
        try:
            input_name_str = self.sample_table_information["column_namein"][0]
            self.input_name_list = name_list_parser(input_name_str)
            self.logger.info(f"Get input name list from sample table information successfully:{self.input_name_list}")
        except Exception as e:
            self.logger.error(f"Get input name list from sample table information failed: {e}")
            self.logger.error(f"Please check the sample table information of {self.sample_name}!!!")
            raise e
        
        # get output name list(output variable name list)
        try:
            output_name_str = self.sample_table_information["column_nameout"][0]
            self.output_name_list = name_list_parser(output_name_str)
            self.logger.info(f"Get output name list from sample table information successfully:{self.output_name_list}")
        except Exception as e:
            self.logger.error(f"Get output name list from sample table information failed: {e}")
            self.logger.error(f"Please check the sample table information of {self.sample_name}!!!")
            raise e
    
    def main(self) -> None:
        # Main realtime prediction pipeline
        current_time = datetime.datetime.now()

        # Get the latest input data from database
        try:
            # pred_input = self.ts_db_client.get_latest_input_data(self.sample_table_in_name)
            pred_input = self.ts_db_client.get_latest_input_data_by_column(self.input_name_list)
            self.logger.info(f"Get the latest input data from database successfully:{pred_input}")
            self.logger.info(f"column name:{pred_input.columns}")
        except pyodbc.Error as e:
            self.logger.error(f"Get the latest input data from database failed: {e}")
            self.ts_db_client.connect_db()
            self.logger.info("Reconnect to the database successfully!!!")
            pred_input = self.ts_db_client.get_latest_input_data_by_column(self.input_name_list)
            self.logger.info(f"Get the latest input data from database successfully:{pred_input}")
            self.logger.info(f"column name:{pred_input.columns}")
            # raise InputDataError(f"Error: {e}")
        except Exception as e:
            # raise InputDataError(f"Error: {e}")
            self.logger.error(f"Get the latest input data from database failed: {e}")
        
        # 输入数据预处理
        # 分钟均值
        self.logger.debug(f"before calculate_minute_average: {pred_input}")
        pred_input = calculate_minute_average(pred_input)
        pred_input = pred_input.tail(self.model_parameter_dict[self.project_name]["x_length"])
        self.logger.debug(f"after calculate_minute_average: {pred_input}")

        # judge if the device is running
        device_status = check_device_status(pred_input, self.feed_amount_column_name)
        # if device is running, then start realtime predict
        if device_status:
            # Get the latest true value from database
            try:
                true_df = self.out_db_client.get_latest_true_value(self.sample_table_out_name)
                true_series_list = [true_df[col] for col in true_df.columns]
                true_data = [series.item() for series in true_series_list]
                true_time, true_value = true_data[0], true_data[1]  # true_time is the time of the latest true value
                self.logger.info(f"{self.project_name} 最新真实值时间：{true_time}，最新真实值：{true_value}")
            except Exception as e:
                # raise TrueValueError(f"Error: {e}")
                self.logger.error(f"Get the latest true value from database failed: {e}")
            # Transform the pred_input and true_value into the format of model input
            # Transform pred_input into torch
            try:
                pred_input = pred_input[:, 1:]  # 去除时间列
                pred_input = self.scaler_x.transform(pred_input)  # 将输入数据进行归一化
                pred_input = torch.tensor(pred_input).unsqueeze(0).float().to(self.device)
            except Exception as e:
                # raise TransformInputError(f"Error: {e}")
                self.logger.error(f"Transform the pred_input into torch failed: {e}")
            
            if self.update_flag:
                # Update the latest true value into the database according to the current_time format
                try:
                    self.realtime_db_client.update_realvalue(table_name=self.project_name, realvalue=true_value, time_real=true_time)
                except pyodbc.Error as e:
                    self.logger.error(
                        f"{self.project_name} update realtime value counters database failure {e}, please check realtime predict database status!!!")
                    self.realtime_db_client.reconnect_db()
                    raise UpdateDatabaseError(f"Error: {e}")
                except Exception as e:
                    raise UpdateDatabaseError(f"Error: {e}")
            else:
                self.logger.warning(f"{self.project_name}在{current_time}时刻不更新数据库中的真实值!!!")

            # running realtime predict using self.model
            try:
                with torch.no_grad():
                    pred_value = self.model(pred_input)  # 将pred_input送入模型进行预测
                pred_value = self.scaler_y.inverse_transform(pred_value.reshape(-1, 1).to(torch.device("cpu")))  # 将预测值进行反归一化
                time_predict = current_time + self.pred_time  # 当前预测值对应的时间
                time_predict = time_predict.strftime("%Y-%m-%d %H:%M:%S")  # 将时间格式转换为字符串
                self.logger.info(f"{self.project_name}在{time_predict}时刻的预测值为：{pred_value.item()}")
            except Exception as e:
                raise PredictError(f"Error: {e}")

            if self.update_flag:
                # write predict value into database
                try:
                    self.realtime_db_client.update_predictvalue(table_name=self.project_name, predictvalue=pred_value.item(),
                                                                time_predict=time_predict, pred_len_str=self.pred_len_str)
                except pyodbc.Error as e:
                    self.logger.error(
                        f"{self.project_name} update realtime predict value counters database Error:{e}, please check realtime predict database status!!!")
                    self.realtime_db_client.reconnect_db()
                    raise UpdatePredictValueError(f"Error: {e}")
                except Exception as e:
                    raise UpdatePredictValueError(f"Error: {e}")
            else:
                self.logger.warning(f"{self.project_name}在{current_time}时刻不更新数据库!!!")
        else:
            # self.logger.warning(f"Device {self.project_name} is not running at time:{current_time}, skip realtime predict.")
            self.logger.warning(f"{self.project_name}在{current_time}时刻关联的设备不在运行，跳过当前时刻的实时预测。")


class RealtimePredictorAll(ScheduledTask):
    """
    RealtimePredictor is a class for realtime prediction of electricity consumption/coal consumption and quality index 
    including 0(soft sensor)、3、5、30 mins prediction
    """
    def __init__(self, project_name: str, dbconfig: dict) -> None:
        super().__init__(project_name, dbconfig)
        self.task_type = "realtime_predict"
        self.project_name = project_name
        self.update_flag = False  # flag to indicate whether to update the database, default is True
        self.logger = get_logger(self.project_name, self.task_type)

        # database connections based on dbconfig
        self.web_db_client = database_builder(dbconfig["mssql"]["web"])
        self.ts_db_client = database_builder(dbconfig["mssql"]["timeseries"])
        self.realtime_db_client = database_builder(dbconfig["mssql"]["realtimepredict"])

        # Get all project names for realtime predict
        # besides the project name in list is set as key in vars dictionary
        self.project_name_list = []
        suffix_list = ["", "_pred3", "_pred5", "_pred30"]
        for suffix in suffix_list:
            self.project_name_list.append(self.project_name + suffix)
        self.logger.info(f"All project names for realtime predict: {self.project_name_list}")
        
        try:
            self.sample_name, self.model_name = self.web_db_client.get_prediction_info(self.project_name)
        except Exception as e:
            self.logger.error(f"Get the sample name and model name of {self.project_name} from web database failed: {e}")
            self.logger.info("使用本地信息!!!")
            self.sample_name, self.model_name = split_sample_and_model(self.project_name)
        self.sample_table_in_name = self.sample_name + "_in"  # input table(view) name
        self.sample_table_out_name = self.sample_name + "_out"  # output table(view) name

        if self.ts_db_client.is_table_exist(self.sample_table_out_name):
            self.out_db_client = self.ts_db_client
        else:
            self.out_db_client = database_builder(self.dbconfig["mssql"]["quality"])

        # init sample name dictionary, algorithm name dictionary, sample table dictionary, model parameter dictionary, model dictionary
        self.sample_name_dict = {}  # project_name对应的样本表名称
        self.model_name_dict = {}  # project_name对应的模型名称
        self.algorithm_name_dict = {}  # project_name对应的算法名称
        self.model_parameter_dict = {}  # project_name对应的模型参数
        self.model_dict = {}  # project_name对应的模型
        self.sample_table_in_name_dict = {}  # project_name对应的输入样本表名称
        self.sample_table_out_name_dict = {}  # project_name对应的输出样本表名称
        self.scaler_x_dict = {}  # project_name对应的输入归一化参数
        self.scaler_y_dict = {}  # project_name对应的输出归一化参数
        self.pred_len_str_dict = {}  # project_name对应的预测长度字符串
        self.pred_time_dict = {}  # project_name对应的预测时间
        
        self.get_basic_info()

        self.logger.info(f"{self.project_name_list} 的预测信息获取完毕, 可以进行实时预测!!!")

    def get_basic_info(self) -> None:
        """
        Get basic information of each project
        """
        for project_name in self.project_name_list:
            self.logger.info(f"正在获取{project_name}的基本信息...")
            # Get sample name and model name
            try:
                sample_name, model_name = self.web_db_client.get_prediction_info(project_name)
            except Exception as e:
                self.logger.error(f"Get the sample name and model name of {project_name} from web database failed: {e}")
                self.logger.info("使用本地信息!!!")
                sample_name, model_name = split_sample_and_model(project_name)
            self.sample_name_dict[project_name] = sample_name
            self.model_name_dict[project_name] = model_name
            self.logger.info(f"{project_name}的样本名称：{sample_name}，模型名称：{model_name}")

            # Get sample table in name and sample table out name
            sample_table_in_name = sample_name + "_in"
            sample_table_out_name = sample_name + "_out"
            self.sample_table_in_name_dict[project_name] = sample_table_in_name
            self.sample_table_out_name_dict[project_name] = sample_table_out_name
            self.logger.info(f"{project_name}的输入样本表名称：{sample_table_in_name}，输出样本表名称：{sample_table_out_name}")
            # Get model parameter
            # If local model parameter exists, then read local model parameter,
            # else read from web database
            model_parameter_path = Path(f"resource/model_parameter/{model_name}/model_config.toml")
            if model_parameter_path.exists():
                self.model_parameter_dict[project_name] = read_model_parameter_toml(model_parameter_path)
                self.algorithm_name_dict[project_name] = self.model_parameter_dict[project_name]["algorithm_name"]
            else:
                self.algorithm_name_dict[project_name], self.model_parameter_dict[project_name] = self.web_db_client.get_model_parameter(model_name)
            self.logger.info(f"{project_name}的算法名称：{self.algorithm_name_dict[project_name]}，模型参数：{self.model_parameter_dict[project_name]}")

            # initialize model
            model_path = Path("resource", "models", project_name, "checkpoint.pth")
            model = build_model(self.algorithm_name_dict[project_name], self.model_parameter_dict[project_name])
            model.load_state_dict(torch.load(model_path, map_location=self.device, weights_only=True))
            model.to(self.device)
            self.model_dict[project_name] = model
            self.logger.info(f"{project_name}的模型初始化完毕")
            # load the normalization parameter
            scaler_x_path = Path("resource", "scaler", project_name, "scaler_x.pkl")
            scaler_y_path = Path("resource", "scaler", project_name, "scaler_y.pkl")
            with open(scaler_x_path, "rb") as f:
                self.scaler_x_dict[project_name] = pickle.load(f)
            with open(scaler_y_path, "rb") as f:
                self.scaler_y_dict[project_name] = pickle.load(f)

            # get the prediction length and prediction time
            self.pred_len_str_dict[project_name] = str(self.model_parameter_dict[project_name]["pred_len"]) + "分钟预测值"
            self.pred_time_dict[project_name] = self.model_parameter_dict[project_name]["pred_len"] * datetime.timedelta(minutes=1)
            self.logger.info(f"{project_name}的预测长度字符串：{self.pred_len_str_dict[project_name]}，预测时间：{self.pred_time_dict[project_name]}")
        self.logger.info("所有项目的基本信息获取完毕，可以进行实时预测!!!")

        # Determine whether real-time prediction is required based on datetime
        self.datetime_past = datetime.datetime.now()

        # feed amount column_name 
        self.feed_amount_column_name = self.ts_db_client.get_feed_amount_column_name(self.sample_table_in_name)
    
    def main(self) -> None:
        # Main realtime prediction pipeline
        current_time = datetime.datetime.now()

        # Get the latest input data from database
        try:
            pred_input = self.ts_db_client.get_latest_input_data(self.sample_table_in_name)
        except Exception as e:
            self.logger.error(f"Get the latest input data from database failed: {e}")
            raise InputDataError(f"Error: {e}")
            
        # 输入数据预处理
        # 分钟均值
        self.logger.debug(f"before calculate_minute_average: {pred_input}")
        pred_input = calculate_minute_average(pred_input)
        pred_input = pred_input.tail(self.model_parameter_dict[self.project_name]["x_length"])
        self.logger.debug(f"after calculate_minute_average: {pred_input}")

        # judge if the device is running
        device_status = check_device_status(pred_input, self.feed_amount_column_name)
        # if device is running, then start realtime predict
        if device_status:
            # Get the latest true value from database
            try:
                true_df = self.out_db_client.get_latest_true_value(self.sample_table_out_name)
                true_series_list = [true_df[col] for col in true_df.columns]
                true_data = [series.item() for series in true_series_list]
                true_time, true_value = true_data[0], true_data[1]  # true_time is the time of the latest true value
                self.logger.info(f"{self.project_name} 最新真实值时间：{true_time}，最新真实值：{true_value}")
            except Exception as e:
                raise TrueValueError(f"Error: {e}")

            # Transform the pred_input and true_value into the format of model input
            # Transform pred_input into torch
            try:
                pred_input = pred_input[:, 1:]  # 去除时间列
                pred_input = self.scaler_x_dict[self.project_name].transform(pred_input)  # 将输入数据进行归一化
                pred_input = torch.tensor(pred_input).unsqueeze(0).float().to(self.device)
            except Exception as e:
                raise TransformInputError(f"Error: {e}")

            # Update the latest true value into the database according to the current_time format
            if self.update_flag:
                try:
                    self.realtime_db_client.update_realvalue(table_name=self.project_name, realvalue=true_value, time_real=true_time)
                except pyodbc.Error as e:
                    self.logger.error(
                        f"{self.project_name} update realtime value counters database failure {e}, please check realtime predict database status!!!")
                    self.realtime_db_client.reconnect_db()
                    raise UpdateDatabaseError(f"Error: {e}")
                except Exception as e:
                    raise UpdateDatabaseError(f"Error: {e}")
            else:
                self.logger.warning(f"{self.project_name}在{current_time}时刻不更新数据库中的真实值!!!")

            # 循环计算每一个模型实时预测值，并写入数据库
            for project_name in self.project_name_list:
                # running realtime predict using self.model
                try:
                    with torch.no_grad():
                        self.logger.info(f"pred_input: {pred_input.shape}")
                        pred_value = self.model_dict[project_name](pred_input)  # 将pred_input送入模型进行预测
                    pred_value = self.scaler_y_dict[project_name].inverse_transform(pred_value.reshape(-1, 1).to(torch.device("cpu")))  # 将预测值进行反归一化
                    time_predict = current_time + self.pred_time_dict[project_name]  # 当前预测值对应的时间
                    time_predict = time_predict.strftime("%Y-%m-%d %H:%M:%S")  # 将时间格式转换为字符串
                    self.logger.info(f"{project_name}在{time_predict}时刻的预测值为：{pred_value.item()}")
                except Exception as e:
                    raise PredictError(f"Error: {e}")

                if self.update_flag:
                    # write predict value into database
                    try:
                        self.realtime_db_client.update_predictvalue(table_name=project_name, predictvalue=pred_value.item(),
                                                                    time_predict=time_predict, pred_len_str=self.pred_len_str_dict[project_name])
                    except pyodbc.Error as e:
                        self.logger.error(
                            f"{project_name} update realtime predict value counters database Error:{e}, please check realtime predict database status!!!")
                        self.realtime_db_client.reconnect_db()
                        raise UpdatePredictValueError(f"Error: {e}")
                    except Exception as e:
                        raise UpdatePredictValueError(f"Error: {e}")
                else:
                    self.logger.warning(f"{project_name}在{current_time}时刻不更新数据库!!!")
        else:
            self.logger.warning(f"Device {self.project_name} is not running at time:{current_time}, skip realtime predict.")


class TransformerRealtimePredictor(RealtimePredictor):
    """
    RealtimePredictor is a class for realtime prediction of transformer like model
    """
    def __init__(self, project_name: str, dbconfig: dict) -> None:
        super().__init__(project_name, dbconfig)
        self.task_type = "realtime_predict"
        self.project_name = project_name
        self.update_flag = False  # flag to indicate whether to update the database, default is True
        self.logger = get_logger(self.project_name, self.task_type)

        # database connections based on dbconfig
        self.web_db_client = database_builder(dbconfig["mssql"]["web"])
        self.ts_db_client = database_builder(dbconfig["mssql"]["timeseries"])
        self.realtime_db_client = database_builder(dbconfig["mssql"]["realtimepredict"])

        try:
            self.sample_name, self.model_name = self.web_db_client.get_prediction_info(self.project_name)
        except Exception as e:
            self.logger.error(f"Get the sample name and model name of {self.project_name} from web database failed: {e}")
            self.logger.info("使用本地信息!!!")
            self.sample_name, self.model_name = split_sample_and_model(self.project_name)
        self.sample_table_in_name = self.sample_name + "_in"  # input table(view) name
        self.sample_table_out_name = self.sample_name + "_out"  # output table(view) name
        
        if self.ts_db_client.is_table_exist(self.sample_table_out_name):
            self.out_db_client = self.ts_db_client
        else:
            self.out_db_client = database_builder(self.dbconfig["mssql"]["quality"])
        
        self.get_basic_info()

    def get_basic_info(self) -> None:
        """
        Get basic information of the project
        """
        # Get model parameter
        # If local model parameter exists, then read local model parameter,
        # else read from web database
        model_parameter_path = Path(f"resource/model_parameter/{self.model_name}/model_config.toml")
        if model_parameter_path.exists():
            self.model_parameter = read_model_parameter_toml(model_parameter_path)
            self.algorithm_name = self.model_parameter["algorithm_name"]
        else:
            self.algorithm_name, self.model_parameter = self.web_mssql_client.get_model_parameter(self.model_name)

        # Get model path and model name according to project name in database   
        self.model_path = Path("resource", "models", self.project_name, "checkpoint.pth")
        self.model = build_model(self.algorithm_name, self.model_parameter)
        self.model.load_state_dict(torch.load(self.model_path, map_location=self.device, weights_only=True))
        self.model.to(self.device)

        # normalization parameter of x
        self.scaler_x_path = Path("resource", "scaler", self.project_name, "scaler_x.pkl")
        # normalization parameter of y
        self.scaler_y_path = Path("resource", "scaler", self.project_name, "scaler_y.pkl")
        # load scaler_x
        with open(self.scaler_x_path, "rb") as f:
            self.scaler_x = pickle.load(f)
        # load scaler_y
        with open(self.scaler_y_path, "rb") as f:
            self.scaler_y = pickle.load(f)

        # parameter about realtime predict
        self.pred_len = self.model_parameter["pred_len"]
        self.pred_len_str = str(self.pred_len) + "分钟预测值"
        self.pred_time = self.pred_len * datetime.timedelta(minutes=1)

        # Determine whether real-time prediction is required based on datetime
        self.datetime_past = datetime.datetime.now()

        # feed amount column_name 
        self.feed_amount_column_name = self.ts_db_client.get_feed_amount_column_name(self.sample_table_in_name)

        # get sample table information
        try:
            self.sample_table_information = self.web_db_client.get_sample_table_information(self.sample_name)
        except Exception as e:
            self.logger.error(f"Get sample table information from web mssql database failed: {e}")
            self.logger.error(f"Please check the sample name {self.sample_name} in web mssql database!!!")
            raise e
        
        # get input name list(input variable name list)  
        try:
            input_name_str = self.sample_table_information["column_namein"][0]
            self.input_name_list = name_list_parser(input_name_str)
            self.logger.info(f"Get input name list from sample table information successfully:{self.input_name_list}")
        except Exception as e:
            self.logger.error(f"Get input name list from sample table information failed: {e}")
            self.logger.error(f"Please check the sample table information of {self.sample_name}!!!")
            raise e
        
        # get output name list(output variable name list)
        try:
            output_name_str = self.sample_table_information["column_nameout"][0]
            self.output_name_list = name_list_parser(output_name_str)
            self.logger.info(f"Get output name list from sample table information successfully:{self.output_name_list}")
        except Exception as e:
            self.logger.error(f"Get output name list from sample table information failed: {e}")
            self.logger.error(f"Please check the sample table information of {self.sample_name}!!!")
            raise e
    
    def main(self) -> None:
        # Main realtime prediction pipeline
        current_time = datetime.datetime.now()

        # Get the latest input data from database
        try:
            # pred_input = self.ts_db_client.get_latest_input_data(self.sample_table_in_name)
            pred_input = self.ts_db_client.get_latest_input_data_by_column_time(self.input_name_list, self.pred_len * 6)
            self.logger.info(f"Get the latest input data from database successfully:{pred_input}")
            self.logger.info(f"column name:{pred_input.columns}")
        except pyodbc.Error as e:
            self.logger.error(f"Get the latest input data from database failed: {e}")
            self.ts_db_client.connect_db()
            self.logger.info("Reconnect to the database successfully!!!")
            pred_input = self.ts_db_client.get_latest_input_data_by_column(self.input_name_list)
            self.logger.info(f"Get the latest input data from database successfully:{pred_input}")
            self.logger.info(f"column name:{pred_input.columns}")
            # raise InputDataError(f"Error: {e}")
        except Exception as e:
            # raise InputDataError(f"Error: {e}")
            self.logger.error(f"Get the latest input data from database failed: {e}")
        
        # 输入数据预处理
        # 分钟均值
        self.logger.debug(f"before calculate_minute_average: {pred_input}")
        pred_input = calculate_minute_average(pred_input)
        pred_input = pred_input.tail(self.model_parameter_dict[self.project_name]["x_length"])
        self.logger.debug(f"after calculate_minute_average: {pred_input}")

        # judge if the device is running
        device_status = check_device_status(pred_input, self.feed_amount_column_name)
        # if device is running, then start realtime predict
        if device_status:
            # Get the latest true value from database
            try:
                true_df = self.out_db_client.get_latest_true_value(self.sample_table_out_name)
                true_series_list = [true_df[col] for col in true_df.columns]
                true_data = [series.item() for series in true_series_list]
                true_time, true_value = true_data[0], true_data[1]  # true_time is the time of the latest true value
                self.logger.info(f"{self.project_name} 最新真实值时间：{true_time}，最新真实值：{true_value}")
            except Exception as e:
                # raise TrueValueError(f"Error: {e}")
                self.logger.error(f"Get the latest true value from database failed: {e}")
            # Transform the pred_input and true_value into the format of model input
            # Transform pred_input into torch
            try:
                pred_input = pred_input[:, 1:]  # 去除时间列
                pred_input = self.scaler_x.transform(pred_input)  # 将输入数据进行归一化
                pred_input = torch.tensor(pred_input).unsqueeze(0).float().to(self.device)
            except Exception as e:
                # raise TransformInputError(f"Error: {e}")
                self.logger.error(f"Transform the pred_input into torch failed: {e}")
            
            if self.update_flag:
                # Update the latest true value into the database according to the current_time format
                try:
                    self.realtime_db_client.update_realvalue(table_name=self.project_name, realvalue=true_value, time_real=true_time)
                except pyodbc.Error as e:
                    self.logger.error(
                        f"{self.project_name} update realtime value counters database failure {e}, please check realtime predict database status!!!")
                    self.realtime_db_client.reconnect_db()
                    raise UpdateDatabaseError(f"Error: {e}")
                except Exception as e:
                    raise UpdateDatabaseError(f"Error: {e}")
            else:
                self.logger.warning(f"{self.project_name}在{current_time}时刻不更新数据库中的真实值!!!")

            # running realtime predict using self.model
            try:
                with torch.no_grad():
                    pred_value = self.model(pred_input)  # 将pred_input送入模型进行预测
                pred_value = self.scaler_y.inverse_transform(pred_value.reshape(-1, 1).to(torch.device("cpu")))  # 将预测值进行反归一化
                time_predict = current_time + self.pred_time  # 当前预测值对应的时间
                time_predict = time_predict.strftime("%Y-%m-%d %H:%M:%S")  # 将时间格式转换为字符串
                self.logger.info(f"{self.project_name}在{time_predict}时刻的预测值为：{pred_value.item()}")
            except Exception as e:
                raise PredictError(f"Error: {e}")

            if self.update_flag:
                # write predict value into database
                try:
                    self.realtime_db_client.update_predictvalue(table_name=self.project_name, predictvalue=pred_value.item(),
                                                                time_predict=time_predict, pred_len_str=self.pred_len_str)
                except pyodbc.Error as e:
                    self.logger.error(
                        f"{self.project_name} update realtime predict value counters database Error:{e}, please check realtime predict database status!!!")
                    self.realtime_db_client.reconnect_db()
                    raise UpdatePredictValueError(f"Error: {e}")
                except Exception as e:
                    raise UpdatePredictValueError(f"Error: {e}")
            else:
                self.logger.warning(f"{self.project_name}在{current_time}时刻不更新数据库!!!")
        else:
            # self.logger.warning(f"Device {self.project_name} is not running at time:{current_time}, skip realtime predict.")
            self.logger.warning(f"{self.project_name}在{current_time}时刻关联的设备不在运行，跳过当前时刻的实时预测。")
