import torch.nn as nn


class CRNN(nn.Module):
    def __init__(self, configs):
        super(CRNN, self).__init__()

        self.feature_size = configs.feature_size
        
        # Convolutional layers
        self.conv1 = nn.Sequential(
            nn.Conv1d(self.feature_size, 256, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm1d(256),
            nn.ELU(alpha=0.2)
        )
        
        self.conv2 = nn.Sequential(
            nn.Conv1d(256, 128, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm1d(128),
            nn.ELU(alpha=0.2)
        )
        
        # Bidirectional LSTM layers
        self.lstm1 = nn.LSTM(
            input_size=128, 
            hidden_size=128, 
            num_layers=2, 
            batch_first=True, 
            bidirectional=True
        )
        
        self.lstm2 = nn.LSTM(
            input_size=128, 
            hidden_size=128, 
            num_layers=2, 
            batch_first=True, 
            bidirectional=True
        )
        
        # Final dense layer
        self.fc = nn.Linear(256, 1)
        
    def forward(self, x):
        # Convolutional layers
        x = x.permute(0, 2, 1)  # Change to (batch, features, timesteps)
        x = self.conv1(x)
        x = self.conv2(x)
        
        # Prepare for LSTM
        x = x.permute(0, 2, 1)  # Change to (batch, timesteps, features)
        
        # LSTM layers
        x, _ = self.lstm1(x)
        x, _ = self.lstm2(x)
        
        # Take the last time step
        x = x[:, -1, :]
        
        # Final prediction
        x = self.fc(x)
        
        return x