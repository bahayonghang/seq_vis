from dataclasses import dataclass

# 设置plant: 合川|三友
PLANT = "合川"

match PLANT:
    case "合川":
        # 需要写入decision_consistency表的能耗列表
        ENERGY_CONSUMPTION_LIST = ["生料A磨电耗", "生料B磨电耗", "熟料电耗", "熟料实物煤耗", "煤磨电耗",
                                    "水泥A磨电耗", "水泥B磨电耗"]
        # 项目相关的运行状态变量
        @dataclass
        class ProjectOperationStatus:
            # 实时预测项目
            原料A磨电耗样本_原料A磨电耗样本_CNN: str = "原料A磨运行状态"
            原料A磨生料细度样本_原料A磨生料细度样本_CNN: str = "原料A磨运行状态"
            原料B磨电耗样本_原料B磨电耗样本_CNN: str = "原料B磨运行状态"
            原料B磨生料细度样本_原料B磨生料细度样本_CNN: str = "原料B磨运行状态"
            回转窑电耗样本_回转窑电耗样本_CNN: str = "窑系统运行状态"
            回转窑煤耗样本_回转窑煤耗样本_CNN: str = "窑系统运行状态"
            窑fcao样本_窑fcao样本_CNN: str = "窑系统运行状态"
            水泥A磨电耗样本_水泥A磨电耗样本_CNN: str = "水泥A磨运行状态"
            水泥A磨细度样本_水泥A磨细度样本_CNN: str = "水泥A磨运行状态"
            水泥A磨比表面积样本_水泥A磨比表面积样本_CNN: str = "水泥A磨运行状态"
            水泥B磨电耗样本_水泥B磨电耗样本_CNN: str = "水泥B磨运行状态"
            水泥B磨细度样本_水泥B磨细度样本_CNN: str = "水泥B磨运行状态"
            水泥B磨比表面积样本_水泥B磨比表面积样本_CNN: str = "水泥B磨运行状态"
            # 优化决策项目
            原料A磨: str = "原料A磨运行状态"
            原料B磨: str = "原料B磨运行状态"
            窑系统: str = "窑系统运行状态"
            煤磨: str = "煤磨运行状态"
            水泥A磨: str = "水泥A磨运行状态"
            水泥B磨: str = "水泥B磨运行状态" 
    case "三友":
        ENERGY_CONSUMPTION_LIST = ["原料A磨单位电耗", "原料B磨单位电耗", "窑系统单位电耗", "吨熟料实物煤耗", 
                                    "煤磨电耗", "水泥A磨单位电耗", "水泥B磨单位电耗"]
        # 项目相关的运行状态变量
        @dataclass
        class ProjectOperationStatus:
            # 实时预测项目
            原料A磨电耗样本_原料A磨电耗样本_CNN: str = "原料A磨运行状态"
            原料A磨生料细度样本_原料A磨生料细度样本_CNN: str = "原料A磨运行状态"
            原料B磨电耗样本_原料B磨电耗样本_CNN: str = "原料B磨运行状态"
            原料B磨生料细度样本_原料B磨生料细度样本_CNN: str = "原料B磨运行状态"
            回转窑电耗样本_回转窑电耗样本_CNN: str = "窑系统运行状态"
            回转窑煤耗样本_回转窑煤耗样本_CNN: str = "窑系统运行状态"
            窑fcao样本_窑fcao样本_CNN: str = "窑系统运行状态"
            水泥A磨电耗样本_水泥A磨电耗样本_CNN: str = "水泥A磨运行状态"
            水泥A磨细度样本_水泥A磨细度样本_CNN: str = "水泥A磨运行状态"
            水泥A磨比表面积样本_水泥A磨比表面积样本_CNN: str = "水泥A磨运行状态"
            水泥B磨电耗样本_水泥B磨电耗样本_CNN: str = "水泥B磨运行状态"
            水泥B磨细度样本_水泥B磨细度样本_CNN: str = "水泥B磨运行状态"
            水泥B磨比表面积样本_水泥B磨比表面积样本_CNN: str = "水泥B磨运行状态"
            # 优化决策项目
            原料A磨: str = "原料A磨运行状态"
            原料B磨: str = "原料B磨运行状态"
            窑系统: str = "窑系统运行状态"
            煤磨: str = "煤磨运行状态"
            水泥A磨: str = "水泥A磨运行状态"
            水泥B磨: str = "水泥B磨运行状态" 
