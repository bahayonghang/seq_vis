import re
import torch
import uuid

from abc import abstractmethod, ABC
from typing import Optional

# from industrytslib.utils.logutils import get_logger


class ScheduledTask(ABC):
    """
    Base class for scheduled tasks.
    """
    def __init__(self, project_name: str, dbconfig: dict) -> None:
        self.project_name = project_name
        self.task_type = None
        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        # self.logger = get_logger(self.project_name, self.task_type)
        self.dbconfig = dbconfig
        self.uuid = uuid.uuid4()

    @abstractmethod
    def main(self) -> None:
        """
        Main function for the scheduled task.
        """
        raise NotImplementedError("Task main function is not implemented!!!")

    @staticmethod
    def extract_number(time_str: str) -> Optional[int]:
        match = re.match(r'(\d+)min', time_str)
        if match:
            return int(match.group(1))
        return None
    
    def clean_up(self) -> None:
        """
        Clean up the task.
        """
        print(f"Clean up the task: {self.project_name}.")
    

class AsyncScheduledTask(ScheduledTask):
    """
    Base class for scheduled tasks.
    """
    def __init__(self, project_name: str, dbconfig: dict) -> None:
        self.project_name = project_name
        self.task_type = None
        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        # self.logger = get_logger(self.project_name, self.task_type)
        self.dbconfig = dbconfig

    @abstractmethod
    async def main(self) -> None:
        """
        Main function for the scheduled task.
        """
        raise NotImplementedError("Task main function is not implemented!!!")
    
    def clean_up(self) -> None:
        """
        Clean up the async task.
        """
        print(f"Clean up the async task: {self.project_name}.")

# define realtime predict exception
class RealtimePredictError(Exception):
    pass


class InputDataError(RealtimePredictError):
    def __init__(self, message="Get realtime input data from time series database failed."):
        self.message = message
        super().__init__(self.message)


class TrueValueError(RealtimePredictError):
    def __init__(self, message="Get realtime true value from output database failed."):
        self.message = message
        super().__init__(self.message)


class TransformInputError(RealtimePredictError):
    def __init__(self, message="Transform realtime input data into torch failed."):
        self.message = message
        super().__init__(self.message)


class UpdateDatabaseError(RealtimePredictError):
    def __init__(self, message="Update realtime value counters database failed."):
        self.message = message
        super().__init__(self.message)


class PredictError(RealtimePredictError):
    def __init__(self, message="Predict realtime value using model failed."):
        self.message = message
        super().__init__(self.message)


class UpdatePredictValueError(RealtimePredictError):
    def __init__(self, message="Update realtime predict value counters database failed."):
        self.message = message
        super().__init__(self.message)