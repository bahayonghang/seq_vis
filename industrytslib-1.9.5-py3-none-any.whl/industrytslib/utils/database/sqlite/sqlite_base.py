import sqlite3

import polars as pl

from industrytslib.utils.database.base import Database
from industrytslib.utils.logutils import get_logger


class SqliteConnection(Database):
    def __init__(self, config: dict):
        self.config = config
        self.logger = get_logger("SQLite")

        self.conn = sqlite3.connect(self.config["database"])
        self.cursor = self.conn.cursor()
        self.logger.info(f"SQLite Connect to {self.config['database']} Successfully!")

    def close(self) -> None:
        """
        close the connection to the database
        """
        self.cursor.close()
        self.conn.close()
        self.logger.info("SQLite Connection Closed!")

    def query(self, sql: str) -> pl.DataFrame:
        self.cursor.execute(sql)
        rows = self.cursor.fetchall()
        columns = [column[0] for column in self.cursor.description]
        df = pl.DataFrame({col: [row[i] for row in rows] for i, col in enumerate(columns)})
        return df
    
    def check_table_exists(self, table_name: str) -> bool:
        """
        check if the table exists
        """
        self.cursor.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name='{table_name}'")
        return self.cursor.fetchone() is not None
    