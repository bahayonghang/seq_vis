import datetime
import torch
import pickle

import polars as pl

from pathlib import Path

from industrytslib.models.aimodels import build_model
from industrytslib.utils.database import database_builder

from industrytslib.core.base import ScheduledTask
from industrytslib.utils.readconfig import read_model_parameter_toml
from industrytslib.utils.basefunc import split_sample_and_model, name_list_parser
from industrytslib.utils.logutils import get_logger
from industrytslib.utils.share.reader import ReadDataframe


class SequenceSoftPredictor(ScheduledTask):
    """
    SequenceSOftPredictor is a class for sequence soft prediction,
    which apply transformer model to predict the next value of the sequence used for quality index prediction

    统一使用准确度最高的软测量模型, 根据预测长度从sequence predict table中取输入数据, 然后滑动窗口计算预测值
    """
    def __init__(self, project_name: str, dbconfig: dict) -> None:
        super().__init__(project_name, dbconfig)
        self.task_type = "realtime_predict_sequence_soft"
        self.project_name = project_name
        self.update_flag = True  # flag to indicate whether to update the database, default is True
        self.logger = get_logger(self.project_name, self.task_type)
        self.read_dataframe = ReadDataframe()

        # !实际运行时请修正为online
        self.run_mode = "online"

        # database connections based on dbconfig
        self.web_db_client = database_builder(dbconfig["mssql"]["web"])
        self.ts_db_client = database_builder(dbconfig["mssql"]["timeseries"])
        self.realtime_db_client = database_builder(dbconfig["mssql"]["realtimepredictalter"])

        # check realtime predict table existence in database
        self.realtime_db_client.check_table(self.project_name)
        
        try:
            self.sample_name, self.model_name = self.web_db_client.get_prediction_info(self.project_name)
        except Exception as e:
            self.logger.error(f"Get the sample name and model name of {self.project_name} \
                              from web database failed: {e}")
            self.logger.info("使用本地信息!!!")
            self.sample_name, self.model_name = split_sample_and_model(self.project_name)
        self.sample_table_in_name = self.sample_name + "_in"  # input table(view) name
        self.sample_table_out_name = self.sample_name + "_out"  # output table(view) name
        
        self.get_basic_info()

        self.logger.info(f"{self.project_name} 的预测信息获取完毕, 可以进行实时预测!!!")

    def get_basic_info(self) -> None:
        """
        Get basic information of each project
        """
        # Get model parameter
        # If local model parameter exists, then read local model parameter,
        # else read from web database
        model_parameter_path = Path(f"resource/model_parameter/{self.model_name}/model_config.toml")
        if model_parameter_path.exists():
            self.model_parameter = read_model_parameter_toml(model_parameter_path)
            self.algorithm_name = self.model_parameter["algorithm_name"]
        else:
            self.algorithm_name, self.model_parameter = self.web_db_client.get_model_parameter(self.model_name)

        # Get model path and model name according to project name in database   
        self.model_path = Path("resource", "models", self.project_name, "checkpoint.pth")
        self.model = build_model(self.algorithm_name, self.model_parameter)
        self.model.load_state_dict(torch.load(self.model_path, map_location=self.device, weights_only=True))
        self.model.to(self.device)

        # normalization parameter of x
        self.scaler_x_path = Path("resource", "scaler", self.project_name, "scaler_x.pkl")
        # normalization parameter of y
        self.scaler_y_path = Path("resource", "scaler", self.project_name, "scaler_y.pkl")
        # load scaler_x
        with open(self.scaler_x_path, "rb") as f:
            self.scaler_x = pickle.load(f)
        # load scaler_y
        with open(self.scaler_y_path, "rb") as f:
            self.scaler_y = pickle.load(f)

        # 使用到的序列预测项目名称
        self.sequence_predict_project_name = self.model_parameter["sequence_predict_project_name"]

        # Determine whether real-time prediction is required based on datetime
        self.datetime_past = datetime.datetime.now()

        self.get_var_name_list()

    def get_var_name_list(self) -> None:
        """
        Get the input name list and output name list
        """
        # get sample table information
        try:
            self.sample_table_information = self.web_db_client.get_sample_table_information(self.sample_name)
        except Exception as e:
            self.logger.error(f"Get sample table information from web mssql database failed: {e}")
            self.logger.error(f"Please check the sample name {self.sample_name} in web mssql database!!!")
            raise e
        
        # get input name list(input variable name list)  
        try:
            input_name_str = self.sample_table_information["column_namein"][0]
            self.input_name_list = name_list_parser(input_name_str)
            self.input_name_list.insert(0, "DateTime")
            self.logger.info(f"""
                             Get input name list from sample table information successfully:
                             {self.input_name_list}
                            """)
        except Exception as e:
            self.logger.error(f"Get input name list from sample table information failed: {e}")
            self.logger.error(f"Please check the sample table information of {self.sample_name}!!!")
            raise e
        
        # get output name list(output variable name list)
        try:
            output_name_str = self.sample_table_information["column_nameout"][0]
            self.output_name_list = name_list_parser(output_name_str)
            self.logger.info(f"""
                             Get output name list from sample table information successfully:
                             {self.output_name_list}
                            """)
        except Exception as e:
            self.logger.error(f"Get output name list from sample table information failed: {e}")
            self.logger.error(f"Please check the sample table information of {self.sample_name}!!!")
            raise e
        
        # 从样本信息中获取当前设备在TagDatabase运行标志位
        try:
            self.device_operation_flag: str = self.sample_table_information["operationflag"].item()
            self.logger.info(f"{self.project_name}在TagDatabase的运行标志位为: {self.device_operation_flag}")
            # 彩色打印运行标志位信息
            print(f"\033[1;34m================{self.project_name}运行标志位：{self.device_operation_flag}=================\033[0m")
        except Exception as e:
            self.logger.error(f"Get device operation flag from sample table information failed: {e}")
            self.logger.error(f"Please check the sample table information of {self.sample_name}!!!")
            # raise e
            self.device_operation_flag = None
    
    def get_sliding_window_data(
            self, 
            pred_input: pl.DataFrame, 
            current_time: datetime.datetime
        ) -> list[pl.DataFrame]:
        """
        Get sliding window data from prediction input DataFrame.

        Args:
            pred_input: Input DataFrame containing DateTime column and feature columns
            current_time: Current timestamp to start sliding window from
        
        Returns:
            list[pl.DataFrame]: List of DataFrames containing all sliding windows
        
        Raises:
            ValueError: If current_time is not found in DataFrame or window size is invalid
        """
        # Find index of current_time in the DataFrame
        try:
            current_time_idx = pred_input.with_row_count().filter(
                pl.col("DateTime") == current_time
            ).select("row_nr").item()
        except Exception as e:
            raise ValueError(f"Current time {current_time} not found in input data: {e}")

        window_size = self.model_parameter["x_length"]
        if window_size > len(pred_input):
            raise ValueError(f"Window size {window_size} is larger than input data length {len(pred_input)}")

        # Calculate how many complete windows we can create
        max_windows = len(pred_input) - current_time_idx - window_size + 1
        if max_windows <= 0:
            raise ValueError("Not enough data points after current_time for a complete window")

        # Create sliding windows
        window_dfs = []
        for i in range(max_windows):
            start_idx = current_time_idx + i
            window = pred_input.slice(start_idx, window_size)
            window_dfs.append(window)

        # Concatenate all windows
        return window_dfs if window_dfs else []

    def main(self) -> None:
        # Main realtime prediction pipeline
        current_time = datetime.datetime.now().replace(second=0, microsecond=0)

        # judge if the device is running
        try:
            if self.device_operation_flag is None:
                device_status = True
                self.logger.warning(f"{self.project_name}没有运行标志位，默认设备运行!!!")
            else:
                if self.read_dataframe.read_dataframe_latest().is_empty():
                    device_status = self.ts_db_client.check_device_running_status(self.device_operation_flag)
                else:
                    device_status = self.read_dataframe.check_device_status(self.device_operation_flag)
        except Exception as e:
            self.logger.error(f"Check device status failed: {e}")
            if self.run_mode == "online":
                self.logger.warning("=================请检查数据库和数据采集软件工作是否正常!!!=================")
                # raise InputDataError(f"Error: {e}")
                return
            elif self.run_mode == "local":
                device_status = True

        print(f"\033[1;34m当前{self.project_name}运行状态为{device_status}\033[0m")

        # Get the latest input data from database
        try:
            pred_input = self.realtime_db_client.get_predict_data_by_table_name(self.sequence_predict_project_name)
            self.logger.info(f"Initial pred_input:\n{pred_input}")
            # 从pred_input中选择input_name_list中的列
            pred_input = pred_input.select(self.input_name_list)
            self.logger.info(f"pred_input:\n{pred_input}")

            # # !替代随机生成一个90*12的dataframe
            # enc_input = pl.DataFrame(np.random.rand(60, len(self.input_name_list)))
            # dec_input = pl.DataFrame(np.random.rand(30, len(self.input_name_list)))
            # enc_input.columns = self.input_name_list
            # dec_input.columns = self.input_name_list
            # # 在dec_input和enc_input中添加时间戳列
            # enc_input = add_datetime_column(enc_input, mode="backward")
            # dec_input = add_datetime_column(dec_input, mode="forward")
            # pred_input = pl.concat([enc_input, dec_input])
            # print(f"pred_input:\n{pred_input}")
        except Exception as e:
            self.logger.error(f"Get the latest input data from database failed: {e}")
            # raise InputDataError(f"Error: {e}")
        
        # 检测输入数据是否为空
        if pred_input.is_empty():
            self.logger.warning(f"当前时间{current_time}项目{self.project_name}输入数据为空，跳过实时预测!!!")
            self.logger.warning("=================请检查数据库和数据采集软件工作是否正常!!!=================")
            return
        
        # 根据current_time从pred_input循环读取长度为self.model_parameter["x_length"]的输入数据
        # !默认DateTime列按照时间正序排列
        # 首先在DateTime列找到current_time的索引
        try:
            current_time_index = pred_input.with_row_count().filter(
                pl.col("DateTime") == current_time
            ).select("row_nr").item()
            self.logger.info(f"current_time {current_time}的索引为: {current_time_index}")
        except Exception as e:
            self.logger.error(f"Cannot find current_time {current_time} in input data: {e}")
            return

        # 然后从当前索引开始滑动窗口并向后读取读取长度为self.model_parameter["x_length"]的输入数据
        window_size = self.model_parameter["x_length"]
        pred_input_list = []

        # 计算可以创建多少个完整窗口
        max_windows = len(pred_input) - current_time_index - 1
        self.logger.info(f"可以创建的完整窗口数量为: {max_windows}")
        if max_windows <= 0:
            self.logger.warning("Not enough data points after current_time for a complete window")
            return

        # 创建滑动窗口
        for i in range(max_windows):
            end_idx = current_time_index + i + 1
            start_idx = end_idx - window_size + 1
            window = pred_input.slice(start_idx, window_size)
            self.logger.info(f"window {i}:\n{window.shape}")
            pred_input_list.append(window)

        if not pred_input_list:
            self.logger.warning(f"No valid sliding windows could be created for {current_time}")
            return
        
        # 如果设备未运行，则将所有的预测值置为0
        if not device_status:
            for pred_input in pred_input_list:
                pred_time = pred_input.select(pl.col("DateTime")).row(-1)[0]
                if self.update_flag:    
                    # Update the latest true value into the database according to the current_time format
                    try:
                        self.realtime_db_client.update_predictvalue(
                            table_name=self.project_name, 
                            predictvalue=0, 
                            time_predict=pred_time
                        )
                    except Exception as e:
                        self.logger.error(f"Update the predict value into database failed: {e}")
            return
        
        for pred_input in pred_input_list:
            try:
                # 预测时间为pred_input的DateTime列的最后一行
                pred_time = pred_input.select(pl.col("DateTime")).row(-1)[0]
                pred_input = pred_input[:, 1:]  # 去除时间列
                pred_input = self.scaler_x.transform(pred_input)  # 将输入数据进行归一化
                pred_input = torch.tensor(pred_input).unsqueeze(0).float().to(self.device)
            except Exception as e:
                self.logger.error(f"Transform the pred_input into torch failed: {e}")
                continue

            try:
                with torch.no_grad():
                    pred_value = self.model(pred_input)
                pred_value = self.scaler_y.inverse_transform(pred_value.reshape(-1, 1).to(torch.device("cpu")))  # 将预测值进行反归一化
                self.logger.info(f"{self.project_name}在{pred_time}时刻的预测值为：{pred_value.item()}")
            except Exception as e:
                self.logger.error(f"Predict the value failed: {e}")
                continue

            if self.update_flag:    
                # Update the latest true value into the database according to the current_time format
                try:
                    self.realtime_db_client.update_predictvalue(
                        table_name=self.project_name, 
                        predictvalue=pred_value.item(), 
                        time_predict=pred_time
                    )
                except Exception as e:
                    self.logger.error(f"Update the predict value into database failed: {e}")

    def detect_production_periods(self, df: pl.DataFrame, max_gap: datetime.timedelta = datetime.timedelta(hours=2)) -> pl.DataFrame:
        """
        监测时间间隔，划分生产周期。

        Args:
            df: 包含DateTime列的DataFrame
            max_gap: 最大允许的时间间隔，超出此值则视为生产周期的中断

        Returns:
            pl.DataFrame: 包含生产周期ID的DataFrame
        """
        # 计算时间差
        time_diffs = df.with_columns([
            pl.col("DateTime").diff().alias("time_diff")
        ])
        
        # 创建生产周期ID
        period_changes = time_diffs.with_columns([
            (pl.col("time_diff") > pl.duration(nanoseconds=int(max_gap.total_seconds() * 1e9)))
            .cast(pl.Int32)
            .alias("period_change")
        ])
        
        # 计算累积和来生成周期ID（第一行的period_change设为0）
        production_periods = period_changes.with_columns([
            pl.col("period_change").fill_null(0).cumsum().alias("production_period")
        ])
        
        # 只保留原始列和production_period列
        result = production_periods.select([
            pl.all().exclude(["time_diff", "period_change"]),
            pl.col("production_period")
        ])
        
        return result
        
            