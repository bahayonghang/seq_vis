import torch
import subprocess

def get_gpu_memory_map():
    """
    获取每个 GPU 的显存使用情况。
    返回字典，key 为 GPU 的 id，value 为显存占用的百分比。
    
    Examples:
        >>> get_gpu_memory_map()
        {0: 10.5, 1: 20.3, 2: 30.2}
    """
    result = subprocess.run(
        ['nvidia-smi', '--query-gpu=index,memory.used,memory.total', '--format=csv,noheader,nounits'],
        stdout=subprocess.PIPE
    )
    output = result.stdout.decode('utf-8').strip().split('\n')
    
    gpu_memory_map = {}
    for line in output:
        gpu_id, mem_used, mem_total = map(int, line.split(', '))
        mem_util = (mem_used / mem_total) * 100  # 显存占用百分比
        gpu_memory_map[gpu_id] = mem_util
        print(f"GPU {gpu_id} 已分配显存: {mem_util}%")
    
    return gpu_memory_map

def select_least_used_gpu():
    """
    选择显存占用率最低的 GPU 并设置为当前 GPU 设备。
    
    Examples:
        >>> select_least_used_gpu()
        Using GPU: 0 with 10.5% memory usage.
    """
    gpu_memory_map = get_gpu_memory_map()
    least_used_gpu = min(gpu_memory_map, key=gpu_memory_map.get)  # 获取显存占用率最低的 GPU id
    torch.cuda.set_device(least_used_gpu)  # 设置当前使用的 GPU
    
    print(f"Using GPU: {least_used_gpu} with {gpu_memory_map[least_used_gpu]:.2f}% memory usage.")
    device = torch.device(f"cuda:{least_used_gpu}")
    return device

# 使用示例
if __name__ == "__main__":
    print(select_least_used_gpu())
    
