import numpy as np
import polars as pl

# 多目标优化算法
import pymoo.core.algorithm
from pymoo.algorithms.moo.moead import MOEAD
from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.algorithms.moo.nsga3 import NSGA3
# 单目标优化算法
from pymoo.algorithms.soo.nonconvex.de import DE
from pymoo.algorithms.soo.nonconvex.ga import GA
# 优化算子
from pymoo.decomposition.asf import ASF
from pymoo.operators.crossover.sbx import SBX
from pymoo.operators.mutation.pm import PM
from pymoo.operators.sampling.lhs import LHS
from pymoo.operators.sampling.rnd import FloatRandomSampling
from pymoo.util.ref_dirs import get_reference_directions


def select_single_objective_optimization_algorithm(algorithm_name: str, algorithm_parameter: pl.DataFrame) -> pymoo.core.algorithm.Algorithm:
    """
    选择单目标优化算法
    :param algorithm_name: 优化算法名称
    :param algorithm_parameter: 优化算法参数
    :return: 优化算法
    """
    match algorithm_name:
        case "GA":
            algorithm = GA(
                pop_size=algorithm_parameter["population_count"].item(),
                sampling=LHS(),
                mutation=PM(),
                crossover=SBX()
            )
        case "DE":
            algorithm = DE(
                pop_size=algorithm_parameter["population_count"].item(),
                variant="DE/rand/1/bin",
                CR=0.3,
                dither="vector",
                jitter=False
            )
        case _:
            print("Invalid optimization algorithm name")
            algorithm = DE(
                pop_size=algorithm_parameter["population_count"].item(),
                variant="DE/rand/1/bin",
                CR=0.3,
                dither="vector",
                jitter=False
            )
    return algorithm


def select_multi_objective_optimization_algorithm(algorithm_name: str, algorithm_parameter: pl.DataFrame) -> pymoo.core.algorithm.Algorithm:
    """
    选择多目标优化算法
    :param algorithm_name: 优化算法名称
    :param algorithm_parameter: 优化算法参数
    :return: 优化算法
    """
    match algorithm_name:
        case "NSGA2":
            algorithm = NSGA2(
                pop_size=algorithm_parameter["population_count"].item(),
                n_offsprings=algorithm_parameter["population_count"].item(),
                sampling=FloatRandomSampling(),
                crossover=SBX(prob=0.9, eta=15),
                mutation=PM(prob=0.1, eta=20),
                eliminate_duplicates=True
            )
        case "NSGA3":
            ref_dirs = get_reference_directions("das-dennis", 3, n_partitions=12)
            algorithm = NSGA3(
                pop_size=algorithm_parameter["population_count"].item(),
                ref_dirs=ref_dirs,
            )
        case "MOEA/D":
            ref_dirs = get_reference_directions("uniform", 3, n_partitions=12)
            algorithm = MOEAD(
                ref_dirs=ref_dirs,
                n_neighbors=15,
                prob_neighbor_mating=0.7
            )
        case _:
            print("Invalid optimization algorithm name")
            algorithm = NSGA2(
                pop_size=algorithm_parameter["population_count"].item(),
                n_offsprings=algorithm_parameter["population_count"].item(),
                sampling=FloatRandomSampling(),
                crossover=SBX(prob=0.9, eta=15),
                mutation=PM(prob=0.1, eta=20),
                eliminate_duplicates=True
            )
    return algorithm


def solution_selection(selection_type: str, solution) -> list:
    """
    根据选择类型从优化求解结果中选择最优解。

    Args:
        selection_type (str): 选择最优解的策略,支持"均衡"、"能耗"、"产量"
        solution (pymoo.core.result.Result): 优化求解的结果。

    Returns:
        list: 决策值列表,即最优解对应的X值。

    Raises:
        ValueError: 如果选择类型不是"均衡"或"产量",则抛出ValueError异常。
    """
    F = solution.F
    X = solution.X
    match selection_type:
        case "均衡":
            # 目标函数值归一化
            # fl = F.min(axis=0)
            # fu = F.max(axis=0)
            # print(f"Scale f1: [{fl[0]}, {fu[0]}]")
            # print(f"Scale f2: [{fl[1]}, {fu[1]}]")

            approx_ideal = F.min(axis=0)
            approx_nadir = F.max(axis=0)

            nF = (F - approx_ideal) / (approx_nadir - approx_ideal)

            # fl = nF.min(axis=0)
            # fu = nF.max(axis=0)
            # print(f"Scale f1: [{fl[0]}, {fu[0]}]")
            # print(f"Scale f2: [{fl[1]}, {fu[1]}]")
            decomp = ASF()
            if F.shape[1] == 2:
                weights = np.array([0.5, 0.5])
            else:
                weights = np.array([0.3, 0.3, 0.4])
            i = decomp.do(nF, 1 / weights).argmin()
            return X[i]
        case "产量":
            # 产量最大
            return X[np.argmax(F[:, 2])]
        case "能耗":
            # 能耗最小
            return X[np.argmin(F[:, 0])]
        case "质量":
            # 质量最优
            return X[np.argmax(F[:, 1])]
        case _:
            raise ValueError("选择的最优解策略不在已知的模式当中,请检查!!!")


def set_termination(termination_type: str) -> pymoo.core.termination.Termination:
    """
    设置优化算法的终止条件。

    Args:
        termination_type (str): "quick" or "slow"。

    Returns:
        pymoo.core.termination.Termination: 优化算法的终止条件。

    Raises:
        ValueError: 如果终止条件的类型不在"最大迭代次数"、"最大评估次数"、"最大时间"中,则抛出ValueError异常。
    """
    match termination_type:
        case "quick":
            termination = pymoo.termination.default.DefaultMultiObjectiveTermination(
                xtol=1e-6,
                cvtol=1e-4,
                ftol=0.0025,
                period=5,
                n_max_gen=50,
                n_max_evals=10000
            )
        case "slow":
            termination = pymoo.termination.default.DefaultMultiObjectiveTermination(
                xtol=1e-8,
                cvtol=1e-6,
                ftol=0.0025,
                period=10,
                n_max_gen=100,
                n_max_evals=10000
            )
        case _:
            print("Invalid termination type")
            termination = pymoo.termination.default.DefaultMultiObjectiveTermination(
                xtol=1e-6,
                cvtol=1e-4,
                ftol=0.0025,
                period=5,
                n_max_gen=50,
                n_max_evals=10000
            )
    return termination
