"""
Time series processing, including:
- empirical mode decomposition (EMD), 
- variational mode decomposition (VMD)
- wavelet transform (WT).
"""
from typing import Tuple, Optional, List, Union
import numpy as np
import matplotlib.pyplot as plt
from PyEMD import EMD
from sktime.libs.vmdpy import VMD
import pywt
from pathlib import Path

class TimeSeriesDecomposition:
    """
    A class for time series decomposition using various methods including EMD, VMD, and Wavelet Transform.
    
    This class provides methods to decompose time series data into different components
    using various decomposition techniques. It also includes visualization capabilities.

    Attributes:
        signal: The input time series signal
        sampling_rate: Sampling rate of the signal
        save_path: Path to save decomposition results
    """

    def __init__(
            self, 
            signal: np.ndarray,
            sampling_rate: float = 1.0,
            save_path: Optional[Union[str, Path]] = None
        ) -> None:
        """
        Initialize TimeSeriesDecomposition with input signal.

        Args:
            signal: Input time series data
            sampling_rate: Sampling rate of the signal in Hz
            save_path: Directory path to save decomposition results
        """
        self.signal = signal
        self.sampling_rate = sampling_rate
        self.save_path = Path(save_path) if save_path else Path.cwd()
        self._validate_input()

    def _validate_input(self) -> None:
        """
        Validate input signal data.

        Raises:
            ValueError: If signal is empty or contains invalid values
        """
        if len(self.signal) == 0:
            raise ValueError("Input signal is empty")
        if not np.isfinite(self.signal).all():
            raise ValueError("Signal contains invalid values (inf or nan)")

    def apply_emd(self) -> Tuple[np.ndarray, List[np.ndarray]]:
        """
        Apply Empirical Mode Decomposition (EMD) to the signal.

        Returns:
            Tuple containing:
                - Time points array
                - List of IMF arrays (Intrinsic Mode Functions)

        Raises:
            RuntimeError: If EMD decomposition fails
        """
        try:
            emd = EMD()
            imfs = emd(self.signal)
            time = np.arange(len(self.signal)) / self.sampling_rate
            return time, imfs
        except Exception as e:
            raise RuntimeError(f"EMD decomposition failed: {str(e)}")

    def apply_vmd(
            self, 
            alpha: float = 2000, 
            tau: float = 0.0, 
            K: int = 3, 
            DC: bool = False, 
            init: int = 1, 
            tol: float = 1e-7
        ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Apply Variational Mode Decomposition (VMD) to the signal.

        Args:
            alpha: Bandwidth constraint parameter
            tau: Noise-tolerance parameter
            K: Number of modes to extract
            DC: Include DC part if True
            init: Initialization method (1: uniform)
            tol: Convergence tolerance

        Returns:
            Tuple containing:
                - Decomposed modes
                - Frequency domain modes
                - Center frequencies of modes

        Raises:
            RuntimeError: If VMD decomposition fails
        """
        try:
            u, u_hat, omega = VMD(
                self.signal, 
                alpha, 
                tau, 
                K, 
                DC, 
                init, 
                tol
            )
            return u, u_hat, omega
        except Exception as e:
            raise RuntimeError(f"VMD decomposition failed: {str(e)}")

    def apply_wavelet(
            self, 
            wavelet: str = 'db4', 
            level: Optional[int] = None
        ) -> Tuple[List[np.ndarray], List[np.ndarray]]:
        """
        Apply Wavelet Transform decomposition to the signal.

        Args:
            wavelet: Wavelet type (e.g., 'db4', 'haar')
            level: Decomposition level (if None, automatically determined)

        Returns:
            Tuple containing:
                - List of coefficients arrays
                - List of details arrays

        Raises:
            RuntimeError: If wavelet decomposition fails
        """
        try:
            if level is None:
                level = pywt.dwt_max_level(len(self.signal), pywt.Wavelet(wavelet).dec_len)
            coeffs = pywt.wavedec(self.signal, wavelet, level=level)
            return coeffs, [np.zeros_like(c) for c in coeffs[1:]]
        except Exception as e:
            raise RuntimeError(f"Wavelet decomposition failed: {str(e)}")

    def plot_decomposition(
            self, 
            decomp_type: str, 
            components: np.ndarray,
            title: str = "Signal Decomposition",
            save: bool = True
        ) -> None:
        """
        Plot decomposition results.

        Args:
            decomp_type: Type of decomposition ('emd', 'vmd', or 'wavelet')
            components: Decomposed components to plot
            title: Plot title
            save: Whether to save the plot to file

        Raises:
            ValueError: If decomposition type is invalid
        """
        if decomp_type not in ['emd', 'vmd', 'wavelet']:
            raise ValueError(f"Invalid decomposition type: {decomp_type}")

        time = np.arange(len(self.signal)) / self.sampling_rate
        
        plt.figure(figsize=(12, 8))
        plt.subplot(components.shape[0] + 1, 1, 1)
        plt.plot(time, self.signal)
        plt.title("Original Signal")
        
        for i in range(components.shape[0]):
            plt.subplot(components.shape[0] + 1, 1, i + 2)
            plt.plot(time, components[i])
            plt.title(f"Component {i+1}")
        
        plt.tight_layout()
        
        if save:
            plt.savefig(self.save_path / f"{decomp_type}_decomposition.png")
        plt.close()
