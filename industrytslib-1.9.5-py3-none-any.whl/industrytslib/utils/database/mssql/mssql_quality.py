import datetime

import polars as pl

from .mssql_base import MSSQLConnection
from industrytslib.utils.logutils import get_logger

class MSSQLQuality(MSSQLConnection):
    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self.logger = get_logger("MSSQLQuality", "database")

    def get_output_data_train(self, output_table_name: str, begin_time: datetime.datetime, 
                              end_time: datetime.datetime) -> pl.DataFrame:
        """
        获取指定时间范围内的输出数据
        Args:
            output_table_name (str): 表名
            begin_time (str): 起始时间
            end_time (str): 结束时间
        Returns:
            pl.DataFrame: 输出数据
        """
        sql = f"""
            SELECT * FROM {output_table_name} 
            WHERE TagTime BETWEEN '{begin_time}' AND '{end_time}' order by TagTime
        """
        self.logger.info(f"Quality query sql: {sql}")
        rows = self.query(sql)
        return rows
    
    def get_output_data_history(self, output_table_name: str, begin_time: datetime.datetime, 
                                end_time: datetime.datetime) -> pl.DataFrame:
        """
        获取指定时间范围内的输出数据
        Args:
            output_table_name (str): 表名
            begin_time (str): 起始时间
            end_time (str): 结束时间
        Returns:
            pl.DataFrame: 输出数据
        """
        sql = f"""
            SELECT * FROM {output_table_name} 
            WHERE TagTime BETWEEN '{begin_time}' AND '{end_time}' order by TagTime
        """
        self.logger.info(f"Quality query sql: {sql}")
        rows = self.query(sql)
        return rows

    def get_latest_true_value(self, table_name: str) -> pl.DataFrame:
        """Get true value of latest quality data from quality database

        Args:
            table_name (str): table name

        Returns:
            pl.DataFrame: true value
        """
        # 获取最新的一条非Null数据（第二列非空）
        sql = f"""
            SELECT TOP (1) *
            FROM {table_name}
            WHERE TagTime IS NOT NULL
            AND (SELECT TOP 1 COLUMN_NAME 
                 FROM INFORMATION_SCHEMA.COLUMNS 
                 WHERE TABLE_NAME = '{table_name}'
                 AND COLUMN_NAME != 'TagTime') IS NOT NULL
            ORDER BY TagTime DESC
        """
        rows = self.query(sql)
        return rows
    
    def get_latest_true_value_quality_rt(self, table_name: str) -> pl.DataFrame:
        """
        获取实时预测的最新真实值,非null值
        """
        sql = f"""
            SELECT TOP (12) *
            FROM {table_name}
            WHERE TagTime IS NOT NULL
            AND (SELECT TOP 1 COLUMN_NAME 
                 FROM INFORMATION_SCHEMA.COLUMNS 
                 WHERE TABLE_NAME = '{table_name}'
                 AND COLUMN_NAME != 'TagTime') IS NOT NULL
            ORDER BY TagTime DESC
        """
        rows = self.query(sql)
        rows = rows.drop_nulls()
        return rows
    
    def get_latest_true_value_by_column(self, column_name: str) -> pl.DataFrame:
        """
        从质检表中获取指定列名的最新真实值
        """
        sql = f'''
            SELECT TOP (1) {column_name}
            FROM 样本检验结果
            WHERE DateTime BETWEEN DATEADD(HOUR, -6, GETDATE()) AND GETDATE()
            ORDER BY TagTime DESC
            '''
        rows = self.query(sql)
        return rows
    
    # ! 在线训练部分
    # 获取最新的在线训练数据
    def get_output_data_online(self, output_table_name: str) -> pl.DataFrame:
        """
        获取最新的在线训练数据,默认获取最近1个月的数据
        Args:
            output_table_name (str): 表名
        Returns:
            pl.DataFrame: 在线训练数据
        """
        sql = f"""
            SELECT * FROM {output_table_name} 
            WHERE TagTime BETWEEN DATEADD(MONTH, -1, GETDATE()) AND GETDATE()
            ORDER BY TagTime DESC
        """
        rows = self.query(sql)
        return rows
    