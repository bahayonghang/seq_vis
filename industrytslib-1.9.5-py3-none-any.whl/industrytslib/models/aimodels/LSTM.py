import torch
import torch.nn as nn


# 定义基础LSTM类
class LSTM1(nn.Module):
    def __init__(self, model_parameter):
        """
        基础LSTM类，各参数含义如下：
        :param model_parameter: 模型参数
        :param input_size: 输入数据的维度
        :param output_size: 输出数据的维度
        :param hidden_size: 隐藏层的维度
        :param num_layers: LSTM的层数
        :param batch_first: 是否将batch放在第一维度
        """
        super(LSTM1, self).__init__()
        self.input_size = model_parameter['input_size']
        self.output_size = model_parameter['output_size']
        self.hidden_size = model_parameter['hidden_size']
        self.num_layers = model_parameter['num_layers']
        self.num_directions = 1  # 单向LSTM
        self.batch_first = True

        self.lstm = nn.LSTM(self.input_size, self.hidden_size, self.num_layers, batch_first=self.batch_first)
        self.fc_1 = nn.Linear(self.hidden_size, 64)
        self.fc_2 = nn.Linear(64, 16)
        self.out = nn.Linear(16, self.output_size)

        self.relu = nn.LeakyReLU()
        self.sigmoid = nn.Sigmoid()
        self.dropout = nn.Dropout(model_parameter["dropout"])

    def forward(self, x):
        # x: [batch_size, seq_len, input_size]
        # h0: [num_layers, batch_size, hidden_size]
        # c0: [num_layers, batch_size, hidden_size]
        h0 = torch.randn(self.num_directions * self.num_layers, x.size(0), self.hidden_size, device=x.device).float()
        c0 = torch.randn(self.num_directions * self.num_layers, x.size(0), self.hidden_size, device=x.device).float()
        # out: [batch_size, seq_len, hidden_size]
        # h_n: [num_layers, batch_size, hidden_size]
        # c_n: [num_layers, batch_size, hidden_size]
        ula, (h_out, c_out) = self.lstm(x, (h0, c0))
        # ula, (h_out, _) = self.lstm(x)
        # out: [batch_size, hidden_size]
        # h_out = h_out.view(-1, self.hidden_size)
        # out = self.linear(h_out)
        # out = out.squeeze()
        # h_out = h_out.view(-1, self.hidden_size)

        out = self.relu(self.fc_1(ula))
        out = self.sigmoid(self.fc_2(out))
        out = self.dropout(out)
        out = self.out(out)
        out = out[:, -1, :].squeeze()
        # out = self.out(h_out)
        # out = out.squeeze()
        # pred = self.linear(ula)
        # pred = pred[:, -1, :]
        return out


class LSTM(nn.Module):  # 继承了nn.Module类
    def __init__(self, model_parameter):
        super().__init__()
        # self.input_size = model_parameter['input_size']
        # self.output_size = model_parameter['output_size']
        # self.hidden_size = model_parameter['hidden_size']
        # self.num_layers = model_parameter['num_layers']
        self.input_size = model_parameter.input_size
        self.output_size = model_parameter.output_size
        self.hidden_size = model_parameter.hidden_size
        self.num_layers = model_parameter.num_layers
        self.lstm = nn.LSTM(self.input_size, self.hidden_size, self.num_layers, batch_first=True)  # 定义了一个nn.LSTM对象
        self.linear = nn.Linear(self.hidden_size*60, self.output_size)  # 线性层对象，将隐藏状态大小和输出大小传入，用于将 LSTM 的输出转化为期望的输出大小
        # self.device = model_parameter['device']
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        # self.relu = nn.LeakyReLU()
        # self.sigmoid = nn.Sigmoid()
        # self.dropout = nn.Dropout(model_parameter["dropout"])

    def forward(self, x):
        # h_0 = torch.randn(self.num_layers, self.batch_size, self.hidden_size).to(self.device)
        # c_0 = torch.randn(self.num_layers, self.batch_size, self.hidden_size).to(self.device)
        ula, (h_out, _) = self.lstm(x)  # x是输入数据，返回两个值， ula代表每个时间步骤的lstm输出

        # h_out = h_out.view(-1, self.hidden_size)  # 这个最终的隐藏状态变形成了一个2D张量  隐藏单元数量  最终的隐藏状态变形成一个 2D 张量，形状为 (batch_size, hidden_size)
        #
        # out = self.linear(h_out)  # 形成了线性变换
        # out = out.squeeze()  # 输入批次中每个序列的预测输出

        ula = ula.view(-1, self.hidden_size*60)
        out = self.linear(ula)
        out = out.squeeze()

        return out
