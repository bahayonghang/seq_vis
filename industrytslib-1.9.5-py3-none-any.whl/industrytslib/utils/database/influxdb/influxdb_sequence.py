import time
import pytz
import json
import polars as pl

from datetime import datetime
from typing import Dict, List, Optional
from influxdb_client import InfluxDBClient, Point, WritePrecision
from influxdb_client.client.write_api import SYNCHRONOUS
from industrytslib.utils.logutils import get_logger
from .influxdb_base import InfluxDB


class InfluxdbSequence(InfluxDB):
    def __init__(self, config: dict) -> None:
        """初始化预测结果存储类
        
        Args:
            config: 配置字典,包含influxdb连接信息
        """
        super().__init__(config)
        self.config = config
        self.logger = get_logger("PredictionStorage", "database")

        self.url = self.config["url"]
        self.token = self.config["token"]
        self.org = self.config["org"]
        self.timezone = pytz.timezone("Asia/Shanghai")

        # 初始化influxdb客户端
        self.client = InfluxDBClient(url=self.url, token=self.token, org=self.org)
        self.logger.info(f"connect to influxdb:{self.url} | org: {self.org} | token: {self.token} | success!!!")
        self.write_api = self.client.write_api(write_options=SYNCHRONOUS)
        self.query_api = self.client.query_api()
        self.delete_api = self.client.delete_api()

    def __del__(self) -> None:
        """关闭数据库连接"""
        self.client.close()

    def save_prediction_overwrite(
            self, 
            bucket: str,
            pred_df: pl.DataFrame, 
            model_version: str,
            parameters: Dict
        ) -> None:
        """覆盖式保存预测结果
        
        Args:
            bucket: 数据库名
            pred_df: 预测结果DataFrame，必须包含DateTime列
            model_version: 模型版本
            parameters: 模型参数字典
        """
        start_time = time.time()
        points = []
        measurement = "预测结果表"

        try:
            # 获取当前时间戳
            timestamp = self.timezone.localize(datetime.now()).timestamp() * 1e9

            # 将预测结果转换为数据点
            for row in pred_df.iter_rows(named=True):
                point = Point(measurement)
                point.time(int(timestamp), write_precision=WritePrecision.NS)
                
                # 添加标签
                point.tag("model_version", model_version)
                point.tag("prediction_type", "latest")
                
                # 添加模型参数
                point.field("parameters", json.dumps(parameters))
                
                # 添加预测值
                for col in pred_df.columns:
                    if col != "DateTime":
                        try:
                            value = float(row[col])
                            point.field(str(col), value)
                        except ValueError:
                            self.logger.warning(f"Invalid prediction value for {col}: {row[col]}. Skipping.")
                            continue
                
                points.append(point)

            # 批量写入数据
            batch_size = 1000
            for i in range(0, len(points), batch_size):
                batch = points[i:i+batch_size]
                try:
                    self.write_api.write(bucket=bucket, record=batch, org=self.org)
                    self.logger.info(f"Wrote batch of {len(batch)} predictions to {bucket}")
                except Exception as e:
                    self.logger.error(f"Error writing batch to {bucket}: {e}")
                    raise

            end_time = time.time()
            self.logger.info(f"Total prediction writing time: {end_time - start_time:.2f} seconds")

        except Exception as e:
            self.logger.error(f"Error saving predictions: {e}")
            raise

    def save_prediction_incremental(
            self,
            bucket: str,
            pred_df: pl.DataFrame,
            model_version: str,
            parameters: Dict
        ) -> None:
        """增量保存预测结果
        
        Args:
            bucket: 数据库名
            pred_df: 预测结果DataFrame，必须包含DateTime列
            model_version: 模型版本
            parameters: 模型参数字典
        """
        start_time = time.time()
        points = []
        measurement = "预测结果表"

        try:
            # 获取当前时间作为预测创建时间
            created_at = self.timezone.localize(datetime.now())
            timestamp = created_at.timestamp() * 1e9

            # 将预测结果转换为数据点
            for row in pred_df.iter_rows(named=True):
                point = Point(measurement)
                point.time(int(timestamp), write_precision=WritePrecision.NS)
                
                # 添加标签
                point.tag("model_version", model_version)
                point.tag("prediction_created_at", created_at.isoformat())
                
                # 添加模型参数
                point.field("parameters", json.dumps(parameters))
                
                # 添加预测值
                for col in pred_df.columns:
                    if col != "DateTime":
                        try:
                            value = float(row[col])
                            point.field(str(col), value)
                        except ValueError:
                            self.logger.warning(f"Invalid prediction value for {col}: {row[col]}. Skipping.")
                            continue
                
                points.append(point)

            # 批量写入数据
            batch_size = 1000
            for i in range(0, len(points), batch_size):
                batch = points[i:i+batch_size]
                try:
                    self.write_api.write(bucket=bucket, record=batch, org=self.org)
                    self.logger.info(f"Wrote batch of {len(batch)} predictions to {bucket}")
                except Exception as e:
                    self.logger.error(f"Error writing batch to {bucket}: {e}")
                    raise

            end_time = time.time()
            self.logger.info(f"Total prediction writing time: {end_time - start_time:.2f} seconds")

        except Exception as e:
            self.logger.error(f"Error saving predictions: {e}")
            raise

    def query_latest_predictions(
            self,
            bucket: str,
            feature_names: Optional[List[str]] = None
        ) -> pl.DataFrame:
        """查询最新预测结果
        
        Args:
            bucket: 数据库名
            feature_names: 特征名列表，如果为None则查询所有特征
            
        Returns:
            预测结果DataFrame
        """
        try:
            # 构建查询语句
            feature_filter = ""
            if feature_names:
                feature_filter = ' or '.join([f'r["_field"] == "{f}"' for f in feature_names])
                feature_filter = f' and ({feature_filter})'

            query = f'''
            from(bucket:"{bucket}")
                |> range(start: -1d)  // 可根据需要调整时间范围
                |> filter(fn: (r) => r._measurement == "预测结果表")
                |> filter(fn: (r) => r["prediction_type"] == "latest"{feature_filter})
            '''

            # 执行查询
            tables = self.query_api.query(query, org=self.org)
            
            # 处理查询结果
            records = []
            for table in tables:
                for record in table.records:
                    time = record.get_time().astimezone(self.timezone)
                    feature = record.get_field()
                    value = record.get_value()
                    records.append((time, feature, value))

            # 转换为DataFrame
            if not records:
                self.logger.warning("No prediction results found")
                return pl.DataFrame()

            df = pl.DataFrame(
                records,
                schema=["DateTime", "Feature", "Value"]
            )

            # 透视表转换
            df_pivot = df.pivot(
                values="Value",
                index="DateTime",
                columns="Feature"
            )

            return df_pivot

        except Exception as e:
            self.logger.error(f"Error querying predictions: {e}")
            raise

    def query_prediction_history(
            self,
            bucket: str,
            feature_names: List[str],
            start_time: datetime,
            end_time: datetime,
            model_version: Optional[str] = None
        ) -> pl.DataFrame:
        """查询预测历史
        
        Args:
            bucket: 数据库名
            feature_names: 特征名列表
            start_time: 开始时间
            end_time: 结束时间
            model_version: 模型版本，可选
            
        Returns:
            预测历史DataFrame
        """
        try:
            # 转换时区
            start_time_utc = self.timezone.localize(start_time).astimezone(pytz.UTC)
            end_time_utc = self.timezone.localize(end_time).astimezone(pytz.UTC)

            # 构建查询语句
            feature_filter = ' or '.join([f'r["_field"] == "{f}"' for f in feature_names])
            model_filter = f' and r["model_version"] == "{model_version}"' if model_version else ""

            query = f'''
            from(bucket:"{bucket}")
                |> range(start: {start_time_utc.isoformat()}, stop: {end_time_utc.isoformat()})
                |> filter(fn: (r) => r._measurement == "预测结果表")
                |> filter(fn: (r) => {feature_filter}{model_filter})
            '''

            # 执行查询
            tables = self.query_api.query(query, org=self.org)
            
            # 处理查询结果
            records = []
            for table in tables:
                for record in table.records:
                    time = record.get_time().astimezone(self.timezone)
                    feature = record.get_field()
                    value = record.get_value()
                    created_at = record.values.get("prediction_created_at")
                    records.append((time, feature, value, created_at))

            # 转换为DataFrame
            if not records:
                self.logger.warning("No prediction history found")
                return pl.DataFrame()

            df = pl.DataFrame(
                records,
                schema=["DateTime", "Feature", "Value", "PredictionCreatedAt"]
            )

            # 透视表转换
            df_pivot = df.pivot(
                values="Value",
                index=["DateTime", "PredictionCreatedAt"],
                columns="Feature"
            )

            return df_pivot

        except Exception as e:
            self.logger.error(f"Error querying prediction history: {e}")
            raise e
