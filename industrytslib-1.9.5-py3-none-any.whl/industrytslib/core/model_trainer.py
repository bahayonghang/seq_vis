import gc
import json
import pickle
import progressbar
import time
import torch

import numpy as np
import polars as pl
# import platform

# from datetime import datetime
from pathlib import Path
from typing import Tuple
from tqdm import trange
from torch import optim
from torch.utils.data import DataLoader, Dataset
from torch.utils.tensorboard import SummaryWriter
# from torch.amp import autocast
from torchinfo import summary

from industrytslib.core.base import ScheduledTask
from industrytslib.utils.basefunc import name_list_parser, get_current_time, split_sample_and_model
from industrytslib.utils.database import database_builder
from industrytslib.utils.data_processing.polarsoperation import filter_feed_columns
from industrytslib.utils.data_processing.data_provider import data_provider_builder
# from industrytslib.models.model_builder import build_model
from industrytslib.models.aimodels import build_model
from industrytslib.models.aimodels.utils.tools import EarlyStopping, adjust_learning_rate
from industrytslib.models.aimodels.utils.metrics import metric
from industrytslib.utils.visualization import plotter_builder
from industrytslib.utils.data_processing.data_preprocess import TransformerDataFramePreprocess, ClassicDataFrameProcess, SequenceDataFrameProcess
from industrytslib.utils.readconfig import read_model_parameter_toml
from industrytslib.utils.gpu import select_least_used_gpu
from industrytslib.utils.logutils import get_logger


def get_device() -> torch.device:
    if torch.cuda.is_available():
        # num_gpus = torch.cuda.device_count()
        # if num_gpus >= 2:
        #     return torch.device("cuda:1")
        # else:
        #     return torch.device("cuda:0")
        return select_least_used_gpu()
    else:
        return torch.device("cpu")


class ModelTrainer(ScheduledTask):
    """
    ModelTrainer is a basic class for training models.
    """
    def __init__(self, project_name: str, dbconfig: dict) -> None:
        super().__init__(project_name, dbconfig)
        self.task_type = "train"
        self.logger = get_logger(self.project_name, self.task_type)

        self.device = get_device()
        self.logger.info(f"Using device: {self.device}")
        self.scaler_y_path = Path(f"resource/scaler/{self.project_name}/scaler_y.pkl")

        self.writer = SummaryWriter(log_dir=f"resource/tensorboard/{self.project_name}/{get_current_time()}")  # tensorboard writer
        self.plotter = plotter_builder(plotter_type="plotly", project_name=self.project_name)
        
    def database_connection(self) -> None:
        # Database connection(if you need train offline, just comment thre follow 2 lines)
        self.web_mssql_client = database_builder(self.dbconfig["mssql"]["web"])
        self.ts_mssql_client = database_builder(self.dbconfig["mssql"]["timeseries"])

        try:
            self.sample_name, self.model_name = self.web_mssql_client.get_prediction_info(self.project_name)
            self.logger.info(f"Get sample name and model name from project name {self.project_name} successfully!!!")
            self.logger.info(f"Sample name: {self.sample_name}, model name: {self.model_name}!!!")
        except Exception as e:
            self.logger.error(f"Get prediction info from web mssql database failed: {e}")
            self.logger.error(f"Please check the project name {self.project_name} in web mssql database!!!")
            self.sample_name, self.model_name = split_sample_and_model(self.project_name)
            self.logger.info(f"Get sample name and model name from project name {self.project_name} successfully!!!")
            self.logger.info(f"Sample name: {self.sample_name}, model name: {self.model_name}!!!")
            # raise e

        self.sample_table_in_name = self.sample_name + "_in"  # input table(view) name
        self.sample_table_out_name = self.sample_name + "_out"  # output table(view) name

        # # If the output table exists, then use the ts_mssql_client to connect the table
        # # Else use the quality database client to connect the table
        # try:
        #     if self.ts_mssql_client.is_table_exist(self.sample_table_out_name):
        #         self.out_db_client = self.ts_mssql_client
        #     else:
        #         self.out_db_client = database_builder(self.dbconfig["mssql"]["quality"])
        # except Exception as e:
        #     self.logger.error(f"Output Database connection failed: {e}")
        #     raise e

    def get_trainer_information(self) -> None:
        """
        Get trainer information from web database,including sample table information, algorithm information, model parameter, input name list
        """
        try:
            self.sample_table_information = self.web_mssql_client.get_sample_table_information(self.sample_name)
            self.logger.info(f"Get sample table information from web mssql database successfully:{self.sample_table_information}")
        except Exception as e:
            self.logger.error(f"Get sample table information from web mssql database failed: {e}")
            self.logger.error("Please check the sample name in web mssql database!!!")
            # raise e
        
        # get input name list(input variable name list)  
        try:
            input_name_str = self.sample_table_information["column_namein"][0]
            self.input_name_list = name_list_parser(input_name_str)
            self.logger.info(f"Get input name list from sample table information successfully:{self.input_name_list}")
        except Exception as e:
            self.logger.error(f"Get input name list from sample table information failed: {e}")
            self.logger.error("Please check the sample table information!!!")
            # raise e
        
        # get output name list(output variable name list)
        try:
            output_name_str = self.sample_table_information["column_nameout"][0]
            self.output_name_list = name_list_parser(output_name_str)
            self.logger.info(f"Get output name list from sample table information successfully:{self.output_name_list}")
        except Exception as e:
            self.logger.error(f"Get output name list from sample table information failed: {e}")
            self.logger.error("Please check the sample table information!!!")
            # raise e
        
        self.get_model_parameter()
    
    def get_model_parameter(self) -> None:
        """
        Get model prarameter based on config
        """
        match self.dbconfig["model_info_location"]["location"]:
            case "sqlite":
                sqlite_model_info_client = database_builder(self.dbconfig["sqlite"]["model_info"])
                self.model_parameter = sqlite_model_info_client.get_model_parameter(self.model_name)
                self.algorithm_name = self.model_parameter["algorithm_name"]
            case "mssql":
                self.algorithm_name, self.model_parameter = self.web_mssql_client.get_model_parameter(self.model_name)
            case "toml":
                model_parameter_path = Path(f"resource/model_parameter/{self.model_name}/model_config.toml")
                self.model_parameter = read_model_parameter_toml(model_parameter_path)
                self.algorithm_name = self.model_parameter["algorithm_name"]
            case _:
                self.logger.error(f"No such model info location: {self.dbconfig['model_info_location']}")
                raise ValueError(f"No such model info location: {self.dbconfig['model_info_location']}")
        self.logger.info(f"Get model parameter from {self.dbconfig['model_info_location']['location']} successfully!!!")
        self.logger.info(f"Model parameter: {self.model_parameter}")

        # build output database depend on model_parameter["output_flag"]
        # if output_flag in model_parameter, then use the output_flag to build the output database
        # else use the default output database
        if "output_flag" in self.model_parameter:
            match self.model_parameter["output_flag"]:
                case "control":
                    self.output_flag = "control"
                    self.out_db_client = self.ts_mssql_client
                    self.logger.info("Output database is timeseries database!!!")
                case "quality":
                    self.output_flag = "quality"
                    self.out_db_client = database_builder(self.dbconfig["mssql"]["quality"])
                    self.logger.info("Output database is quality database!!!")
                case _:
                    self.logger.error(f"No such output flag: {self.model_parameter['output_flag']}")
                    raise ValueError(f"No such output flag: {self.model_parameter['output_flag']}")
        else:
            self.output_flag = "control"
            self.out_db_client = self.ts_mssql_client
            self.logger.info("Output database is timeseries database!!!")
        
    def get_train_data(self) -> Tuple[pl.DataFrame, pl.DataFrame]:
        """
        获取训练数据。
        TODO 将数据交互格式写入配置文件:csv, parquet, pickle, etc.
        Args:
            无参数。

        Returns:
            Tuple[pl.DataFrame, pl.DataFrame]: 包含两个元素的元组,每个元素都是polars DataFrame类型。
            第一个DataFrame包含特征数据,第二个DataFrame包含标签数据。
        """
        self.input_csv_path = f"resource/datasets/{self.sample_name}/data_in.csv"
        self.output_csv_path = f"resource/datasets/{self.sample_name}/data_out.csv"
        # 如果self.input_csv_path存在，则直接读取csv文件作为训练数据
        if Path(self.input_csv_path).exists() and Path(self.output_csv_path).exists():
            self.logger.info(f"Get training data from local csv file {self.input_csv_path} and {self.output_csv_path}.")
            data_input = pl.read_csv(self.input_csv_path)
            data_output = pl.read_csv(self.output_csv_path)
        else:
            # 先创建文件夹
            sample_path = Path(self.input_csv_path).parent
            if sample_path.exists() is False:
                sample_path.mkdir(parents=True, exist_ok=True)
            begin_time, end_time = self.sample_table_information["begin_time"][0], self.sample_table_information["end_time"][0]
            self.logger.info(f"Get training data from table {self.sample_table_in_name} between time {begin_time} and {end_time}.")

            # query input data from ts database
            self.logger.info(f"trying to get input data from {self.ts_mssql_client}!!!")
            # data_input = self.ts_mssql_client.get_input_data_train(self.sample_table_in_name, begin_time, end_time)
            data_input = self.ts_mssql_client.get_input_data_history(self.input_name_list, begin_time, end_time)  # 从历史表中获取数据,然后拼接
            # filter the train_data_input according to feed_amount column, which is bigger than 10
            data_input = filter_feed_columns(data_input)
            # save input data to local
            data_input.write_csv(self.input_csv_path)
            self.logger.info(f"Get input training data from table {self.sample_table_in_name} successfully!!!")

            # query output data from self.out_db_client
            self.logger.info(f"trying to get output data from {self.out_db_client}!!!")
            match self.output_flag:
                case "control":
                    data_output = self.out_db_client.get_output_data_history(self.output_name_list, begin_time, end_time)
                case "quality":
                    data_output = self.out_db_client.get_output_data_history(self.sample_table_out_name, begin_time, end_time)
                case _:
                    self.logger.error(f"No such output flag: {self.output_flag}")
                    raise ValueError(f"No such output flag: {self.output_flag}")
            # save output data to local
            data_output.write_csv(self.output_csv_path)
            self.logger.info(f"Get output training data from table {self.sample_table_out_name} successfully!!!")

        return data_input, data_output
    
    def build_model(self) -> None:
        """
        Build model according to the model parameter.
        """
        self.model = build_model(self.algorithm_name, self.model_parameter).to(self.device)
        self.logger.info(f"Build model {self.algorithm_name} | {self.model_parameter} | {self.device} successfully!!!")
    
    def _set_optimizer(self, model_parameter: dict) -> optim.Optimizer:
        """
        Set optimizer according to the model parameter.
        Args:
            model_parameter (dict): Model parameter from web database.
        Returns:
            torch.optim.Optimizer: Optimizer object.
        """
        try:
            match model_parameter["optimizer"]:
                case "Adam":
                    optimizer = optim.Adam(self.model.parameters(), lr=self.model_parameter["learning_rate"], betas=(0.5, 0.999), eps=1e-8)
                case "SGD":
                    optimizer = optim.SGD(self.model.parameters(), lr=self.model_parameter["learning_rate"])
                case "Adamax":
                    optimizer = optim.Adamax(self.model.parameters(), lr=self.model_parameter["learning_rate"])
                case "AdamW":
                    optimizer = optim.AdamW(self.model.parameters(), lr=self.model_parameter["learning_rate"], betas=(0.0, 0.95),
                                                   weight_decay=0.05)
                case _:
                    self.logger.warning("No such optimizer.Please check the optimizer name in model parameter!!!")
                    optimizer = optim.AdamW(self.model.parameters(), lr=self.model_parameter["learning_rate"], betas=(0.0, 0.95),
                                                   weight_decay=0.05)
        except KeyError as e:
            self.logger.error(f"{self.project_name}参数中没有:{e}!!!")
            optimizer = optim.Adam(self.model.parameters(), lr=self.model_parameter["learning_rate"], betas=(0.5, 0.999), eps=1e-8)
        # self.epoch_scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=5000, gamma=0.5)
        return optimizer

    def _set_criterion(self, model_parameter: dict) -> torch.nn.Module:
        """
        Set criterion according to the model parameter.
        Args:
            model_parameter (dict): Model parameter from web database.
        Returns:
            torch.nn.modules.loss._Loss: Criterion object.
        """
        try:
            match model_parameter["criterion"]:
                case "MSE":
                    criterion = torch.nn.MSELoss()
                case _:
                    self.logger.warning("No such criterion.Please check the criterion name in model parameter!!!")
                    criterion = torch.nn.MSELoss()
        except KeyError as e:
            self.logger.error(f"{self.project_name}参数中没有:{e}!!!")
            criterion = torch.nn.MSELoss()
        return criterion
    
    def _get_data(self, flag) -> Tuple[Dataset, DataLoader]:
        data_set, data_loader = data_provider_builder(self.project_name, self.data_input, self.model_parameter["data_type"], 
                                              self.model_parameter, flag)
        return data_set, data_loader
    
    def ensure_path(self) -> None:
        """
        init path object and ensure the path exists
        """
        self.train_result_path = Path(f"resource/results/train_results/{self.project_name}")  # 存放训练结果绘图的路径
        # 判断训练结果路径是否存在,如果不存在则创建文件夹
        if not self.train_result_path.exists():
            self.train_result_path.mkdir(parents=True, exist_ok=True)
    
    def main(self) -> None:
        self.database_connection()
        self.get_trainer_information()
    

class TransformerTrainer(ModelTrainer):
    """
    Trainer for transformer like models, including informer, etc.
    """
    def __init__(self, project_name: str, dbconfig: dict) -> None:
        super().__init__(project_name, dbconfig)

    def _get_data(self, flag) -> Tuple[Dataset, DataLoader]:
        data_set, data_loader = data_provider_builder(self.project_name, self.data_input, "transformer", 
                                              self.model_parameter, flag)
        return data_set, data_loader

    def _process_one_batch_time(self, batch_x: torch.Tensor, batch_y: torch.Tensor,
                                batch_x_mark: torch.Tensor, batch_y_mark: torch.Tensor
                                ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        处理一个batch的数据。加载data_input, data_output,输出预测值与真实值。

        Args:
            batch_x (torch.Tensor): 特征数据。
            batch_y (torch.Tensor): 标签数据。

        Returns:
            Tuple[torch.Tensor, torch.Tensor]: 包含两个元素的元组,分别是预测值和真实值。
        """
        batch_x = batch_x.float().to(self.device)
        batch_y = batch_y.float()

        batch_x_mark = batch_x_mark.float().to(self.device)
        batch_y_mark = batch_y_mark.float().to(self.device)

        # dec_inp = torch.zeros([batch_y.shape[0], self.model_parameter["pred_len"], batch_y.shape[-1]]).float().to(self.device)
        dec_inp = torch.zeros([batch_y.shape[0], self.model_parameter["pred_len"], batch_y.shape[-1]]).float()
        dec_inp = torch.cat([batch_y[:, :self.model_parameter["label_len"], :], dec_inp], dim=1).float().to(self.device)

        # encoder - decoder
        if "TimeMachine" in self.algorithm_name:
            outputs = self.model(batch_x)
        else:
            outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark)

        f_dim = -1 if self.model_parameter["features"] == "MS" else 0
        outputs = outputs[:, -self.model_parameter["pred_len"]:, f_dim:].to(self.device)
        batch_y = batch_y[:, -self.model_parameter["pred_len"]:, f_dim:].to(self.device)

        return outputs, batch_y
    
    
    def vali(self, vali_data: Dataset, vali_loader: DataLoader, criterion: torch.nn.Module) -> float:
        """
        Validate the model.
        Args:
            vali_data (Dataset): Validation dataset.
            vali_loader (DataLoader): Validation data loader.
        Returns:
            float: Validation loss.
        """
        self.model.eval()
        vali_loss_list = []

        with torch.no_grad():
            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(vali_loader):
                outputs, batch_y = self._process_one_batch_time(batch_x, batch_y, batch_x_mark, batch_y_mark)
                loss = criterion(outputs, batch_y)
                vali_loss_list.append(loss.item())

        vali_loss = np.mean(vali_loss_list)
        return vali_loss

    def train(self):
        """
        train the model.
        """
        # split data into train, vali and test
        train_data, train_loader = self._get_data("train")
        vali_data, vali_loader = self._get_data("val")
        test_data, test_loader = self._get_data("test")
        self.logger.debug(f"Get train, vali and test data of {self.project_name} successfully!!!")

        with open(self.scaler_y_path, "rb") as f:
            self.scaler_y = pickle.load(f)


        # # 检查当前操作系统是否为Linux
        # is_linux = platform.system() == 'Linux'
        # # 在Linux上使用torch.compile优化模型
        # if is_linux:
        #     self.model = torch.compile(self.model, mode="max-autotune")
        #     self.logger.info("在Linux上使用torch.compile优化模型成功!")
        # set the criterion and optimizer
        self.criterion = self._set_criterion(self.model_parameter)
        self.optimizer = self._set_optimizer(self.model_parameter)

        # path for saving trained model
        trained_model_path = Path(f"resource/models/{self.project_name}")
        # judge if the trained model exists, if not then create the folder
        if not trained_model_path.exists():
            trained_model_path.mkdir(parents=True, exist_ok=True)

        train_bar = progressbar.ProgressBar(maxval=self.model_parameter["num_epochs"]).start()

        time_train_start = time.time()  # 开始训练的时间,用于计算训练所用的时间

        # early_stopping = EarlyStopping(patience=self.model_parameter["patience"], verbose=True)

        train_steps = len(train_loader)  # 计算训练用的步数

        train_loss_total_list = []  # 记录训练损失的列表,后续用于绘制训练损失曲线
        vali_loss_total_list = []  # 记录验证损失的列表,后续用于绘制验证损失曲线

        for epoch in trange(self.model_parameter["num_epochs"]):
            iter_count = 0  # 记录迭代次数
            train_loss_list = []  # 记录训练损失

            self.model.train()
            epoch_time_start = time.time()  # 记录每个epoch开始的时间

            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(train_loader):
                iter_count += 1
                self.optimizer.zero_grad()
                pred, true = self._process_one_batch_time(batch_x, batch_y, batch_x_mark, batch_y_mark)

                loss = self.criterion(pred, true)
                train_loss_list.append(loss.item())
                self.optimizer.zero_grad()

                if iter_count % 100 == 0:
                    self.logger.debug(
                        f"Epoch {epoch + 1} / {self.model_parameter['num_epochs']} Iteration {iter_count} "
                        f"/ {train_steps}, Loss: {loss.item():.4f}")

                loss.backward()
                self.optimizer.step()

            train_bar.update(epoch + 1)

            epoch_time_end = time.time()  # 记录每个epoch结束的时间
            epoch_cost_time = epoch_time_end - epoch_time_start  # 计算每个epoch所用的时间
            self.logger.debug(f"Epoch {epoch + 1} / {self.model_parameter['num_epochs']} cost time: {epoch_cost_time:.2f}s!")

            train_loss = np.average(train_loss_list)  # 计算训练损失
            vali_loss = self.vali(vali_data=vali_data, vali_loader=vali_loader, criterion=self.criterion)  # 计算验证损失

            # record loss of every epoch
            self.logger.info(f"{self.project_name}:Epoch {epoch + 1} / {self.model_parameter['num_epochs']} cost time: {epoch_cost_time:.2f}")
            self.logger.info(f"{self.project_name}:Epoch {epoch + 1} / {self.model_parameter['num_epochs']} "
                             f"train loss: {train_loss:.4f}, vali loss: {vali_loss:.4f}")

            self.writer.add_scalar("Loss/train", train_loss, epoch)
            self.writer.add_scalar("Loss/vali", vali_loss, epoch)

            train_loss_total_list.append(train_loss)  # 将训练损失加入到列表中
            vali_loss_total_list.append(vali_loss)  # 将验证损失加入到列表中

            # early_stopping(vali_loss, self.model, trained_model_path.joinpath("checkpoint.pth"))
            # if early_stopping.early_stop:
            #     print("Early stopping")
            #     break

            # adjust_learning_rate(self.optimizer, epoch + 1, self.model_parameter)

            torch.save(self.model.state_dict(), trained_model_path.joinpath(f"checkpoint_{epoch+1}_{get_current_time()}.pth"))
        
        time_train_end = time.time()  # 结束训练的时间
        time_train = time_train_end - time_train_start  # 计算训练所用的时间
        self.logger.info(f"训练{self.project_name}模型成功,用时{time_train}s!")

        train_bar.finish()

        self.plotter.plot_loss(time_now=get_current_time(),
                  train_loss_list=train_loss_total_list,
                  vali_loss_list=vali_loss_total_list,
                  save_path=self.train_result_path)
        self.logger.info(f"成功绘制{self.project_name}训练、验证损失曲线图！")

        # 清空占用的显存
        torch.cuda.empty_cache()

        return
    
    def train_with_big_batch(self):
        """
        train the model.
        """
        # split data into train, vali and test
        train_data, train_loader = self._get_data("train")
        vali_data, vali_loader = self._get_data("val")
        test_data, test_loader = self._get_data("test")
        self.logger.debug(f"Get train, vali and test data of {self.project_name} successfully!!!")

        with open(self.scaler_y_path, "rb") as f:
            self.scaler_y = pickle.load(f)


        # # 检查当前操作系统是否为Linux
        # is_linux = platform.system() == 'Linux'
        # # 在Linux上使用torch.compile优化模型
        # if is_linux:
        #     self.model = torch.compile(self.model, mode="max-autotune")
        #     self.logger.info("在Linux上使用torch.compile优化模型成功!")
        # set the criterion and optimizer
        self.criterion = self._set_criterion(self.model_parameter)
        self.optimizer = self._set_optimizer(self.model_parameter)

        # path for saving trained model
        trained_model_path = Path(f"resource/models/{self.project_name}")
        # judge if the trained model exists, if not then create the folder
        if not trained_model_path.exists():
            trained_model_path.mkdir(parents=True, exist_ok=True)

        train_bar = progressbar.ProgressBar(maxval=self.model_parameter["num_epochs"]).start()

        time_train_start = time.time()  # 开始训练的时间,用于计算训练所用的时间

        early_stopping = EarlyStopping(patience=self.model_parameter["patience"], verbose=True)

        train_steps = len(train_loader)  # 计算训练用的步数

        train_loss_total_list = []  # 记录训练损失的列表,后续用于绘制训练损失曲线
        vali_loss_total_list = []  # 记录验证损失的列表,后续用于绘制验证损失曲线

        for epoch in trange(self.model_parameter["num_epochs"]):
            iter_count = 0  # 记录迭代次数
            train_loss_list = []  # 记录训练损失

            self.model.train()
            epoch_time_start = time.time()  # 记录每个epoch开始的时间

            scaler = torch.amp.GradScaler()

            # accumulation_steps = 8

            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(train_loader):
                iter_count += 1
                train_loss_batch_list = []
                batch_size = batch_x.shape[0]
                mini_batch_size = int(batch_size / 8)

                self.optimizer.zero_grad()
                for j in range(0, len(batch_x), mini_batch_size):
                    end = min(j + mini_batch_size, batch_x.shape[0])
                    # 将数据移动到GPU
                    mini_batch_x = batch_x[j:end].to(self.device)
                    mini_batch_y = batch_y[j:end].to(self.device)
                    mini_batch_x_mark = batch_x_mark[j:end].to(self.device)
                    mini_batch_y_mark = batch_y_mark[j:end].to(self.device)

                    pred, true = self._process_one_batch_time(
                        mini_batch_x,
                        mini_batch_y,
                        mini_batch_x_mark,
                        mini_batch_y_mark
                    )

                    loss = self.criterion(pred, true)
                    train_loss_batch_list.append(loss.item())
                    # 清理这个小批次的内存
                    del mini_batch_x, mini_batch_y, mini_batch_x_mark, mini_batch_y_mark
                    del pred, true, loss
                    torch.cuda.empty_cache()
                    gc.collect()
                
                # 计算平均 loss 并反向传播
                avg_loss = np.mean(train_loss_batch_list)
                scaler.scale(torch.tensor(avg_loss, device=self.device, requires_grad=True)).backward()
                scaler.step(self.optimizer)
                scaler.update()
                train_loss_list.append(avg_loss)
                self.optimizer.zero_grad()

                if iter_count % 100 == 0:
                    self.logger.debug(
                        f"Epoch {epoch + 1} / {self.model_parameter['num_epochs']} Iteration {iter_count} "
                        f"/ {train_steps}, Loss: {avg_loss:.4f}")

                # loss.backward()
                # self.optimizer.step()

            train_bar.update(epoch + 1)

            epoch_time_end = time.time()  # 记录每个epoch结束的时间
            epoch_cost_time = epoch_time_end - epoch_time_start  # 计算每个epoch所用的时间

            train_loss = np.average(train_loss_list)  # 计算训练损失
            vali_loss = self.vali(vali_data=vali_data, vali_loader=vali_loader, criterion=self.criterion)  # 计算验证损失

            # record loss of every epoch
            self.logger.info(f"{self.project_name}:Epoch {epoch + 1} / {self.model_parameter['num_epochs']} cost time: {epoch_cost_time:.2f}")
            self.logger.info(f"{self.project_name}:Epoch {epoch + 1} / {self.model_parameter['num_epochs']} "
                             f"train loss: {train_loss:.4f}, vali loss: {vali_loss:.4f}")

            self.writer.add_scalar("Loss/train", train_loss, epoch)
            self.writer.add_scalar("Loss/vali", vali_loss, epoch)

            train_loss_total_list.append(train_loss)  # 将训练损失加入到列表中
            vali_loss_total_list.append(vali_loss)  # 将验证损失加入到列表中

            early_stopping(vali_loss, self.model, trained_model_path.joinpath("checkpoint.pth"))
            if early_stopping.early_stop:
                print("Early stopping")
                break

            adjust_learning_rate(self.optimizer, epoch + 1, self.model_parameter)

            torch.save(self.model.state_dict(), trained_model_path.joinpath("checkpoint.pth"))
        
        time_train_end = time.time()  # 结束训练的时间
        time_train = time_train_end - time_train_start  # 计算训练所用的时间
        self.logger.info(f"训练{self.project_name}模型成功,用时{time_train}s!")

        train_bar.finish()

        self.plotter.plot_loss(time_now=get_current_time(),
                  train_loss_list=train_loss_total_list,
                  vali_loss_list=vali_loss_total_list,
                  save_path=self.train_result_path)
        self.logger.info(f"成功绘制{self.project_name}训练、验证损失曲线图！")

        # 清空占用的显存
        torch.cuda.empty_cache()

        return

    def test(self, test=0, **kwargs):
        """
        Test model.
        """
        test_data, test_loader = self._get_data("test")
        if kwargs.get("pth_name"):
            pth_name = kwargs.get("pth_name")
        else:
            pth_name = "checkpoint.pth"

        if test == 1:
            self.logger.info("loading existing model!")
            self.model.load_state_dict(torch.load(Path(f"resource/models/{self.project_name}").joinpath(pth_name), weights_only=True))

        self.model.eval()

        preds = []
        trues = []

        for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(test_loader):
            pred, true = self._process_one_batch_time(batch_x, batch_y, batch_x_mark, batch_y_mark)
            # inverse transform
            pred_ndarray = np.zeros((pred.shape[0], pred.shape[1], pred.shape[2]))
            true_ndarray = np.zeros((true.shape[0], true.shape[1], true.shape[2]))

            match self.model_parameter["features"]:
                case "MS" | "S":
                    for j in range(pred.shape[0]):
                        pred_ndarray[j] = test_data.inverse_transform_y(pred[j].detach().cpu().numpy())
                        true_ndarray[j] = test_data.inverse_transform_y(true[j].detach().cpu().numpy())
                case "M":
                    for j in range(pred.shape[0]):
                        pred_ndarray[j] = test_data.inverse_transform_x(pred[j].detach().cpu().numpy())
                        true_ndarray[j] = test_data.inverse_transform_x(true[j].detach().cpu().numpy())
                case _:
                    raise ValueError(f"Invalid features: {self.model_parameter['features']}")
            # preds.append(pred.detach().cpu().numpy())
            # trues.append(true.detach().cpu().numpy())
            preds.append(pred_ndarray)
            trues.append(true_ndarray)

        preds = np.array(preds)
        trues = np.array(trues)
        preds = preds.reshape(-1, preds.shape[-2], preds.shape[-1])
        trues = trues.reshape(-1, trues.shape[-2], trues.shape[-1])
        self.logger.info('test shape:', preds.shape, trues.shape)

        # result save
        result_save_path = Path(f"resource/results/test_results/{self.project_name}/{get_current_time()}_test")
        if not result_save_path.exists():
            result_save_path.mkdir(parents=True, exist_ok=True)

        mae, mse, rmse, mape, mspe = metric(torch.from_numpy(preds), torch.from_numpy(trues))
        self.logger.info('mse:{}, mae:{}'.format(mse, mae))

        np.save(result_save_path.joinpath('pred.npy'), preds)
        np.save(result_save_path.joinpath('true.npy'), trues)
        np.save(result_save_path.joinpath('metrics.npy'), np.array([mae, mse, rmse, mape, mspe]))

        # 将self.name_list_input写入result_save_path
        with open(result_save_path.joinpath('name_list.txt'), 'w') as f:
            for name in self.input_name_list:
                f.write(f"{name}\n")
        
        # 将self.model_parameter写入result_save_path
        with open(result_save_path.joinpath('model_parameter.json'), 'w') as f:
            json.dump(self.model_parameter, f)

        # save model
        torch.save(self.model.state_dict(), result_save_path.joinpath('checkpoint.pth'))
        return
    
    def test_train(self, test=0):
        """
        Test model.
        """
        train_data, train_loader = self._get_data("train")
        if test == 1:
            self.logger.info("loading existing model!")
            self.model.load_state_dict(torch.load(Path(f"resource/models/{self.project_name}").joinpath("checkpoint.pth")))

        self.model.eval()

        preds = []
        trues = []

        for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(train_loader):
            pred, true = self._process_one_batch_time(batch_x, batch_y, batch_x_mark, batch_y_mark)
            # inverse transform
            pred_ndarray = np.zeros((pred.shape[0], pred.shape[1], pred.shape[2]))
            true_ndarray = np.zeros((true.shape[0], true.shape[1], true.shape[2]))
            
            match self.model_parameter["features"]:
                case "MS" | "S":
                    for j in range(pred.shape[0]):
                        pred_ndarray[j] = train_data.inverse_transform_y(pred[j].detach().cpu().numpy())
                        true_ndarray[j] = train_data.inverse_transform_y(true[j].detach().cpu().numpy())
                case "M":
                    for j in range(pred.shape[0]):
                        pred_ndarray[j] = train_data.inverse_transform_x(pred[j].detach().cpu().numpy())
                        true_ndarray[j] = train_data.inverse_transform_x(true[j].detach().cpu().numpy())
                case _:
                    raise ValueError(f"Invalid features: {self.model_parameter['features']}")
                
            # preds.append(pred.detach().cpu().numpy())
            # trues.append(true.detach().cpu().numpy())
            preds.append(pred_ndarray)
            trues.append(true_ndarray)

        preds = np.array(preds)
        trues = np.array(trues)
        self.logger.info('test shape:', preds.shape, trues.shape)
        preds = preds.reshape(-1, preds.shape[-2], preds.shape[-1])
        trues = trues.reshape(-1, trues.shape[-2], trues.shape[-1])
        self.logger.info('test shape:', preds.shape, trues.shape)

        # result save
        result_save_path = Path(f"resource/results/test_train_results/{self.project_name}/{get_current_time()}_test_train")
        if not result_save_path.exists():
            result_save_path.mkdir(parents=True, exist_ok=True)

        mae, mse, rmse, mape, mspe = metric(torch.from_numpy(preds), torch.from_numpy(trues))
        self.logger.info('mse:{}, mae:{}'.format(mse, mae))

        np.save(result_save_path.joinpath('pred_train.npy'), preds)
        np.save(result_save_path.joinpath('true_train.npy'), trues)
        np.save(result_save_path.joinpath('metrics_train.npy'), np.array([mae, mse, rmse, mape, mspe]))

        # 将self.name_list_input写入result_save_path
        with open(result_save_path.joinpath('name_list.txt'), 'w') as f:
            for name in self.input_name_list:
                f.write(f"{name}\n")

        return
    
    def print_model_info_transformer(self):
        freq_map = {"h": 4, "t": 5, "s": 6, "m": 1, "a": 1, "w": 2, "d": 3, "b": 3}
        time_embedding_size = freq_map[self.model_parameter['freq']]
        input_size1 = (self.model_parameter['batch_size'], self.model_parameter['seq_len'], self.model_parameter['enc_in'])
        input_size2 = (self.model_parameter['batch_size'], self.model_parameter['seq_len'], time_embedding_size)
        input_size3 = (self.model_parameter['batch_size'], self.model_parameter['label_len'] + self.model_parameter['pred_len'], self.model_parameter['dec_in'])
        input_size4 = (self.model_parameter['batch_size'], self.model_parameter['label_len'] + self.model_parameter['pred_len'], time_embedding_size)
        self.logger.info(f"input_size1: {input_size1}, input_size2: {input_size2}, input_size3: {input_size3}, input_size4: {input_size4}")

        if "TimeMachine" in self.algorithm_name:
            summary(self.model, input_size=(input_size1))
        else:
            summary(self.model, input_size=(input_size1, input_size2, input_size3, input_size4))
    
    def main(self) -> None:
        # connect to database and get trainer information
        self.database_connection()
        self.get_trainer_information()
        self.ensure_path()
        self.build_model()

        # 打印模型信息
        self.print_model_info_transformer()

        # Get data from database or local csv files
        self.data_input, self.data_output = self.get_train_data()
        data_process_client = TransformerDataFramePreprocess(self.data_input, self.data_output)
        self.data_input, self.data_output = data_process_client.run()

        # 绘制输入输出曲线
        self.plotter.plot_input_curve(input_df=self.data_input, save_path=self.train_result_path)
        self.plotter.plot_output_curve(output_df=self.data_output, save_path=self.train_result_path)
        self.logger.info(f"{self.project_name}的输入数据为：{self.data_input}")
        self.logger.info(f"{self.project_name}的输出数据为：{self.data_output}")
        # self.data = pl.concat([self.data_input, self.data_output], how="horizontal")

        # data pipline
        # self.data = self.data_input

        self.logger.info(f"model: {self.model}")
        self.logger.info(f"model_parameter: {self.model_parameter}")
        # self.logger.info(f"model summary: {summary(self.model, input_size=(self.model_parameter['batch_size'], self.model_parameter['seq_len'], self.model_parameter['feature_dim']))}")

        self.train()
        # self.train_with_big_batch()  # 使用大batch训练,降低loss变化幅度

        self.test()

        # self.test(test=1)
        self.test_train()

    def main_test(self, **kwargs):
        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        # connect to database and get trainer information
        self.database_connection()
        self.get_trainer_information()
        self.ensure_path()
        self.build_model()

        # Get data from database or local csv files
        self.data_input, self.data_output = self.get_train_data()
        data_process_client = TransformerDataFramePreprocess(self.data_input, self.data_output)
        self.data_input, self.data_output = data_process_client.run()

        self.test(test=1, pth_name=kwargs.get("pth_name"))


class SequenceTrainer(ModelTrainer):
    """
    Trainer for sequence models, 指定输出序列的维度和变量
    """
    def __init__(self, project_name: str, dbconfig: dict) -> None:
        super().__init__(project_name, dbconfig)

    def _get_data(self, flag) -> Tuple[Dataset, DataLoader]:
        data_set, data_loader = data_provider_builder(self.project_name, self.data_input, "sequence", 
                                              self.model_parameter, flag)
        return data_set, data_loader

    def _process_one_batch_time(self, batch_x: torch.Tensor, batch_y: torch.Tensor,
                                batch_x_mark: torch.Tensor, batch_y_mark: torch.Tensor
                                ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        处理一个batch的数据。加载data_input, data_output,输出预测值与真实值。

        Args:
            batch_x (torch.Tensor): 特征数据。
            batch_y (torch.Tensor): 标签数据。

        Returns:
            Tuple[torch.Tensor, torch.Tensor]: 包含两个元素的元组,分别是预测值和真实值。
        """
        batch_x = batch_x.float().to(self.device)
        batch_y = batch_y.float()

        batch_x_mark = batch_x_mark.float().to(self.device)
        batch_y_mark = batch_y_mark.float().to(self.device)

        # dec_inp = torch.zeros([batch_y.shape[0], self.model_parameter["pred_len"], batch_y.shape[-1]]).float().to(self.device)
        dec_inp = torch.zeros([batch_y.shape[0], self.model_parameter["pred_len"], batch_y.shape[-1]]).float()
        dec_inp = torch.cat([batch_y[:, :self.model_parameter["label_len"], :], dec_inp], dim=1).float().to(self.device)

        # encoder - decoder
        if "TimeMachine" in self.algorithm_name:
            outputs = self.model(batch_x)
        else:
            outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark)

        f_dim = -1 if self.model_parameter["features"] == "MS" else 0
        outputs = outputs[:, -self.model_parameter["pred_len"]:, f_dim:].to(self.device)
        batch_y = batch_y[:, -self.model_parameter["pred_len"]:, f_dim:].to(self.device)

        return outputs, batch_y
    
    
    def vali(self, vali_data: Dataset, vali_loader: DataLoader, criterion: torch.nn.Module) -> float:
        """
        Validate the model.
        Args:
            vali_data (Dataset): Validation dataset.
            vali_loader (DataLoader): Validation data loader.
        Returns:
            float: Validation loss.
        """
        self.model.eval()
        vali_loss_list = []

        with torch.no_grad():
            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(vali_loader):
                outputs, batch_y = self._process_one_batch_time(batch_x, batch_y, batch_x_mark, batch_y_mark)
                loss = criterion(outputs, batch_y)
                vali_loss_list.append(loss.item())

        vali_loss = np.mean(vali_loss_list)
        return vali_loss

    def train(self):
        """
        train the model.
        """
        # split data into train, vali and test
        train_data, train_loader = self._get_data("train")
        vali_data, vali_loader = self._get_data("val")
        test_data, test_loader = self._get_data("test")
        self.logger.debug(f"Get train, vali and test data of {self.project_name} successfully!!!")

        with open(self.scaler_y_path, "rb") as f:
            self.scaler_y = pickle.load(f)


        # # 检查当前操作系统是否为Linux
        # is_linux = platform.system() == 'Linux'
        # # 在Linux上使用torch.compile优化模型
        # if is_linux:
        #     self.model = torch.compile(self.model, mode="max-autotune")
        #     self.logger.info("在Linux上使用torch.compile优化模型成功!")
        # set the criterion and optimizer
        self.criterion = self._set_criterion(self.model_parameter)
        self.optimizer = self._set_optimizer(self.model_parameter)

        # path for saving trained model
        trained_model_path = Path(f"resource/models/{self.project_name}")
        # judge if the trained model exists, if not then create the folder
        if not trained_model_path.exists():
            trained_model_path.mkdir(parents=True, exist_ok=True)

        train_bar = progressbar.ProgressBar(maxval=self.model_parameter["num_epochs"]).start()

        time_train_start = time.time()  # 开始训练的时间,用于计算训练所用的时间

        # early_stopping = EarlyStopping(patience=self.model_parameter["patience"], verbose=True)

        train_steps = len(train_loader)  # 计算训练用的步数

        train_loss_total_list = []  # 记录训练损失的列表,后续用于绘制训练损失曲线
        vali_loss_total_list = []  # 记录验证损失的列表,后续用于绘制验证损失曲线

        for epoch in trange(self.model_parameter["num_epochs"]):
            iter_count = 0  # 记录迭代次数
            train_loss_list = []  # 记录训练损失

            self.model.train()
            epoch_time_start = time.time()  # 记录每个epoch开始的时间

            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(train_loader):
                iter_count += 1
                self.optimizer.zero_grad()
                pred, true = self._process_one_batch_time(batch_x, batch_y, batch_x_mark, batch_y_mark)

                loss = self.criterion(pred, true)
                train_loss_list.append(loss.item())
                self.optimizer.zero_grad()

                if iter_count % 100 == 0:
                    self.logger.debug(
                        f"Epoch {epoch + 1} / {self.model_parameter['num_epochs']} Iteration {iter_count} "
                        f"/ {train_steps}, Loss: {loss.item():.4f}")

                loss.backward()
                self.optimizer.step()

            train_bar.update(epoch + 1)

            epoch_time_end = time.time()  # 记录每个epoch结束的时间
            epoch_cost_time = epoch_time_end - epoch_time_start  # 计算每个epoch所用的时间
            self.logger.debug(f"Epoch {epoch + 1} / {self.model_parameter['num_epochs']} cost time: {epoch_cost_time:.2f}s!")

            train_loss = np.average(train_loss_list)  # 计算训练损失
            vali_loss = self.vali(vali_data=vali_data, vali_loader=vali_loader, criterion=self.criterion)  # 计算验证损失

            # record loss of every epoch
            self.logger.info(f"{self.project_name}:Epoch {epoch + 1} / {self.model_parameter['num_epochs']} cost time: {epoch_cost_time:.2f}")
            self.logger.info(f"{self.project_name}:Epoch {epoch + 1} / {self.model_parameter['num_epochs']} "
                             f"train loss: {train_loss:.4f}, vali loss: {vali_loss:.4f}")

            self.writer.add_scalar("Loss/train", train_loss, epoch)
            self.writer.add_scalar("Loss/vali", vali_loss, epoch)

            train_loss_total_list.append(train_loss)  # 将训练损失加入到列表中
            vali_loss_total_list.append(vali_loss)  # 将验证损失加入到列表中

            # early_stopping(vali_loss, self.model, trained_model_path.joinpath("checkpoint.pth"))
            # if early_stopping.early_stop:
            #     print("Early stopping")
            #     break

            # adjust_learning_rate(self.optimizer, epoch + 1, self.model_parameter)

            torch.save(self.model.state_dict(), trained_model_path.joinpath(f"checkpoint_{epoch+1}_{get_current_time()}.pth"))
        
        time_train_end = time.time()  # 结束训练的时间
        time_train = time_train_end - time_train_start  # 计算训练所用的时间
        self.logger.info(f"训练{self.project_name}模型成功,用时{time_train}s!")

        train_bar.finish()

        self.plotter.plot_loss(time_now=get_current_time(),
                  train_loss_list=train_loss_total_list,
                  vali_loss_list=vali_loss_total_list,
                  save_path=self.train_result_path)
        self.logger.info(f"成功绘制{self.project_name}训练、验证损失曲线图！")

        # 清空占用的显存
        torch.cuda.empty_cache()

        return
    
    def test(self, test=0, **kwargs):
        """
        Test model.
        """
        test_data, test_loader = self._get_data("test")
        if kwargs.get("pth_name"):
            pth_name = kwargs.get("pth_name")
        else:
            pth_name = "checkpoint.pth"

        if test == 1:
            self.logger.info("loading existing model!")
            self.model.load_state_dict(torch.load(Path(f"resource/models/{self.project_name}").joinpath(pth_name), weights_only=True))

        self.model.eval()

        preds = []
        trues = []

        for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(test_loader):
            pred, true = self._process_one_batch_time(batch_x, batch_y, batch_x_mark, batch_y_mark)
            # inverse transform
            pred_ndarray = np.zeros((pred.shape[0], pred.shape[1], pred.shape[2]))
            true_ndarray = np.zeros((true.shape[0], true.shape[1], true.shape[2]))

            match self.model_parameter["features"]:
                case "MS" | "S":
                    for j in range(pred.shape[0]):
                        pred_ndarray[j] = test_data.inverse_transform_y(pred[j].detach().cpu().numpy())
                        true_ndarray[j] = test_data.inverse_transform_y(true[j].detach().cpu().numpy())
                case "M":
                    for j in range(pred.shape[0]):
                        pred_ndarray[j] = test_data.inverse_transform_x(pred[j].detach().cpu().numpy())
                        true_ndarray[j] = test_data.inverse_transform_x(true[j].detach().cpu().numpy())
                case _:
                    raise ValueError(f"Invalid features: {self.model_parameter['features']}")
            # preds.append(pred.detach().cpu().numpy())
            # trues.append(true.detach().cpu().numpy())
            preds.append(pred_ndarray)
            trues.append(true_ndarray)

        preds = np.array(preds)
        trues = np.array(trues)
        preds = preds.reshape(-1, preds.shape[-2], preds.shape[-1])
        trues = trues.reshape(-1, trues.shape[-2], trues.shape[-1])
        self.logger.info('test shape:', preds.shape, trues.shape)

        # result save
        result_save_path = Path(f"resource/results/test_results/{self.project_name}/{get_current_time()}_test")
        if not result_save_path.exists():
            result_save_path.mkdir(parents=True, exist_ok=True)

        mae, mse, rmse, mape, mspe = metric(torch.from_numpy(preds), torch.from_numpy(trues))
        self.logger.info('mse:{}, mae:{}'.format(mse, mae))

        np.save(result_save_path.joinpath('pred.npy'), preds)
        np.save(result_save_path.joinpath('true.npy'), trues)
        np.save(result_save_path.joinpath('metrics.npy'), np.array([mae, mse, rmse, mape, mspe]))

        # 将self.name_list_input写入result_save_path
        with open(result_save_path.joinpath('name_list.txt'), 'w') as f:
            for name in self.input_name_list:
                f.write(f"{name}\n")
        
        # 将self.model_parameter写入result_save_path
        with open(result_save_path.joinpath('model_parameter.json'), 'w') as f:
            json.dump(self.model_parameter, f)

        # save model
        torch.save(self.model.state_dict(), result_save_path.joinpath('checkpoint.pth'))
        return
    
    def test_train(self, test=0):
        """
        Test model.
        """
        train_data, train_loader = self._get_data("train")
        if test == 1:
            self.logger.info("loading existing model!")
            self.model.load_state_dict(torch.load(Path(f"resource/models/{self.project_name}").joinpath("checkpoint.pth")))

        self.model.eval()

        preds = []
        trues = []

        for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(train_loader):
            pred, true = self._process_one_batch_time(batch_x, batch_y, batch_x_mark, batch_y_mark)
            # inverse transform
            pred_ndarray = np.zeros((pred.shape[0], pred.shape[1], pred.shape[2]))
            true_ndarray = np.zeros((true.shape[0], true.shape[1], true.shape[2]))
            
            match self.model_parameter["features"]:
                case "MS" | "S":
                    for j in range(pred.shape[0]):
                        pred_ndarray[j] = train_data.inverse_transform_y(pred[j].detach().cpu().numpy())
                        true_ndarray[j] = train_data.inverse_transform_y(true[j].detach().cpu().numpy())
                case "M":
                    for j in range(pred.shape[0]):
                        pred_ndarray[j] = train_data.inverse_transform_x(pred[j].detach().cpu().numpy())
                        true_ndarray[j] = train_data.inverse_transform_x(true[j].detach().cpu().numpy())
                case _:
                    raise ValueError(f"Invalid features: {self.model_parameter['features']}")
                
            # preds.append(pred.detach().cpu().numpy())
            # trues.append(true.detach().cpu().numpy())
            preds.append(pred_ndarray)
            trues.append(true_ndarray)

        preds = np.array(preds)
        trues = np.array(trues)
        self.logger.info('test shape:', preds.shape, trues.shape)
        preds = preds.reshape(-1, preds.shape[-2], preds.shape[-1])
        trues = trues.reshape(-1, trues.shape[-2], trues.shape[-1])
        self.logger.info('test shape:', preds.shape, trues.shape)

        # result save
        result_save_path = Path(f"resource/results/test_train_results/{self.project_name}/{get_current_time()}_test_train")
        if not result_save_path.exists():
            result_save_path.mkdir(parents=True, exist_ok=True)

        mae, mse, rmse, mape, mspe = metric(torch.from_numpy(preds), torch.from_numpy(trues))
        self.logger.info('mse:{}, mae:{}'.format(mse, mae))

        np.save(result_save_path.joinpath('pred_train.npy'), preds)
        np.save(result_save_path.joinpath('true_train.npy'), trues)
        np.save(result_save_path.joinpath('metrics_train.npy'), np.array([mae, mse, rmse, mape, mspe]))

        # 将self.name_list_input写入result_save_path
        with open(result_save_path.joinpath('name_list.txt'), 'w') as f:
            for name in self.input_name_list:
                f.write(f"{name}\n")

        return
    
    def print_model_info_transformer(self):
        freq_map = {"h": 4, "t": 5, "s": 6, "m": 1, "a": 1, "w": 2, "d": 3, "b": 3}
        time_embedding_size = freq_map[self.model_parameter['freq']]
        input_size1 = (self.model_parameter['batch_size'], self.model_parameter['seq_len'], self.model_parameter['enc_in'])
        input_size2 = (self.model_parameter['batch_size'], self.model_parameter['seq_len'], time_embedding_size)
        input_size3 = (self.model_parameter['batch_size'], self.model_parameter['label_len'] + self.model_parameter['pred_len'], self.model_parameter['dec_in'])
        input_size4 = (self.model_parameter['batch_size'], self.model_parameter['label_len'] + self.model_parameter['pred_len'], time_embedding_size)
        self.logger.info(f"input_size1: {input_size1}, input_size2: {input_size2}, input_size3: {input_size3}, input_size4: {input_size4}")

        if "TimeMachine" in self.algorithm_name:
            summary(self.model, input_size=(input_size1))
        else:
            summary(self.model, input_size=(input_size1, input_size2, input_size3, input_size4))
    
    def main(self) -> None:
        # connect to database and get trainer information
        self.database_connection()
        self.get_trainer_information()
        self.ensure_path()
        self.build_model()

        # 打印模型信息
        self.print_model_info_transformer()

        # Get data from database or local csv files
        self.data_input, self.data_output = self.get_train_data()
        data_process_client = SequenceDataFrameProcess(self.data_input, self.data_output)
        self.data_input, self.data_output = data_process_client.run()

        # 绘制输入输出曲线
        self.plotter.plot_input_curve(input_df=self.data_input, save_path=self.train_result_path)
        self.plotter.plot_output_curve(output_df=self.data_output, save_path=self.train_result_path)
        self.logger.info(f"{self.project_name}的输入数据为：{self.data_input}")
        self.logger.info(f"{self.project_name}的输出数据为：{self.data_output}")
        # self.data = pl.concat([self.data_input, self.data_output], how="horizontal")

        # data pipline
        # self.data = self.data_input

        self.logger.info(f"model: {self.model}")
        self.logger.info(f"model_parameter: {self.model_parameter}")
        # self.logger.info(f"model summary: {summary(self.model, input_size=(self.model_parameter['batch_size'], self.model_parameter['seq_len'], self.model_parameter['feature_dim']))}")

        self.train()
        # self.train_with_big_batch()  # 使用大batch训练,降低loss变化幅度

        self.test()

        # self.test(test=1)
        self.test_train()

    def main_test(self, **kwargs):
        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        # connect to database and get trainer information
        self.database_connection()
        self.get_trainer_information()
        self.ensure_path()
        self.build_model()

        # Get data from database or local csv files
        self.data_input, self.data_output = self.get_train_data()
        data_process_client = TransformerDataFramePreprocess(self.data_input, self.data_output)
        self.data_input, self.data_output = data_process_client.run()

        self.test(test=1, pth_name=kwargs.get("pth_name"))
        

class ClassicTrainer(ModelTrainer):
    """
    Trainer for classic models, including lstm, gru, etc.
    """
    def __init__(self, project_name: str, dbconfig: dict) -> None:
        super().__init__(project_name, dbconfig)
    
    def _get_data(self, flag) -> Tuple[Dataset, DataLoader, Dataset, DataLoader]:
        data_set_x, data_loader_x = data_provider_builder(self.project_name, self.data_input, "input", 
                                              self.model_parameter, flag)
        data_set_y, data_loader_y = data_provider_builder(self.project_name, self.data_output, "output", 
                                              self.model_parameter, flag)
        return data_set_x, data_loader_x, data_set_y, data_loader_y

    def vali(self, vali_loader_x: DataLoader, vali_loader_y: DataLoader, criterion: torch.nn.Module) -> float:
        """
        验证模型。

        Args:
            vali_loader_x (DataLoader): 验证集的输入数据
            vali_loader_y (DataLoader): 验证集的输出数据
            criterion (torch.nn.Module): 损失函数

        Returns:
            float: 验证集损失
        """
        vali_loss_list = []
        self.model.eval()
        with torch.no_grad():
            for i, (batch_x, batch_y) in enumerate(zip(vali_loader_x, vali_loader_y)):
                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.float().to(self.device)
                y_pred = self.model(batch_x)
                loss = criterion(y_pred, batch_y)
                vali_loss_list.append(loss.item())
        vali_loss = np.average(vali_loss_list)
        return vali_loss

    def train(self):
        """
        train model
        """
        # split data into train, vali and test
        train_data_x, train_loader_x, train_data_y, train_loader_y = self._get_data("train")
        vali_data_x, vali_loader_x, vali_data_y, vali_loader_y = self._get_data("val")

        self.logger.debug(f"Get train, vali and test data of {self.project_name} successfully!!!")

        with open(self.scaler_y_path, "rb") as f:
            self.scaler_y = pickle.load(f)
        
         # # 检查当前操作系统是否为Linux
        # is_linux = platform.system() == 'Linux'
        # # 在Linux上使用torch.compile优化模型
        # if is_linux:
        #     self.model = torch.compile(self.model, mode="max-autotune")
        #     self.logger.info("在Linux上使用torch.compile优化模型成功!")
        # set the criterion and optimizer
        self.criterion = self._set_criterion(self.model_parameter)
        self.optimizer = self._set_optimizer(self.model_parameter)

        # path for saving trained model
        trained_model_path = Path(f"resource/models/{self.project_name}")
        # judge if the trained model exists, if not then create the folder
        if not trained_model_path.exists():
            trained_model_path.mkdir(parents=True, exist_ok=True)

        train_bar = progressbar.ProgressBar(maxval=self.model_parameter["num_epochs"]).start()

        time_train_start = time.time()  # 开始训练的时间,用于计算训练所用的时间

        train_steps = len(train_loader_x)  # 计算训练用的步数

        train_loss_total_list = []  # 记录训练损失的列表,后续用于绘制训练损失曲线
        vali_loss_total_list = []  # 记录验证损失的列表,后续用于绘制验证损失曲线

        for epoch in trange(self.model_parameter["num_epochs"]):
            iter_count = 0  # 记录迭代次数
            train_loss_list = []  # 记录训练损失

            # true_train_list = []  # 记录真实值的列表
            # pred_train_list = []  # 记录预测值的列表

            self.model.train()
            epoch_time_start = time.time()  # 记录每个epoch开始的时间

            for i, (batch_x, batch_y) in enumerate(zip(train_loader_x, train_loader_y)):
                iter_count +=1

                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.float().to(self.device)

                y_pred = self.model(batch_x)


                loss = self.criterion(y_pred, batch_y)
                # loss.requires_grad_(True)
                train_loss_list.append(loss.item())

                # true_train_list += (batch_y.detach().cpu().numpy().reshape(-1, 1).reshape(-1).tolist())
                # pred_train_list += (y_pred.detach().cpu().numpy().reshape(-1, 1).reshape(-1).tolist())

                self.optimizer.zero_grad()

                if iter_count % 100 == 0:
                    self.logger.debug(
                        f"Epoch {epoch + 1} / {self.model_parameter['num_epochs']} Iteration {iter_count} / {train_steps}, \
                            Loss: {loss.item():.4f}")

                loss.backward()
                self.optimizer.step()
            
            # self.epoch_scheduler.step()

            # 打印每个参数的梯度
            # for name, param in self.model.named_parameters():
            #     if param.grad is not None:
            #         self.logger.debug(f"Gradient for {name}: {param.grad.norm().item()}")


            train_bar.update(epoch + 1)
            # 训练到最后一个epoch则绘制训练结果图
            self.logger.info(f"{self.project_name}:Epoch {epoch + 1} / {self.model_parameter['num_epochs']} cost time: {time.time() - epoch_time_start:.2f}")
            # if (epoch + 1) == self.model_parameter["num_epochs"]:
            #     true_train_array = np.array(true_train_list)
            #     pred_train_array = np.array(pred_train_list)
            #     # 反归一化true和predict,用于绘制曲线
            #     true_train_array = self.scaler_y.inverse_transform(true_train_array.reshape(1, -1))
            #     pred_train_array = self.scaler_y.inverse_transform(pred_train_array.reshape(1, -1))

            #     time_now = get_current_time()
            #     # 使用pyecharts绘制true_train_list和pred_train_list的矢量图并保存
            #     self.plotter.plot_train_result(time_now=time_now, epoch=epoch+1, true_list=true_train_array.tolist()[0],pred_list=pred_train_array.tolist()[0], save_path=self.train_result_path)
            #     self.logger.info(f"绘制{self.project_name}训练结果图成功！")

            epoch_time_end = time.time()  # 记录每个epoch结束的时间
            epoch_cost_time = epoch_time_end - epoch_time_start  # 计算每个epoch所用的时间
            self.logger.debug(f"Epoch {epoch + 1} / {self.model_parameter['num_epochs']} cost time: {epoch_cost_time:.2f}")

            train_loss = np.average(train_loss_list)  # 计算训练损失
            vali_loss = self.vali(vali_loader_x=vali_loader_x, vali_loader_y=vali_loader_y, criterion=self.criterion)  # 计算验证损失

            self.logger.info(f"Epoch {epoch + 1} / {self.model_parameter['num_epochs']} train_loss: {train_loss:.4f}, vali_loss: {vali_loss:.4f}")

            self.writer.add_scalar("Loss/train", train_loss, epoch)
            self.writer.add_scalar("Loss/vali", vali_loss, epoch)

            train_loss_total_list.append(train_loss)  # 将训练损失加入到列表中
            vali_loss_total_list.append(vali_loss)  # 将验证损失加入到列表中

            if (epoch + 1) % (self.model_parameter["num_epochs"] // 10) == 0:
                current_time = get_current_time()
                torch.save(self.model.state_dict(), trained_model_path.joinpath(f"checkpoint_{epoch + 1}_{vali_loss:.4f}_{current_time}.pth"))

        torch.save(self.model.state_dict(), trained_model_path.joinpath("checkpoint.pth"))
        time_train_end = time.time()  # 结束训练的时间
        time_train = time_train_end - time_train_start  # 计算训练所用的时间
        self.logger.info(f"训练{self.project_name}模型成功,用时{time_train}s!")

        train_bar.finish()

        self.plotter.plot_loss(time_now=get_current_time(), train_loss_list=train_loss_total_list, vali_loss_list=vali_loss_total_list,
                               save_path=self.train_result_path )
        self.logger.info(f"成功绘制{self.project_name}训练、验证损失曲线图！")

        torch.cuda.empty_cache()  # 清理cuda缓存

        return 
        

    def test(self, test=0) -> None:
        """
        test model
        """
        test_data_x, test_loader_x, test_data_y, test_loader_y = self._get_data("test")
        self.logger.info(f"开始测试{self.project_name}模型！")

        if test == 1:
            self.logger.info("loading existing model!")
            self.model.load_state_dict(torch.load(Path(f"resource/models/{self.project_name}").joinpath("checkpoint.pth"), weights_only=True))

        with open(self.scaler_y_path, "rb") as f:
                    self.scaler_y = pickle.load(f)

        self.model.eval()

        pred_test_list = []
        true_test_list = []

        with torch.no_grad():
            for i, (batch_x, batch_y) in enumerate(zip(test_loader_x, test_loader_y)):
                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.float().to(self.device)
                y_pred = self.model(batch_x)
                true_test_list += (batch_y.detach().cpu().numpy().reshape(-1).tolist())
                pred_test_list += (y_pred.detach().cpu().numpy().reshape(-1).tolist())

        pred_test_array = np.array(pred_test_list)
        true_test_array = np.array(true_test_list)
        self.logger.info(f"true_test_array: {true_test_array} with shape: {true_test_array.shape}")
        self.logger.info(f"pred_test_array: {pred_test_array} with shape: {pred_test_array.shape}")
        pred_test_array = self.scaler_y.inverse_transform(pred_test_array.reshape(1, -1))
        true_test_array = self.scaler_y.inverse_transform(true_test_array.reshape(1, -1))

        test_result_path = Path(f"resource/results/test_results/{self.project_name}")
        if not test_result_path.exists():
            test_result_path.mkdir(parents=True, exist_ok=True)
        time_now = get_current_time()
        self.plotter.plot_test_result(time_now=time_now,true_list=true_test_array.tolist()[0], pred_list=pred_test_array.tolist()[0], save_path=test_result_path)
        self.logger.info(f"绘制{self.project_name}测试结果图成功！")

        # 计算测试结果（误差）
        mae, mse, rmse, mape, mspe = metric(torch.from_numpy(pred_test_array), torch.from_numpy(true_test_array))
        self.logger.info(f"测试{self.project_name}模型得到的误差:mae={mae:.4f}, mse={mse:.4f}, rmse={rmse:.4f}, mape={mape:.4f}, mspe={mspe:.4f}")

        torch.cuda.empty_cache()  # 释放显存

    def test_train(self, test=0) -> None:
        """
        test model
        """
        test_data_x, test_loader_x, test_data_y, test_loader_y = self._get_data("train")
        self.logger.info(f"开始测试{self.project_name}模型！")

        if test == 1:
            self.logger.info("loading existing model!")
            self.model.load_state_dict(torch.load(Path(f"resource/models/{self.project_name}").joinpath("checkpoint.pth"), weights_only=True))

        with open(self.scaler_y_path, "rb") as f:
                    self.scaler_y = pickle.load(f)

        self.model.eval()

        pred_test_list = []
        true_test_list = []

        with torch.no_grad():
            for i, (batch_x, batch_y) in enumerate(zip(test_loader_x, test_loader_y)):
                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.float().to(self.device)
                y_pred = self.model(batch_x)
                true_test_list += (batch_y.detach().cpu().numpy().reshape(-1).tolist())
                pred_test_list += (y_pred.detach().cpu().numpy().reshape(-1).tolist())

        pred_test_array = np.array(pred_test_list)
        true_test_array = np.array(true_test_list)
        pred_test_array = self.scaler_y.inverse_transform(pred_test_array.reshape(1, -1))
        true_test_array = self.scaler_y.inverse_transform(true_test_array.reshape(1, -1))

        test_result_path = Path(f"resource/results/test_train_results/{self.project_name}")
        if not test_result_path.exists():
            test_result_path.mkdir(parents=True, exist_ok=True)
        time_now = get_current_time()
        self.plotter.plot_test_result(time_now=time_now,true_list=true_test_array.tolist()[0], pred_list=pred_test_array.tolist()[0], save_path=test_result_path)
        self.logger.info(f"绘制{self.project_name}测试结果图成功！")

        # 计算测试结果（误差）
        mae, mse, rmse, mape, mspe = metric(torch.from_numpy(pred_test_array), torch.from_numpy(true_test_array))
        self.logger.info(f"使用训练数据测试{self.project_name}模型得到的误差:mae={mae:.4f}, mse={mse:.4f}, rmse={rmse:.4f}, mape={mape:.4f}, mspe={mspe:.4f}")

        torch.cuda.empty_cache()  # 释放显存
    
    def print_model_info_classic(self):
        input_size = (self.model_parameter['batch_size'], self.model_parameter['x_length'], self.model_parameter['in_channels'])
        self.logger.info(f"input_size: {input_size}")
        summary(self.model, input_size=input_size)

    def plot_data_analysis(self) -> None:
        """
        绘制数据分析图表
        """
        # 绘制输入输出曲线
        self.plotter.plot_input_curve(input_df=self.data_input, save_path=self.train_result_path)
        self.plotter.plot_output_curve(output_df=self.data_output, save_path=self.train_result_path)
        self.logger.info(f"{self.project_name}的输入数据为：{self.data_input}")
        self.logger.info(f"{self.project_name}的输出数据为：{self.data_output}")

        # 绘制输入输出箱线图
        self.plotter.plot_input_boxplot(input_df=self.data_input, save_path=self.train_result_path)
        self.plotter.plot_output_boxplot(output_df=self.data_output, save_path=self.train_result_path)


    def main(self) -> None:
        # connect to database and get trainer information
        self.database_connection()
        self.get_trainer_information()
        self.ensure_path()
        self.build_model()

        # print model info
        self.print_model_info_classic()

        # Get data from database or local csv files
        self.data_input, self.data_output = self.get_train_data()
        # data_process_client = DataFramePreprocess(self.data_input, self.data_output)
        data_process_client = ClassicDataFrameProcess(self.data_input, self.data_output)
        self.data_input, self.data_output = data_process_client.run()

        # 绘制输入输出曲线等
        self.plot_data_analysis()

        self.train()
        self.test_train()
        self.test()
    
    # 测试已有的模型
    def main_test(self) -> None:
        # connect to database and get trainer information
        self.database_connection()
        self.get_trainer_information()
        self.ensure_path()
        self.build_model()

        # print model info
        self.print_model_info_classic()

        # Get data from database or local csv files
        self.data_input, self.data_output = self.get_train_data()
        data_process_client = ClassicDataFrameProcess(self.data_input, self.data_output)
        self.data_input, self.data_output = data_process_client.run()
        
        self.test_train(test=1)
        self.test(test=1)
    
    def run(self, preprocess_flag: bool = True) -> None:
        """
        运行模型训练和测试
        """
        # connect to database and get trainer information
        self.database_connection()
        self.get_trainer_information()
        self.ensure_path()
        self.build_model()

        # print model info
        self.print_model_info_classic()

        # Get data from database or local csv files
        self.data_input, self.data_output = self.get_train_data()
        # data_process_client = DataFramePreprocess(self.data_input, self.data_output)
        data_process_client = ClassicDataFrameProcess(self.data_input, self.data_output)
        self.data_input, self.data_output = data_process_client.run_flag(preprocess_flag=preprocess_flag)

        # 绘制输入输出曲线等
        self.plot_data_analysis()

        self.train()
        self.test_train()
        self.test()


