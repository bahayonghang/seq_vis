import pickle
import numpy as np
import pandas as pd
import polars as pl

from pathlib import Path
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from torch.utils.data import Dataset

from industrytslib.models.aimodels.utils.timefeatures import time_features
from industrytslib.utils.data_processing.polarsoperation import detect_production_periods


def generate_random_index(data_len:int, random_num:int):
    """
    从一个Dataset中随机抽取
    """
    random_index = np.random.choice(data_len, random_num, replace=False)
    return random_index


class InputTimeSeriesDataset(Dataset):
    def __init__(self, project_name: str, tsdata: pl.DataFrame, size: list, scaler_type: str = 'minmax', flag: str = 'train'):
        """
        初始化TimeSeriesDataset类
        
        参数:
        tsdata (pl.DataFrame): 特征数据
        window_size (int): 滑动窗口大小
        scaler_type (str): 归一化类型，可以是 'standard' 或 'minmax'
        """
        super().__init__()
        self.project_name = project_name
        self.tsdata = tsdata
        self.columns = self.tsdata.columns
        self.scaler_folder_path = Path(f"resource/scaler/{self.project_name}")
        if self.scaler_folder_path.exists() is False:
            self.scaler_folder_path.mkdir(parents=True)
        self.scaler_path = Path(f"resource/scaler/{self.project_name}/scaler_x.pkl")

        # init
        self.flag = flag
        assert self.flag in ['train', 'test', 'val']
        type_map = {'train': 0, 'val': 1, 'test': 2}
        self.set_type = type_map[flag]

        self.x_length = size[0]
        self.y_length = size[1]
        self.pred_len = size[2]
        self.x_sliding_length = size[3]
        self.y_sliding_length = size[4]

        match scaler_type:
            case 'standard':
                self.scaler = StandardScaler()
            case 'minmax':
                self.scaler = MinMaxScaler(feature_range=(0, 1))
            case _:
                print(f'scaler_type must be either \'standard\' or \'minmax\', but got {scaler_type}')
                self.scaler = StandardScaler()

        self.__read_data__()

    def __read_data__(self):
        num_train = int(len(self.tsdata) * 0.8)
        num_vali = int(len(self.tsdata) * 0.1)
        # num_test = len(self.tsdata) - num_train - num_vali

        # 如果x_sliding_length大于1，则需要将num_train限制为x_sliding_length的整数倍
        if self.x_sliding_length > 1:
            num_train = num_train - num_train % self.x_sliding_length
            num_vali = num_vali - num_vali % self.x_sliding_length

        border1s = [0, num_train, num_train + num_vali]
        border2s = [num_train, num_train + num_vali, len(self.tsdata)]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]

        # 归一化，并把归一化参数保存到本地
        self.scaler.fit(self.tsdata)
        self.tsdata = self.scaler.transform(self.tsdata)
        with open(self.scaler_path, 'wb') as f:
            pickle.dump(self.scaler, f)

        self.data = self.tsdata[border1: border2]
        print(f"length of {self.flag} input data: {len(self.data)}")

    def __getitem__(self, index):
        s_begin = index * self.x_sliding_length
        s_end = s_begin + self.x_length
        
        if s_end > len(self.data):
            # If there's not enough data left, return None
            return None
        
        seq_x = self.data[s_begin:s_end]
        
        if seq_x.shape[0] != self.x_length:
            # This shouldn't happen now, but keep as a safeguard
            print(f"seq_x shape is {seq_x.shape}, but expected shape is {self.x_length}")
            return None
        
        return seq_x

    def __len__(self):
        return (len(self.data) - self.x_length) // self.x_sliding_length

    def inverse_transform(self, x):
        return self.scaler.inverse_transform(x)


class OutputTimeSeriesDataset(Dataset):
    def __init__(self, project_name: str, tsdata: pl.DataFrame, size: list, scaler_type: str = 'minmax', flag: str = 'train'):
        """
        初始化OutputTimeSeriesDataset类
        
        参数:
        tsdata (pl.DataFrame): 特征数据
        window_size (int): 滑动窗口大小
        scaler_type (str): 归一化类型，可以是 'standard' 或 'minmax'
        """
        super().__init__()
        self.project_name = project_name
        self.tsdata = tsdata
        self.columns = self.tsdata.columns
        self.scaler_folder_path = Path(f"resource/scaler/{self.project_name}")
        if self.scaler_folder_path.exists() is False:
            self.scaler_folder_path.mkdir(parents=True)
        self.scaler_path = Path(f"resource/scaler/{self.project_name}/scaler_y.pkl")

        # init
        self.flag = flag
        assert self.flag in ['train', 'test', 'val']
        type_map = {'train': 0, 'val': 1, 'test': 2}
        self.set_type = type_map[flag]

        self.x_length = size[0]
        self.y_length = size[1]
        self.pred_len = size[2]
        self.x_sliding_length = size[3]
        self.y_sliding_length = size[4]

        match scaler_type:
            case 'standard':
                self.scaler = StandardScaler()
            case 'minmax':
                self.scaler = MinMaxScaler(feature_range=(0, 1))
            case _:
                print(f'scaler_type must be either \'standard\' or \'minmax\', but got {scaler_type}')
                self.scaler = StandardScaler()

        self.__read_data__()

    def __read_data__(self):
        num_train = int(len(self.tsdata) * 0.8)
        num_vali = int(len(self.tsdata) * 0.1)
        # num_test = len(self.tsdata) - num_train - num_vali

        border1s = [0, num_train, num_train + num_vali]
        border2s = [num_train, num_train + num_vali, len(self.tsdata)]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]

        # 归一化，并把归一化参数保存到本地
        self.scaler.fit(self.tsdata)
        self.tsdata = self.scaler.transform(self.tsdata)
        with open(self.scaler_path, 'wb') as f:
            pickle.dump(self.scaler, f)

        self.data = self.tsdata[border1: border2]
        print(f"length of {self.flag} output data: {len(self.data)}")

    def __getitem__(self, index):
        s_begin = index * self.y_sliding_length
        s_end = s_begin + self.y_length + self.pred_len - 1

        seq_y = self.data[s_end]

        return seq_y

    def __len__(self):
        return (len(self.data) - self.y_length - self.pred_len) // self.y_sliding_length

    def inverse_transform(self, x):
        return self.scaler.inverse_transform(x)


class SequenceTimeSeriesDataset(Dataset):
    def __init__(
        self, project_name: str, input_data: pl.DataFrame, output_data: pl.DataFrame, 
        size: list | None, scaler_type: str = 'minmax', flag: str = 'train', freq: str = 't'
    ):
        """
        基于pl.dataframe的时间序列数据集
        参数:
        input_data (pl.DataFrame): 输入数据
        output_data (pl.DataFrame): 输出数据
        Note: input_data和output_data的DateTime列必须相同,行数必须相同
        scaler_type (str): 归一化类型，可以是 'standard' 或 'minmax'
        """
        super().__init__()
        self.project_name = project_name

        self.input_data = input_data
        self.output_data = output_data
        assert self.input_data.shape[0] == self.output_data.shape[0], "input_data和output_data的行数必须相同"

        self.datetime_data = input_data.select(input_data.columns[0])
        # set input_data without datetime column
        self.input_data = self.input_data.select(self.input_data.columns[1:])
        # set output_data without datetime column
        self.output_data = self.output_data.select(self.output_data.columns[1:])

        self.input_columns = self.input_data.columns
        self.output_columns = self.output_data.columns

        self.scaler_folder_path = Path(f"resource/scaler/{self.project_name}")
        if self.scaler_folder_path.exists() is False:
            self.scaler_folder_path.mkdir(parents=True)
        self.scaler_x_path = Path(f"resource/scaler/{self.project_name}/scaler_x.pkl")
        self.scaler_y_path = Path(f"resource/scaler/{self.project_name}/scaler_y.pkl")

        match size:
            case None:
                self.seq_len = 24*4*4
                self.label_len = 24*4
                self.pred_len = 24*4
            case _:
                self.seq_len = size[0]
                self.label_len = size[1]
                self.pred_len = size[2]
        # init
        self.freq = freq
        self.flag = flag
        assert self.flag in ['train', 'test', 'val']
        type_map = {'train': 0, 'val': 1, 'test': 2}
        self.set_type = type_map[flag]

        # 定义数据集归一化方式
        match scaler_type:
            case 'standard':
                self.scaler_x = StandardScaler()
                self.scaler_y = StandardScaler()
            case 'minmax':
                self.scaler_x = MinMaxScaler(feature_range=(0, 1))
                self.scaler_y = MinMaxScaler(feature_range=(0, 1))
            case _:
                print(f'scaler_type must be either \'standard\' or \'minmax\', but got {scaler_type}')
                self.scaler_x = MinMaxScaler(feature_range=(0, 1))
                self.scaler_y = MinMaxScaler(feature_range=(0, 1))

        self.__read_data__()

    def __read_data__(self):
        num_train = int(len(self.input_data) * 0.8)
        num_vali = int(len(self.input_data) * 0.1)
        # num_test = len(self.input_data) - num_train - num_vali

        border1s = [0, num_train, num_train + num_vali]
        border2s = [num_train, num_train + num_vali, len(self.input_data)]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]

        df_stamp = self.datetime_data[border1: border2].to_pandas()
        # df_stamp['DateTime'] = pd.to_datetime(df_stamp.DateTime)
        df_stamp['DateTime'] = pd.to_datetime(df_stamp.iloc[:, 0])
        self.data_stamp = time_features(df_stamp, timeenc=1, freq=self.freq)

        # 归一化，并把归一化参数保存到本地
        self.scaler_x.fit(self.input_data)
        self.input_data = self.scaler_x.transform(self.input_data)
        with open(self.scaler_x_path, 'wb') as f:
            pickle.dump(self.scaler_x, f)

        self.scaler_y.fit(self.output_data)
        self.output_data = self.scaler_y.transform(self.output_data)
        with open(self.scaler_y_path, 'wb') as f:
            pickle.dump(self.scaler_y, f)

        self.data_x = self.input_data[border1: border2]
        self.data_y = self.output_data[border1: border2]

    def __getitem__(self, index: int):
        s_begin = index
        s_end = s_begin + self.seq_len
        r_begin = s_end - self.label_len
        r_end = r_begin + self.label_len + self.pred_len

        seq_x = self.data_x[s_begin: s_end]
        seq_y = self.data_y[r_begin: r_end]
        seq_x_mark = self.data_stamp[s_begin: s_end]
        seq_y_mark = self.data_stamp[r_begin: r_end]

        seq_y_history = self.data_y[s_begin: r_begin]

        return seq_x, seq_y, seq_x_mark, seq_y_mark, seq_y_history

    def __len__(self):
        return len(self.data_x) - self.seq_len - self.pred_len + 1
    
    def inverse_transform_x(self, x):
        return self.scaler_x.inverse_transform(x)

    def inverse_transform_y(self, y):
        return self.scaler_y.inverse_transform(y)


class RandomSequenceTimeSeriesDataset(Dataset):
    def __init__(
            self, project_name: str, input_data: pl.DataFrame, 
            output_data: pl.DataFrame, size: list | None, 
            scaler_type: str = 'minmax', flag: str = 'train', freq: str = 't'
    ):
        """
        基于pl.dataframe的时间序列数据集
        参数:
        input_data (pl.DataFrame): 输入数据
        output_data (pl.DataFrame): 输出数据
        Note: input_data和output_data的DateTime列必须相同,行数必须相同
        scaler_type (str): 归一化类型，可以是 'standard' 或 'minmax'
        """
        super().__init__()
        self.project_name = project_name

        self.input_data = input_data
        self.output_data = output_data
        assert self.input_data.shape[0] == self.output_data.shape[0], "input_data和output_data的行数必须相同"

        self.datetime_data = input_data.select(input_data.columns[0])
        # set input_data without datetime column
        self.input_data = self.input_data.select(self.input_data.columns[1:])
        # set output_data without datetime column
        self.output_data = self.output_data.select(self.output_data.columns[1:])

        self.input_columns = self.input_data.columns
        self.output_columns = self.output_data.columns

        self.scaler_folder_path = Path(f"resource/scaler/{self.project_name}")
        if self.scaler_folder_path.exists() is False:
            self.scaler_folder_path.mkdir(parents=True)
        self.scaler_x_path = Path(f"resource/scaler/{self.project_name}/scaler_x.pkl")
        self.scaler_y_path = Path(f"resource/scaler/{self.project_name}/scaler_y.pkl")

        match size:
            case None:
                self.seq_len = 24*4*4
                self.label_len = 24*4
                self.pred_len = 24*4
            case _:
                self.seq_len = size[0]
                self.label_len = size[1]
                self.pred_len = size[2]
        # init
        self.freq = freq
        self.flag = flag
        assert self.flag in ['train', 'test', 'val']
        type_map = {'train': 0, 'val': 1, 'test': 2}
        self.set_type = type_map[flag]

        # 根据flag设置随机数种子
        match self.flag:
            case 'train':
                pass
            case _:
                np.random.seed(42)

        # 定义数据集归一化方式
        match scaler_type:
            case 'standard':
                self.scaler_x = StandardScaler()
                self.scaler_y = StandardScaler()
            case 'minmax':
                self.scaler_x = MinMaxScaler(feature_range=(0, 1))
                self.scaler_y = MinMaxScaler(feature_range=(0, 1))
            case _:
                print(f'scaler_type must be either \'standard\' or \'minmax\', but got {scaler_type}')
                self.scaler_x = MinMaxScaler(feature_range=(0, 1))
                self.scaler_y = MinMaxScaler(feature_range=(0, 1))

        self.__read_data__()

    def __read_data__(self):
        """Read and prepare data using sliding windows with random starting points."""
        total_length = len(self.input_data)
        
        # Calculate the length needed for one complete sequence
        sequence_length = self.seq_len + self.pred_len
        
        # Calculate how many valid sequences we can create
        valid_start_indices = total_length - sequence_length + 1
        
        # Generate all possible starting indices
        all_start_indices = np.arange(valid_start_indices)
        np.random.shuffle(all_start_indices)  # Randomly shuffle starting points
        
        # Calculate number of sequences for each split
        num_sequences = len(all_start_indices)
        num_train = int(num_sequences * 0.8)
        num_vali = int(num_sequences * 0.1)
        
        # Split starting indices for each set
        train_starts = all_start_indices[:num_train]
        val_starts = all_start_indices[num_train:num_train + num_vali]
        test_starts = all_start_indices[num_train + num_vali:]
        
        # Select appropriate starting indices based on flag
        starts_map = {
            'train': train_starts,
            'val': val_starts,
            'test': test_starts
        }
        selected_starts = starts_map[self.flag]
        
        # Fit scalers on the entire dataset (since it's time series data)
        self.scaler_x.fit(self.input_data)
        self.scaler_y.fit(self.output_data)
        
        # Save scalers
        with open(self.scaler_x_path, 'wb') as f:
            pickle.dump(self.scaler_x, f)
        with open(self.scaler_y_path, 'wb') as f:
            pickle.dump(self.scaler_y, f)
        
        # Transform all data
        self.input_data = self.scaler_x.transform(self.input_data)
        self.output_data = self.scaler_y.transform(self.output_data)
        
        # Store starting indices for use in __getitem__
        self.valid_indices = selected_starts
        
        # Process datetime features for the entire dataset
        df_stamp = self.datetime_data.to_pandas()
        df_stamp['DateTime'] = pd.to_datetime(df_stamp.iloc[:, 0])
        self.data_stamp = time_features(df_stamp, timeenc=1, freq=self.freq)
        
        print(f"Number of {self.flag} sequences: {len(self.valid_indices)}")

    def __getitem__(self, index: int):
        """Get a sequence starting from a random valid starting point."""
        # Get the starting point for this sequence
        s_begin = self.valid_indices[index]
        s_end = s_begin + self.seq_len
        r_begin = s_end - self.label_len
        r_end = r_begin + self.label_len + self.pred_len

        seq_x = self.input_data[s_begin:s_end]
        seq_y = self.output_data[r_begin:r_end]
        seq_x_mark = self.data_stamp[s_begin:s_end]
        seq_y_mark = self.data_stamp[r_begin:r_end]
        seq_y_history = self.output_data[s_begin:r_begin]

        return seq_x, seq_y, seq_x_mark, seq_y_mark, seq_y_history


    def __len__(self):
        """Return the number of valid sequences for this split."""
        return len(self.valid_indices)
    
    def inverse_transform_x(self, x):
        return self.scaler_x.inverse_transform(x)

    def inverse_transform_y(self, y):
        return self.scaler_y.inverse_transform(y)


# 根据运行时间段划分数据集，然后划分训练集、验证集、测试集
class OperationSequenceTimeSeriesDataset(Dataset):
    def __init__(
        self, 
        project_name: str, 
        input_data: pl.DataFrame, 
        output_data: pl.DataFrame, 
        size: list | None, 
        scaler_type: str = 'minmax', 
        flag: str = 'train', 
        freq: str = 't'
    ):
        """
        基于pl.dataframe的时间序列数据集
        参数:
        input_data (pl.DataFrame): 输入数据
        output_data (pl.DataFrame): 输出数据
        Note: input_data和output_data的DateTime列必须相同,行数必须相同
        scaler_type (str): 归一化类型，可以是 'standard' 或 'minmax'
        """
        super().__init__()
        self.project_name = project_name

        self.data_input = input_data
        # self.data_output = output_data
        self.data_output = input_data
        assert self.data_input.shape[0] == self.data_output.shape[0], f"{self.project_name} | {self.flag} | input_data和output_data的行数必须相同"

        self.datetime_data = input_data.select(input_data.columns[0])
        # set input_data without datetime column
        self.input_data = self.data_input.select(self.data_input.columns[1:])
        # set output_data without datetime column
        self.output_data = self.data_output.select(self.data_output.columns[1:])

        self.input_columns = self.data_input.columns
        self.output_columns = self.data_output.columns

        self.scaler_folder_path = Path(f"resource/scaler/{self.project_name}")
        if self.scaler_folder_path.exists() is False:
            self.scaler_folder_path.mkdir(parents=True)
        self.scaler_x_path = Path(f"resource/scaler/{self.project_name}/scaler_x.pkl")
        self.scaler_y_path = Path(f"resource/scaler/{self.project_name}/scaler_y.pkl")

        match size:
            case None:
                self.seq_len = 24*4*4
                self.label_len = 24*4
                self.pred_len = 24*4
            case _:
                self.seq_len = size[0]
                self.label_len = size[1]
                self.pred_len = size[2]
        # init
        self.freq = freq
        self.flag = flag
        assert self.flag in ['train', 'test', 'val']
        type_map = {'train': 0, 'val': 1, 'test': 2}
        self.set_type = type_map[flag]

        # 根据flag设置随机数种子
        match self.flag:
            case 'train':
                pass
            case _:
                np.random.seed(42)

        # 定义数据集归一化方式
        match scaler_type:
            case 'standard':
                self.scaler_x = StandardScaler()
                self.scaler_y = StandardScaler()
            case 'minmax':
                self.scaler_x = MinMaxScaler(feature_range=(0, 1))
                self.scaler_y = MinMaxScaler(feature_range=(0, 1))
            case _:
                print(f'scaler_type must be either \'standard\' or \'minmax\', but got {scaler_type}')
                self.scaler_x = MinMaxScaler(feature_range=(0, 1))
                self.scaler_y = MinMaxScaler(feature_range=(0, 1))

        self.__read_data__()

    def __read_data__(self):
        """
        Read and prepare data by splitting within each production period into train/val/test sets.
        For each production period, the data is split in an 8:1:1 ratio.
        """
        # Add production period IDs to input and output data
        self.data_input = detect_production_periods(self.data_input)
        self.data_output = detect_production_periods(self.data_output)
        print(f"After add production period:{self.project_name} | {self.flag} | data_input:{self.data_input}")
        print(f"After add production period:{self.project_name} | {self.flag} | data_output:{self.data_output}")
        
        # 保存DateTime和生产周期信息
        self.datetime_data = self.data_input.select(pl.col("DateTime"))
        production_periods = self.data_input.select(pl.col("production_period"))
        production_periods_output = self.data_output.select(pl.col("production_period"))
        # 检查production_periods和production_periods_output是否相同
        assert production_periods.equals(production_periods_output), f"{self.project_name} | {self.flag} | production_periods和production_periods_output不相同"
        
        # 设置input_data和output_data（不包含DateTime和production_period列）
        self.input_data = self.data_input.select(self.data_input.columns[1:-1])  # 排除DateTime和production_period
        self.output_data = self.data_output.select(self.data_output.columns[1:-1])  # 排除DateTime和production_period
        
        # Get unique production periods
        unique_periods = production_periods.select(pl.col("production_period")).unique().sort(by="production_period")
        print(f"unique_periods: {unique_periods}")
        
        # Calculate sequence length needed for one complete sequence
        sequence_length = self.seq_len + self.pred_len
        
        # Store valid indices for each split
        all_valid_indices = {
            'train': [],
            'val': [],
            'test': []
        }
        
        # Process each production period separately
        for period in unique_periods.to_series():
            # Get indices for current period
            period_indices = production_periods.with_row_count().filter(
                pl.col("production_period") == period
            ).get_column("row_nr").to_list()
            
            period_length = len(period_indices)
            # print(f"period: {period}, period_length: {period_length}")
            
            # Skip if period is too short for a complete sequence
            if period_length < sequence_length:
                continue
                
            # Find all valid starting points in this period
            valid_indices_in_period = []
            for i in range(period_length - sequence_length + 1):
                valid_indices_in_period.append(period_indices[i])
            
            # Skip if no valid sequences in this period
            if not valid_indices_in_period:
                continue
                
            # Shuffle indices within this period
            valid_indices_in_period = np.array(valid_indices_in_period)
            # np.random.shuffle(valid_indices_in_period)
            
            # Split indices for this period (8:1:1)
            n_indices = len(valid_indices_in_period) - self.seq_len - self.pred_len + 1

            if n_indices <= 0:
                continue

            n_train = int(n_indices * 0.8)
            n_val = int(n_indices * 0.1)
            
            # Add to appropriate splits
            all_valid_indices['train'].extend(valid_indices_in_period[:n_train])
            all_valid_indices['val'].extend(valid_indices_in_period[n_train:n_train + n_val])
            all_valid_indices['test'].extend(valid_indices_in_period[n_train + n_val:])
            print(f"period: {period}, n_train: {n_train}, n_val: {n_val}, n_test: {n_indices - n_train - n_val}")
        
        # Select indices for current split
        self.valid_indices = np.array(all_valid_indices[self.flag])
        # np.random.shuffle(self.valid_indices)  # Final shuffle of selected indices
        
        # Fit and transform data with scalers
        self.scaler_x.fit(self.input_data)
        self.scaler_y.fit(self.output_data)
        
        # Save scalers
        with open(self.scaler_x_path, 'wb') as f:
            pickle.dump(self.scaler_x, f)
        with open(self.scaler_y_path, 'wb') as f:
            pickle.dump(self.scaler_y, f)
        
        # Transform data
        self.input_data = self.scaler_x.transform(self.input_data)
        self.output_data = self.scaler_y.transform(self.output_data)
        
        # Process datetime features
        df_stamp = self.datetime_data.to_pandas()
        df_stamp['DateTime'] = pd.to_datetime(df_stamp.iloc[:, 0])
        self.data_stamp = time_features(df_stamp, timeenc=1, freq=self.freq)
        
        print(f"Number of production periods: {len(unique_periods)}")
        print(f"Number of {self.flag} sequences: {len(self.valid_indices)}")

    def __getitem__(self, index: int):
        """
        Get a sequence starting from a random valid starting point.
        """
        # Get the starting point for this sequence
        s_begin = self.valid_indices[index]
        s_end = s_begin + self.seq_len
        r_begin = s_end - self.label_len
        r_end = r_begin + self.label_len + self.pred_len

        seq_x = self.input_data[s_begin:s_end]
        seq_y = self.output_data[r_begin:r_end]
        seq_x_mark = self.data_stamp[s_begin:s_end]
        seq_y_mark = self.data_stamp[r_begin:r_end]
        seq_y_history = self.output_data[s_begin:s_end]

        return seq_x, seq_y, seq_x_mark, seq_y_mark, seq_y_history

    def __len__(self):
        """
        Return the number of valid sequences for this split.
        """
        return len(self.valid_indices)
    
    def inverse_transform_x(self, x):
        return self.scaler_x.inverse_transform(x)

    def inverse_transform_y(self, y):
        return self.scaler_y.inverse_transform(y)
    

class OperationSequenceDatasetTime(Dataset):
    def __init__(
        self, 
        project_name: str, 
        input_data: pl.DataFrame, 
        output_data: pl.DataFrame, 
        size: list | None, 
        scaler_type: str = 'minmax', 
        flag: str = 'train', 
        freq: str = 't'
    ):
        """
        基于pl.dataframe的时间序列数据集
        参数:
        input_data (pl.DataFrame): 输入数据
        output_data (pl.DataFrame): 输出数据
        Note: input_data和output_data的DateTime列必须相同,行数必须相同
        scaler_type (str): 归一化类型，可以是 'standard' 或 'minmax'
        """
        super().__init__()
        self.project_name = project_name

        self.data_input = input_data
        # self.data_output = output_data
        self.data_output = input_data
        assert self.data_input.shape[0] == self.data_output.shape[0], f"{self.project_name} | {self.flag} | input_data和output_data的行数必须相同"

        self.datetime_data = input_data.select(input_data.columns[0])
        # set input_data without datetime column
        self.input_data = self.data_input.select(self.data_input.columns[1:])
        # set output_data without datetime column
        self.output_data = self.data_output.select(self.data_output.columns[1:])

        self.input_columns = self.data_input.columns
        self.output_columns = self.data_output.columns

        self.scaler_folder_path = Path(f"resource/scaler/{self.project_name}")
        if self.scaler_folder_path.exists() is False:
            self.scaler_folder_path.mkdir(parents=True)
        self.scaler_x_path = Path(f"resource/scaler/{self.project_name}/scaler_x.pkl")
        self.scaler_y_path = Path(f"resource/scaler/{self.project_name}/scaler_y.pkl")

        match size:
            case None:
                self.seq_len = 24*4*4
                self.label_len = 24*4
                self.pred_len = 24*4
            case _:
                self.seq_len = size[0]
                self.label_len = size[1]
                self.pred_len = size[2]
        # init
        self.freq = freq
        self.flag = flag
        assert self.flag in ['train', 'test', 'val']
        type_map = {'train': 0, 'val': 1, 'test': 2}
        self.set_type = type_map[flag]

        # 根据flag设置随机数种子
        match self.flag:
            case 'train':
                pass
            case _:
                np.random.seed(42)

        # 定义数据集归一化方式
        match scaler_type:
            case 'standard':
                self.scaler_x = StandardScaler()
                self.scaler_y = StandardScaler()
            case 'minmax':
                self.scaler_x = MinMaxScaler(feature_range=(0, 1))
                self.scaler_y = MinMaxScaler(feature_range=(0, 1))
            case _:
                print(f'scaler_type must be either \'standard\' or \'minmax\', but got {scaler_type}')
                self.scaler_x = MinMaxScaler(feature_range=(0, 1))
                self.scaler_y = MinMaxScaler(feature_range=(0, 1))

        self.__read_data__()

    def __read_data__(self):
        """
        Read and prepare data by splitting within each production period into train/val/test sets.
        For each production period, the data is split in an 8:1:1 ratio.
        """
        # Add production period IDs to input and output data
        self.data_input = detect_production_periods(self.data_input)
        self.data_output = detect_production_periods(self.data_output)
        print(f"After add production period:{self.project_name} | {self.flag} | data_input:{self.data_input}")
        print(f"After add production period:{self.project_name} | {self.flag} | data_output:{self.data_output}")
        
        # 保存DateTime和生产周期信息
        self.datetime_data = self.data_input.select(pl.col("DateTime"))
        production_periods = self.data_input.select(pl.col("production_period"))
        production_periods_output = self.data_output.select(pl.col("production_period"))
        # 检查production_periods和production_periods_output是否相同
        assert production_periods.equals(production_periods_output), f"{self.project_name} | {self.flag} | production_periods和production_periods_output不相同"
        
        # 设置input_data和output_data（不包含DateTime和production_period列）
        self.input_data = self.data_input.select(self.data_input.columns[1:-1])  # 排除DateTime和production_period
        self.output_data = self.data_output.select(self.data_output.columns[1:-1])  # 排除DateTime和production_period
        
        # Get unique production periods
        unique_periods = production_periods.select(pl.col("production_period")).unique().sort(by="production_period")
        print(f"unique_periods: {unique_periods}")
        
        # Calculate sequence length needed for one complete sequence
        sequence_length = self.seq_len + self.pred_len
        
        # Store valid indices for each split
        all_valid_indices = {
            'train': [],
            'val': [],
            'test': []
        }
        
        # Process each production period separately
        for period in unique_periods.to_series():
            # Get indices for current period
            period_indices = production_periods.with_row_count().filter(
                pl.col("production_period") == period
            ).get_column("row_nr").to_list()
            
            period_length = len(period_indices)
            # print(f"period: {period}, period_length: {period_length}")
            
            # Skip if period is too short for a complete sequence
            if period_length < sequence_length:
                continue
                
            # Find all valid starting points in this period
            valid_indices_in_period = []
            for i in range(period_length - sequence_length + 1):
                valid_indices_in_period.append(period_indices[i])
            
            # Skip if no valid sequences in this period
            if not valid_indices_in_period:
                continue
                
            # Shuffle indices within this period
            valid_indices_in_period = np.array(valid_indices_in_period)
            # np.random.shuffle(valid_indices_in_period)
            
            # Split indices for this period (8:1:1)
            n_indices = len(valid_indices_in_period) - self.seq_len - self.pred_len + 1

            if n_indices <= 0:
                continue

            n_train = int(n_indices * 0.8)
            n_val = int(n_indices * 0.1)
            
            # Add to appropriate splits
            all_valid_indices['train'].extend(valid_indices_in_period[:n_train])
            all_valid_indices['val'].extend(valid_indices_in_period[n_train:n_train + n_val])
            all_valid_indices['test'].extend(valid_indices_in_period[n_train + n_val:])
            print(f"period: {period}, n_train: {n_train}, n_val: {n_val}, n_test: {n_indices - n_train - n_val}")
        
        # Select indices for current split
        self.valid_indices = np.array(all_valid_indices[self.flag])
        # np.random.shuffle(self.valid_indices)  # Final shuffle of selected indices
        
        # Fit and transform data with scalers
        self.scaler_x.fit(self.input_data)
        self.scaler_y.fit(self.output_data)
        
        # Save scalers
        with open(self.scaler_x_path, 'wb') as f:
            pickle.dump(self.scaler_x, f)
        with open(self.scaler_y_path, 'wb') as f:
            pickle.dump(self.scaler_y, f)
        
        # Transform data
        self.input_data = self.scaler_x.transform(self.input_data)
        self.output_data = self.scaler_y.transform(self.output_data)
        
        # Process datetime features
        df_stamp = self.datetime_data.to_pandas()
        df_stamp['DateTime'] = pd.to_datetime(df_stamp.iloc[:, 0])
        self.data_stamp = time_features(df_stamp, timeenc=1, freq=self.freq)
        
        print(f"Number of production periods: {len(unique_periods)}")
        print(f"Number of {self.flag} sequences: {len(self.valid_indices)}")

    def __getitem__(self, index: int):
        """
        Get a sequence starting from a random valid starting point.
        """
        # Get the starting point for this sequence
        s_begin = self.valid_indices[index]
        s_end = s_begin + self.seq_len
        r_begin = s_end - self.label_len
        r_end = r_begin + self.label_len + self.pred_len

        seq_x = self.input_data[s_begin:s_end]
        seq_y = self.output_data[r_begin:r_end]
        seq_x_mark = self.data_stamp[s_begin:s_end]
        seq_y_mark = self.data_stamp[r_begin:r_end]
        seq_y_history = self.output_data[s_begin:s_end]

        # time series data
        seq_x_time = self.datetime_data[s_begin:s_end]
        seq_y_time = self.datetime_data[r_begin:r_end]

        return seq_x, seq_y, seq_x_mark, seq_y_mark, seq_y_history, seq_x_time, seq_y_time

    def __len__(self):
        """
        Return the number of valid sequences for this split.
        """
        return len(self.valid_indices)
    
    def inverse_transform_x(self, x):
        return self.scaler_x.inverse_transform(x)

    def inverse_transform_y(self, y):
        return self.scaler_y.inverse_transform(y)
    

class TransformerTimeSeriesDataset(Dataset):
    def __init__(self, project_name: str, tsdata: pl.DataFrame, size: list | None, scaler_type: str = 'standard', flag: str = 'train', freq: str = 't'):
        """
        基于pl.dataframe的时间序列数据集
        参数:
        tsdata (pl.DataFrame): 特征数据
        scaler_type (str): 归一化类型，可以是 'standard' 或 'minmax'
        """
        super().__init__()
        self.project_name = project_name
        self.tsdata = tsdata
        self.columns = self.tsdata.columns

        self.datetime_data = self.tsdata.select(self.columns[0])
        self.data_stamp = None
        self.input_data = self.tsdata.select(self.columns[1:])
        self.output_data = self.tsdata.select(self.columns[-1])

        self.scaler_folder_path = Path(f"resource/scaler/{self.project_name}")
        if self.scaler_folder_path.exists() is False:
            self.scaler_folder_path.mkdir(parents=True)
        self.scaler_x_path = Path(f"resource/scaler/{self.project_name}/scaler_x.pkl")
        self.scaler_y_path = Path(f"resource/scaler/{self.project_name}/scaler_y.pkl")

        match size:
            case None:
                self.seq_len = 24*4*4
                self.label_len = 24*4
                self.pred_len = 24*4
            case _:
                self.seq_len = size[0]
                self.label_len = size[1]
                self.pred_len = size[2]
        # init
        self.freq = freq
        self.flag = flag
        assert self.flag in ['train', 'test', 'val']
        type_map = {'train': 0, 'val': 1, 'test': 2}
        self.set_type = type_map[flag]

        # 定义数据集归一化方式
        match scaler_type:
            case 'standard':
                self.scaler_x = StandardScaler()
                self.scaler_y = StandardScaler()
            case 'minmax':
                self.scaler_x = MinMaxScaler(feature_range=(0, 1))
                self.scaler_y = MinMaxScaler(feature_range=(0, 1))
            case _:
                print(f'scaler_type must be either \'standard\' or \'minmax\', but got {scaler_type}')
                self.scaler_x = MinMaxScaler(feature_range=(0, 1))
                self.scaler_y = MinMaxScaler(feature_range=(0, 1))

        self.__read_data__()

    def __read_data__(self):
        num_train = int(len(self.tsdata) * 0.8)
        num_vali = int(len(self.tsdata) * 0.1)
        # num_test = len(self.tsdata) - num_train - num_vali

        border1s = [0, num_train, num_train + num_vali]
        border2s = [num_train, num_train + num_vali, len(self.tsdata)]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]

        df_stamp = self.datetime_data[border1: border2].to_pandas()
        # df_stamp['DateTime'] = pd.to_datetime(df_stamp.DateTime)
        df_stamp['DateTime'] = pd.to_datetime(df_stamp.iloc[:, 0])
        self.data_stamp = time_features(df_stamp, timeenc=1, freq=self.freq)

        # 归一化，并把归一化参数保存到本地
        self.scaler_x.fit(self.input_data)
        self.input_data = self.scaler_x.transform(self.input_data)
        with open(self.scaler_x_path, 'wb') as f:
            pickle.dump(self.scaler_x, f)

        self.scaler_y.fit(self.output_data)
        self.output_data = self.scaler_y.transform(self.output_data)
        with open(self.scaler_y_path, 'wb') as f:
            pickle.dump(self.scaler_y, f)

        self.data_x = self.input_data[border1: border2]
        self.data_y = self.input_data[border1: border2]

        # 从self.data_x，self.data_y中随机抽取数量为train_length的样本
        # match self.flag:
        #     case 'train':
        #         self.data_index = generate_random_index(len(self.input_data), num_train)
        #     case 'val':
        #         self.data_index = generate_random_index(len(self.input_data), num_vali)
        #     case 'test':
        #         self.data_index = generate_random_index(len(self.input_data), num_test)
        #     case _:
        #         raise ValueError(f"Invalid flag: {self.flag}")
        # self.data_x = self.input_data[self.data_index]
        # self.data_y = self.input_data[self.data_index]

    def __getitem__(self, index: int):
        s_begin = index
        s_end = s_begin + self.seq_len
        r_begin = s_end - self.label_len
        r_end = r_begin + self.label_len + self.pred_len

        seq_x = self.data_x[s_begin: s_end]
        seq_y = self.data_y[r_begin: r_end]
        seq_x_mark = self.data_stamp[s_begin: s_end]
        seq_y_mark = self.data_stamp[r_begin: r_end]

        return seq_x, seq_y, seq_x_mark, seq_y_mark

    def __len__(self):
        return len(self.data_x) - self.seq_len - self.pred_len + 1

    def inverse_transform_x(self, x):
        return self.scaler_x.inverse_transform(x)

    def inverse_transform_y(self, y: pl.Series):
        return self.scaler_y.inverse_transform(y)


class ClassicControlTimeSeriesDataset(Dataset):
    def __init__(
            self, project_name: str, input_data: pl.DataFrame, output_data: pl.DataFrame, 
            size: list, scaler_type: str = 'minmax', flag: str = 'train'
        ):
        """
        初始化ClassicControlTimeSeriesDataset类
        输入输出都是控制器数据库的数据
        参数:
        input_data (pl.DataFrame): 输入数据
        output_data (pl.DataFrame): 输出数据
        window_size (int): 滑动窗口大小
        scaler_type (str): 归一化类型，可以是 'standard' 或 'minmax'
        """
        super().__init__()
        self.project_name = project_name

        self.input_data = input_data
        self.output_data = output_data

        self.input_columns = self.input_data.columns
        self.output_columns = self.output_data.columns
        self.scaler_folder_path = Path(f"resource/scaler/{self.project_name}")
        if self.scaler_folder_path.exists() is False:
            self.scaler_folder_path.mkdir(parents=True)
        self.scaler_x_path = Path(f"resource/scaler/{self.project_name}/scaler_x.pkl")
        self.scaler_y_path = Path(f"resource/scaler/{self.project_name}/scaler_y.pkl")
        # init
        self.flag = flag
        assert self.flag in ['train', 'test', 'val']
        type_map = {'train': 0, 'val': 1, 'test': 2}
        self.set_type = type_map[flag]

        self.x_length = size[0]
        self.y_length = size[1]
        self.pred_len = size[2]
        self.x_sliding_length = size[3]
        self.y_sliding_length = size[4]

        match scaler_type:
            case 'standard':
                self.scaler_x = StandardScaler()
                self.scaler_y = StandardScaler()
            case 'minmax':
                self.scaler_x = MinMaxScaler(feature_range=(0, 1))
                self.scaler_y = MinMaxScaler(feature_range=(0, 1))
            case _:
                print(f'scaler_type must be either \'standard\' or \'minmax\', but got {scaler_type}')
                self.scaler_x = StandardScaler()
                self.scaler_y = StandardScaler()

        self.__read_data__()

    def __read_data__(self):
        num_train = int(len(self.input_data) * 0.8)
        num_vali = int(len(self.input_data) * 0.1)
        # num_test = len(self.input_data) - num_train - num_vali

        # 如果x_sliding_length大于1，则需要将num_train限制为x_sliding_length的整数倍
        if self.x_sliding_length > 1:
            num_train = num_train - num_train % self.x_sliding_length
            num_vali = num_vali - num_vali % self.x_sliding_length

        border1s = [0, num_train, num_train + num_vali]
        border2s = [num_train, num_train + num_vali, len(self.input_data)]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]

        # 归一化，并把归一化参数保存到本地
        self.scaler_x.fit(self.input_data)
        self.input_data = self.scaler_x.transform(self.input_data)
        with open(self.scaler_x_path, 'wb') as f:
            pickle.dump(self.scaler_x, f)
        self.scaler_y.fit(self.output_data)
        self.output_data = self.scaler_y.transform(self.output_data)
        with open(self.scaler_y_path, 'wb') as f:
            pickle.dump(self.scaler_y, f)

        self.data_x = self.input_data[border1: border2]
        self.data_y = self.output_data[border1: border2]
        print(f"length of {self.flag} input data: {len(self.data_x)}")
        print(f"length of {self.flag} output data: {len(self.data_y)}")

    def __getitem__(self, index):
        s_begin = index * self.x_sliding_length
        s_end = s_begin + self.x_length
        r_begin = index * self.y_sliding_length
        r_end = r_begin + self.y_length + self.pred_len - 1
        
        if s_end > len(self.data_x):
            # If there's not enough data left, return None
            return None
        
        seq_x = self.data_x[s_begin:s_end]
        seq_y = self.data_y[r_end]
        
        if seq_x.shape[0] != self.x_length:
            # This shouldn't happen now, but keep as a safeguard
            print(f"seq_x shape is {seq_x.shape}, but expected shape is {self.x_length}")
            return None
        
        return seq_x, seq_y

    def __len__(self):
        return (len(self.data_x) - self.x_length - self.pred_len) // self.x_sliding_length

    def inverse_transform_x(self, x):
        return self.scaler_x.inverse_transform(x)
    
    def inverse_transform_y(self, y):
        return self.scaler_y.inverse_transform(y)
    

class ClassicQualityTimeSeriesDataset(Dataset):
    def __init__(
        self, project_name: str, input_data: pl.DataFrame, output_data: pl.DataFrame, 
        size: list, scaler_type: str = 'minmax', flag: str = 'train'
    ):
        """
        初始化ClassicControlTimeSeriesDataset类
        输入是控制器数据库的数据，输出是质量数据库的数据
        参数:
        input_data (pl.DataFrame): 输入数据
        output_data (pl.DataFrame): 输出数据
        window_size (int): 滑动窗口大小
        scaler_type (str): 归一化类型，可以是 'standard' 或 'minmax'
        """
        super().__init__()
        self.project_name = project_name

        self.input_data = input_data
        self.output_data = output_data

        self.input_columns = self.input_data.columns
        self.output_columns = self.output_data.columns
        self.scaler_folder_path = Path(f"resource/scaler/{self.project_name}")
        if self.scaler_folder_path.exists() is False:
            self.scaler_folder_path.mkdir(parents=True)
        self.scaler_x_path = Path(f"resource/scaler/{self.project_name}/scaler_x.pkl")
        self.scaler_y_path = Path(f"resource/scaler/{self.project_name}/scaler_y.pkl")
        # init
        self.flag = flag
        assert self.flag in ['train', 'test', 'val']
        type_map = {'train': 0, 'val': 1, 'test': 2}
        self.set_type = type_map[flag]

        self.x_length = size[0]
        self.y_length = size[1]
        self.pred_len = size[2]
        self.x_sliding_length = size[3]
        self.y_sliding_length = size[4]

        match scaler_type:
            case 'standard':
                self.scaler_x = StandardScaler()
                self.scaler_y = StandardScaler()
            case 'minmax':
                self.scaler_x = MinMaxScaler(feature_range=(0, 1))
                self.scaler_y = MinMaxScaler(feature_range=(0, 1))
            case _:
                print(f'scaler_type must be either \'standard\' or \'minmax\', but got {scaler_type}')
                self.scaler_x = StandardScaler()
                self.scaler_y = StandardScaler()

        self.__read_data__()

    def __read_data__(self):
        num_train_x = int(len(self.input_data) * 0.8)
        num_vali_x = int(len(self.input_data) * 0.1)
        # num_test = len(self.input_data) - num_train - num_vali
        num_train_y = int(len(self.output_data) * 0.8)
        num_vali_y = int(len(self.output_data) * 0.1)
        print(f"num_train_x: {num_train_x}, num_vali_x: {num_vali_x}, num_train_y: {num_train_y}, num_vali_y: {num_vali_y}")

        # 如果x_sliding_length大于1，则需要将num_train限制为x_sliding_length的整数倍
        if self.x_sliding_length > 1:
            num_train_x = num_train_x - num_train_x % self.x_sliding_length
            num_vali_x = num_vali_x - num_vali_x % self.x_sliding_length

        border1s_x = [0, num_train_x, num_train_x + num_vali_x]
        border2s_x = [num_train_x, num_train_x + num_vali_x, len(self.input_data)]
        # border2s_x = [len(self.input_data), num_train_x + num_vali_x, len(self.input_data)]
        print(f"border1s_x: {border1s_x}, border2s_x: {border2s_x}")
        border1_x = border1s_x[self.set_type]
        border2_x = border2s_x[self.set_type]

        border1s_y = [0, num_train_y, num_train_y + num_vali_y]
        border2s_y = [num_train_y, num_train_y + num_vali_y, len(self.output_data)]
        # border2s_y = [len(self.output_data), num_train_y + num_vali_y, len(self.output_data)]
        print(f"border1s_y: {border1s_y}, border2s_y: {border2s_y}")
        border1_y = border1s_y[self.set_type]
        border2_y = border2s_y[self.set_type]

        # 归一化，并把归一化参数保存到本地
        self.scaler_x.fit(self.input_data)
        self.input_data = self.scaler_x.transform(self.input_data)
        with open(self.scaler_x_path, 'wb') as f:
            pickle.dump(self.scaler_x, f)
        self.scaler_y.fit(self.output_data)
        self.output_data = self.scaler_y.transform(self.output_data)
        with open(self.scaler_y_path, 'wb') as f:
            pickle.dump(self.scaler_y, f)

        self.data_x = self.input_data[border1_x: border2_x]
        self.data_y = self.output_data[border1_y: border2_y]
        print(f"length of {self.flag} input data: {len(self.data_x)}")
        print(f"length of {self.flag} output data: {len(self.data_y)}")

    def __getitem__(self, index):
        s_begin = index * self.x_sliding_length
        s_end = s_begin + self.x_length
        r_begin = index * self.y_sliding_length
        r_end = r_begin + self.y_length - 1
        
        if s_end > len(self.data_x):
            # If there's not enough data left, return None
            return None
        
        seq_x = self.data_x[s_begin:s_end]
        seq_y = self.data_y[r_end]
        
        if seq_x.shape[0] != self.x_length:
            # This shouldn't happen now, but keep as a safeguard
            print(f"seq_x shape is {seq_x.shape}, but expected shape is {self.x_length}")
            return None
        
        return seq_x, seq_y

    def __len__(self):
        return (len(self.data_x) - self.x_length) // self.x_sliding_length

    def inverse_transform_x(self, x):
        return self.scaler_x.inverse_transform(x)
    
    def inverse_transform_y(self, y):
        return self.scaler_y.inverse_transform(y)


class RandomClassicQualityTimeSeriesDataset(Dataset):
    def __init__(
        self, project_name: str, input_data: pl.DataFrame, output_data: pl.DataFrame, 
        size: list, scaler_type: str = 'minmax', flag: str = 'train'
    ):
        """
        初始化RandomClassicQualityTimeSeriesDataset类
        输入是控制器数据库的数据，输出是质量数据库的数据
        参数:
        input_data (pl.DataFrame): 输入数据
        output_data (pl.DataFrame): 输出数据
        window_size (int): 滑动窗口大小
        scaler_type (str): 归一化类型，可以是 'standard' 或 'minmax'
        """
        super().__init__()
        self.project_name = project_name

        self.input_data = input_data
        self.output_data = output_data

        self.input_columns = self.input_data.columns
        self.output_columns = self.output_data.columns
        self.scaler_folder_path = Path(f"resource/scaler/{self.project_name}")
        if self.scaler_folder_path.exists() is False:
            self.scaler_folder_path.mkdir(parents=True)
        self.scaler_x_path = Path(f"resource/scaler/{self.project_name}/scaler_x.pkl")
        self.scaler_y_path = Path(f"resource/scaler/{self.project_name}/scaler_y.pkl")
        # init
        self.flag = flag
        assert self.flag in ['train', 'test', 'val']
        type_map = {'train': 0, 'val': 1, 'test': 2}
        self.set_type = type_map[flag]

        # 根据flag设置随机数种子
        match self.flag:
            case 'train':
                pass
            case _:
                np.random.seed(42)

        self.x_length = size[0]
        self.y_length = size[1]
        self.pred_len = size[2]
        self.x_sliding_length = size[3]
        self.y_sliding_length = size[4]

        match scaler_type:
            case 'standard':
                self.scaler_x = StandardScaler()
                self.scaler_y = StandardScaler()
            case 'minmax':
                self.scaler_x = MinMaxScaler(feature_range=(0, 1))
                self.scaler_y = MinMaxScaler(feature_range=(0, 1))
            case _:
                print(f'scaler_type must be either \'standard\' or \'minmax\', but got {scaler_type}')
                self.scaler_x = StandardScaler()
                self.scaler_y = StandardScaler()

        self.__read_data__()
        # 重置随机种子，只用于训练时的batch采样
        np.random.seed(None)

    def __read_data__(self):
        """Read and prepare data ensuring strict train/val/test separation."""
        # 生成所有可能的序列起始索引
        total_length = len(self.output_data)

        # Generate all possible starting indices
        all_start_indices = np.arange(total_length)
         # 使用固定种子打乱所有索引（只做一次）
        np.random.shuffle(all_start_indices)  # Randomly shuffle starting points

        # Calculate number of sequences for each split
        num_sequences = len(all_start_indices)
        num_train = int(num_sequences * 0.8)
        num_vali = int(num_sequences * 0.1)

        # Split starting indices for each set
        train_starts = all_start_indices[:num_train]
        val_starts = all_start_indices[num_train:num_train + num_vali]
        test_starts = all_start_indices[num_train + num_vali:]

        # Select appropriate starting indices based on flag
        starts_map = {
            'train': train_starts,
            'val': val_starts,
            'test': test_starts
        }
        self.valid_indices = starts_map[self.flag]

        # 如果是训练集，可以在每个epoch重新打乱训练数据的顺序
        if self.flag == 'train':
            np.random.seed(None)  # 重置随机种子
            np.random.shuffle(self.valid_indices)  # 只打乱训练集的顺序

        # 数据预处理
        self.__preprocess_data__()

    def __preprocess_data__(self):
        # 归一化，并把归一化参数保存到本地
        self.scaler_x.fit(self.input_data)
        self.input_data = self.scaler_x.transform(self.input_data)
        with open(self.scaler_x_path, 'wb') as f:
            pickle.dump(self.scaler_x, f)
        self.scaler_y.fit(self.output_data)
        self.output_data = self.scaler_y.transform(self.output_data)
        with open(self.scaler_y_path, 'wb') as f:
            pickle.dump(self.scaler_y, f)

        # Store starting indices for use in __getitem__
        self.data_x = self.input_data
        self.data_y = self.output_data

    def __getitem__(self, index):
        s_begin = self.valid_indices[index] * self.x_sliding_length
        s_end = s_begin + self.x_length
        r_begin = self.valid_indices[index] * self.y_sliding_length
        r_end = r_begin + self.y_length - 1
        
        if s_end > len(self.data_x):
            # If there's not enough data left, return None
            return None
        
        seq_x = self.data_x[s_begin:s_end]
        seq_y = self.data_y[r_end]
        
        if seq_x.shape[0] != self.x_length:
            # This shouldn't happen now, but keep as a safeguard
            print(f"seq_x shape is {seq_x.shape}, but expected shape is {self.x_length}")
            return None
        
        return seq_x, seq_y

    def __len__(self):
        return len(self.valid_indices)

    def inverse_transform_x(self, x: np.ndarray) -> np.ndarray:
        """Inverse transform input data.

        Args:
            x (np.ndarray): Scaled input data

        Returns:
            np.ndarray: Original scale input data
        """
        return self.scaler_x.inverse_transform(x)
    
    def inverse_transform_y(self, y: np.ndarray) -> np.ndarray:
        """Inverse transform output data.

        Args:
            y (np.ndarray): Scaled output data

        Returns:
            np.ndarray: Original scale output data
        """
        return self.scaler_y.inverse_transform(y)
    