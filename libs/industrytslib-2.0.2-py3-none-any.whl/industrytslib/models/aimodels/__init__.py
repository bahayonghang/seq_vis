import torch.nn as nn
import importlib

from types import SimpleNamespace

from .mlstm import mLSTM
from .slstm import sLSTM
from .xlstm import xLSTM

from .Informer import Informer, InformerAlter
from .iTransformer import iTransformer
from .PatchTST import PatchTST
from .crossformer import CrossFormer
from .TimesNet import TimesNet
from .TimeMixer import TimeMixer
from .TimeXer import TimeXer
from .MTST import MTST
from .WaveForM import WaveForM

# Trasnformer models
from .tsformer import (
    FEDFormer, NSFEDFormer, 
    Pyraformer, 
    Nonstationary_Transformer, 
    ETSFormer
)

from .LSTMKAN import LSTMKAN
from .CNN import CNN, CNN_LSTM, CNNLSTMKAN
from .TCN import TCN
from .LTCA import LTCA, LTCAKAN, XLTCAKAN
from .CRNN import CRNN

# ! 这一部分是用于直接从库中导入AI model
# 尝试导入mamba_ssm,导入成功则mamba_flag为True
mamba_flag = False
# Check if the mamba_ssm module is available
if importlib.util.find_spec("mamba_ssm") is not None:
    mamba_flag = True
    # Now you can use mamba_ssm
else:
    print("MambaSSM not installed, skipping import")

__all__ = ["mLSTM", "sLSTM", "xLSTM",
        "Informer", "InformerAlter", "iTransformer","PatchTST", "CrossFormer", "TimesNet", "TimeMixer", "TimeXer",
        "FEDFormer", "NSFEDFormer", "Pyraformer", "Nonstationary_Transformer", "ETSFormer",
        "WaveForM",
        "MTST",
        "CNN", "TCN", "LTCA", "LTCAKAN", "XLTCAKAN", "LSTMKAN", "CNN_LSTM", "CNNLSTMKAN", "CRNN"]


# ! 这一部分是用于通过build_model函数导入AI model
model_dict = {
    # xLSTM models
    "mLSTM": mLSTM,
    "sLSTM": sLSTM,
    "xLSTM": xLSTM,

    # transformer models
    "informer": Informer,
    "informer_alter": InformerAlter,
    "iTransformer": iTransformer,
    "PatchTST": PatchTST,
    "CrossFormer": CrossFormer,
    "TimesNet": TimesNet,
    "TimeMixer": TimeMixer,
    "TimeXer": TimeXer,
    "MTST": MTST,

    # Trasnformer models
    "FEDFormer": FEDFormer,
    "NSFEDFormer": NSFEDFormer,
    "Pyraformer": Pyraformer,
    "Nonstationary_Transformer": Nonstationary_Transformer,
    "ETSFormer": ETSFormer,
    "WaveForM": WaveForM,

    # basic models
    "CNN": CNN,
    "TCN": TCN,
    "LTCA": LTCA,
    "LTCAKAN": LTCAKAN,
    "XLTCAKAN": XLTCAKAN,
    "LSTMKAN": LSTMKAN,
    "CNN_LSTM": CNN_LSTM,
    "CNNLSTMKAN": CNNLSTMKAN,
    "CRNN": CRNN,
}


if mamba_flag:
    from .Mambabasic import MambaBasic
    from .TimeMachine import TimeMachine
    from .TimesMamba import TimesMamba
    # 强调彩色打印
    print("\033[91mmamba_ssm has been imported, Mamba based models is available!!!\033[0m")
    model_dict.update({
        "MambaBasic": MambaBasic,
        "TimeMachine": TimeMachine,
        "TimesMamba": TimesMamba,
    })
    __all__.extend(["MambaBasic", "TimeMachine", "TimesMamba"])
else:
    print("\033[91mMamba not installed, skipping import MambaBasic\033[0m")


def build_model(model_name:str, model_parameter:dict) -> nn.Module:
    """
    根据model_name和model_parameter构建模型
    Args:
        model_name: 模型名称, 如"informer"
        model_parameter: 模型参数, 如{"d_model": 64, "n_heads": 8, "e_layers": 2, "d_layers": 2, "d_ff": 256, "dropout": 0.1, "use_gpu": True}
    Returns:
        model: 构建的torch.nn.Module模型
    Examples:
        >>> model = build_model(
        "informer", 
        {"d_model": 64, "n_heads": 8, "e_layers": 2, "d_layers": 2, "d_ff": 256, "dropout": 0.1, "use_gpu": True}
        )
    """
    ModelClass = model_dict[model_name]

    # 将model_parameter这个dict类型转换为可以使用.的类型
    model_parameter = SimpleNamespace(**model_parameter)    
    
    model = ModelClass(model_parameter).float()
    
    try:
        if model_parameter.use_multi_gpu and model_parameter.use_gpu:
            model = nn.DataParallel(model, device_ids=model_parameter.device_ids)
    except KeyError:
        print("未使用多GPU")
    finally:
        return model


__all__.append("build_model")
