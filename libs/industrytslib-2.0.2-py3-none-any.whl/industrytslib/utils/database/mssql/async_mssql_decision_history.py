import datetime
import polars as pl

from .async_mssql_base import AsyncMSSQLConnection
from industrytslib.utils.logutils import get_logger

class AsyncMSSQLDecisionHistory(AsyncMSSQLConnection):
    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self.logger = get_logger("MSSQLDecisonHistory", "database")

    async def create_table_decision_history(self) -> None:
        """
        创建决策历史表
        """
        create_table_sql = """
            CREATE TABLE decision_history (
                [DateTime] DATETIME,
                [变量名称] NVARCHAR(255),
                [optimization_project_name] NVARCHAR(255),
                [optimization_type] NVARCHAR(255),
                [反馈值] DECIMAL(10, 4),
                [实际设定值] DECIMAL(10, 4),
                [AI决策值] DECIMAL(10, 4),
                [consistency] DECIMAL(10, 4),
            );
            """
        await self.cursor.execute(create_table_sql)
        await self.connection.commit()

    async def create_table_decision_consistency(self) -> None:
        """
        创建决策一致性表
        """
        create_table_sql = """
                   CREATE TABLE decision_consistency (
                       [DateTime] DATETIME,
                       [optimization_project_name] NVARCHAR(255),
                       [optimization_type] NVARCHAR(255),
                       [consistency] DECIMAL(10, 4),
                       [原料A磨单位电耗] DECIMAL(10, 4),
                       [原料B磨单位电耗] DECIMAL(10, 4),
                       [窑系统单位电耗] DECIMAL(10, 4),
                       [吨熟料实物煤耗] DECIMAL(10, 4),
                       [煤磨电耗] DECIMAL(10, 4),
                       [水泥A磨单位电耗] DECIMAL(10, 4),
                   );
                   """
        await self.cursor.execute(create_table_sql)
        await self.connection.commit()

    async def check_table_optimization_history(self) -> None:
        """
        检查决策历史表是否存在，不存在则创建
        """
        exist_flag = await self.is_table_exist("decision_history")
        if not exist_flag:
            self.logger.info("决策历史表不存在，创建决策历史表...")
            try:
                await self.create_table_decision_history()
                self.logger.info("决策历史表创建成功!!!")
            except Exception as e:
                self.logger.error(f"创建决策历史表失败: {e}, 请检查数据库连接!!!")
                raise e
        else:
            self.logger.info("决策历史表已存在!!!")

    async def check_table_decision_consistency(self) -> None:
        """
        检查决策一致性表是否存在，不存在则创建
        """
        exist_flag = await self.is_table_exist("decision_consistency")
        if not exist_flag:
            self.logger.info("决策一致性表不存在，创建决策一致性表...")
            try:
                await self.create_table_decision_consistency()
                self.logger.info("决策一致性表创建成功!!!")
            except Exception as e:
                self.logger.error(f"创建决策一致性表失败: {e}, 请检查数据库连接!!!")
                raise e
        else:
            self.logger.info("决策一致性表已存在!!!")

    async def get_decision_realtime(self) -> pl.DataFrame:
        """
        获取decision_realtime视图中的数据
        """
        query_sql = "SELECT * FROM decision_realtime"
        rows = await self.query(query_sql)
        return rows
    
    async def insert_decision_history(self, time_now: datetime.datetime, var_name: str, project_name: str, opt_type: str, row: pl.DataFrame) -> None:
        """
        插入决策历史数据
        """
        feedback_value = row['反馈值'].item()
        actual_value = row['实际设定值'].item()
        ai_decision_value = row['AI决策值'].item()
        if feedback_value is None:
            feedback_value = 0
            self.logger.warning(f"{var_name}反馈值为空,已设置为0")
        if actual_value is None:
            actual_value = 0
            self.logger.warning(f"{var_name}实际设定值为空,已设置为0")
        if ai_decision_value is None:
            ai_decision_value = 0
            self.logger.warning(f"{var_name}AI决策值为空,已设置为0")
        insert_sql = f"""
                INSERT INTO decision_history
                VALUES ('{time_now}', '{var_name}', '{project_name}', '{opt_type}', 
                        {feedback_value}, {actual_value}, {ai_decision_value}, NULL)
            """
        await self.cursor.execute(insert_sql)
        await self.connection.commit()

    async def query_energy_consumption(self, energy_consumption_list: list) -> list:
        """
        查询decision_consistency表中的能耗数据
        """
        query_energy_consumption = f"""
                                    SELECT TagName, TagVal FROM TagDatabase
                                    WHERE TagName IN ({','.join('?' * len(energy_consumption_list))})
                                    """
        await self.cursor.execute(query_energy_consumption, energy_consumption_list)
        energy_consumption_data = await self.cursor.fetchall()
        return energy_consumption_data
    
    async def update_decision_consistency(self, current_time: datetime.datetime, energy_consumption_data: list) -> None:
        """
        更新decision_consistency表中的能耗数据
        """
        update_query = f"""
                UPDATE decision_consistency
                SET {', '.join([f"[{tag_name}] = {tag_val}" for tag_name, tag_val in energy_consumption_data])}
                WHERE DateTime = '{current_time}'
            """
        await self.cursor.execute(update_query)
        await self.connection.commit()

    # 从决策历史中选取最近的决策数据
    async def select_recent_decision_data(self) -> pl.DataFrame:
        """
        从决策历史中选取最近的决策数据
        """
        query_sql = """
                    SELECT * FROM decision_realtime
                    ORDER BY [DateTime] DESC
                    """
        rows = await self.query(query_sql)
        return rows
    
    # 根据varname、gruop将一致性指标写入数据库
    async def update_decision_history(self, single_var_consistency: float, current_time:datetime.datetime, var_name:str, 
                                project_name: str, opt_type: str) -> None:
        update_sql = f"""
                        UPDATE decision_history
                        SET consistency = {single_var_consistency}
                        WHERE DateTime = '{current_time}'
                        AND 变量名称 = '{var_name}'
                        AND optimization_project_name = '{project_name}'
                        AND optimization_type = '{opt_type}'
                    """
        # print(f"update_decision_history:{update_sql}")
        await self.execute(update_sql)
    
    # 将综合一致性指标更新到数据库
    async def update_overall_consisitency(self, current_time:datetime.datetime, project_name:str, opt_type:str, overall_consistency: float) -> None:
        insert_query = f"""
                Insert into decision_consistency (DateTime, optimization_project_name, optimization_type, consistency)
                VALUES ('{current_time}', '{project_name}', '{opt_type}', {overall_consistency})
            """
        await self.cursor.execute(insert_query)
        await self.connection.commit()
