class Database:
    def __init__(self, config: dict) -> None:
        self.config = config
