import datetime

def get_current_time() -> str:
    """
    Get current time

    Returns:
        str: current time
    Examples:
        >>> get_current_time()
        '2024-12-07 12:00:00'
    """
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

