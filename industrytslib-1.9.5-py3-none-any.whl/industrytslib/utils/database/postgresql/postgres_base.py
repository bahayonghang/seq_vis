import datetime
import time
from typing import Optional, List

import polars as pl

import psycopg
from psycopg.rows import dict_row

from industrytslib.utils.database.base import Database
from industrytslib.utils.logutils import get_logger


class PostgreSQLConnection(Database):
    """
    PostgreSQL database connection base class.
    
    Implements basic database operations using psycopg3 with connection pooling.
    """
    
    def __init__(self, config: dict) -> None:
        """
        Initialize PostgreSQL connection with configuration.

        Args:
            config: Dictionary containing database configuration
        """
        self.config = config
        self.logger = get_logger("PostgreSQL", "database")

        self.host = self.config['host']
        self.port = self.config['port']
        self.username = self.config['username']
        self.password = self.config['password']
        self.database = self.config['database']

        # Connection pool settings
        self.max_retries = 9999
        self.retry_delay = 60  # seconds
        
        self.connect_db()

    def connect(self) -> None:
        """
        Create connection to PostgreSQL database.
        """
        conninfo = (
            f"host={self.host} "
            f"port={self.port} "
            f"dbname={self.database} "
            f"user={self.username} "
            f"password={self.password}"
        )
        
        self.conn = psycopg.connect(
            conninfo=conninfo,
            row_factory=dict_row,
            autocommit=False
        )
        self.cursor = self.conn.cursor()
        self.logger.info(f"Connected to PostgreSQL at {self.host}:{self.port}/{self.database} as {self.username}")

    def connect_db(self) -> None:
        """
        Pipeline for connecting to PostgreSQL database with retry logic.
        """
        for attempt in range(self.max_retries):
            try:
                self.connect()
                self.logger.info(f"Successfully connected to PostgreSQL database at {self.host}")
                self.max_retries = 9999
                return
            except Exception as e:
                self.logger.warning(
                    f"Connection attempt {attempt + 1} failed for {self.username}@{self.host}/{self.database}: {str(e)}"
                )
                if attempt < self.max_retries - 1:
                    self.logger.info(f"Retrying in {self.retry_delay} seconds...")
                    time.sleep(self.retry_delay)
                else:
                    self.logger.error(f"Failed to connect after {self.max_retries} attempts")
                    raise

    def close(self) -> None:
        """Close the database connection."""
        if hasattr(self, 'cursor'):
            self.cursor.close()
        if hasattr(self, 'conn'):
            self.conn.close()
            self.logger.info("Database connection closed")

    def is_table_exist(self, table_name: str) -> bool:
        """
        Check if table exists in database.

        Args:
            table_name: Name of the table to check

        Returns:
            bool: True if table exists, False otherwise
        """
        sql = """
            SELECT EXISTS (
                SELECT FROM information_schema.tables 
                WHERE table_name = %s
            );
        """
        self.cursor.execute(sql, (table_name,))
        return self.cursor.fetchone()['exists']

    def query(
            self, 
            sql: str, 
            parameters: Optional[tuple] = None
        ) -> pl.DataFrame:
        """
        Execute a query and return results as a Polars DataFrame.

        Args:
            sql: SQL query string
            parameters: Optional query parameters

        Returns:
            pl.DataFrame: Query results
        """
        self.cursor.execute(sql, parameters)
        rows = self.cursor.fetchall()
        if not rows:
            return pl.DataFrame()
        return pl.DataFrame(rows)

    def execute(
            self, 
            sql: str, 
            parameters: Optional[tuple] = None
        ) -> None:
        """
        Execute a SQL command.

        Args:
            sql: SQL command to execute
            parameters: Optional command parameters
        """
        self.cursor.execute(sql, parameters)
        self.conn.commit()

    def truncate_table(self, table_name: str) -> None:
        """
        Truncate a table.

        Args:
            table_name: Name of table to truncate
        """
        sql = f"TRUNCATE TABLE {table_name}"
        self.execute(sql)

    def add_column(
            self, 
            table_name: str, 
            column_name: str, 
            column_type: str
        ) -> None:
        """
        Add a column to a table.

        Args:
            table_name: Target table name
            column_name: New column name
            column_type: PostgreSQL data type for new column
        """
        sql = f"ALTER TABLE {table_name} ADD COLUMN {column_name} {column_type}"
        self.execute(sql)

    def update_list(
            self, 
            table_name: str, 
            time_update: datetime.datetime,
            name_list: List[str], 
            value_list: List[float]
        ) -> None:
        """
        Update multiple columns with values for a specific timestamp.

        Args:
            table_name: Target table name
            time_update: Timestamp to update
            name_list: List of column names
            value_list: List of values to update
        """
        set_clause = ", ".join([f"{name}_true = %s" for name in name_list])
        sql = f"""
            UPDATE {table_name} 
            SET {set_clause}
            WHERE "DateTime" = %s
        """
        parameters = tuple(value_list) + (time_update,)
        self.execute(sql, parameters)

    def insert_list(
            self, 
            table_name: str, 
            time_insert: datetime.datetime,
            name_list: List[str], 
            value_list: List[float]
        ) -> None:
        """
        Insert a new row with multiple values.

        Args:
            table_name: Target table name
            time_insert: Timestamp for new row
            name_list: List of column names
            value_list: List of values to insert
        """
        columns = ["DateTime"] + [f"{name}_true" for name in name_list]
        placeholders = ", ".join(["%s"] * (len(name_list) + 1))
        
        sql = f"""
            INSERT INTO {table_name} 
            ({', '.join(columns)})
            VALUES ({placeholders})
        """
        parameters = (time_insert,) + tuple(value_list)
        self.execute(sql, parameters)

    def insert_sequence_value(
            self,
            table_name: str,
            time_insert: datetime.datetime,
            name_list: List[str],
            value_list: List[float]
        ) -> None:
        """
        Insert sequence prediction values.

        Args:
            table_name: Target table name
            time_insert: Timestamp for new row
            name_list: List of column names
            value_list: List of values to insert
        """
        columns = ["DateTime"] + name_list
        placeholders = ", ".join(["%s"] * (len(name_list) + 1))
        
        sql = f"""
            INSERT INTO {table_name} 
            ({', '.join(columns)})
            VALUES ({placeholders})
        """
        parameters = (time_insert,) + tuple(value_list)
        self.execute(sql, parameters)

    def clear_table_data_by_columns(
            self,
            table_name: str,
            columns_to_clear: List[str]
        ) -> int:
        """
        Clear data in specified columns.

        Args:
            table_name: Target table name
            columns_to_clear: List of columns to clear

        Returns:
            int: Number of affected rows
        """
        if not columns_to_clear:
            raise ValueError("columns_to_clear list cannot be empty")
            
        set_clause = ", ".join([f"{col} = NULL" for col in columns_to_clear])
        where_clause = " OR ".join([f"{col} IS NOT NULL" for col in columns_to_clear])
        
        sql = f"""
            UPDATE {table_name}
            SET {set_clause}
            WHERE {where_clause}
        """
        
        self.cursor.execute(sql)
        affected_rows = self.cursor.rowcount
        self.conn.commit()
        return affected_rows
