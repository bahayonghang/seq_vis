import datetime
import time
import polars as pl

# from .shared_data import get_global_df, set_global_df
from industrytslib.utils.database import database_builder  
from industrytslib.utils.readconfig import read_config_toml   
from industrytslib.utils.share.shared_dataframe import SharedDataFrame
from industrytslib.utils.data_processing.polarsoperation import vstack_with_fill

# db_config = read_config_toml("config/dbconfig.toml")
# mssql_ts_client = database_builder(db_config["mssql"]["timeseries"])


# def modify_dataframe() -> None:
#     """
#     修改全局 DataFrame 的函数
#     """
#     current_df = get_global_df()
#     if current_df.is_empty():
#         # 如果全局 DataFrame 为空，则从数据库查询最新的数据
#         print(f"当前时间: {datetime.datetime.now()}开始查询历史数据库")
#         time_start = time.time()
#         latest_df = mssql_ts_client.query_decision_history_data_latest()
#         time_end = time.time()
#         print(f"从数据库查询最新数据耗时: {time_end - time_start:.4f} 秒")
#     else:
#         # 如果全局 DataFrame 不为空，则查询TagDatabase中的数据，剔除最旧的一条数据并添加最新的数据
#         print(f"当前时间: {datetime.datetime.now()}全局 DataFrame 不为空")
#         time_start = time.time()
#         latest_df = mssql_ts_client.query_tagdatabase_latest()
#         # 将latest_df的列按照current_df的列顺序排列
#         latest_df = latest_df.select(current_df.columns)
#         # 剔除current_df中最旧的一行数据
#         current_df = current_df.slice(1, None)
#         # 将latest_df添加到current_df中
#         latest_df = current_df.vstack(latest_df)
#         time_end = time.time()
#         print(f"修改 DataFrame 耗时: {time_end - time_start:.4f} 秒")
#     # 更新全局 DataFrame
#     set_global_df(latest_df)


# def modify_dataframe_name_list(input_name_list: list[str]) -> None:
#     """修改全局 DataFrame 的函数，带参数"""
#     """
#     修改全局 DataFrame 的函数
#     """
#     current_df = get_global_df()
#     if current_df.is_empty():
#         # 如果全局 DataFrame 为空，则从数据库查询最新的数据
#         print(f"当前时间: {datetime.datetime.now()}开始查询历史数据库")
#         time_start = time.time()
#         latest_df = mssql_ts_client.query_decision_history_data_latest_by_name_list(input_name_list)
#         time_end = time.time()
#         print(f"从数据库查询最新数据耗时: {time_end - time_start:.4f} 秒")
#     else:
#         # 如果全局 DataFrame 不为空，则查询TagDatabase中的数据，剔除最旧的一条数据并添加最新的数据
#         print(f"当前时间: {datetime.datetime.now()}全局 DataFrame 不为空")
#         time_start = time.time()
#         latest_df = mssql_ts_client.query_tagdatabase_latest_by_name_list(input_name_list)
#         # 将latest_df的列按照current_df的列顺序排列
#         latest_df = latest_df.select(input_name_list)
#         # 剔除current_df中最旧的一行数据
#         current_df = current_df.slice(1, None)
#         # 将latest_df添加到current_df中
#         latest_df = current_df.vstack(latest_df)
#         time_end = time.time()
#         print(f"修改 DataFrame 耗时: {time_end - time_start:.4f} 秒")
#     # 更新全局 DataFrame
#     set_global_df(latest_df)


# def modify_dataframe_shared(input_name_list: list[str]) -> None:
#     """修改全局 DataFrame 的函数，带参数"""
#     """
#     修改全局 DataFrame 的函数
#     """
#     shared_df = SharedDataFrame()
#     current_df = shared_df.read_dataframe()
#     if current_df.is_empty():
#         # 如果全局 DataFrame 为空，则从数据库查询最新的数据
#         print(f"当前时间: {datetime.datetime.now()}开始查询历史数据库")
#         time_start = time.time()
#         latest_df = mssql_ts_client.query_decision_history_data_latest_by_name_list(input_name_list)
#         time_end = time.time()
#         print(f"从数据库查询最新数据耗时: {time_end - time_start:.4f} 秒")
#     else:
#         # 如果全局 DataFrame 不为空，则查询TagDatabase中的数据，剔除最旧的一条数据并添加最新的数据
#         print(f"当前时间: {datetime.datetime.now()}全局 DataFrame 不为空")
#         time_start = time.time()
#         latest_df = mssql_ts_client.query_tagdatabase_latest_by_name_list(input_name_list)
#         # 将latest_df的列按照current_df的列顺序排列
#         latest_df = latest_df.select(input_name_list)
#         # 剔除current_df中最旧的一行数据
#         current_df = current_df.slice(1, None)
#         # 将latest_df添加到current_df中
#         latest_df = current_df.vstack(latest_df)
#         time_end = time.time()
#         print(f"修改 DataFrame 耗时: {time_end - time_start:.4f} 秒")
#     # 更新全局 DataFrame
#     shared_df.update_dataframe(latest_df)

class ModifyDataframe:
    def __init__(self):
        db_config = read_config_toml("config/dbconfig.toml")
        self.mssql_ts_client = database_builder(db_config["mssql"]["timeseries"])
        self.shared_df = SharedDataFrame()

    def update_dataframe(self, df: pl.DataFrame) -> pl.DataFrame:
        """
        Update global DataFrame
        Args:
            df (pl.DataFrame): input dataframe
        Returns:
            pl.DataFrame: updated dataframe
        """
        if df.is_empty():
            # 如果全局 DataFrame 为空，则从数据库查询最新的数据
            print(f"当前时间: {datetime.datetime.now()}开始查询历史数据库")
            time_start = time.time()
            latest_df = self.mssql_ts_client.query_history_data_latest()
            print(f"初始全局DataFrame: {latest_df}")
            time_end = time.time()
            print(f"从数据库查询最新数据耗时: {time_end - time_start:.4f} 秒")
        else:
            # 如果全局 DataFrame 不为空，则查询TagDatabase中的数据，剔除最旧的一条数据并添加最新的数据
            # print(f"当前时间: {datetime.datetime.now()}全局 DataFrame 不为空")
            # print(f"current_df: {df}")
            # time_start = time.time()
            latest_df = self.mssql_ts_client.query_tagdatabase_latest()
            # print(f"latest_df: {latest_df}")
            # 将latest_df的列按照current_df的列顺序排列 
            latest_df = latest_df.fill_nan(0)

            # # 拼接方式1
            # # 取df.columns和latest_df.columns的交集
            # columns = list(set(df.columns) & set(latest_df.columns))
            # # 根据columns选择历史数据和current_df的列
            # history_df = df.select(columns)
            # latest_df = latest_df.select(columns)
            # # 剔除current_df中最旧的一行数据
            # history_df = history_df.slice(1, None)
            # # 将latest_df添加到current_df中
            # latest_df = history_df.vstack(latest_df)

            # 拼接方式2
            latest_df = vstack_with_fill(df.slice(1, None), latest_df)
            latest_df = latest_df.fill_nan(0)
            # time_end = time.time()
            # print(f"修改 DataFrame 耗时: {time_end - time_start:.4f} 秒")
        # print(f"final_df: {latest_df}")
        return latest_df

    def modify_dataframe(self) -> None:
        # 更新全局 DataFrame
        self.shared_df.update_dataframe(self.update_dataframe)
