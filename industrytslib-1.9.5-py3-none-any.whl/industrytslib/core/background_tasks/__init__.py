from typing import Tuple

from .decision_consistency import DecisonHistory
from .prediction_transaction import PredictionTransaction
from .predcition_settle import PredictionSettle

def build_background_tasks(config: dict) -> Tuple[DecisonHistory, PredictionTransaction, PredictionSettle]:
    decision_history = DecisonHistory(config)
    prediction_transaction = PredictionTransaction(config)
    prediction_settle = PredictionSettle(config)
    return decision_history, prediction_transaction, prediction_settle
