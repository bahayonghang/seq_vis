import importlib
from .base_plotter import BasePlotter
from .plotly_plotter import PlotlyPlotter
from .matplotlib_plotter import MatplotlibPlotter


# 判断umap和tsne是否安装
umap_flag = False
# Check if the mamba_ssm module is available
if importlib.util.find_spec("umap_learn") is not None:
    mamba_flag = True
else:
    print("Umap_learn not installed, skipping import")


def plotter_builder(plotter_type: str, project_name: str) -> BasePlotter:
    """
    builder for plotter

    Args:
        plotter_type (str): plotter type
        project_name (str): project name

    Returns:
        BasePlotter
    """
    match plotter_type:
        case "plotly":
            return PlotlyPlotter(project_name)
        case "matplotlib":
            return MatplotlibPlotter(project_name)
        case _:
            raise ValueError("Invalid plotter type")
        

__all__ = ["plotter_builder"]

if umap_flag:
    from .distribution_plotter import tsne_plotter, umap_plotter
    __all__.extend(["tsne_plotter", "umap_plotter"])
        