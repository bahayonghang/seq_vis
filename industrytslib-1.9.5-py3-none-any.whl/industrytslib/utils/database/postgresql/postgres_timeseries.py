import datetime
from typing import Union, List

import polars as pl

from .postgres_base import PostgreSQLConnection
from industrytslib.utils.logutils import get_logger
from industrytslib.utils.data_processing.polarsoperation import optimization_data_process, calculate_minute_average


class PostgreSQLTimeseries(PostgreSQLConnection):
    """
    PostgreSQL Library for getting realtime and historical data from controller database.
    """
    
    def __init__(self, config: dict) -> None:
        """Initialize PostgreSQL Timeseries connection."""
        super().__init__(config)
        self.logger = get_logger("PostgreSQLTimeseries", "database")

    def get_feed_amount_column_name(self, table_name: str) -> Union[str, List[str]]:
        """
        Get feed amount column name.

        Args:
            table_name: Name of the table

        Returns:
            Either a single column name or list of column names containing feed amount data

        Raises:
            ValueError: If no matching columns found
        """
        sql = """
            SELECT * FROM {table_name}
            WHERE DateTime BETWEEN 
                NOW() - INTERVAL '2 hours' AND NOW() + INTERVAL '1 hour'
            ORDER BY DateTime DESC
            LIMIT 1
        """
        result = self.query(sql)
        columns = result.columns
        
        target_columns = [
            col for col in columns 
            if any(term in col for term in ['喂料量', '给料机', '给煤机'])
        ]
        
        if not target_columns:
            raise ValueError("未找到包含 '喂料量' 或 '给料机' 或 '给煤机' 的列名")
            
        return target_columns[0] if len(target_columns) == 1 else target_columns

    def check_device_running_status(self, var_name: str) -> bool:
        """
        Check device running status from TagDatabase.

        Args:
            var_name: Variable name for device status

        Returns:
            bool: True if device is running, False otherwise
        """
        sql = """
            SELECT TagVal 
            FROM TagDatabase 
            WHERE TagName = %s 
            ORDER BY DateTime DESC 
            LIMIT 1
        """
        rows = self.query(sql, (var_name,))
        return rows["TagVal"].item() == 1

    def get_latest_input_data(self, table_name: str) -> pl.DataFrame:
        """
        Get realtime data of latest 1 hour.

        Args:
            table_name: Name of the table

        Returns:
            pl.DataFrame: Latest input data
        """
        sql = f"""
            SELECT * FROM {table_name}
            WHERE DateTime BETWEEN 
                NOW() - INTERVAL '2 hours' AND NOW() + INTERVAL '1 hour'
            ORDER BY DateTime DESC
            LIMIT 360
        """
        return self.query(sql)

    def get_latest_input_data_by_column(self, input_name_list: List[str]) -> pl.DataFrame:
        """
        Get realtime data by column names from historical table.

        Args:
            input_name_list: List of column names

        Returns:
            pl.DataFrame: Latest input data for specified columns
        """
        name_list = input_name_list.copy()
        placeholders = ','.join(['%s'] * len(name_list))
        
        sql = f"""
            SELECT DateTime, TagName, TagVal
            FROM historical_data
            WHERE DateTime BETWEEN NOW() - INTERVAL '6 hours' AND NOW()
            AND TagName IN ({placeholders})
        """
        
        rows = self.query(sql, tuple(name_list))
        
        # Data processing
        rows = (rows
               .drop_nulls()
               .with_columns(pl.col("DateTime").cast(pl.Datetime))
               .with_columns(pl.col("DateTime").dt.truncate('1s')))
        
        rows_pivot = rows.pivot(
            index="DateTime",
            columns="TagName",
            values="TagVal",
            aggregate_function="first"
        )
        
        rows_pivot = self._remove_column_space(rows_pivot)
        name_list.insert(0, "DateTime")
        rows_pivot = rows_pivot[name_list]
        
        return rows_pivot.tail(360)

    @staticmethod
    def _remove_column_space(df: pl.DataFrame) -> pl.DataFrame:
        """Remove spaces from column names."""
        df.columns = [col.replace(" ", "") for col in df.columns]
        return df

    def get_latest_input_data_by_column_time(
            self, 
            input_name_list: List[str], 
            time_length: int
        ) -> pl.DataFrame:
        """
        Get realtime data for specified time length by column names.

        Args:
            input_name_list: List of column names
            time_length: Length of time window to fetch

        Returns:
            pl.DataFrame: Input data for specified time window
        """
        name_list = input_name_list.copy()
        placeholders = ','.join(['%s'] * len(name_list))
        
        sql = f"""
            SELECT DateTime, TagName, TagVal
            FROM historical_data
            WHERE DateTime BETWEEN NOW() - INTERVAL '6 hours' AND NOW()
            AND TagName IN ({placeholders})
        """
        
        rows = self.query(sql, tuple(name_list))
        
        # Data processing
        rows = (rows
               .drop_nulls()
               .with_columns(pl.col("DateTime").cast(pl.Datetime))
               .with_columns(pl.col("DateTime").dt.truncate('1s')))
        
        rows_pivot = rows.pivot(
            index="DateTime",
            columns="TagName",
            values="TagVal",
            aggregate_function="first"
        )
        
        rows_pivot = self._remove_column_space(rows_pivot)
        name_list.insert(0, "DateTime")
        rows_pivot = rows_pivot[name_list]
        
        # Calculate minute average
        rows_pivot = calculate_minute_average(rows_pivot)
        
        return rows_pivot.tail(time_length)

    def get_latest_true_value(self, table_name: str) -> pl.DataFrame:
        """
        Get latest true value from table.

        Args:
            table_name: Name of the table

        Returns:
            pl.DataFrame: Latest true value
        """
        sql = f"""
            SELECT * FROM {table_name}
            WHERE DateTime BETWEEN 
                NOW() - INTERVAL '2 hours' AND NOW() + INTERVAL '1 hour'
            ORDER BY DateTime DESC
            LIMIT 1
        """
        return self.query(sql)

    def get_latest_true_value_by_column(self, column_name: str) -> pl.DataFrame:
        """
        Get latest true value for specified column.

        Args:
            column_name: Name of the column

        Returns:
            pl.DataFrame: Latest true value for column
        """
        sql = """
            SELECT TagVal
            FROM historical_data
            WHERE DateTime BETWEEN NOW() - INTERVAL '1 hour' AND NOW()
            AND TagName = %s
            LIMIT 1
        """
        return self.query(sql, (column_name,))

    def get_input_data_train(
            self, 
            input_table_name: str, 
            begin_time: datetime.datetime,
            end_time: datetime.datetime
        ) -> pl.DataFrame:
        """
        Get training input data for specified time range.

        Args:
            input_table_name: Name of input table
            begin_time: Start time
            end_time: End time

        Returns:
            pl.DataFrame: Training input data
        """
        sql = """
            SELECT * FROM {}
            WHERE DateTime BETWEEN %s AND %s
            ORDER BY DateTime
        """.format(input_table_name)
        
        return self.query(sql, (begin_time, end_time))

    def get_input_data_history(
            self,
            name_list: List[str],
            begin_time: Union[str, datetime.datetime],
            end_time: Union[str, datetime.datetime]
        ) -> pl.DataFrame:
        """
        Get historical input data for specified columns and time range.

        Args:
            name_list: List of column names
            begin_time: Start time
            end_time: End time

        Returns:
            pl.DataFrame: Historical input data
        """
        placeholders = ','.join(['%s'] * len(name_list))
        sql = f"""
            SELECT * FROM historical_data
            WHERE TagName IN ({placeholders})
            AND DateTime BETWEEN %s AND %s
            ORDER BY DateTime
        """
        
        rows = self.query(sql, tuple(name_list) + (begin_time, end_time))
        
        # Data processing
        rows = (rows
               .drop_nulls()
               .with_columns(pl.col("DateTime").cast(pl.Datetime))
               .with_columns(pl.col("DateTime").dt.truncate('1s')))
        
        df_pivot = rows.pivot(
            index="DateTime",
            columns="TagName",
            values="TagVal",
            aggregate_function="first"
        )
        
        df_pivot = self._remove_column_space(df_pivot)
        name_list.insert(0, "DateTime")
        df_pivot = df_pivot[name_list]
        
        return df_pivot

    def query_decision_history_data(
            self, 
            table_name: str, 
            time_query: int
        ) -> pl.DataFrame:
        """
        Query historical data for decision making.

        Args:
            table_name: Name of the table
            time_query: Time length to query (in minutes)

        Returns:
            pl.DataFrame: Historical data for decision making
        """
        time_query = time_query * 6
        sql = f"""
            SELECT * FROM {table_name}
            WHERE DateTime BETWEEN 
                NOW() - INTERVAL '2 hours' AND NOW() + INTERVAL '1 hour'
            ORDER BY DateTime DESC
            LIMIT {time_query}
        """
        
        rows = self.query(sql)
        return optimization_data_process(rows, int(time_query / 6))

    def query_decision_history_data_by_name(
            self, 
            input_name_list: List[str], 
            time_query: int
        ) -> pl.DataFrame:
        """
        Query historical data by column names for decision making.

        Args:
            input_name_list: List of column names
            time_query: Time length to query

        Returns:
            pl.DataFrame: Historical data for decision making
        """
        name_list = input_name_list.copy()
        placeholders = ','.join(['%s'] * len(name_list))
        
        sql = f"""
            SELECT DateTime, TagName, TagVal
            FROM historical_data
            WHERE DateTime BETWEEN NOW() - INTERVAL '6 hours' AND NOW()
            AND TagName IN ({placeholders})
        """
        
        rows = self.query(sql, tuple(name_list))
        
        # Data processing
        rows = (rows
               .drop_nulls()
               .with_columns(pl.col("DateTime").cast(pl.Datetime))
               .with_columns(pl.col("DateTime").dt.truncate('1s')))
        
        rows_pivot = rows.pivot(
            index="DateTime",
            columns="TagName",
            values="TagVal",
            aggregate_function="first"
        )
        
        rows_pivot = self._remove_column_space(rows_pivot)
        name_list.insert(0, "DateTime")
        rows_pivot = rows_pivot[name_list]
        
        # Calculate minute average
        rows_pivot = calculate_minute_average(rows_pivot)
        
        return rows_pivot.tail(time_query)
