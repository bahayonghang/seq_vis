from pathlib import Path
from typing import List, Optional


def generate_tree(
    root_dir: str | Path,
    exclude_dirs: Optional[List[str]] = None,
    exclude_files: Optional[List[str]] = None,
    max_depth: int = 5,
) -> str:
    """Generate a tree structure of the project directory.
    
    Args:
        root_dir: Root directory to start from
        exclude_dirs: List of directory names to exclude
        exclude_files: List of file names to exclude
        max_depth: Maximum depth of the tree
    
    Returns:
        str: Tree structure as a string

    Examples:
        >>> generate_tree("src/industrytslib")
    """
    if exclude_dirs is None:
        exclude_dirs = ['.git', '__pycache__', '.pytest_cache', '.ruff_cache', 'build', 'dist', '.venv']
    if exclude_files is None:
        exclude_files = ['.gitignore', '.DS_Store', '*.pyc', '*.pyo', '*.pyd']
    
    root = Path(root_dir)
    tree = []
    
    def should_exclude(path: Path) -> bool:
        """Check if path should be excluded."""
        if path.is_dir():
            return any(exclude in path.parts for exclude in exclude_dirs)
        return any(path.match(pattern) for pattern in exclude_files)
    
    def add_to_tree(directory: Path, prefix: str = '', depth: int = 0) -> None:
        """Recursively add directory contents to tree."""
        if depth > max_depth:
            return
            
        paths = sorted(directory.iterdir(), key=lambda x: (x.is_file(), x.name))
        
        for i, path in enumerate(paths):
            if should_exclude(path):
                continue
                
            is_last = i == len([p for p in paths if not should_exclude(p)]) - 1
            connector = '└── ' if is_last else '├── '
            tree.append(f"{prefix}{connector}{path.name}")
            
            if path.is_dir():
                new_prefix = prefix + ('    ' if is_last else '│   ')
                add_to_tree(path, new_prefix, depth + 1)
    
    add_to_tree(root)
    return '\n'.join(tree)


def update_docs_tree(docs_file: str | Path = 'docs/docs/index.md') -> None:
    """Update the project tree in the documentation file.
    
    Args:
        docs_file: Path to the documentation file to update
    
    Examples:
        >>> update_docs_tree()
    """
    tree = generate_tree('src/industrytslib')
    tree_content = f"```txt\nsrc/industrytslib\n{tree}\n```"
    
    docs_path = Path(docs_file)
    content = docs_path.read_text(encoding='utf-8')
    
    # Find the tree section and replace it
    start_marker = "```txt"
    end_marker = "```"
    
    start_idx = content.find(start_marker)
    if start_idx == -1:
        return
    
    end_idx = content.find(end_marker, start_idx) + len(end_marker)
    
    new_content = content[:start_idx] + tree_content + content[end_idx:]
    docs_path.write_text(new_content, encoding='utf-8')


if __name__ == '__main__':
    update_docs_tree() 