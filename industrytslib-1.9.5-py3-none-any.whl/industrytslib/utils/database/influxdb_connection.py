import influxdb_client
import os
import time
import pytz
import random
import pandas as pd
import polars as pl

from datetime import datetime, timedelta
from influxdb_client import InfluxDBClient, Point, WritePrecision
from influxdb_client.client.write_api import SYNCHRONOUS

from industrytslib.utils.database.base import Database
from industrytslib.utils.logutils import get_logger

class InfluxDB(Database):
    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self.config = config
        self.logger = get_logger("InfluxDB")

        self.url = self.config["url"]
        self.token = self.config["token"]
        self.org = self.config["org"]
        self.timezone = pytz.timezone("Asia/Shanghai")

        self.client = influxdb_client.InfluxDBClient(url=self.url, token=self.token, org=self.org)
        self.logger.info(f"connect to influxdb:{self.url} | org: {self.org} | token: {self.token} | success!!!")
        self.write_api = self.client.write_api(write_options=SYNCHRONOUS)
        self.query_api = self.client.query_api()
        self.delete_api = self.client.delete_api()
    
    def __del__(self):
        self.client.close()
        
    def write_data(self, bucket: str, data: Point) -> None:
        self.write_api.write(bucket=bucket, record=data, org=self.org)
        self.logger.info(f"write data to {bucket} success!!!")
        
    def read_data(self, query: str) -> list:
        tables = self.query_api.query(query, org=self.org)
        self.logger.info("read data success!!!")
        return tables
    
    def delete_measurement(self, bucket: str, measurement: str) -> None:
        start_time = "1970-01-01T00:00:00Z"  # 开始时间设为一个远过去的时间
        end_time = datetime.now().isoformat() + "Z"  # 结束时间为当前时间

        try:
            self.delete_api.delete(
                start=start_time,
            stop=end_time, 
            bucket=bucket, 
            predicate=f"_measurement=\"{measurement}\"",
                org=self.org
            )
        except Exception as e:
            self.logger.error(f"Error deleting measurement: {e}")
    
    def save_history_data(self, bucket: str, history_data: pl.DataFrame) -> None:
        """
        保存历史数据到influxdb
        Args:
            bucket: 数据库名
            history_data: 历史数据，polars.DataFrame格式
        """
        start_time = time.time()
        points = []
        measurement = "历史表"


        # Convert DataTime to timestamp
        try:
            timestamp = self.timezone.localize(datetime.now()).timestamp() * 1e9
        except Exception as e:
            self.logger.error(f"Error processing timestamp: {e}")

        for row in history_data.iter_rows(named=True):
            point = Point(measurement)
            point.time(int(timestamp), write_precision=WritePrecision.NS)
            
            # Add TagQuality and TagName as tags
            point.tag("TagQuality", str(row['TagQuality']))
            # point.tag("TagName", str(row['TagName']))
            
            # Convert TagVal to float, use 0.0 if conversion fails
            try:
                tag_val = float(row['TagVal'])
                # tag_val乘以一个随机数，模拟现实 TODO 实际用的时候注释掉
                tag_val = tag_val * random.random()
            except ValueError:
                self.logger.warning(f"Invalid TagVal for {row['TagName']}: {row['TagVal']}. Using 0.0 instead.")
                tag_val = 0.0
            
            point.field(str(row['TagName']), tag_val)
            
            points.append(point)
        
        # Write all points in batches
        batch_size = 1000
        total_points = len(points)
        points_written = 0
        
        for i in range(0, total_points, batch_size):
            batch = points[i:i+batch_size]
            batch_start_time = time.time()
            try:
                self.write_api.write(bucket=bucket, record=batch, org=self.org)
                points_written += len(batch)
                batch_end_time = time.time()
                batch_duration = batch_end_time - batch_start_time
                self.logger.info(f"Wrote batch of {len(batch)} points to {bucket} in {batch_duration:.2f} seconds")
            except Exception as e:
                self.logger.error(f"Error writing batch to {bucket}: {e}")
        
        end_time = time.time()
        total_duration = end_time - start_time
        
        self.logger.info(f"Finished writing {points_written} out of {total_points} points to {bucket}")
        self.logger.info(f"Total time taken: {total_duration:.2f} seconds")
        if points_written > 0:
            average_write_time = total_duration / points_written
            self.logger.info(f"Average time per point: {average_write_time*1000:.2f} milliseconds")

    def query_history_data(self, bucket: str, tag_names: list, start_time: datetime, end_time: datetime) -> pl.DataFrame:
        """
        查询历史数据
        Args:
            bucket: 数据库名
            tag_names: 标签名列表
            start_time: 开始时间
            end_time: 结束时间
        Returns:
            polars.DataFrame格式
        """
        # Convert Beijing time to UTC
        beijing_tz = pytz.timezone("Asia/Shanghai")
        utc_tz = pytz.UTC
        
        start_time_utc = beijing_tz.localize(start_time).astimezone(utc_tz)
        end_time_utc = beijing_tz.localize(end_time).astimezone(utc_tz)
        
        # Construct the Flux query
        tag_filter = ' or '.join([f'r["_field"] == "{tagname}"' for tagname in tag_names])
        query = f'''
        from(bucket:"{bucket}")
            |> range(start: {start_time_utc.isoformat()}, stop: {end_time_utc.isoformat()})
            |> filter(fn: (r) => r._measurement == "历史表")
            |> filter(fn: (r) => {tag_filter})
        '''
        
        # Execute the query
        tables = self.query_api.query(query, org=self.org)

        records = []
        for table in tables:
            for record in table.records:
                records.append((record.get_time(), record.get_field(), record.get_value()))
        
        df = pd.DataFrame(records, columns=['DateTime', 'TagName', 'TagVal'])

        # Pivot操作，将TagName列转化为多列，每列是一个TagName的value
        df_pivot = df.pivot(index='DateTime', columns='TagName', values='TagVal').reset_index()

        print(df_pivot)

        return df_pivot
        


if __name__ == "__main__":
    from industrytslib.utils.readconfig import read_config_toml
    config = read_config_toml("dbconfig.toml")["influxdb"]
    influx_client = InfluxDB(config)

    start_time = datetime(2024, 9, 1, 0, 0, 0)
    end_time = datetime(2024, 10, 2, 0, 0, 0)
    tag_names = [
    "水泥A辊压机仓重反馈",
    "水泥A入库提升机电流反馈",
    "水泥A循环风机挡板反馈",
    "水泥A定辊电流反馈",
    "水泥A动辊电流反馈",
    "水泥A喂料量反馈",
    "水泥A磨主机电流反馈",
    "水泥A磨出口压力反馈",
    "水泥A8406挡板反馈",
    "水泥A磨单位电耗",
    "水泥A循环风机频率反馈",
        "水泥A选粉机电流反馈"
    ]
    result_df = influx_client.query_history_data("控制器数据库", tag_names, start_time, end_time)
    result_df = pl.from_pandas(result_df)
    print(result_df)
    del influx_client
