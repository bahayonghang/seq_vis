import torch

import torch.nn as nn
import numpy as np
import torch.nn.functional as F

from math import sqrt
from industrytslib.models.aimodels.utils.masking import TriangularCausalMask, ProbMask
from reformer_pytorch import LSHSelfAttention
from einops import rearrange, repeat


class DSAttention(nn.Module):
    '''
    De-stationary Attention
    '''

    def __init__(self, mask_flag=True, factor=5, scale=None, attention_dropout=0.1, output_attention=False):
        super(DSAttention, self).__init__()
        self.scale = scale
        self.mask_flag = mask_flag
        self.output_attention = output_attention
        self.dropout = nn.Dropout(attention_dropout)

    def forward(self, queries, keys, values, attn_mask, tau=None, delta=None):
        B, L, H, E = queries.shape
        _, S, _, D = values.shape
        scale = self.scale or 1. / sqrt(E)

        tau = 1.0 if tau is None else tau.unsqueeze(
            1).unsqueeze(1)  # B x 1 x 1 x 1
        delta = 0.0 if delta is None else delta.unsqueeze(
            1).unsqueeze(1)  # B x 1 x 1 x S

        # De-stationary Attention, rescaling pre-softmax score with learned de-stationary factors
        scores = torch.einsum("blhe,bshe->bhls", queries, keys) * tau + delta

        if self.mask_flag:
            if attn_mask is None:
                attn_mask = TriangularCausalMask(B, L, device=queries.device)

            scores.masked_fill_(attn_mask.mask, -np.inf)

        A = self.dropout(torch.softmax(scale * scores, dim=-1))
        V = torch.einsum("bhls,bshd->blhd", A, values)

        if self.output_attention:
            return V.contiguous(), A
        else:
            return V.contiguous(), None


class FullAttention(nn.Module):
    def __init__(self, mask_flag=True, factor=5, scale=None, attention_dropout=0.1, output_attention=False):
        super(FullAttention, self).__init__()
        self.scale = scale
        self.mask_flag = mask_flag
        self.output_attention = output_attention
        self.dropout = nn.Dropout(attention_dropout)

    def forward(self, queries, keys, values, attn_mask, tau=None, delta=None):
        B, L, H, E = queries.shape
        _, S, _, D = values.shape
        scale = self.scale or 1. / sqrt(E)

        scores = torch.einsum("blhe,bshe->bhls", queries, keys)

        if self.mask_flag:
            if attn_mask is None:
                attn_mask = TriangularCausalMask(B, L, device=queries.device)

            scores.masked_fill_(attn_mask.mask, -np.inf)

        A = self.dropout(torch.softmax(scale * scores, dim=-1))
        V = torch.einsum("bhls,bshd->blhd", A, values)

        if self.output_attention:
            return V.contiguous(), A
        else:
            return V.contiguous(), None


class ProbAttention(nn.Module):
    def __init__(self, mask_flag=True, factor=5, scale=None, attention_dropout=0.1, output_attention=False):
        super(ProbAttention, self).__init__()
        self.factor = factor
        self.scale = scale
        self.mask_flag = mask_flag
        self.output_attention = output_attention
        self.dropout = nn.Dropout(attention_dropout)

    def _prob_QK(self, Q, K, sample_k, n_top):  # n_top: c*ln(L_q)
        # Q [B, H, L, D]
        B, H, L_K, E = K.shape
        _, _, L_Q, _ = Q.shape

        # calculate the sampled Q_K
        K_expand = K.unsqueeze(-3).expand(B, H, L_Q, L_K, E)
        # real U = U_part(factor*ln(L_k))*L_q
        index_sample = torch.randint(L_K, (L_Q, sample_k))
        K_sample = K_expand[:, :, torch.arange(
            L_Q).unsqueeze(1), index_sample, :]
        Q_K_sample = torch.matmul(
            Q.unsqueeze(-2), K_sample.transpose(-2, -1)).squeeze()

        # find the Top_k query with sparisty measurement
        M = Q_K_sample.max(-1)[0] - torch.div(Q_K_sample.sum(-1), L_K)
        M_top = M.topk(n_top, sorted=False)[1]

        # use the reduced Q to calculate Q_K
        Q_reduce = Q[torch.arange(B)[:, None, None],
                   torch.arange(H)[None, :, None],
                   M_top, :]  # factor*ln(L_q)
        Q_K = torch.matmul(Q_reduce, K.transpose(-2, -1))  # factor*ln(L_q)*L_k

        return Q_K, M_top

    def _get_initial_context(self, V, L_Q):
        B, H, L_V, D = V.shape
        if not self.mask_flag:
            # V_sum = V.sum(dim=-2)
            V_sum = V.mean(dim=-2)
            contex = V_sum.unsqueeze(-2).expand(B, H,
                                                L_Q, V_sum.shape[-1]).clone()
        else:  # use mask
            # requires that L_Q == L_V, i.e. for self-attention only
            assert (L_Q == L_V)
            contex = V.cumsum(dim=-2)
        return contex

    def _update_context(self, context_in, V, scores, index, L_Q, attn_mask):
        B, H, L_V, D = V.shape

        if self.mask_flag:
            attn_mask = ProbMask(B, H, L_Q, index, scores, device=V.device)
            scores.masked_fill_(attn_mask.mask, -np.inf)

        attn = torch.softmax(scores, dim=-1)  # nn.Softmax(dim=-1)(scores)

        context_in[torch.arange(B)[:, None, None],
        torch.arange(H)[None, :, None],
        index, :] = torch.matmul(attn, V).type_as(context_in)
        if self.output_attention:
            attns = (torch.ones([B, H, L_V, L_V]) /
                     L_V).type_as(attn).to(attn.device)
            attns[torch.arange(B)[:, None, None], torch.arange(H)[
                                                  None, :, None], index, :] = attn
            return context_in, attns
        else:
            return context_in, None

    def forward(self, queries, keys, values, attn_mask, tau=None, delta=None):
        B, L_Q, H, D = queries.shape
        _, L_K, _, _ = keys.shape

        queries = queries.transpose(2, 1)
        keys = keys.transpose(2, 1)
        values = values.transpose(2, 1)

        U_part = self.factor * \
                 np.ceil(np.log(L_K)).astype('int').item()  # c*ln(L_k)
        u = self.factor * \
            np.ceil(np.log(L_Q)).astype('int').item()  # c*ln(L_q)

        U_part = U_part if U_part < L_K else L_K
        u = u if u < L_Q else L_Q

        scores_top, index = self._prob_QK(
            queries, keys, sample_k=U_part, n_top=u)

        # add scale factor
        scale = self.scale or 1. / sqrt(D)
        if scale is not None:
            scores_top = scores_top * scale
        # get the context
        context = self._get_initial_context(values, L_Q)
        # update the context with selected top_k queries
        context, attn = self._update_context(
            context, values, scores_top, index, L_Q, attn_mask)

        return context.contiguous(), attn


class AttentionLayer(nn.Module):
    def __init__(self, attention, d_model, n_heads, 
                 d_keys=None, d_values=None, mix=False):
        super(AttentionLayer, self).__init__()

        d_keys = d_keys or (d_model // n_heads)
        d_values = d_values or (d_model // n_heads)

        self.inner_attention = attention
        self.query_projection = nn.Linear(d_model, d_keys * n_heads)
        self.key_projection = nn.Linear(d_model, d_keys * n_heads)
        self.value_projection = nn.Linear(d_model, d_values * n_heads)
        self.out_projection = nn.Linear(d_values * n_heads, d_model)
        self.n_heads = n_heads

    def forward(self, queries, keys, values, attn_mask, tau=None, delta=None):
        B, L, _ = queries.shape
        _, S, _ = keys.shape
        H = self.n_heads

        queries = self.query_projection(queries).view(B, L, H, -1)
        keys = self.key_projection(keys).view(B, S, H, -1)
        values = self.value_projection(values).view(B, S, H, -1)

        out, attn = self.inner_attention(
            queries,
            keys,
            values,
            attn_mask,
            tau=tau,
            delta=delta
        )
        out = out.view(B, L, -1)

        return self.out_projection(out), attn
    

class AttentionLayerLTCA(nn.Module):
    def __init__(self, attention, d_model, n_heads, 
                 d_keys=None, d_values=None, mix=False):
        super(AttentionLayerLTCA, self).__init__()

        d_keys = d_keys or (d_model//n_heads)
        d_values = d_values or (d_model//n_heads)

        self.inner_attention = attention
        self.query_projection = nn.Linear(d_model, d_keys * n_heads)
        self.key_projection = nn.Linear(d_model, d_keys * n_heads)
        self.value_projection = nn.Linear(d_model, d_values * n_heads)
        self.out_projection = nn.Linear(d_values * n_heads, d_model)
        self.n_heads = n_heads
        self.mix = mix

    def forward(self, queries, keys, values, attn_mask):
        B, L, _ = queries.shape
        _, S, _ = keys.shape
        H = self.n_heads

        queries = self.query_projection(queries).view(B, L, H, -1)
        keys = self.key_projection(keys).view(B, S, H, -1)
        values = self.value_projection(values).view(B, S, H, -1)

        out, attn = self.inner_attention(
            queries,
            keys,
            values,
            attn_mask
        )
        if self.mix:
            out = out.transpose(2,1).contiguous()
        out = out.view(B, L, -1)

        return self.out_projection(out), attn


class CSAAttentionLayer(nn.Module):
    def __init__(self, attention, d_model, n_heads, d_keys=None, d_values=None, value_post_key=False):
        super(CSAAttentionLayer, self).__init__()

        self.value_post_key = value_post_key

        d_keys = d_keys or (d_model // n_heads)
        d_values = d_values or (d_model // n_heads)

        self.inner_attention = attention
        self.query_projection = nn.Linear(d_model, d_keys * n_heads)
        self.key_projection = nn.Linear(d_model, d_keys * n_heads)
        if self.value_post_key:
            self.value_projection = nn.Sequential(
                # nn.ReLU(),
                nn.Linear(d_keys * n_heads, d_values * n_heads)
            )
        else:
            self.value_projection = nn.Linear(d_model, d_values * n_heads)
        self.out_projection = nn.Linear(d_values * n_heads, d_model)
        self.n_heads = n_heads

    def forward(self, queries, keys, values, attn_mask, tau=None, delta=None, use_Q=True):
        B, L, _ = queries.shape
        _, S, _ = keys.shape
        H = self.n_heads

        if use_Q:
            # print(f"using W_Q")
            queries = self.query_projection(queries)
            keys = self.query_projection(keys)
        else:
            queries = self.key_projection(queries)
            keys = self.key_projection(keys)

        if self.value_post_key:
            values = self.value_projection(keys).view(B, S, H, -1)
        else:
            values = self.value_projection(values).view(B, S, H, -1)

        queries = queries.view(B, L, H, -1)
        keys = keys.view(B, S, H, -1)

        out, attn = self.inner_attention(
            queries,
            keys,
            values,
            attn_mask,
            tau=tau,
            delta=delta
        )
        out = out.view(B, L, -1)

        return self.out_projection(out), attn


class LinearAttentionLayer(nn.Module):
    def __init__(self, attention, d_model, n_heads, d_keys=None, d_values=None, value_post_key=False):
        super(LinearAttentionLayer, self).__init__()

        self.value_post_key = value_post_key

        d_keys = d_keys or (d_model // n_heads)
        d_values = d_values or (d_model // n_heads)

        # self.inner_attention = attention
        self.query_projection = nn.Linear(d_model, d_model)
        self.key_projection = nn.Linear(d_model, d_model)
        # if self.value_post_key:
        #     self.value_projection = nn.Sequential(
        #         # nn.ReLU(),
        #         nn.Linear(d_keys * n_heads, d_values * n_heads)
        #     )
        # else:
        #     self.value_projection = nn.Linear(d_model, d_values * n_heads)
        self.value_projection = nn.Linear(d_model * 2, d_model)
        self.out_projection = nn.Linear(d_model, d_model)
        self.n_heads = n_heads

    def forward(self, queries, keys, values, attn_mask, tau=None, delta=None, use_Q=True):
        B, L, _ = queries.shape
        _, S, _ = keys.shape
        H = self.n_heads

        if use_Q:
            # print(f"using W_Q")
            queries = self.query_projection(queries)
            keys = self.query_projection(keys)
        else:
            queries = self.key_projection(queries)
            keys = self.key_projection(keys)

        # queries = queries.view(B, L, H, -1)
        # keys = keys.view(B, S, H, -1)

        queries_ = queries.unsqueeze(2).repeat(1, 1, S, 1)
        keys_ = keys.unsqueeze(1).repeat(1, L, 1, 1)
        qk = torch.cat([queries_, keys_], dim=-1)
        # print(qk.shape, self.value_projection)
        values = self.value_projection(qk)
        # print("vp", values.shape)
        values = values.mean(dim=2)
        out = values.view(B, L, -1)
        # print("out", values.shape)
        # B, L, _ = queries.shape
        # _, S, _ = keys.shape
        # H = self.n_heads
        #
        # if use_Q:
        #     # print(f"using W_Q")
        #     queries = self.query_projection(queries)
        #     keys = self.query_projection(keys)
        # else:
        #     queries = self.key_projection(queries)
        #     keys = self.key_projection(keys)
        #
        # if self.value_post_key:
        #     values = self.value_projection(keys).view(B, S, H, -1)
        # else:
        #     values = self.value_projection(values).view(B, S, H, -1)
        #
        # queries = queries.view(B, L, H, -1)
        # keys = keys.view(B, S, H, -1)
        #
        # out, attn = self.inner_attention(
        #     queries,
        #     keys,
        #     values,
        #     attn_mask,
        #     tau=tau,
        #     delta=delta
        # )
        # out = out.view(B, L, -1)

        return self.out_projection(out), _


class ReformerLayer(nn.Module):
    def __init__(self, attention, d_model, n_heads, d_keys=None,
                 d_values=None, causal=False, bucket_size=4, n_hashes=4):
        super().__init__()
        self.bucket_size = bucket_size
        self.attn = LSHSelfAttention(
            dim=d_model,
            heads=n_heads,
            bucket_size=bucket_size,
            n_hashes=n_hashes,
            causal=causal
        )

    def fit_length(self, queries):
        # inside reformer: assert N % (bucket_size * 2) == 0
        B, N, C = queries.shape
        if N % (self.bucket_size * 2) == 0:
            return queries
        else:
            # fill the time series
            fill_len = (self.bucket_size * 2) - (N % (self.bucket_size * 2))
            return torch.cat([queries, torch.zeros([B, fill_len, C]).to(queries.device)], dim=1)

    def forward(self, queries, keys, values, attn_mask, tau, delta):
        # in Reformer: defalut queries=keys
        B, N, C = queries.shape
        queries = self.attn(self.fit_length(queries))[:, :N, :]
        return queries, None


class TwoStageAttentionLayer(nn.Module):
    '''
    The Two Stage Attention (TSA) Layer
    input/output shape: [batch_size, Data_dim(D), Seg_num(L), d_model]
    '''

    def __init__(self, configs,
                 seg_num, factor, d_model, n_heads, d_ff=None, dropout=0.1):
        super(TwoStageAttentionLayer, self).__init__()
        d_ff = d_ff or 4 * d_model
        self.time_attention = AttentionLayer(FullAttention(False, configs.factor, attention_dropout=configs.dropout,
                                                           output_attention=configs.output_attention), d_model, n_heads)
        self.dim_sender = AttentionLayer(FullAttention(False, configs.factor, attention_dropout=configs.dropout,
                                                       output_attention=configs.output_attention), d_model, n_heads)
        self.dim_receiver = AttentionLayer(FullAttention(False, configs.factor, attention_dropout=configs.dropout,
                                                         output_attention=configs.output_attention), d_model, n_heads)
        self.router = nn.Parameter(torch.randn(seg_num, factor, d_model))

        self.dropout = nn.Dropout(dropout)

        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.norm3 = nn.LayerNorm(d_model)
        self.norm4 = nn.LayerNorm(d_model)

        self.MLP1 = nn.Sequential(nn.Linear(d_model, d_ff),
                                  nn.GELU(),
                                  nn.Linear(d_ff, d_model))
        self.MLP2 = nn.Sequential(nn.Linear(d_model, d_ff),
                                  nn.GELU(),
                                  nn.Linear(d_ff, d_model))

    def forward(self, x, attn_mask=None, tau=None, delta=None):
        # Cross Time Stage: Directly apply MSA to each dimension
        batch = x.shape[0]
        time_in = rearrange(x, 'b ts_d seg_num d_model -> (b ts_d) seg_num d_model')
        time_enc, attn = self.time_attention(
            time_in, time_in, time_in, attn_mask=None, tau=None, delta=None
        )
        dim_in = time_in + self.dropout(time_enc)
        dim_in = self.norm1(dim_in)
        dim_in = dim_in + self.dropout(self.MLP1(dim_in))
        dim_in = self.norm2(dim_in)

        # Cross Dimension Stage: use a small set of learnable vectors to aggregate and distribute messages to build the D-to-D connection
        dim_send = rearrange(dim_in, '(b ts_d) seg_num d_model -> (b seg_num) ts_d d_model', b=batch)
        batch_router = repeat(self.router, 'seg_num factor d_model -> (repeat seg_num) factor d_model', repeat=batch)
        dim_buffer, attn = self.dim_sender(batch_router, dim_send, dim_send, attn_mask=None, tau=None, delta=None)
        dim_receive, attn = self.dim_receiver(dim_send, dim_buffer, dim_buffer, attn_mask=None, tau=None, delta=None)
        dim_enc = dim_send + self.dropout(dim_receive)
        dim_enc = self.norm3(dim_enc)
        dim_enc = dim_enc + self.dropout(self.MLP2(dim_enc))
        dim_enc = self.norm4(dim_enc)

        final_out = rearrange(dim_enc, '(b seg_num) ts_d d_model -> b ts_d seg_num d_model', b=batch)

        return final_out


# 稀疏化采样：不计算所有查询与所有键之间的点积得分，而是从键K中随机采样一部分并找到与这些键最相关的查询Q
# 上下文初始化：根据是否需要掩码，将上下文向量初始化为所有键值的平均值，或者初始化为键值的累积和（即每个位置的上下文向量仅依赖于之前的位置信息）
# 上下文更新：根据稀疏后的注意力得分来更新上下文向量，还会返回注意力权重矩阵（如果需要的话）
# 前向传播：接收查询、键、值以及可选的掩码，返回更新后的上下文向量和注意力权重矩阵（如果需要的话）
class ProbAttentionAlter(nn.Module):
    def __init__(self, mask_flag=True, factor=5, scale=None, attention_dropout=0.1, output_attention=False):
        super(ProbAttentionAlter, self).__init__()
        self.mask_flag = mask_flag
        self.factor = factor
        self.scale = scale
        self.dropout = nn.Dropout(attention_dropout)
        self.output_attention = output_attention

    # 从键K中采样一部分，并找到与这些键最相关的查询Q
    def _prob_QK(self, Q, K, sample_k, n_top):  # sample_k=U_part, n_top=u
        B, H, L_K, E = K.shape  # E：每个头的嵌入维度
        _, _, L_Q, _ = Q.shape

        # 从键K中随机选取一部分，计算这些键与所有查询之间的点积得分，记为Q_K_sample
        K_expand = K.unsqueeze(-3).expand(B, H, L_Q, L_K, E)
        index_sample = torch.randint(L_K, (L_Q, sample_k))  # 从[0,L_K)范围内随机选取L_Q * sample_k个整数索引，生成一个[L_Q,sample_k]的二维张量，每一行包含sample_k个随机索引
        K_sample = K_expand[:, :, torch.arange(L_Q).unsqueeze(1), index_sample, :]
        # torch.arange(L_Q)：生成范围从0到L_Q-1的一维张量，包含查询序列的所有索引
        # torch.arange(L_Q).unsqueeze(1)：形状为 [L_Q, 1]
        # 从每一个查询的对应的键中选取sample_k个键，K_sample 形状为 [B, H, L_Q, sample_k, E]
        Q_K_sample = torch.matmul(Q.unsqueeze(-2), K_sample.transpose(-2, -1)).squeeze(-2)
        # Q.unsqueeze(-2)：扩展维度，查询张量 Q 的形状从 [B, H, L_Q, E] 变为 [B, H, L_Q, 1, E]
        # transpose(-2, -1)：转置最后两个维度
        # matmul：点积得到[B, H, L_Q, 1, sample_k] 的得分矩阵； squeeze(-2)：最终的得分矩阵的形状为[B, H, L_Q, sample_k]

        # 根据稀疏度测量值拿到n_top个查询的索引值
        M = Q_K_sample.max(-1)[0] - torch.div(Q_K_sample.sum(-1), L_K)  # M：[B, H, L_Q]，稀疏度测量值（计算每个查询的最大得分与平均得分之间的差异来衡量每个查询的稀疏程度）
        # max(-1)[0]：沿最后一个维度求最大值，返回形状为[B, H, L_Q] 的张量
        # [0]：max函数会返回最大值和对应的索引，[0]则要求只返回最大值
        # div(Q_K_sample.sum(-1), L_K)：将求和的结果除以L_K，得到每个查询与所有采样键之间的平均点积得分
        M_top = M.topk(n_top, sorted=False)[1]  # M_top：[B, H, n_top]，M中得分最高的前n_top个查询的索引
        # topk函数：从M中选择前n_top个最大值及其对应的索引，返回一个元组，第一个元素是前n_top个最大值，第二个元素是这些最大值对应的索引
        # sorted=False：返回的索引不需要排序，默认情况下topk返回的索引是按降序排列的

        # 从查询张量Q中提取前n_top个最高得分的查询，计算这些查询与所有键之间的点积得分
        # 减少计算复杂度，保留最重要的查询，选择出最相关的键，用于后续的注意力机制计算
        Q_reduce = Q[torch.arange(B)[:, None, None],
                     torch.arange(H)[None, :, None],
                     M_top, :]  # Q：[B, H, L_Q, E]；  Q_reduce：[B, H, n_top, E]，从Q中提取出每个批次和每个头中前n_top 个最高得分的查询
        Q_K = torch.matmul(Q_reduce, K.transpose(-2, -1))  # Q_K ：[B, H, n_top, L_K]

        return Q_K, M_top

    # 上下文向量：用于存储每个查询的初始状态，方便后续的注意力计算
    def _get_initial_context(self, V, L_Q):
        B, H, L_V, D = V.shape
        if not self.mask_flag:
            V_sum = V.mean(dim=-2)  # V_sum形状为[B, H, D]
            contex = V_sum.unsqueeze(-2).expand(B, H, L_Q, V_sum.shape[-1]).clone()  # 扩展后contex形状为[B, H, L_Q, D]，clone会创建一个新张量，不会修改原张量
        else:
            assert(L_Q == L_V)  # 要求L_Q == L_V，如果不成立，抛出一个 AssertionError 异常
            contex = V.cumsum(dim=-2)  # contex形状为[B, H, L_V, D]，累积和：确保当前位置只依赖于之前的位置信息，不会泄露未来的信息
            # sum：全部求和； cumsum：累积求和
        return contex

    # 返回更新后的上下文向量和注意力权重矩阵（有要求时）
    # 上下文向量：由值向量通过加权求和得到（注意力权重矩阵和值向量矩阵相乘）
    def _update_context(self, context_in, V, scores, index, L_Q, attn_mask, gate_values):
        # context_in：均匀分布的结果，V：原始的Values，scores：采样的Q和全部K的点积归一化的结果
        B, H, L_V, D = V.shape

        if self.mask_flag:
            attn_mask = ProbMask(B, H, L_Q, index, scores, device=V.device)
            scores.masked_fill_(attn_mask.mask, -np.inf)  # 将mask为True的位置的注意力得分设置为-np.inf（经softmax后这些位置的注意力权重重置为0，从而忽略这些位置）

        attn = torch.softmax(scores, dim=-1)  # 将注意力得分转换为概率分布

        # attn张量的每个元素表示在给定查询下，每个键值对的重要性或权重，这些权重之和为 1。
        # gate_values = gate_values.  # gate_values形状为[B, H, L_V, 1]

        gate_values = F.interpolate(gate_values, size=(gate_values.shape[-2],attn.shape[-1]), mode='bilinear', align_corners=False)
        attn1 = torch.matmul(attn,gate_values)
        context_in[torch.arange(B)[:, None, None],
                   torch.arange(H)[None, :, None],
                   index, :] = torch.matmul(attn1, V).type_as(context_in)
        # 注意力权重attn与键值V相乘，得到新的上下文向量，并更新到context_in张量的指定位置上

        if self.output_attention:
            attns = (torch.ones([B, H, L_V, L_V])/L_V).type_as(attn).to(attn.device)  # 创建一个均匀分布的概率矩阵，所有元素初始化为1/L_V
            attns[torch.arange(B)[:, None, None], torch.arange(H)[None, :, None], index, :] = attn  # 将注意力权重根据索引更新到attns上
            return (context_in, attns)
        else:
            return (context_in, None)

    def forward(self, queries, keys, values, attn_mask, gate_values):
        B, L_Q, H, D = queries.shape
        _, L_K, _, _ = keys.shape

        queries = queries.transpose(2,1)  # 交换第二、三维度，将头数放到第二维度
        keys = keys.transpose(2,1)
        values = values.transpose(2,1)

        U_part = self.factor * np.ceil(np.log(L_K)).astype('int').item()  # U_part=c*ln(L_k)向上取整后乘以factor，再转换为整数
        u = self.factor * np.ceil(np.log(L_Q)).astype('int').item()  # u=c*ln(L_Q)
        # ceil：向上取整，是对ln的结果进行向上取整； item：将NumPy数组转换为Python标量； factor：控制采样数量

        # 确保不超过对应的序列长度
        U_part = U_part if U_part<L_K else L_K
        u = u if u<L_Q else L_Q

        # 得到筛选后的Q和全部K计算点积，前n_top个查询的索引

        scores_top, index = self._prob_QK(queries, keys, sample_k=U_part, n_top=u)

        scale = self.scale or 1./sqrt(D)  # 缩放：避免当嵌入维度D较大时点积变得过大
        if scale is not None:
            scores_top = scores_top * scale  # 在嵌入维度较大时调整得分的尺度

        context = self._get_initial_context(values, L_Q)  # 不用掩码：每个查询的初始上下文向量是所有键值的平均值； 用掩码：是当前位置之前的键值的累积和
        # update the context with selected top_k queries
        context, attn = self._update_context(context, values, scores_top, index, L_Q, attn_mask, gate_values)

        return context.transpose(2,1).contiguous(), attn
    

class DynamicAttentionLayer(nn.Module):
    def __init__(self, attention, d_model, n_heads,
                 d_keys=None, d_values=None, mix=False, hidden_size=64):
        super(DynamicAttentionLayer, self).__init__()

        d_keys = d_keys or (d_model // n_heads)
        d_values = d_values or (d_model // n_heads)

        self.inner_attention = attention
        self.query_projection = nn.Linear(d_model, d_keys * n_heads)
        self.key_projection = nn.Linear(d_model, d_keys * n_heads)
        self.value_projection = nn.Linear(d_model, d_values * n_heads)
        self.out_projection = nn.Linear(d_values * n_heads, d_model)

        self.n_heads = n_heads
        self.mix = mix

        # 添加 GRU 层，用于对 queries, keys, values 进行特征提取
        self.gru = nn.GRU(d_model, hidden_size, batch_first=True)
        self.gru_query = nn.GRU(d_model, hidden_size, batch_first=True)
        self.gru_key = nn.GRU(d_model, hidden_size, batch_first=True)
        self.gru_value = nn.GRU(d_model, hidden_size, batch_first=True)
        self.gru_linear = nn.Linear(64, 512)
        # self.gate_fc = nn.Linear(hidden_size, queries.shape[1])  # 映射到一个标量（门控值）
        self.sigmoid = nn.Sigmoid()  # 确保门控值在 [0, 1] 范围内

    def forward(self, queries, keys, values, attn_mask):
        B, L, _ = queries.shape
        _, S, _ = keys.shape
        H = self.n_heads

        queries = self.query_projection(queries).view(B, L, H, -1)  # 查询、键、值分别通过线性层进行投影，并重新排列形状
        keys = self.key_projection(keys).view(B, S, H, -1)
        values = self.value_projection(values).view(B, S, H, -1)

        # 通过 GRU 计算门控值
        gru_out = queries.view(B, L, -1)  # 展平 H 和 d_values
        gru_output, _ = self.gru(gru_out)  # GRU 的输入是 [B, L, H * d_value]
        # gate_values = self.gate_fc(gru_output)  # [B, L, 1]
        gate_values = self.sigmoid(gru_output)  # 将门控值限制在 [0, 1] 范围内
        gate_values = gate_values.unsqueeze(1)  # [B, L, 1, 1]
        # 将门控值应用到注意力输出
        # gated_attn = attn * gate_values.unsqueeze(-1)  # 门控调整注意力权重
        #
        # # 使用门控的注意力权重对值进行加权
        # gated_out = torch.matmul(gated_attn, values)

        # 计算多头注意力
        out, attn = self.inner_attention(
            queries, keys, values, attn_mask, gate_values
        )


        if self.mix:
            out = out.transpose(2, 1).contiguous()  # 交换头和序列维度

        out = out.view(B, L, -1)  # 将最终的输出展平

        # 通过输出投影层
        return self.out_projection(out), attn


class MultiHeadSelfAttention(nn.Module):
    dim_in: int  # input dimension
    dim_k: int   # key and query dimension
    dim_v: int   # value dimension
    num_heads: int  # number of heads, for each head, dim_* = dim_* // num_heads

    def __init__(self, dim_in, dim_k, dim_v, num_heads=8):
        super(MultiHeadSelfAttention, self).__init__()
        assert dim_k % num_heads == 0 and dim_v % num_heads == 0, "dim_k and dim_v must be multiple of num_heads"
        self.dim_in = dim_in
        self.dim_k = dim_k
        self.dim_v = dim_v
        self.num_heads = num_heads
        self.linear_q = nn.Linear(dim_in, dim_k, bias=False)
        self.linear_k = nn.Linear(dim_in, dim_k, bias=False)
        self.linear_v = nn.Linear(dim_in, dim_v, bias=False)
        self._norm_fact = 1 / sqrt(dim_k // num_heads)

    def forward(self, x):
        # x: tensor of shape (batch, n, dim_in)
        batch, n, dim_in = x.shape
        assert dim_in == self.dim_in

        nh = self.num_heads
        dk = self.dim_k // nh  # dim_k of each head
        dv = self.dim_v // nh  # dim_v of each head

        q = self.linear_q(x).reshape(batch, n, nh, dk).transpose(1, 2)  # (batch, nh, n, dk)
        k = self.linear_k(x).reshape(batch, n, nh, dk).transpose(1, 2)  # (batch, nh, n, dk)
        v = self.linear_v(x).reshape(batch, n, nh, dv).transpose(1, 2)  # (batch, nh, n, dv)

        dist = torch.matmul(q, k.transpose(2, 3)) * self._norm_fact  # batch, nh, n, n
        dist = torch.softmax(dist, dim=-1)  # batch, nh, n, n

        att = torch.matmul(dist, v)  # batch, nh, n, dv
        att = att.transpose(1, 2).reshape(batch, n, self.dim_v)  # batch, n, dim_v
        return att  
     