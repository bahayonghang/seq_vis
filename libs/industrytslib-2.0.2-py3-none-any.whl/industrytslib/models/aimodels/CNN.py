import torch
import torch.nn as nn
import torch.nn.functional as F

from kan import KAN


# class CNN(nn.Module):
#     def __init__(self, in_channels: int, out_channels:int, hidden_size: int, num_layers: int, output_size: int):
#         """
#         CNN Model
#         :param model_parameter: 模型参数,字典类型
#         - in_channels: 输入通道数,即输入维度,有几个输入变量即为几
#         - out_channels: 输出通道数,即输出维度,一般为1
#         - hidden_size: 隐藏层神经元个数
#         - num_layers: 隐藏层层数
#         - output_size: 输出层神经元个数
#         - batch_size: 批次大小
#         - seq_length: 序列长度
#         - num_directions: LSTM方向数,单向为1,双向为2
#         """
#         super(CNN, self).__init__()
#         self.in_channels = in_channels
#         self.out_channels = out_channels
#         self.hidden_size = hidden_size
#         self.num_layers = num_layers
#         self.output_size = output_size

#         self.num_directions = 1  # 单向LSTM
#         self.relu = nn.ReLU(inplace=True)

#         # (batch_size=64, seq_len=3, input_size=3) ---> permute(0, 2, 1)
#         # (64, 3, 3)
#         self.conv = nn.Sequential(
#             nn.Conv1d(in_channels=self.in_channels, out_channels=self.out_channels, kernel_size=3),
#             # shape(7,--)  ->(64,3,2)
#             nn.ReLU())
#         self.lstm = nn.LSTM(input_size=self.out_channels, hidden_size=self.hidden_size, num_layers=self.num_layers,
#                             batch_first=True)
#         self.fc = nn.Linear(self.hidden_size, self.output_size)

#     def forward(self, x):
#         x = x.permute(0, 2, 1)
#         x = self.conv(x)
#         x = x.permute(0, 2, 1)
#         # batch_size, seq_len = x.size()[0], x.size()[1]
#         h_0 = torch.randn(self.num_directions * self.num_layers, x.size(0), self.hidden_size, device=x.device)
#         c_0 = torch.randn(self.num_directions * self.num_layers, x.size(0), self.hidden_size, device=x.device)
#         # output(batch_size, seq_len, num_directions * hidden_size)
#         output, _ = self.lstm(x, (h_0, c_0))
#         pred = self.fc(output)
#         pred = pred[:, -1, :]
#         return pred


class CNN(nn.Module):
    def __init__(self, configs):
        """
        CNN Model
        :param model_parameter: 模型参数,字典类型
        - in_channels: 输入通道数,即输入维度,有几个输入变量即为几
        - out_channels: 输出通道数,即输出维度,一般为1
        - hidden_size: 隐藏层神经元个数
        - num_layers: 隐藏层层数
        - output_size: 输出层神经元个数
        - batch_size: 批次大小
        - seq_length: 序列长度
        - num_directions: LSTM方向数,单向为1,双向为2
        """
        super(CNN, self).__init__()
        self.in_channels = configs.in_channels
        self.out_channels = configs.out_channels
        self.hidden_size = configs.hidden_size
        self.num_layers = configs.num_layers
        self.output_size = configs.output_size

        self.num_directions = 1  # 单向LSTM
        # self.relu = nn.ReLU(inplace=True)
        self.relu = nn.LeakyReLU()

        # (batch_size=64, seq_len=3, input_size=3) ---> permute(0, 2, 1)
        # (64, 3, 3)
        self.conv = nn.Sequential(
            nn.Conv1d(in_channels=self.in_channels, out_channels=self.out_channels, kernel_size=3),
            # shape(7,--)  ->(64,3,2)
            nn.ReLU())

        self.dense = nn.Linear(self.in_channels, self.out_channels)

        self.lstm = nn.LSTM(input_size=self.out_channels, hidden_size=self.hidden_size, num_layers=self.num_layers,
                            batch_first=True)
        self.fc = nn.Linear(self.hidden_size, self.output_size)

    def forward(self, x):
        x = x.permute(0, 2, 1)
        x = self.conv(x)
        
        x = x.permute(0, 2, 1)
        # batch_size, seq_len = x.size()[0], x.size()[1]
        h_0 = torch.randn(self.num_directions * self.num_layers, x.size(0), self.hidden_size, device=x.device)
        c_0 = torch.randn(self.num_directions * self.num_layers, x.size(0), self.hidden_size, device=x.device)
        # output(batch_size, seq_len, num_directions * hidden_size)
        output, _ = self.lstm(x, (h_0, c_0))
        pred = self.fc(output)
        pred = pred[:, -1, :]
        return pred
    

class CNN_LSTM(nn.Module):
    # def __init__(self, input_dim, hidden_dim, num_layers, output_dim, device):
    def __init__(self, configs):
        super(CNN_LSTM, self).__init__()
        self.input_dim = configs.in_channels
        self.hidden_dim = configs.hidden_size
        self.num_layers = configs.num_layers
        self.out_dim = configs.output_size

        # 添加更多卷积层，并增加输出通道数
        self.conv1 = nn.Conv1d(self.input_dim, 256, kernel_size=5, padding=2)
        self.bn1 = nn.BatchNorm1d(256)
        self.conv2 = nn.Conv1d(256, 128, kernel_size=5, padding=2)
        self.bn2 = nn.BatchNorm1d(128)
        self.conv3 = nn.Conv1d(128, 64, kernel_size=3, padding=1)
        self.bn3 = nn.BatchNorm1d(64)

        # 使用LSTM层
        self.lstm = nn.LSTM(64, self.hidden_dim, self.num_layers, batch_first=True)

        # 全连接层
        self.fc = nn.Linear(self.hidden_dim, self.out_dim)

        # Dropout正则化
        self.dropout = nn.Dropout(p=0.5)

    def forward(self, x):
        # 将输入从 (batch_size, seq_length, input_dim) 转换为 (batch_size, input_dim, seq_length)
        x = x.transpose(1, 2)

        # 卷积层 + BatchNorm + 激活函数
        x = F.relu(self.bn1(self.conv1(x)))
        x = F.relu(self.bn2(self.conv2(x)))
        x = F.relu(self.bn3(self.conv3(x)))

        # 转换为 LSTM 需要的 (batch_size, seq_length, feature_dim)
        x = x.transpose(1, 2)

        # 初始化隐藏状态和细胞状态，并将它们放置到对应设备
        h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_dim, device=x.device)
        c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_dim, device=x.device)

        # 前向传播LSTM
        out, (hn, cn) = self.lstm(x, (h0, c0))

        # Dropout
        out = self.dropout(out)

        # 通过全连接层
        out = self.fc(out[:, -1, :])

        return out


class CNNLSTMKAN(nn.Module):
    def __init__(self, configs):
        """
        CNNLSTMKAN Model
        :param model_parameter: 模型参数,字典类型
        - in_channels: 输入通道数,即输入维度,有几个输入变量即为几
        - out_channels: 输出通道数,即输出维度,一般为1
        - hidden_size: 隐藏层神经元个数
        - num_layers: 隐藏层层数
        - output_size: 输出层神经元个数
        - batch_size: 批次大小
        - seq_length: 序列长度
        - num_directions: LSTM方向数,单向为1,双向为2
        """
        super(CNNLSTMKAN, self).__init__()
        self.in_channels = configs.in_channels
        self.out_channels = configs.out_channels
        self.hidden_size = configs.hidden_size
        self.num_layers = configs.num_layers
        self.output_size = configs.output_size

        self.num_directions = 1  # 单向LSTM
        # self.relu = nn.ReLU(inplace=True)
        self.relu = nn.LeakyReLU()

        # (batch_size=64, seq_len=3, input_size=3) ---> permute(0, 2, 1)
        # (64, 3, 3)
        self.conv = nn.Sequential(
            nn.Conv1d(in_channels=self.in_channels, out_channels=self.out_channels, kernel_size=3),
            # shape(7,--)  ->(64,3,2)
            nn.ReLU())

        self.dense = nn.Linear(self.in_channels, self.out_channels)

        self.lstm = nn.LSTM(input_size=self.out_channels, hidden_size=self.hidden_size, num_layers=self.num_layers,
                            batch_first=True)
        # self.fc = nn.Linear(self.hidden_size, self.output_size)
        self.fc = KAN(width=[self.x_length * self.hidden_size, self.output_size])

    def forward(self, x):
        x = x.permute(0, 2, 1)
        x = self.conv(x)
        
        x = x.permute(0, 2, 1)
        # batch_size, seq_len = x.size()[0], x.size()[1]
        h_0 = torch.randn(self.num_directions * self.num_layers, x.size(0), self.hidden_size, device=x.device)
        c_0 = torch.randn(self.num_directions * self.num_layers, x.size(0), self.hidden_size, device=x.device)
        # output(batch_size, seq_len, num_directions * hidden_size)
        output, _ = self.lstm(x, (h_0, c_0))
        pred = self.fc(output)
        pred = pred[:, -1, :]
        return pred
    