import torch
import torch.nn as nn
from math import sqrt
from kan import KAN

from industrytslib.models.aimodels.layers.attn import AttentionLayerLTCA
from .xlstm import xLSTM

# 构建 TCN 层
class TCNLayer(nn.Module):
    def __init__(self, input_size, output_size, kernel_size, dilation):
        super(TCNLayer, self).__init__()
        self.conv = nn.Conv1d(input_size, output_size, kernel_size=kernel_size, dilation=dilation, padding=(kernel_size - 1) * dilation // 2)
        self.activation = nn.ReLU()

    def forward(self, x):
        return self.activation(self.conv(x))

# 定义全注意力机制
class FullAttention(nn.Module):
    def __init__(self, mask_flag=True, factor=5, scale=None, attention_dropout=0.1, output_attention=False):
        super(FullAttention, self).__init__()
        self.scale = scale
        self.mask_flag = mask_flag
        self.output_attention = output_attention
        self.dropout = nn.Dropout(attention_dropout)

    def forward(self, queries, keys, values, attn_mask):
        B, L, H, E = queries.shape
        _, S, _, D = values.shape
        scale = self.scale or 1. / sqrt(E)

        scores = torch.einsum("blhe,bshe->bhls", queries, keys)

        A = self.dropout(torch.softmax(scale * scores, dim=-1))
        V = torch.einsum("bhls,bshd->blhd", A, values)

        if self.output_attention:
            return (V.contiguous(), A)
        else:
            return (V.contiguous(), None)

# 构建 LTCA 模型
class LTCA(nn.Module):
    def __init__(self, config: dict):
        super(LTCA, self).__init__()
        self.x_length = config.x_length
        self.input_size = config.in_channels
        self.hidden_size = config.hidden_size
        self.output_size = config.output_size
        self.num_layers = config.num_layers
        self.kernel_size = config.kernel_size
        self.num_blocks = config.num_blocks
        self.dropout_rate = config.dropout_rate

        self.tcn_layers = nn.ModuleList([TCNLayer(self.input_size if i == 0 else self.hidden_size, self.hidden_size, self.kernel_size, 2**i) for i in range(self.num_blocks)])
        self.lstm = nn.LSTM(self.hidden_size, self.hidden_size, self.num_layers, batch_first=True, dropout=self.dropout_rate)
        self.attention = AttentionLayerLTCA(FullAttention(False, 5, self.dropout_rate, output_attention=False),
                                        self.hidden_size, 8, mix=False)
        self.fc = nn.Linear(self.x_length * self.hidden_size, self.output_size)

    # def forward(self, x):
    #     for tcn in self.tcn_layers:
    #         x = tcn(x.permute(0, 2, 1)).permute(0, 2, 1)  # 转换维度以适配 Conv1d
    #     out, _ = self.lstm(x)
    #     context, _ = self.attention(out, out, out, None)
    #     context = context.view(context.size(0), -1)
    #     out = self.fc(context)
    #     return out
    def forward(self, x):
        for tcn in self.tcn_layers:
            x = tcn(x.permute(0, 2, 1)).permute(0, 2, 1)  # 转换维度以适配 Conv1d
        out, _ = self.lstm(x)
        context, _ = self.attention(out, out, out, None)
        context = context.view(out.size(0), -1)
        out = self.fc(context)
        return out


class LTCAKAN(nn.Module):
    def __init__(self, config: dict):
        super(LTCAKAN, self).__init__()
        self.x_length = config.x_length
        self.input_size = config.in_channels
        self.hidden_size = config.hidden_size
        self.output_size = config.output_size
        self.num_layers = config.num_layers
        self.kernel_size = config.kernel_size
        self.num_blocks = config.num_blocks
        self.dropout_rate = config.dropout_rate

        self.tcn_layers = nn.ModuleList([TCNLayer(self.input_size if i == 0 else self.hidden_size, self.hidden_size, self.kernel_size, 2**i) for i in range(self.num_blocks)])
        self.lstm = nn.LSTM(self.hidden_size, self.hidden_size, self.num_layers, batch_first=True, dropout=self.dropout_rate)
        self.attention = AttentionLayerLTCA(FullAttention(False, 5, self.dropout_rate, output_attention=False),
                                        self.hidden_size, 8, mix=False)
        self.fc = KAN(width=[self.x_length * self.hidden_size, self.output_size])

    def forward(self, x):
        for tcn in self.tcn_layers:
            x = tcn(x.permute(0, 2, 1)).permute(0, 2, 1)  # 转换维度以适配 Conv1d
        out, _ = self.lstm(x)
        context, _ = self.attention(out, out, out, None)
        context = context.view(out.size(0), -1)
        out = self.fc(context)
        return out


class XLTCAKAN(nn.Module):
    def __init__(self, config: dict):
        super(XLTCAKAN, self).__init__()
        self.x_length = config.x_length
        self.input_size = config.in_channels
        self.hidden_size = config.hidden_size
        self.output_size = config.output_size
        self.num_layers = config.num_layers
        self.kernel_size = config.kernel_size
        self.num_blocks = config.num_blocks
        self.dropout_rate = config.dropout_rate

        self.tcn_layers = nn.ModuleList([TCNLayer(self.input_size if i == 0 else self.hidden_size, self.hidden_size, self.kernel_size, 2**i) for i in range(self.num_blocks)])

        # TODO xLSTM 的参数需要根据 config 进行调整
        self.xlstm = xLSTM(self.hidden_size, self.hidden_size, self.num_layers, self.num_blocks, dropout=self.dropout_rate)

        self.attention = AttentionLayerLTCA(FullAttention(False, 5, self.dropout_rate, output_attention=False),
                                        self.hidden_size, 8, mix=False)
        self.fc = KAN(width=[self.x_length * self.hidden_size, self.output_size])

    def forward(self, x):
        for tcn in self.tcn_layers:
            x = tcn(x.permute(0, 2, 1)).permute(0, 2, 1)  # 转换维度以适配 Conv1d
        out, _ = self.xlstm(x)
        context, _ = self.attention(out, out, out, None)
        context = context.view(out.size(0), -1)
        out = self.fc(context)
        return out
    