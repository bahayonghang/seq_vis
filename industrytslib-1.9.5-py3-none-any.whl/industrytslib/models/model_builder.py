# import inspect

import torch.nn as nn

from types import SimpleNamespace


# 导入自定义AI模型
from industrytslib.models.aimodels import (
    mLSTM, sLSTM, xLSTM,
    Informer, iTransformer, PatchTST, CrossFormer, TimesNet, TimeMixer, MTST,
    CNN, TCN, LTCA, LSTMKAN, CNN_LSTM
)

# 先尝试导入mamba_ssm，如果不报错则导入MambaBasic
try:
    import mamba_ssm
    from industrytslib.models.aimodels import MambaBasic, TimeMachine
    print("mamba_ssm has been imported, Mamba based models is available!!!")
    model_dict = {
    # xLSTM models
    "mLSTM": mLSTM,
    "sLSTM": sLSTM,
    "xLSTM": xLSTM,
    # mamba models
    "MambaBasic": MambaBasic,
    "TimeMachine": TimeMachine,
    # transformer models
    "informer": Informer,
    "iTransformer": iTransformer,
    "PatchTST": PatchTST,
    "CrossFormer": CrossFormer,
    "TimesNet": TimesNet,
    "TimeMixer": TimeMixer,
    "MTST": MTST,
    # basic models
    "CNN": CNN,
    "TCN": TCN,
    "LTCA": LTCA,
    "LSTMKAN": LSTMKAN,
    "CNN_LSTM": CNN_LSTM,
}
except ImportError:
    print("Mamba not installed, skipping import MambaBasic")
    model_dict = {
    # xLSTM models
    "mLSTM": mLSTM,
    "sLSTM": sLSTM,
    "xLSTM": xLSTM,

    # transformer models
    "informer": Informer,
    "iTransformer": iTransformer,
    "PatchTST": PatchTST,
    "CrossFormer": CrossFormer,
    "TimesNet": TimesNet,
    "TimeMixer": TimeMixer,
    "MTST": MTST,
    # basic models
    "CNN": CNN,
    "TCN": TCN,
    "LTCA": LTCA,
    "LSTMKAN": LSTMKAN,
    "CNN_LSTM": CNN_LSTM,
}


# # 获取模型初始化方法的参数列表
# def get_init_params(model_class: nn.Module):
#     signature = inspect.signature(model_class.__init__)
#     params = signature.parameters
#     return params


# # 获取必须提供的参数列表（没有默认值的参数）
# def get_required_params(params: dict):
#     required_params = [
#         name for name, param in params.items()
#         if param.default == inspect.Parameter.empty and param.kind in [param.POSITIONAL_OR_KEYWORD, param.KEYWORD_ONLY]
#     ]
#     try:
#         required_params.remove("self")
#         print(f"required_params: {required_params}")
#         return required_params
#     except ValueError:
#         print(f"required_params: {required_params}")
#         return required_params


# # 检查字典中是否包含所有必须的参数
# def check_missing_params(required_params: list, kwargs: dict):
#     missing_params = [param for param in required_params if param not in kwargs]
#     if missing_params:
#         raise ValueError(f"缺少必要的参数: {', '.join(missing_params)}")


# # 过滤字典，只保留模型初始化方法接受的参数
# def filter_kwargs(params: dict, kwargs: dict):
#     valid_params = params.keys()
#     filtered_kwargs = {k: v for k, v in kwargs.items() if k in valid_params}
#     return filtered_kwargs


# def build_model(model_name: str, model_parameter: dict, **kwargs: dict):
#     """
#     构建模型
#     """
#     ModelClass = model_dict[model_name]
#     # 获取初始化方法的参数
#     params = get_init_params(ModelClass)

#     # 获取必须的参数列表
#     required_params = get_required_params(params)

#     # 检查是否有缺失的参数
#     check_missing_params(required_params, model_parameter)

#     # 过滤参数字典
#     filtered_params = filter_kwargs(params, model_parameter)

#     # 使用过滤后的参数来实例化模型
#     model = ModelClass(**filtered_params)

#     return model

def build_model(model_name:str, model_parameter:dict):
    """
    构建模型
    """
    ModelClass = model_dict[model_name]

    # 将model_parameter这个dict类型转换为可以使用.的类型
    model_parameter = SimpleNamespace(**model_parameter)    
    
    model = ModelClass(model_parameter).float()
    
    try:
        if model_parameter.use_multi_gpu and model_parameter.use_gpu:
            model = nn.DataParallel(model, device_ids=model_parameter.device_ids)
    except KeyError:
        print("未使用多GPU")
    finally:
        return model