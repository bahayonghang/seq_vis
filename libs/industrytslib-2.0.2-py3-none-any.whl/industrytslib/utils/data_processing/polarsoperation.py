import numpy as np
import polars as pl
import pywt

from datetime import datetime, timedelta
from scipy.signal import savgol_filter
from typing import Tuple, List, Optional, Union, Sequence


def convert_datetime_format(df: pl.DataFrame) -> pl.DataFrame:
    """Convert DateTime column from various formats to standard format.

    Args:
        df (pl.DataFrame): DataFrame containing a DateTime column

    Returns:
        pl.DataFrame: DataFrame with standardized DateTime format (%Y-%m-%d %H:%M:%S.%f)

    Examples:
        >>> df = pl.DataFrame({
        ...     'DateTime': ['4/18/2023 0:00', '4/18/2023 0:01'],
        ...     'Value': [1, 2]
        ... })
        >>> result = convert_datetime_format(df)
        >>> print(result)
        shape: (2, 2)
        ┌─────────────────────┬───────┐
        │ DateTime            ┆ Value │
        │ ---                ┆ ---   │
        │ datetime[μs]       ┆ i64   │
        ╞═════════════════════╪═══════╡
        │ 2023-04-18 00:00:00┆ 1     │
        │ 2023-04-18 00:01:00┆ 2     │
        └─────────────────────┴───────┘
    """
    try:
        # First try direct conversion
        df = df.with_columns(pl.col("DateTime").cast(pl.Datetime))
    except pl.exceptions.InvalidOperationError:
        try:
            # Try parsing with specific format for "M/D/YYYY H:MM" format
            df = df.with_columns(
                pl.col("DateTime").str.strptime(
                    pl.Datetime,
                    format="%m/%d/%Y %H:%M"
                ).alias("DateTime")
            )
        except pl.exceptions.InvalidOperationError as e:
            print(f"Failed to convert DateTime with first format, trying alternative: {e}")
            try:
                # Try parsing with format including seconds
                df = df.with_columns(
                    pl.col("DateTime").str.strptime(
                        pl.Datetime,
                        format="%m/%d/%Y %H:%M:%S"
                    ).alias("DateTime")
                )
            except pl.exceptions.InvalidOperationError as e:
                print(f"Failed to convert DateTime with second format: {e}")
                # Try parsing with format including seconds
                try:
                    df = df.with_columns(
                        pl.col("DateTime").str.strptime(
                            pl.Datetime,
                            format="%Y-%m-%d %H:%M:%S"
                        ).alias("DateTime")
                    )
                except Exception as e:
                    raise ValueError(f"转换时间列失败: {e}")
    return df


def calculate_minute_average(dataframe_cal: pl.DataFrame) -> pl.DataFrame:
    """Calculate the average value per minute

    Args:
        dataframe_cal (pl.DataFrame): Input DataFrame, default time column is DateTime

    Returns:
        pl.DataFrame: DataFrame with average values per minute
    
    Examples:
        >>> dataframe_cal = pl.DataFrame({
        ...     'DateTime': ['2024-01-01 00:00:00', '2024-01-01 00:00:01', '2024-01-01 00:00:02'],
        ...     'Value': [1, 2, 3]
        ... })
        >>> calculate_minute_average(dataframe_cal)
        shape: (2, 2)
        ┌─────────────────────┬───────┐
        │ DateTime            ┆ Value │
        │ ---                ┆ ---   │
        │ datetime[μs]       ┆ i64   │
        ╞═════════════════════╪═══════╡
        │ 2024-01-01 00:00:00┆ 1     │
        │ 2024-01-01 00:00:01┆ 2     │
        └─────────────────────┴───────┘
    """
    # 将DateTime列转换为datetime类型
    dataframe_cal = convert_datetime_format(dataframe_cal)

    # 按 DateTime 列进行排序
    # print(f"dataframe_cal for calculating minute average: {dataframe_cal}")
    try:
        df_polars = dataframe_cal.sort("DateTime", descending=False)
    except Exception as e:
        print(f"不需要排序: {e}")
        df_polars = dataframe_cal

    # # 将DateTime列转换为datetime类型
    # if not df_polars.select(pl.col("DateTime")).dtypes[0] == pl.Datetime:
    #     try:
    #         df_polars = df_polars.with_columns(pl.col("DateTime").cast(pl.Datetime))
    #     except pl.exceptions.InvalidOperationError as e:
    #         print(f"时间列DateTime格式不对,尝试转换为%Y-%m-%d %H:%M:%S.%f格式: {e}")
    #         # DateTime列格式不对，4/18/2023 0:00尝试转换为%Y-%m-%d %H:%M:%S.%f格式
    #         df_polars = df_polars.with_columns(pl.col("DateTime").str.strptime(pl.Datetime, format="%Y-%m-%d %H:%M:%S.%f"))
    #     except Exception as e:
    #         raise ValueError(f"转换时间列失败: {e}")
            # print(f"转换时间列失败: {e}")

    # Polars计算分钟均值
    try:
        df_polars_minute_avg = df_polars.group_by_dynamic(
            index_column="DateTime",
            every=timedelta(minutes=1),
            closed="left"
        ).agg([pl.col(col).mean().alias(col) for col in df_polars.columns if col != "DateTime"])
    except Exception as e:
        raise ValueError(f"================计算分钟均值失败:{e}!!!=================")
        # print(f"================计算分钟均值失败:{e}!!!=================")

    return df_polars_minute_avg


# 平滑滤波
def smooth_filter(dataframe_process: pl.DataFrame, window_size: int = 5) -> pl.DataFrame:
    """
    Smooth filter the data in a DataFrame | 简单移动平均(SMA)
    Args:
        dataframe_process (pl.DataFrame): 输入数据
        window_size (int): 滑动窗口的大小
    Returns:
        pl.DataFrame: 平滑后的数据
    Examples:
        >>> dataframe_process = pl.DataFrame({
        ...     'DateTime': ['2024-01-01 00:00:00', '2024-01-01 00:00:01', '2024-01-01 00:00:02'],
        ...     'Value': [1, 2, 3]
        ... })
        >>> smooth_filter(dataframe_process, window_size=5)
        shape: (3, 2)
        ┌─────────────────────┬───────┐
        │ DateTime            ┆ Value │
        │ ---                ┆ ---   │
        │ datetime[μs]       ┆ i64   │
        ╞═════════════════════╪═══════╡
        │ 2024-01-01 00:00:00┆ 1     │
        │ 2024-01-01 00:00:01┆ 2     │
        │ 2024-01-01 00:00:02┆ 3     │
        └─────────────────────┴───────┘
    """
    dataframe_process = dataframe_process.with_columns(
        [pl.col(column).rolling_mean(window_size=window_size, min_periods=1).alias(column)
         for column in dataframe_process.columns if column != "DateTime"]
    )
    return dataframe_process


def weighted_moving_average(
    dataframe_process: pl.DataFrame,
    window_size: int = 5,
    weights: Optional[Sequence[float]] = None
) -> pl.DataFrame:
    """
    Weighted moving average filter | 加权移动平均(WMA)
    Args:
        dataframe_process (pl.DataFrame): Input DataFrame
        window_size (int): Size of the moving window
        weights: 自定义权重序列,默认为None使用线性权重
    Returns:
        pl.DataFrame: Filtered DataFrame with weighted moving average
    Examples:
        >>> dataframe_process = pl.DataFrame({
        ...     'DateTime': ['2024-01-01 00:00:00', '2024-01-01 00:00:01', '2024-01-01 00:00:02'],
        ...     'Value': [1, 2, 3]
        ... })
        >>> weighted_moving_average(dataframe_process, window_size=5)
        shape: (3, 2)
        ┌─────────────────────┬───────┐
        │ DateTime            ┆ Value │
        │ ---                ┆ ---   │
        │ datetime[μs]       ┆ i64   │
        ╞═════════════════════╪═══════╡
        │ 2024-01-01 00:00:00┆ 1     │
        │ 2024-01-01 00:00:01┆ 2     │
        │ 2024-01-01 00:00:02┆ 3     │
        └─────────────────────┴───────┘
    """
    if weights is None:
        weights = np.arange(1, window_size + 1)
        weights = weights / weights.sum()
    
    dataframe_process = dataframe_process.with_columns(
        [pl.col(column).rolling_mean(
            window_size=window_size,
            weights=weights,
            min_periods=1
        ).alias(column)
         for column in dataframe_process.columns if column != "DateTime"]
    )
    return dataframe_process


def exponential_moving_average(
        dataframe_process: pl.DataFrame, 
        alpha: float = 0.2
) -> pl.DataFrame:
    """
    Exponential moving average filter | 指数移动平均(EMA)
    Args:
        dataframe_process (pl.DataFrame): Input DataFrame
        alpha (float): Smoothing factor (0 < alpha < 1)
    Returns:
        pl.DataFrame: Filtered DataFrame with exponential moving average
    Examples:
        >>> dataframe_process = pl.DataFrame({
        ...     'DateTime': ['2024-01-01 00:00:00', '2024-01-01 00:00:01', '2024-01-01 00:00:02'],
        ...     'Value': [1, 2, 3]
        ... })
        >>> exponential_moving_average(dataframe_process, alpha=0.2)
        shape: (3, 2)
        ┌─────────────────────┬───────┐
        │ DateTime            ┆ Value │
        │ ---                ┆ ---   │
        │ datetime[μs]       ┆ i64   │
        ╞═════════════════════╪═══════╡
        │ 2024-01-01 00:00:00┆ 1     │
        │ 2024-01-01 00:00:01┆ 2     │
        │ 2024-01-01 00:00:02┆ 3     │
        └─────────────────────┴───────┘
    """
    if not 0 < alpha < 1:
        raise ValueError("Alpha must be between 0 and 1")
    
    dataframe_process = dataframe_process.with_columns(
        [pl.col(column).ewm_mean(
            alpha=alpha,
            adjust=True,
            min_periods=1
        ).alias(column)
         for column in dataframe_process.columns if column != "DateTime"]
    )
    return dataframe_process


# 使用Savitzky-Golay 滤波器降噪
def savitzky_golay_filter(
        dataframe_process: pl.DataFrame, 
        window_length: int = 11, 
        polyorder: int = 3
) -> pl.DataFrame:
    """
    使用Savitzky-Golay 滤波器降噪
    window_size对曲线的平滑作用:window size的值越小,曲线越贴近真实曲线;window size值越大,平滑效果越厉害(Note:window size的值必须为奇数)
    polyorder值对曲线的平滑作用:polyorder值越大,曲线越贴近真实曲线;polyorder值越小,曲线平滑越厉害。另外,当polyorder值较大时,受窗口长度限制,拟合Q会出现问题,高频曲线会变成直线。
    Args:
        dataframe_process (pl.DataFrame): Input DataFrame
        window_length (int): 窗口长度
        polyorder (int): 多项式阶数
    Returns:
        pl.DataFrame: Filtered DataFrame with Savitzky-Golay filter
    Examples:
        >>> dataframe_process = pl.DataFrame({
        ...     'DateTime': ['2024-01-01 00:00:00', '2024-01-01 00:00:01', '2024-01-01 00:00:02'],
        ...     'Value': [1, 2, 3]
        ... })
        >>> savitzky_golay_filter(dataframe_process, window_length=11, polyorder=3)
        shape: (3, 2)
        ┌─────────────────────┬───────┐
        │ DateTime            ┆ Value │
        │ ---                ┆ ---   │
        │ datetime[μs]       ┆ i64   │
        ╞═════════════════════╪═══════╡
        │ 2024-01-01 00:00:00┆ 1     │
        │ 2024-01-01 00:00:01┆ 2     │
        │ 2024-01-01 00:00:02┆ 3     │
        └─────────────────────┴───────┘
    """
    # 创建一个空dataframe
    data_clean = pl.DataFrame()
    # 获取DataFrame的列名
    columns = dataframe_process.columns
    if "DateTime" in columns:
        columns.remove("DateTime")
    for column in columns:
        filtered_data = savgol_filter(
            dataframe_process[column].to_numpy(),
            window_length=window_length,
            polyorder=polyorder
        )
        data_clean = data_clean.with_columns(pl.Series(name=column, values=filtered_data))
    print("Savitzky-Golay 滤波器降噪完成!!!")
    return data_clean


# 基于fft的降噪
def fft_filter(dataframe_process: pl.DataFrame) -> pl.DataFrame:
    """
    基于fft的降噪
    Args:
        dataframe_process (pl.DataFrame): 输入数据
    Returns:
        pl.DataFrame: 降噪后的数据
    """
    # 将DataFrame转换为NumPy数组
    data_np = dataframe_process.to_numpy()
    # 使用FFT进行降噪
    data_np = np.fft.fft2(data_np)
    # 将NumPy数组转换回DataFrame
    dataframe_process = pl.from_numpy(data_np)

    return dataframe_process


# Function for padding the data
def pad_data(
        data: np.ndarray, 
        pad_width: int, 
        mode: str = 'edge'
) -> np.ndarray:
    """
    填充数据,用于小波降噪
    Args:
        data (np.ndarray): 输入数据
        pad_width (int): 填充宽度
        mode (str): 填充模式
    Returns:
        np.ndarray: 填充后的数据
    """
    return np.pad(data, pad_width, mode=mode)


# Wavelet denoising function with parameterisation for wavelet type and decomposition level
def wavelet_denoising(
    data: pl.DataFrame,
    wavelet: str = 'db4',
    level: int = 1
) -> pl.DataFrame:
    """
    小波降噪
    Args:
        data (pl.DataFrame): 输入数据
        wavelet (str): 小波类型
        level (int): 分解层数
    Returns:
        pl.DataFrame: 降噪后的数据
    Examples:
        >>> wavelet_denoising(data, wavelet='db4', level=1)
    """
    data = data.to_numpy()
    # Padding with a width of 100
    padded_data = pad_data(data, pad_width=100, mode='edge')
    # Decompose signal using Wavelet Transform
    coeff = pywt.wavedec(padded_data, wavelet, mode="per", level=level)
    # Estimate the noise level
    sigma = (1 / 0.6745) * np.median(np.abs(coeff[-level] - np.median(coeff[-level])))
    # Calculate the universal threshold
    uthresh = sigma * np.sqrt(2 * np.log(len(padded_data)))
    # Apply soft thresholding to detail coefficients
    coeff[1:] = [pywt.threshold(i, value=uthresh, mode='soft') for i in coeff[1:]]
    # Set high-frequency coefficients to zero
    coeff[-level] = np.zeros_like(coeff[-level])
    # Reconstruct the denoised signal
    denoised_data = pywt.waverec(coeff, wavelet, mode='per')
    # Remove the padding
    denoised_data = denoised_data[100:-100]  # Adjust this if necessary

    # Handle edge effects
    if len(denoised_data) > len(data):
        denoised_data = denoised_data[:len(data)]
    elif len(denoised_data) < len(data):
        denoised_data = np.pad(denoised_data, (0, len(data) - len(denoised_data)), 'edge')

    denoised_dataframe = pl.from_numpy(denoised_data)
    return denoised_dataframe


def check_device_status(
    dataframe_check: pl.DataFrame,
    column_name: Union[str, List[str]],
    duration: int = 5
) -> bool:
    """
    根据给定的时间长度判断 DataFrame 中 '喂料量' 或 '给料机' 列的最新数据的均值是否大于 10。
    
    Args:
        dataframe_check (pl.DataFrame): 包含360*n数据的 DataFrame。
        column_name (str): 包含"喂料量"或者“给料机”的列名。
        duration (int): 用于计算均值的时间长度,以分钟为单位。

    Returns:
        bool: 如果均值大于 10 则返回 True,否则返回 False。
    """
    # print(f"==========检测{column_name}运行状态=============")
    # print(f"dataframe_check:{dataframe_check}")

    if isinstance(column_name, str):
        # 假设时间列是 datetime 类型的,首先对 DataFrame 按时间列进行排序
        dataframe_check = dataframe_check.sort(by="DateTime", descending=True)

        # 获取最新的时间点
        latest_time = dataframe_check["DateTime"].max()
        try:
            latest_time = datetime.strptime(str(latest_time), "%Y-%m-%d %H:%M:%S")
        except Exception as e:
            print(f"转换时间失败: {e},尝试转换为%Y-%m-%d %H:%M:%S.%f格式")
            latest_time = datetime.strptime(str(latest_time), "%Y-%m-%d %H:%M:%S.%f")
        # print(f"latest_time:{latest_time}")

        # 计算时间范围
        start_time = latest_time - timedelta(minutes=duration)

        # 筛选出在时间范围内的数据
        recent_data = dataframe_check.filter(pl.col("DateTime").is_between(start_time, latest_time))

        # 计算目标列的均值
        mean_value = recent_data[column_name].mean()
        # print(f"{column_name}的均值为{mean_value}")
        # print(f"=========={column_name}运行状态检测完毕=============")
        
    elif isinstance(column_name, list):
        mean_value_list = []
        for column in column_name:
            # 计算目标列的均值
            # 假设时间列是 datetime 类型的,首先对 DataFrame 按时间列进行排序
            dataframe_check = dataframe_check.sort(by="DateTime", descending=True)

            # 获取最新的时间点
            latest_time = dataframe_check["DateTime"].max()
            try:
                latest_time = datetime.strptime(str(latest_time), "%Y-%m-%d %H:%M:%S")
            except Exception as e:
                print(f"转换时间失败: {e},尝试转换为%Y-%m-%d %H:%M:%S.%f格式")
                latest_time = datetime.strptime(str(latest_time), "%Y-%m-%d %H:%M:%S.%f")
            # print(f"latest_time:{latest_time}")

            # 计算时间范围
            start_time = latest_time - timedelta(minutes=duration)

            # 筛选出在时间范围内的数据
            recent_data = dataframe_check.filter(pl.col("DateTime").is_between(start_time, latest_time))

            # 计算目标列的均值
            mean_value_list.append(recent_data[column_name].mean())
        
        mean_value = np.mean(mean_value_list)
    # 判断均值是否大于 10
    return mean_value > 10


def filter_feed_columns(dataframe_filter: pl.DataFrame) -> pl.DataFrame:
    """
    从DataFrame中筛选出包含“喂料量”或“给料机”的列,并过滤出该列值大于等于10的行。
    
    Args:
        dataframe_filter (pl.DataFrame): 需要筛选的DataFrame。
    
    Returns:
        pl.DataFrame: 筛选后的DataFrame,包含原始DataFrame中所有列,但只保留“喂料量”或“给料机”列值大于等于10的行。
    
    Raises:
        ValueError: 如果DataFrame中没有包含“喂料量”或“给料机”的列时,将引发此异常。
    """
    # 找出包含“喂料量”或者“给料机”的列名
    feed_columns = [col for col in dataframe_filter.columns if "喂料量" in col or "给料机" in col]

    if not feed_columns:
        raise ValueError("DataFrame does not contain any columns with '喂料量' or '给料机'")

    # 假设我们只处理找到的第一个符合条件的列
    feed_column = feed_columns[0]

    # 过滤掉值小于10的行
    filtered_df = dataframe_filter.filter(pl.col(feed_column) >= 10)

    return filtered_df


def optimization_data_process(data_in: pl.DataFrame, time_duration: int) -> pl.DataFrame:
    """
    优化模块中处理历史数据
    Args:
        data_in (pl.DataFrame): 需要转换的pl.DataFrame
        time_duration (int): 保留的时间长度,单位为分钟

    Returns:
        pl.DataFrame: 处理后的pl.DataFrame
    """
    # 如果"DateTime"列不是datetime类型,将第一列转换为时间列
    if not data_in.select(pl.col("DateTime")).dtypes[0] == pl.Datetime:
        try:
            data_in = data_in.with_columns(pl.col("DateTime").cast(pl.Datetime))
        except Exception as e:
            raise ValueError(f"转换时间列失败: {e}")

    data_in = data_in.sort(by="DateTime", descending=False)
    data_resampled = data_in.group_by_dynamic(
        "DateTime", every="1m", closed="left"
    ).agg([pl.all().mean()]).tail(time_duration)
    return data_resampled


# 根据决策长度拼接历史数据和决策数据*决策时长
def data_joint_decision(
    history_data: pl.DataFrame,
    generator_data: pl.DataFrame,
    decision_length: int
) -> pl.DataFrame:
    """根据决策长度拼接历史数据和决策数据。

    Args:
        history_data: 历史数据
        generator_data: 新生成的随机数据
        decision_length: 决策长度

    Returns:
        拼接后的数据

    Raises:
        AssertionError: 当输入不是pl.DataFrame类型时
    """
    assert type(history_data) is pl.DataFrame and type(generator_data) is pl.DataFrame, "history_data和generator_data必须是pl.DataFrame类型"
    
    # 取generator_data的列名和history_data的列名的交集进行拼接
    generator_data_columns = generator_data.columns
    history_data_columns = history_data.columns
    common_columns = set(generator_data_columns) & set(history_data_columns)
    
    # 按照决策长度拼接
    generator_data = pl.concat([generator_data] * decision_length, how="vertical")
    joint_data = pl.concat([history_data.select(common_columns), generator_data.select(common_columns)], how="vertical")

    # 去除包含null的列
    non_null_columns = [s.name for s in joint_data if s.null_count() == 0]
    df_no_null_cols = joint_data.select(non_null_columns)

    return df_no_null_cols


# 检测csv_path路径的历史数据的最新时间和当前时间的差值
def check_time_difference(csv_path: str) -> Tuple[bool, datetime]:
    """
    检测csv_path路径的历史数据的最新时间和当前时间的差值

    Args:
        csv_path: 历史数据的路径
    
    Returns:
        bool: 如果时间差值大于7天,返回True,否则返回False
        latest time: csv文件的最新时间, datetime类型,提供给sql函数查询csv文件中缺失时间的数据
    """
    # 读取csv文件
    dataframe_check = pl.read_csv(csv_path)
    # 将第一列转换为时间列
    if not dataframe_check.select(pl.col("DateTime")).dtypes[0] == pl.Datetime:
        try:
            dataframe_check = dataframe_check.with_columns(pl.col("DateTime").cast(pl.Datetime))
        except Exception as e:
            raise ValueError(f"转换时间列失败: {e}")
    # 按时间列进行排序
    dataframe_check = dataframe_check.sort(by="DateTime", descending=False)
    # 获取最新时间
    latest_time = dataframe_check["DateTime"][0]
    # 获取当前时间
    current_time = datetime.now()
    # 计算时间差值
    time_difference = current_time - latest_time
    # 如果time_difference大于7天,返回True,否则返回False
    return time_difference > timedelta(days=7), latest_time


def transform_predict_data(df: pl.DataFrame) -> pl.DataFrame:
    """
    将transformer模型预测输出存储在数据库中的数据转换为输入软测量模型中的数据
    处理包含多组true/predict列的Polars DataFrame

    Args:
        df: 输入的DataFrame,包含DateTime和多组*_true/*_predict列

    Returns:
        处理后的DataFrame,包含DateTime和所有合并后的列
    """
    # 获取所有列名
    columns = df.columns

    # 找出所有的true/predict列对
    pairs: List[Tuple[str, str]] = []
    for col in columns:
        if col.endswith('_true'):
            prefix = col[:-5]  # 去掉_true后缀
            predict_col = f"{prefix}_predict"
            if predict_col in columns:
                pairs.append((col, predict_col))

    # 处理每一对列
    merged_expressions = []
    for true_col, predict_col in pairs:
        # 提取前缀作为新列名
        new_col_name = true_col[:-5]  # 去掉_true后缀

        # 创建合并表达式
        merged_expr = (
            pl.when(pl.col(true_col).is_null())
            .then(pl.col(predict_col))
            .otherwise(pl.col(true_col))
            .alias(new_col_name)
        )
        merged_expressions.append(merged_expr)

    # 构建结果DataFrame
    result = df.with_columns(merged_expressions)

    # 只保留DateTime和合并后的列
    keep_columns = ["DateTime"] + [pair[0][:-5] for pair in pairs]
    result = result.select(keep_columns)

    return result


def calculate_predict_index(row: pl.DataFrame) -> Tuple[datetime, float]:
    """计算预测指标。

    Args:
        row: 包含真实值和预测值的数据行

    Returns:
        时间戳和预测指标值的元组
    """
    if row['真实值'] == 0:
        predict_index = 0.0
    else:
        if (abs(row['真实值'] - row['AI预测值']) / abs(row['真实值'])) > 1:
            predict_index = 0.0
        else:
            predict_index = 1.0 - (abs(row['真实值'] - row['AI预测值']) / abs(row['真实值']))
    predict_index = predict_index * 100
    return row['DateTime'], predict_index


def vstack_with_fill(
        df1: pl.DataFrame, 
        df2: pl.DataFrame, 
        default_num: int = 0, 
        default_str: str = "0"
    ) -> pl.DataFrame:
    """
    垂直拼接两个DataFrame,自动处理缺失列并填充默认值

    Args:
        df1: 第一个DataFrame
        df2: 第二个DataFrame
        default_num: 数值类型列的默认值
        default_str: 字符串类型列的默认值

    Returns:
        拼接后的DataFrame
    
    Examples:
        >>> vstack_with_fill(df1, df2)
    """
    # 获取所有唯一列名
    all_columns = list(set(df1.columns) | set(df2.columns))

    # 处理df1缺失的列
    df1_missing = set(all_columns) - set(df1.columns)
    df1_extended = df1
    for col in df1_missing:
        col_type = df2.schema[col]
        if str(col_type) in ["Int64", "Int32", "Int16", "Int8", "Float64", "Float32"]:
            df1_extended = df1_extended.with_columns(pl.lit(default_num).cast(col_type).alias(col))
        else:
            df1_extended = df1_extended.with_columns(pl.lit(default_str).alias(col))

    # 处理df2缺失的列
    df2_missing = set(all_columns) - set(df2.columns)
    df2_extended = df2
    for col in df2_missing:
        col_type = df1.schema[col]
        if str(col_type) in ["Int64", "Int32", "Int16", "Int8", "Float64", "Float32"]:
            df2_extended = df2_extended.with_columns(pl.lit(default_num).cast(col_type).alias(col))
        else:
            df2_extended = df2_extended.with_columns(pl.lit(default_str).alias(col))

    # 确保两个DataFrame具有相同的列顺序
    df1_extended = df1_extended.select(all_columns)
    df2_extended = df2_extended.select(all_columns)

    # 垂直拼接
    result = pl.concat([df1_extended, df2_extended], how="vertical")

    return result


def add_datetime_column(
    df: pl.DataFrame,
    datetime_col_name: str = "DateTime",
    mode: str = "backward"
) -> pl.DataFrame:
    """
    在Polars DataFrame的第一列位置添加一个DateTime列
    时间从当前开始往前推，每行间隔1分钟
    
    Args:
        df: 输入的Polars DataFrame
        datetime_col_name: 新添加的时间列的列名，默认为'DateTime'
        mode: 时间序列模式，为'backward'|'forward'，表示从当前时间开始往前推，还是从当前时间开始往后推
    
    Returns:
        添加了DateTime列的新DataFrame
    
    Examples:
        >>> df = pl.DataFrame({'A': [1, 2, 3], 'B': ['a', 'b', 'c']})
        >>> add_datetime_column(df)
        shape: (3, 3)
        ┌──────────────┬─────┬─────┐
        │ DateTime      ┆ A   ┆ B   │
        │ ---           ┆ --- ┆ --- │
        │ datetime[μs] ┆ i64 ┆ str │
        ╞══════════════╪═════╪═════╡
        │ 2024-11-25 14:00:00 ┆ 1   ┆ a   │
        │ 2024-11-25 14:01:00 ┆ 2   ┆ b   │
        │ 2024-11-25 14:02:00 ┆ 3   ┆ c   │
        └─────────────────────┴─────┴─────┘
    """
    # 获取行数
    n_rows = len(df)
    
    # 生成时间序列
    now = datetime.now().replace(second=0, microsecond=0)
    if mode == "backward":
        datetime_list = [now - timedelta(minutes=i) for i in range(n_rows)]
    elif mode == "forward":
        datetime_list = [now + timedelta(minutes=i+1) for i in range(n_rows)]
    
    # 创建时间序列并排序
    datetime_series = pl.Series(datetime_col_name, datetime_list)
    datetime_series = datetime_series.sort()

    # 将新列添加到DataFrame的最前面
    new_df = pl.DataFrame([datetime_series]).hstack(df)
    
    return new_df


def duplicate_filter(
    df: pl.DataFrame, 
    n: int = 60,
    subset: Optional[list[str]] = None
) -> pl.DataFrame:
    """Remove rows where values in specified columns are repeated more than n times consecutively.
    
    Args:
        df: Input DataFrame
        n: Maximum number of allowed consecutive duplicates (default: 30)
        subset: List of column names to check for duplicates. If None, all columns are used.
    
    Returns:
        pl.DataFrame: DataFrame with filtered rows where consecutive duplicates are limited to n
    Examples:
        >>> df = pl.DataFrame({
        ...     'A': [1, 1, 1, 1, 2, 2, 3],
        ...     'B': ['a', 'a', 'a', 'b', 'b', 'c', 'c']
        ... })
        >>> duplicate_filter(df, n=2)
        shape: (5, 2)
        ┌─────┬─────┐
        │ A   ┆ B   │
        │ --- ┆ --- │
        │ i64 ┆ str │
        ╞═════╪═════╡
        │ 1   ┆ a   │
        │ 1   ┆ a   │
        │ 2   ┆ b   │
        │ 2   ┆ b   │
        │ 3   ┆ c   │
        └─────┴─────┘
    """
    if subset is None:
        subset = df.columns
    else:
        # 检查subset中的列是否在df中,如果不在，则抛出错误
        for col in subset:
            if col not in df.columns:
                raise ValueError(f"Column '{col}' not found in DataFrame columns")
    
    # 创建一个布尔掩码来标记要保留的行
    mask = pl.Series([True] * len(df))
    
    for col in subset:
        # 计算每个值与其前一个值是否相同
        values = df[col].to_numpy()
        # 使用列表推导式创建布尔值列表，并显式转换为布尔类型
        is_same_list = [False] + [bool(values[i] == values[i-1]) for i in range(1, len(values))]
        # is_same = pl.Series(is_same_list, dtype=pl.Boolean)
        
        # 计算连续重复的计数
        counts = [0]  # 初始值
        current_count = 0
        
        # 计算连续重复次数
        for i in range(1, len(is_same_list)):
            if is_same_list[i]:
                current_count += 1
            else:
                current_count = 0
            counts.append(current_count)
        
        # 更新掩码，标记需要删除的行（连续重复次数超过n的行）
        counts_series = pl.Series(counts)
        mask = mask & (counts_series < n)
    
    # 应用掩码过滤数据
    return df.filter(mask)


# 监测时间间隔，划分生产周期
def detect_production_periods(
        df: pl.DataFrame, 
        max_gap: timedelta = timedelta(hours=2)
    ) -> pl.DataFrame:
    """Monitor time intervals and divide into production periods.

    Args:
        df: DataFrame containing a DateTime column
        max_gap: Maximum allowed time gap before considering it a new production period

    Returns:
        pl.DataFrame: DataFrame with original columns plus a production_period column
        indicating different production cycles (0-based index)

    Examples:
        >>> df = pl.DataFrame({
        ...     'DateTime': [datetime(2024, 1, 1, 0, 0), 
        ...                  datetime(2024, 1, 1, 0, 1), 
        ...                  datetime(2024, 1, 1, 3, 0), # 3-hour gap
        ...                  datetime(2024, 1, 1, 3, 1)]
        ... })
        >>> result = detect_production_periods(df, max_gap=timedelta(hours=2))
        >>> print(result)
        shape: (4, 2)
        ┌─────────────────────┬──────────────────┐
        │ DateTime            ┆ production_period │
        │ ---                 ┆ ---              │
        │ datetime[μs]        ┆ i32              │
        ╞═════════════════════╪══════════════════╡
        │ 2024-01-01 00:00:00 ┆ 0                │
        │ 2024-01-01 00:01:00 ┆ 0                │
        │ 2024-01-01 03:00:00 ┆ 1                │
        │ 2024-01-01 03:01:00 ┆ 1                │
        └─────────────────────┴──────────────────┘
        >>> df = pl.read_csv("resource/datasets/二线回转窑电耗样本/data_in.csv")
        >>> result = detect_production_periods(df)
        >>> print(result)
        shape: (4_517_959, 18)
        ┌───────────┬───────────┬──────────┬──────────┬───┬──────────┬──────────┬──────────┬──────────┐
        │ DateTime  ┆ 高温风机  ┆ 一级筒O2 ┆ 一级筒CO ┆ … ┆ 吨熟料实 ┆ 窑系统单 ┆ 喂料量反 ┆ producti │
        │ ---       ┆ 电流反馈  ┆ 反馈     ┆ 反馈     ┆   ┆ 物煤耗   ┆ 位电耗   ┆ 馈       ┆ on_perio │
        │ datetime[ ┆ ---       ┆ ---      ┆ ---      ┆   ┆ ---      ┆ ---      ┆ ---      ┆ d        │
        │ μs]       ┆ f64       ┆ f64      ┆ f64      ┆   ┆ f64      ┆ f64      ┆ f64      ┆ ---      │
        │           ┆           ┆          ┆          ┆   ┆          ┆          ┆          ┆ i32      │
        ╞═══════════╪═══════════╪══════════╪══════════╪═══╪══════════╪══════════╪══════════╪══════════╡
        │ 2023-04-0 ┆ null      ┆ 2.491836 ┆ 1151.120 ┆ … ┆ null     ┆ null     ┆ 422.8573 ┆ 0        │
        │ 1 00:00:0 ┆           ┆          ┆ 972      ┆   ┆          ┆          ┆          ┆          │
        │ 3.130     ┆           ┆          ┆          ┆   ┆          ┆          ┆          ┆          │
        │ 2023-04-0 ┆ 263.11880 ┆ null     ┆ null     ┆ … ┆ 144.9600 ┆ 0.0      ┆ null     ┆ 0        │
        │ 1 00:00:0 ┆ 5         ┆          ┆          ┆   ┆ 07       ┆          ┆          ┆          │
        │ 3.133     ┆           ┆          ┆          ┆   ┆          ┆          ┆          ┆          │
        │ 2023-04-0 ┆ 258.53891 ┆ 2.488892 ┆ 1206.887 ┆ … ┆ 144.9600 ┆ 0.0      ┆ 422.7954 ┆ 0        │
        │ 1 00:00:1 ┆           ┆          ┆ 939      ┆   ┆ 07       ┆          ┆ 1        ┆          │
        │ 3.133     ┆           ┆          ┆          ┆   ┆          ┆          ┆          ┆          │
        │ 2023-04-0 ┆ 261.89111 ┆ 2.46092  ┆ 1248.343 ┆ … ┆ 144.9600 ┆ 0.0      ┆ 422.7865 ┆ 0        │
        │ 1 00:00:2 ┆ 3         ┆          ┆ 994      ┆   ┆ 07       ┆          ┆ 91       ┆          │
        │ 3.123     ┆           ┆          ┆          ┆   ┆          ┆          ┆          ┆          │
        │ 2023-04-0 ┆ 260.73550 ┆ 2.446689 ┆ 1279.730 ┆ … ┆ 144.9600 ┆ 0.0      ┆ 422.9103 ┆ 0        │
        │ 1 00:00:3 ┆ 4         ┆          ┆ 957      ┆   ┆ 07       ┆          ┆ 09       ┆          │
        │ 3.130     ┆           ┆          ┆          ┆   ┆          ┆          ┆          ┆          │
        │ …         ┆ …         ┆ …        ┆ …        ┆ … ┆ …        ┆ …        ┆ …        ┆ …        │
        │ 2024-10-1 ┆ 239.21409 ┆ 9.277139 ┆ 296.6059 ┆ … ┆ 68.25670 ┆ 27.92998 ┆ 360.1687 ┆ 31       │
        │ 1 23:59:1 ┆ 6         ┆          ┆ 88       ┆   ┆ 6        ┆ 9        ┆ 01       ┆          │
        │ 8.960     ┆           ┆          ┆          ┆   ┆          ┆          ┆          ┆          │
        │ 2024-10-1 ┆ 241.00160 ┆ 7.952172 ┆ 290.7172 ┆ … ┆ 68.25670 ┆ 27.92998 ┆ 360.1863 ┆ 31       │
        │ 1 23:59:2 ┆ 2         ┆          ┆ 85       ┆   ┆ 6        ┆ 9        ┆ 1        ┆          │
        │ 8.940     ┆           ┆          ┆          ┆   ┆          ┆          ┆          ┆          │
        │ 2024-10-1 ┆ 238.25120 ┆ 6.914772 ┆ 296.7237 ┆ … ┆ 68.25670 ┆ 27.92998 ┆ 360.1774 ┆ 31       │
        │ 1 23:59:3 ┆ 5         ┆          ┆ 85       ┆   ┆ 6        ┆ 9        ┆ 9        ┆          │
        │ 8.937     ┆           ┆          ┆          ┆   ┆          ┆          ┆          ┆          │
        │ 2024-10-1 ┆ 238.17900 ┆ 6.058941 ┆ 298.9614 ┆ … ┆ 68.25670 ┆ 27.92998 ┆ 360.1068 ┆ 31       │
        │ 1 23:59:4 ┆ 1         ┆          ┆ 87       ┆   ┆ 6        ┆ 9        ┆ 12       ┆          │
        │ 8.950     ┆           ┆          ┆          ┆   ┆          ┆          ┆          ┆          │
        │ 2024-10-1 ┆ 236.90310 ┆ 5.355237 ┆ 306.4991 ┆ … ┆ 68.25670 ┆ 27.92998 ┆ 360.1156 ┆ 31       │
        │ 1 23:59:5 ┆ 7         ┆          ┆ 15       ┆   ┆ 6        ┆ 9        ┆ 92       ┆          │
        │ 8.943     ┆           ┆          ┆          ┆   ┆          ┆          ┆          ┆          │
        └───────────┴───────────┴──────────┴──────────┴───┴──────────┴──────────┴──────────┴──────────┘
    """
    # 将DateTime列转换为时间戳
    # 判断DateTime列是否为pl.Datetime类型，如果不是，则转换为pl.Datetime类型
    if df["DateTime"].dtype != pl.Datetime:
        try:
            df = df.with_columns(pl.col("DateTime").str.strptime(pl.Datetime, format="%Y-%m-%dT%H:%M:%S%.f"))
        except Exception as e:
            print(f"处理DateTime列失败:{e}")
    print(f"dataframe to detect production periods:{df}")
            
    # Calculate time differences
    df_with_diffs = df.with_columns([
        pl.col("DateTime").diff().alias("time_diff")
    ])
    
    # Create period changes (True when gap exceeds max_gap)
    df_with_changes = df_with_diffs.with_columns([
        (pl.col("time_diff") > pl.duration(nanoseconds=int(max_gap.total_seconds() * 1e9)))
        .cast(pl.Int32)
        .alias("period_change")
    ])
    
    # Calculate cumulative sum for period IDs
    result = df_with_changes.with_columns([
        pl.col("period_change").fill_null(0).cum_sum().alias("production_period")
    ]).select([
        pl.all().exclude(["time_diff", "period_change", "production_period"]),
        pl.col("production_period")
    ])
    
    return result


# 缺失数据插补
def missing_data_interpolation(df: pl.DataFrame) -> pl.DataFrame:
    """
    缺失数据插补,主要包含输入、输出数据
    Args:
        df: 输入的DataFrame, 第一列为DateTime
    Returns:
        pl.DataFrame: 插补后的DataFrame
    Examples:
        >>> df = pl.DataFrame({
        ...     'DateTime': [datetime(2024, 1, 1, 0, 0), 
        ...                  datetime(2024, 1, 1, 0, 1), 
        ...                  datetime(2024, 1, 1, 0, 4), # 3-minute gap
        ...                  datetime(2024, 1, 1, 0, 5)],
        ...     'A': [1, 2, 4, 5]
        ... })
        >>> result = missing_data_interpolation(df)
        >>> print(result)
        shape: (4, 2)
        ┌─────────────────────┬──────────────────┐
        │ DateTime            ┆ production_period │
        │ ---                 ┆ ---              │
        │ datetime[μs]        ┆ i32              │
        ╞═════════════════════╪══════════════════╡
        │ 2024-01-01 00:00:00 ┆ 0                │
        │ 2024-01-01 00:01:00 ┆ 1                │
        │ 2024-01-01 00:02:00 ┆ 2                │
        │ 2024-01-01 00:03:00 ┆ 3                │
        │ 2024-01-01 00:04:00 ┆ 4                │
        │ 2024-01-01 00:05:00 ┆ 5                │
        └─────────────────────┴──────────────────┘
    """
    if "TagTime" in df.columns:
        print("TagTime is not support!!!")
        return df
    else:
        pass

