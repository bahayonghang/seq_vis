import datetime
import pyodbc
import re
import time

import numpy as np
import polars as pl

from typing import Tuple

from industrytslib.utils.database.base import Database
from industrytslib.utils.logutils import get_logger
from industrytslib.utils.basefunc import prediction_parameter_parser, name_list_parser
from industrytslib.utils.data_processing.polarsoperation import optimization_data_process



class MSSQLConnection(Database):
    def __init__(self, config: dict) -> None:
        self.config = config
        self.logger = get_logger("MSSQL", "database")

        self.server = self.config['server']
        self.username = self.config['username']
        self.password = self.config['password']
        self.database = self.config['database']

        # Set the maximum number of retries and the delay between retries
        self.max_retries = 9999
        self.retry_delay = 60  # seconds

        self.connect_db()

    def connect(self) -> None:
        """
        connect to mssql database
        """
        # self.connection = pyodbc.connect(
        #     f'DRIVER=ODBC Driver 18 for SQL Server;SERVER={self.server};DATABASE={self.database};UID={self.username};PWD={self.password};TrustServerCertificate=yes;'
        # )
        self.connection = pyodbc.connect(
            f'DRIVER=ODBC Driver 17 for SQL Server;SERVER={self.server};DATABASE={self.database};UID={self.username};PWD={self.password};TrustServerCertificate=yes;'
        )
        self.cursor = self.connection.cursor()
        self.logger.info(f"Connect to {self.server} {self.database} as {self.username} Successfully!")
        
    def connect_db(self) -> None:
        """
        pipline of connect to mssql database, including error handling and retry
        """
        for attempt in range(self.max_retries):
            try:
                self.connect()
                self.logger.info(f"username: {self.username}, password: {self.password} | 连接{self.server}数据库成功")
                self.max_retries = 9999
                return
            except pyodbc.Error as e:
                self.logger.warning(f"username: {self.username}, password: {self.password}, Database: {self.database} | 连接{self.server}尝试 {attempt + 1} 失败: {str(e)}")
                if attempt < self.max_retries - 1:
                    self.logger.info(f"等待 {self.retry_delay} 秒后重试...")
                    time.sleep(self.retry_delay)
                else:
                    self.logger.error(f"username: {self.username}, password: {self.password}, Database: {self.database} | 无法连接到{self.server}数据库，已达到最大重试次数!")
                    raise Exception(f"username: {self.username}, password: {self.password}, Database: {self.database} | 无法连接到{self.server}数据库，已达到最大重试次数!") from e
                
    def close(self) -> None:
        """
        close the connection to the database
        """
        self.cursor.close()
        self.connection.close()
        self.logger.info("数据库连接已关闭!")

    # 判断数据库中表/视图是否存在
    def is_table_exist(self, table_name: str) -> bool:
        """
        check if the table/view exists in the database
        Args:
            table_name (str): the name of the table/view
        Returns:
            bool: True if the table/view exists, False otherwise
        """
        table_exist_sql = f"""
            SELECT *
            FROM sys.objects
            WHERE object_id = OBJECT_ID('{table_name}')
        """
        self.cursor.execute(table_exist_sql)
        return self.cursor.fetchone() is not None

    def query(self, sql: str) -> pl.DataFrame:
        """
        query the data from the database
        Args:
            sql (str): the sql query
        Returns:
            pl.DataFrame: the data from the database
        """
        self.cursor.execute(sql)
        rows = self.cursor.fetchall()
        columns = [column[0] for column in self.cursor.description]
        df = pl.DataFrame({col: [row[i] for row in rows] for i, col in enumerate(columns)})
        return df


class MSSQLWeb(MSSQLConnection):
    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self.logger = get_logger("MSSQLWeb", "database")

    def get_prediction_info(self, project_name: str) -> Tuple[str, str]:
        """
        Get the prediction info of project name in table yunxing
        return:
            sample_name: sample name
            algorithm_name: algorithm name
        """
        sql_prediction_info = f"SELECT * FROM yunxing WHERE sampletable_name = '{project_name}'"
        rows = self.query(sql_prediction_info)
        sample_name = rows["yangben"].to_list()[0]
        model_name = rows["moxing"].to_list()[0]
        self.logger.info(f"Sample name: {sample_name}, algorithm name: {model_name}")
        return sample_name, model_name 

    def get_model_parameter(self, model_name: str) -> Tuple[str, dict]:
        """Get the parameter of the model

        Args:
            model_name (str): model name

        Returns:
            pd.DataFrame: model parameter
        """
        sql = f"select * from algoone where project_name='{model_name}'"
        rows = self.query(sql)

        algorithm_name = rows["model_name"].to_list()[0]  # TODO 这里数据库列名和实际含义不匹配,需要修改数据库

        parameter_str = rows["parameter"].to_list()[0]
        parameter = prediction_parameter_parser(parameter_str)
        self.logger.info(f"The parameter of model {model_name} is: {parameter}")
        return algorithm_name, parameter
    
    # Get sample table information from web database.
    def get_sample_table_information(self, sample_name) -> pl.DataFrame:
        """
        从Web数据库获取样本表信息。

        Args:
            sample_name (str): 样本名称，用于查询对应的样本表信息。

        Returns:
            pl.DataFrame: 包含样本数据时间范围信息的pandas DataFrame对象。

        """
        sql_time_range = f"SELECT * FROM [dbo].[sampletablezong] WHERE sample_table='{sample_name}'"
        sample_table_info = self.query(sql_time_range)
        self.logger.info(f"sample table information of {sample_name}: {sample_table_info}")
        return sample_table_info
    
    def _get_sample_table_input_name(self, sample_name: str) -> list:
        """Get the input name of sample table.
        Args:
            sample_name (str): Sample name.
        Returns:
            list: Input names of sample table.
        """
        sample_table_info = self.get_sample_table_info(sample_name)
        input_name_str = sample_table_info["column_namein"][0]
        input_name_list = name_list_parser(input_name_str)
        return input_name_list

    # optimization information
    def get_optimization_info(self, project_name: str) -> tuple[pl.DataFrame, pl.DataFrame, list, list, list]:
        """Get the optimization information of project name in table optimization
        return:
            optimization_arguments: 优化模型使用的参数
            optimization_constraints: 优化模型使用的约束
            optimization_prediction_model: 优化模型使用的预测模型列表
            input_name_list: 优化模型使用的输入变量列表
        """
        # 1. get optimization arguments
        sql_optimization_arguments = f"SELECT * FROM [dbo].[optimization] WHERE optimization_project_name='{project_name}'"
        optimization_arguments = self.query(sql_optimization_arguments)
        self.logger.info(f"optimization arguments of {project_name}: {optimization_arguments}")

        # 2. get optimization constraints
        sql_optimization_constraints = f"SELECT bianliang FROM [dbo].[optimization] WHERE optimization_project_name='{project_name}'"
        constraints_rows = self.query(sql_optimization_constraints)
        constraints_str = constraints_rows["bianliang"].to_list()[0]
        # 使用正则表达式提取数据
        pattern = re.compile(r'([^, ]+?): min: (-?\d+\.?\d*) max: (-?\d+\.?\d*)', re.UNICODE)
        constraint_data = []
        for match in pattern.finditer(constraints_str):
            name, min_val, max_val = match.groups()
            constraint_data.append({
                'variable': name,
                'min': float(min_val),
                'max': float(max_val)
            })
        optimization_constraints = pl.DataFrame(constraint_data)
        self.logger.info(f"optimization constraints of {project_name}: {optimization_constraints}")

        # get prediction model used by optimization 
        optimization_prediction_model = optimization_arguments["prediction_model"].to_list()[0].split(',')
        prediction_model_table_list = []  # 预测模型的样本表名
        prediction_model_list = []  # 预测模型的模型名
        for i in optimization_prediction_model:
            prediction_model_table_list.append(i.split('_')[0].strip())
            prediction_model_list.append(i.split('_')[1] + '_' + i.split('_')[2])

        # 根据预测模型的样本表名获取要用到的变量名
        input_name_list = []
        for sample_name in prediction_model_table_list:
            input_name = self._get_sample_table_input_name(sample_name)
            input_name_list.append(input_name)

        self.logger.info(f"input name of {project_name}: {input_name_list}")
        return optimization_arguments, optimization_constraints, prediction_model_table_list, prediction_model_list, input_name_list


class MSSQLTimeSeries(MSSQLConnection):
    """
    MSSQL Library for Get realtime data and history data from controller database
    """
    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self.logger = get_logger("MSSQLTimeSeries", "database")

    def get_feed_amount_column_name(self, table_name: str) -> str:
        """
        Get feed amount column name

        Args:
            table_name (str): table name

        Returns:
            str: feed amount column name
        """
        sql = f"SELECT TOP (1) * FROM {table_name} " \
              f"WHERE (DateTime BETWEEN SUBSTRING(CONVERT(varchar, DATEADD(hour, - 2, GETDATE()), 120), 1, 16) AND " \
              f"SUBSTRING(CONVERT(varchar, DATEADD(hour, +1, GETDATE()), 120), 1, 16))" \
              f"ORDER BY DateTime DESC"
        self.cursor.execute(sql)
        columns = [column[0] for column in self.cursor.description]
        self.logger.info(f"Columns: {columns}")
        # 找到包含 '喂料量' 或 '给料机' 的列名
        target_column = None
        for col in columns:
            if '喂料量' in col or '给料机' in col:
                target_column = col
                self.logger.info(f"找到包含 '喂料量' 或 '给料机' 的列名: {target_column}")
                break

        if not target_column:
            raise ValueError("DataFrame 中未找到包含 '喂料量' 或 '给料机' 的列名")

        return target_column
    
    def get_latest_input_data(self, table_name: str) -> pl.DataFrame:
        """
        Get realtime data of latest 1 hour

        Args:
            table_name (str): table name

        Returns:
            pl.DataFrame: realtime data
        """
        sql = f"SELECT TOP 360 * FROM {table_name} " \
              f"WHERE (DateTime BETWEEN SUBSTRING(CONVERT(varchar, DATEADD(hour, - 2, GETDATE()), 120), 1, 16) AND " \
              f"SUBSTRING(CONVERT(varchar, DATEADD(hour, +1, GETDATE()), 120), 1, 16))" \
              f"ORDER BY DateTime DESC"
        rows = self.query(sql)
        return rows

    def get_latest_input_data_by_column(self, input_name_list: str) -> pl.DataFrame:
        """
        Get realtime data of latest 1 hour by column name list from 历史表
        Args:
            input_name_list (str): column name list
        Returns:
            pl.DataFrame: realtime data
        """
        name_list = input_name_list.copy()
        sql = f'''
            SELECT DateTime, TagName, TagVal
            FROM 历史表
            WHERE DateTime BETWEEN DATEADD(HOUR, -2, GETDATE()) AND GETDATE()
            AND TagName IN ('{"', '".join(name_list)}')
            '''
        # print(sql)
        rows = self.query(sql)
        # 先将DateTime列转换为datetime格式
        rows = rows.with_columns(pl.col("DateTime").str.strptime(pl.Datetime))
        # 将第一列DateTime约束到秒
        rows = rows.with_columns(pl.col("DateTime").dt.truncate('1s'))
        # 去除null
        rows = rows.drop_nulls()
        
        rows_pivot = rows.pivot(index="DateTime", on="TagName", values="TagVal")
        rows_pivot = self._remove_column_space(rows_pivot)
        # 先在input_name_list首位加入DateTime
        name_list.insert(0, "DateTime")
        rows_pivot = rows_pivot[name_list]
        return rows_pivot.tail(360)
    
    # 将pl.DataFrame中列名的的空格去除
    @staticmethod
    def _remove_column_space(df: pl.DataFrame) -> pl.DataFrame:
        df.columns = [col.replace(" ", "") for col in df.columns]
        return df
    
    def get_latest_input_data_by_column_time(self, input_name_list: str, time_length: int) -> pl.DataFrame:
        """
        Get realtime data of latest time_length by column name list from 历史表
        Args:
            input_name_list (str): column name list
            time_length (int): time length
        Returns:
            pl.DataFrame: realtime data
        """
        name_list = input_name_list.copy()
        sql = f'''
            SELECT DateTime, TagName, TagVal
            FROM 历史表
            WHERE DateTime BETWEEN DATEADD(HOUR, -5, GETDATE()) AND GETDATE()
            AND TagName IN ('{"', '".join(name_list)}')
            '''
        # print(sql)
        rows = self.query(sql)

        # 先将DateTime列转换为datetime格式
        rows = rows.with_columns(pl.col("DateTime").str.strptime(pl.Datetime))
        # 将第一列DateTime约束到秒
        rows = rows.with_columns(pl.col("DateTime").dt.truncate('1s'))

        rows_pivot = rows.pivot(index="DateTime", on="TagName", values="TagVal")
        rows_pivot = self._remove_column_space(rows_pivot)
        # 先在input_name_list首位加入DateTime
        name_list.insert(0, "DateTime")
        rows_pivot = rows_pivot[name_list]
        return rows_pivot.tail(time_length)


    def get_latest_true_value(self, table_name: str) -> pl.DataFrame:
        """
        Get true value of latest 1 hour
        
        Args:
            table_name (str): table name

        Returns:
            pl.DataFrame: true value
        """
        sql = f"SELECT TOP (1) * FROM {table_name} " \
              f"WHERE (DateTime BETWEEN SUBSTRING(CONVERT(varchar, DATEADD(hour, - 2, GETDATE()), 120), 1, 16) AND " \
              f"SUBSTRING(CONVERT(varchar, DATEADD(hour, +1, GETDATE()), 120), 1, 16))" \
              f"ORDER BY DateTime DESC"
        rows = self.query(sql)
        return rows

    def get_input_data_train(self, input_table_name: str, begin_time: datetime.datetime, end_time: datetime.datetime) -> pl.DataFrame:
        """
        获取指定时间范围内的输入数据

        Args:
            input_table_name (str): 表名
            begin_time (str): 起始时间
            end_time (str): 结束时间

        Returns:
            pl.DataFrame: 输入数据

        """
        sql = f"SELECT * FROM {input_table_name} WHERE DateTime BETWEEN '{begin_time}' AND '{end_time}' order by DateTime"
        rows = self.query(sql)
        return rows

    def get_input_data_history(self, name_list: list, begin_time: str, end_time: str) -> pl.DataFrame:
        """
        根据name_list获取指定时间范围内的输入数据
        Args:
            name_list (list): 表名列表
            begin_time (str): 起始时间
            end_time (str): 结束时间
        Returns:
            pl.DataFrame: 输入数据
        """
        input_name_list = name_list.copy()
        self.logger.info(f"name_list: {input_name_list}")
        sql = f"""
            select * from [历史表] where TagName in ('{"', '".join(input_name_list)}') and DateTime between '{begin_time}' and '{end_time}' order by DateTime
        """
        self.logger.info(f"query history data sql: {sql}")
        # print(sql)
        rows = self.query(sql)

        # 先将DateTime列转换为datetime格式
        try:
            rows = rows.with_columns(pl.col("DateTime").str.strptime(pl.Datetime))
        except pl.exceptions.SchemaError as e:
            self.logger.error(f"DateTime列已经是datetime格式:{e}")
        # 将第一列DateTime约束到秒
        rows = rows.with_columns(pl.col("DateTime").dt.truncate('1s'))

        # transform rows into standard input table
        df_pivot = rows.pivot(index="DateTime", on="TagName", values="TagVal", aggregate_function="first")
        df_pivot = self._remove_column_space(df_pivot)

        # 将DataFrame按照name_list的顺序排列
        # 先在name_list首位加入DateTime
        input_name_list.insert(0, "DateTime")
        df_pivot = df_pivot[input_name_list]

        self.logger.info(f"transform rows to standard input table successfully: {df_pivot}")
        return df_pivot

    def get_output_data_train(self, output_table_name: str, begin_time: str, end_time: str) -> pl.DataFrame:
        """
        获取指定时间范围内的输出数据
        Args:
            output_table_name (str): 表名
            begin_time (str): 起始时间
            end_time (str): 结束时间
        Returns:
            pl.DataFrame: 输出数据
        """
        sql = f"SELECT * FROM {output_table_name} WHERE DateTime BETWEEN '{begin_time}' AND '{end_time}' order by DateTime"
        rows = self.query(sql)
        return rows
    
    def get_output_data_history(self, name_list: list, begin_time: str, end_time: str) -> pl.DataFrame:
        """
        根据name_list获取指定时间范围内的输出数据
        Args:
            name_list (list): 变量名列表
            begin_time (str): 起始时间
            end_time (str): 结束时间
        Returns:
            pl.DataFrame: 输出数据
        """
        input_name_list = name_list.copy()
        sql = f"""
            select * from [历史表] where TagName in ('{"', '".join(input_name_list)}') and DateTime between '{begin_time}' and '{end_time}' order by DateTime
        """
        # print(sql)
        rows = self.query(sql)
        
        # 先将DateTime列转换为datetime格式
        try:
            rows = rows.with_columns(pl.col("DateTime").str.strptime(pl.Datetime))
        except pl.exceptions.SchemaError as e:
            self.logger.error(f"DateTime列已经是datetime格式:{e}")
        # 将第一列DateTime约束到秒
        rows = rows.with_columns(pl.col("DateTime").dt.truncate('1s'))

        # transform rows into standard input table
        df_pivot = rows.pivot(index="DateTime", on="TagName", values="TagVal", aggregate_function="first")
        df_pivot = self._remove_column_space(df_pivot)
        
        # 将DataFrame按照name_list的顺序排列
        # 先在name_list首位加入DateTime
        input_name_list.insert(0, "DateTime")
        df_pivot = df_pivot[input_name_list]

        self.logger.info(f"transform rows to standard output table successfully: {df_pivot}")
        return df_pivot

    # 优化模块
    # 从TagDatabase中读取优化模式
    def get_optimization_mode(self, optimization_procedure: str) -> str:
        """从TagDatabase中读取优化模式
        Args:
            optimization_procedure (str): 优化工序
        Returns:
            str: 优化模式
        """
        match optimization_procedure:
            case "水泥磨":
                mode_sql = ("SELECT Top 1 TagName FROM TagDatabase WHERE TagName LIKE N'%水泥A%' "
                            "and (TagName LIKE N'%优先%' or TagName LIKE N'%均衡模式%') AND TagVal = 1 ORDER BY DataTime DESC")
            case "原料磨":
                mode_sql = ("SELECT Top 1 TagName FROM TagDatabase WHERE TagName LIKE N'%原料%' "
                            "and (TagName LIKE N'%优先%' or TagName LIKE N'%均衡模式%') AND TagVal = 1 ORDER BY DataTime DESC")
            case "煤磨":
                mode_sql = ("SELECT Top 1 TagName FROM TagDatabase WHERE TagName LIKE N'%煤磨%' "
                            "and (TagName LIKE N'%优先%' or TagName LIKE N'%均衡模式%') AND TagVal = 1 ORDER BY DataTime DESC")
            case "窑":
                mode_sql = ("SELECT Top 1 TagName FROM TagDatabase WHERE TagName LIKE N'%窑%' "
                            "and (TagName LIKE N'%优先%' or TagName LIKE N'%均衡模式%') AND TagVal = 1 ORDER BY DataTime DESC")
            case _:
                mode_sql = None
        try:
            optimization_procedure_mode = self.query(mode_sql)["TagName"].item()
            self.logger.info(f"当前{optimization_procedure}的优化模式为{optimization_procedure_mode}")
            optimization_procedure_mode = "均衡"
        except Exception as e:
            self.logger.error(f"当前优化的工序不在优化范围内！！！{e}")
            optimization_procedure_mode = "均衡"
        return optimization_procedure_mode

    def get_cement_mill_target(self) -> Tuple[int, float]:
        """
        从TagDatabase中读取并计算水泥磨的比表面积目标值和细度目标值
        :return: 比表面积目标值
        """
        cement_variety_sql = """SELECT tagName FROM [TagDataBase] WHERE tagName IN (
                                    '水泥APO425管装水泥',
                                    '水泥APO425D',
                                    '水泥APO425普通水泥',
                                    '水泥APO525',
                                    '水泥A道路水泥',
                                    '水泥A铁标水泥'
                                ) AND tagVal = 1;"""
        cement_variety = self.query(cement_variety_sql)["tagName"].item()
        self.logger.info(f"当前水泥品种为{cement_variety}")

        # 根据水泥品种选择比表面积、细度目标值
        match cement_variety:
            case '水泥APO425管装水泥':
                sql_lower_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种1低限'"
                sql_upper_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种1高限'"
                sql_fineness_lower_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种细度1低限'"
                sql_fineness_upper_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种细度1高限'"
            case '水泥APO425D':
                sql_lower_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种2低限'"
                sql_upper_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种2高限'"
                sql_fineness_lower_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种细度2低限'"
                sql_fineness_upper_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种细度2高限'"
            case '水泥APO425普通水泥':
                sql_lower_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种3低限'"
                sql_upper_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种3高限'"
                sql_fineness_lower_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种细度3低限'"
                sql_fineness_upper_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种细度3高限'"
            case '水泥APO525':
                sql_lower_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种4低限'"
                sql_upper_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种4高限'"
                sql_fineness_lower_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种细度4低限'"
                sql_fineness_upper_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种细度4高限'"
            case '水泥A道路水泥':
                sql_lower_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种5低限'"
                sql_upper_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种5高限'"
                sql_fineness_lower_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种细度5低限'"
                sql_fineness_upper_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种细度5高限'"
            case '水泥A铁标水泥':
                sql_lower_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种6低限'"
                sql_upper_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种6高限'"
                sql_fineness_lower_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种细度6低限'"
                sql_fineness_upper_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种细度6高限'"
            case _:
                self.logger.warning(f"当前水泥品种{cement_variety}不在已知的范围内！！！")
                surface_area_target = 350
                fineness_target = 5.25
                return surface_area_target, fineness_target

        surface_area_lower_limit = self.query(sql_lower_limit)["TagVal"].item()
        surface_area_upper_limit = self.query(sql_upper_limit)["TagVal"].item()
        print(self.query(sql_fineness_lower_limit)["TagVal"])
        fineness_lower_limit = self.query(sql_fineness_lower_limit)["TagVal"].item()
        fineness_upper_limit = self.query(sql_fineness_upper_limit)["TagVal"].item()

        surface_area_target = (surface_area_lower_limit + surface_area_upper_limit) / 2
        fineness_target = (fineness_lower_limit + fineness_upper_limit) / 2
        # 如果细度目标均值为0，则将细度目标值设为5.25
        if fineness_target == 0:
            fineness_target = 5.25
        self.logger.info(f"当前优化的水泥品种为{cement_variety}，其比表面积目标值为{surface_area_target}, 细度目标值为{fineness_target}!")

        # 再将目标值写入TagDatabase中，方便前台查看回显
        target_sql = f"UPDATE TagDatabase SET TagVal = {surface_area_target} WHERE TagName = '水泥A比表面积目标寄存'"
        self.cursor.execute(target_sql)
        self.connection.commit()
        self.logger.info(f"将比表面积目标值{surface_area_target}写入TagDatabase成功!")
        return surface_area_target, fineness_target

    def query_decision_history_data(self, table_name: str, time_query: int) -> pl.DataFrame:
        """
        查询用于决策的历史数据
        Args:
            table_name (str): 表名
            time_query (int): 查询时间
        Returns:
            pl.DataFrame: 历史数据
        """
        # 从视图中查询给定长度的数据
        time_query = time_query * 6  # 默认的查询时间为分钟，1min控制器数据库中有6个数，查询的时候需要转换一下
        sql_sentence = f"SELECT Top {time_query} * FROM {table_name} " \
                       f"WHERE (DateTime BETWEEN SUBSTRING(CONVERT(varchar, DATEADD(hour, - 2, GETDATE()), 120), 1, 16) AND " \
                       f"SUBSTRING(CONVERT(varchar, DATEADD(hour, +1, GETDATE()), 120), 1, 16))" \
                       f"ORDER BY DateTime DESC"
        rows = self.query(sql_sentence)
        # 计算分钟均值和平滑滤波
        decision_history_data = optimization_data_process(rows, int(time_query / 6))
        return decision_history_data
    

class MSSQLQuality(MSSQLConnection):
    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self.logger = get_logger("MSSQLQuality", "database")

    def get_output_data_train(self, output_table_name: str, begin_time: datetime.datetime, end_time: datetime.datetime) -> pl.DataFrame:
        """
        获取指定时间范围内的输出数据
        Args:
            output_table_name (str): 表名
            begin_time (str): 起始时间
            end_time (str): 结束时间
        Returns:
            pl.DataFrame: 输出数据
        """
        sql = f"SELECT * FROM {output_table_name} WHERE TagTime BETWEEN '{begin_time}' AND '{end_time}' order by TagTime"
        self.logger.info(f"Quality query sql: {sql}")
        rows = self.query(sql)
        return rows
    
    def get_output_data_history(self, output_table_name: str, begin_time: datetime.datetime, end_time: datetime.datetime) -> pl.DataFrame:
        """
        获取指定时间范围内的输出数据
        """
        """
        获取指定时间范围内的输出数据
        Args:
            output_table_name (str): 表名
            begin_time (str): 起始时间
            end_time (str): 结束时间
        Returns:
            pl.DataFrame: 输出数据
        """
        sql = f"SELECT * FROM {output_table_name} WHERE TagTime BETWEEN '{begin_time}' AND '{end_time}' order by TagTime"
        self.logger.info(f"Quality query sql: {sql}")
        rows = self.query(sql)
        return rows

    def get_latest_true_value(self, table_name: str) -> pl.DataFrame:
        """Get true value of latest quality data from quality database

        Args:
            table_name (str): table name

        Returns:
            pl.DataFrame: true value
        """
        sql = f"SELECT TOP (1) * FROM {table_name} ORDER BY TagTime DESC"
        rows = self.query(sql)
        return rows


class MSSQLRealtimePredict(MSSQLConnection):
    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self.logger = get_logger("MSSQLRealtimePredict", "database")

    def update_realvalue(self, table_name: str, realvalue: float, time_real: str | datetime.datetime) -> None:
        """
        write real value into realtime predict database

        Args:
            table_name (str): table name to insert real value 
            realvalue (float): real value gotten from controller database or quality database
            time_real (str): time to insert real value, can be datatime.datetime or TagTime(str)
        """
        # 先判断time_str是datetime格式还是str格式
        if isinstance(time_real, datetime.datetime):
            time_real = time_real.replace(microsecond=0)
            # 如果是datetime格式,说明真实数据是从控制器数据库中获取的，直接往表里写就行
            try:
                sql = f"UPDATE [{table_name}] SET 真实值 = ? WHERE DateTime = ?"
                self.cursor.execute(sql, (realvalue, time_real))
            except pyodbc.Error as e:
                self.logger.warning(f"Update real value error {e}, please try insert it")
                # 日期不存在,INSERT
                sql = f"INSERT INTO [{table_name}] (DateTime, 真实值) VALUES (?, ?)"
                self.cursor.execute(sql, (time_real, realvalue))
                self.connection.commit()
                # print("更新控制器数据库的真实值成功")
            except Exception as e:
                self.logger.error(f"Update real value failed {e}, please check the database connection!")
        else:
            # 如果是str格式,说明真实数据是从质检库中获取的，需要先将str转换为datetime格式
            # 然后查询这一个小时所有的数据，都更新为data_real
            # 先查询质检库中最新的8条数据，然后将这8条数据的DateTime列转换为str格式，
            sql_quality_real = f"SELECT TOP (24) * FROM {table_name} ORDER BY tagTime DESC"
            self.cursor.execute(sql_quality_real)
            quality_real = self.cursor.fetchall()
            update_sql = f"UPDATE {table_name} SET 真实值 = ? WHERE DateTime BETWEEN ? AND ?"
            for quality_real_data in quality_real:
                # 先判断输出表名中是否带有原料或者生料，若存在则将真实值覆盖时间修改为2个小时
                update_time = datetime.datetime.strptime(str(int(quality_real_data[0]) - 1), '%Y%m%d%H')
                update_value = quality_real_data[1]
                if "原料" in table_name or "生料" in table_name:
                    # print("当前更新的是原料磨的质检表数据，2小时一次！！！")
                    try:
                        self.cursor.execute(update_sql, (
                            update_value, update_time - datetime.timedelta(hours=1),
                            update_time + datetime.timedelta(hours=1)))
                        self.connection.commit()
                    except Exception as e:
                        print("更新质检库的真实值失败", e)
                else:
                    try:
                        # print("当前更新的是正常一小时一次的之间数据！！！")
                        self.cursor.execute(update_sql,
                                            (update_value, update_time, update_time + datetime.timedelta(hours=1)))
                        self.connection.commit()
                    except Exception as e:
                        print("更新质检库的真实值失败", e)

    def update_predictvalue(self, table_name: str, predictvalue: float, time_predict: str, pred_len_str: str) -> None:
        """write predict value into realtime predict database
        Args:
            table_name (str): table name to insert predict value 
            predictvalue (float): predict value gotten from model
            time_predict (str): time to insert predict value
            pred_len_str (str): predict length string
        """
        if pred_len_str == "0分钟预测值":
            column_name = "软测量预测值"
        else:
            column_name = pred_len_str

        pred_len = int(pred_len_str.replace("分钟预测值", ""))
        match pred_len:
            case 0:
                data_predict = predictvalue
            case 3 | 5:
                # 根据预测查询过去的预测值然后均值滤波最后写入数据库
                # 先查询过去的预测值
                history_sql = f"SELECT TOP ({pred_len}) [{column_name}] FROM {table_name} WHERE DateTime < ? ORDER BY DateTime DESC"
                self.cursor.execute(history_sql, time_predict)
                history_predict = self.cursor.fetchall()
                # 将查询到的结果和预测值拼接，然后求均值
                history_predict = np.array(history_predict)
                history_predict = history_predict[~np.equal(history_predict, None)]
                history_predict = np.append(history_predict, predictvalue)
                data_predict = np.mean(history_predict)
            case 30:
                # 根据预测查询过去的预测值然后均值滤波最后写入数据库
                # 先查询过去的预测值
                history_sql = f"SELECT TOP (5) [{column_name}] FROM {table_name} WHERE DateTime < ? ORDER BY DateTime DESC"
                self.cursor.execute(history_sql, time_predict)
                history_predict = self.cursor.fetchall()
                # 将查询到的结果和预测值拼接，然后求均值
                history_predict = np.array(history_predict)
                history_predict = history_predict[~np.equal(history_predict, None)]
                history_predict = np.append(history_predict, predictvalue)
                data_predict = np.mean(history_predict)
            case _:
                data_predict = predictvalue
                self.logger.warning(f"Unsupported predict length: {pred_len_str}")
        try:
            sql = f"UPDATE {table_name} SET [{column_name}] = ? WHERE DateTime = ?"
            self.cursor.execute(sql, (data_predict, time_predict))
            self.connection.commit()
        except pyodbc.Error:
            # 日期不存在,INSERT
            sql = f"INSERT INTO {table_name} (DateTime, [{column_name}]) VALUES (?, ?)"
            self.cursor.execute(sql, (time_predict, data_predict))
            self.connection.commit()
