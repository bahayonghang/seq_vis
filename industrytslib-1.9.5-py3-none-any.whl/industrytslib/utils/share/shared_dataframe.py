import threading
import polars as pl
from typing import Optional, Callable

from industrytslib.utils.logutils import get_logger


class SharedDataFrame:
    _instance = None
    _lock = threading.Lock()
    _read_count = 0
    _read_lock = threading.Lock()
    _write_lock = threading.Lock()

    def __init__(self):
        self.logger = get_logger(__name__, "dataframe_shared")

    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super().__new__(cls)
                cls._instance._df: Optional[pl.DataFrame] = pl.DataFrame()
        return cls._instance

    def set_dataframe(self, df: pl.DataFrame) -> None:
        """
        Set global DataFrame
        """
        with self._write_lock:
            self._df = df.clone()
            self.logger.info("DataFrame已初始化")

    def update_dataframe(self, update_func: Callable[[pl.DataFrame], pl.DataFrame]) -> None:
        """
        Update global DataFrame
        Args:
            update_func (Callable[[pl.DataFrame], pl.DataFrame]): update function
        """
        with self._write_lock:
            if self._df is not None:
                try:
                    updated_df = update_func(self._df.clone())
                    if not isinstance(updated_df, pl.DataFrame):
                        raise ValueError("更新函数必须返回Polars DataFrame")
                    self._df = updated_df
                    self.logger.info("DataFrame更新成功")
                except Exception as e:
                    self.logger.error(f"DataFrame更新失败: {e}")

    def read_dataframe(self) -> Optional[pl.DataFrame]:
        """
        Read global DataFrame
        """
        with self._read_lock:
            self._read_count += 1
            if self._read_count == 1:
                self._write_lock.acquire()

        try:
            if self._df is not None:
                self.logger.info("DataFrame读取成功")
                return self._df.clone()
            return None
        finally:
            with self._read_lock:
                self._read_count -= 1
                if self._read_count == 0:
                    self._write_lock.release()
                    