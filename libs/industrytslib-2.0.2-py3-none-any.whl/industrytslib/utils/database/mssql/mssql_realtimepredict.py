import datetime
import pyodbc

import numpy as np
import polars as pl

from .mssql_base import MSSQLConnection
from industrytslib.utils.logutils import get_logger
from industrytslib.utils.data_processing.polarsoperation import exponential_moving_average, calculate_predict_index


class MSSQLRealtimePredict(MSSQLConnection):
    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self.logger = get_logger("MSSQLRealtimePredict", "database")

    def clean_table(self) -> None:
        """
        清除数据库中多余的表,表名为_pred*结尾的表
        """
        sql = "SELECT name FROM sys.tables WHERE name LIKE '%_pred%'"
        self.cursor.execute(sql)
        rows = self.cursor.fetchall()
        for row in rows:
            self.execute(f"DROP TABLE {row[0]}")
        self.logger.info("清除数据库中多余的表成功!!!")

    def check_table(self, project_name: str) -> None:
        """
        检查数据库中是否存在table_name表,如果不存在则创建
        
        Args:
            project_name: Name of the table to check/create
        """
        # First check if table exists
        check_sql = f"""
        SELECT COUNT(*) 
        FROM INFORMATION_SCHEMA.TABLES 
        WHERE TABLE_NAME = '{project_name}'
        """
        self.cursor.execute(check_sql)
        exists = self.cursor.fetchone()[0]
        
        if not exists:
            self.logger.info(f"Table {project_name} not exists, create it")
            create_sql = f"""
            CREATE TABLE {project_name} (
                [DateTime] DATETIME PRIMARY KEY,
                [真实值] REAL,
                [软测量预测值] REAL,
                [3分钟预测值] REAL,
                [5分钟预测值] REAL,
                [30分钟预测值] REAL,
                [AI预测值] REAL,
                [AI预测指标] REAL
            )
            """
            self.execute(create_sql)
            self.logger.info(f"Created table {project_name}")
        else:
            self.logger.info(f"Table {project_name} already exists")

        self.clean_table()

    def update_realvalue(self, table_name: str, realvalue: float, time_real: str | datetime.datetime) -> None:
        """
        write real value into realtime predict database

        Args:
            table_name (str): table name to insert real value 
            realvalue (float): real value gotten from controller database or quality database
            time_real (str): time to insert real value, can be datatime.datetime or TagTime(str)
        """
        # print(f"server: {self.server}, database: {self.database}, table: {table_name}")
        # 先判断time_str是datetime格式还是str格式
        if isinstance(time_real, datetime.datetime):
            self.logger.info(f"Update real value {realvalue} at {time_real} to {table_name} of controller database")
            time_real = time_real.replace(microsecond=0)
            # 如果是datetime格式,说明真实数据是从控制器数据库中获取的，直接往表里写就行
            # 判断time_real是否存在，存在则update，不存在则insert
            time_query = f"""
            SELECT COUNT(*) FROM [dbo].[{table_name}] WHERE DateTime = ?
            """
            self.cursor.execute(time_query, time_real)
            time_exist = self.cursor.fetchone()[0]
            if time_exist:
                try:
                    sql = f"UPDATE [dbo].[{table_name}] SET 真实值 = ? WHERE DateTime = ?"
                    self.cursor.execute(sql, (realvalue, time_real))
                    self.connection.commit()
                except Exception as e:
                    self.logger.warning(f"Update real value error {e}, please try insert it")
            else:
                try:
                    # 日期不存在,INSERT
                    sql = f"INSERT INTO [{table_name}] (DateTime, 真实值) VALUES (?, ?)"
                    self.cursor.execute(sql, (time_real, realvalue))
                    self.connection.commit()
                except Exception as e:
                    self.logger.error(f"Update real value failed {e}, please check the database connection!")
        else:
            # 如果是str格式,说明真实数据是从质检库中获取的，需要先将str转换为datetime格式
            # 然后查询这一个小时所有的数据，都更新为data_real
            # 先查询质检库中最新的8条数据，然后将这8条数据的DateTime列转换为str格式
            # self.logger.info(f"Update real value {realvalue} at {time_real} to {table_name} of quality database")
            sql_quality_real = f"SELECT TOP (24) * FROM [dbo].[{table_name}] ORDER BY tagTime DESC"
            self.cursor.execute(sql_quality_real)
            quality_real = self.cursor.fetchall()
            update_sql = f"UPDATE {table_name} SET 真实值 = ? WHERE DateTime BETWEEN ? AND ?"
            for quality_real_data in quality_real:
                # 先判断输出表名中是否带有原料或者生料，若存在则将真实值覆盖时间修改为2个小时
                update_time = datetime.datetime.strptime(str(int(quality_real_data[0]) - 1), '%Y%m%d%H')
                update_value = quality_real_data[1]
                if "原料" in table_name or "生料" in table_name:
                    # print("当前更新的是原料磨的质检表数据，2小时一次！！！")
                    try:
                        self.cursor.execute(update_sql, (
                            update_value, update_time - datetime.timedelta(hours=1),
                            update_time + datetime.timedelta(hours=1)))
                        self.connection.commit()
                    except Exception as e:
                        print("更新质检库的真实值失败", e)
                else:
                    try:
                        # print("当前更新的是正常一小时一次的之间数据！！！")
                        self.cursor.execute(update_sql,
                                            (update_value, update_time, update_time + datetime.timedelta(hours=1)))
                        self.connection.commit()
                    except Exception as e:
                        print("更新质检库的真实值失败", e)
        self.logger.info(f"更新{table_name}表时刻{time_real}的真实值{realvalue}成功!!!")
    
    def update_realvalue_control(self, table_name: str, realvalue: float, time_real: str) -> None:
        """
        更新控制器数据库中的真实值
        """
        self.logger.info(f"Update real value {realvalue} at {time_real} to {table_name} of controller database")
        time_real = time_real.replace(microsecond=0)
        # 如果是datetime格式,说明真实数据是从控制器数据库中获取的，直接往表里写就行
        # 判断time_real是否存在，存在则update，不存在则insert
        time_query = f"""
        SELECT COUNT(*) FROM [dbo].[{table_name}] WHERE DateTime = ?
        """
        self.cursor.execute(time_query, time_real)
        time_exist = self.cursor.fetchone()[0]
        if time_exist:
            try:
                sql = f"UPDATE [dbo].[{table_name}] SET 真实值 = ? WHERE DateTime = ?"
                self.cursor.execute(sql, (realvalue, time_real))
                self.connection.commit()
            except Exception as e:
                self.logger.warning(f"Update real value error {e}, please try insert it")
        else:
            try:
                # 日期不存在,INSERT
                sql = f"INSERT INTO [{table_name}] (DateTime, 真实值) VALUES (?, ?)"
                self.cursor.execute(sql, (time_real, realvalue))
                self.connection.commit()
            except Exception as e:
                self.logger.error(f"Update real value failed {e}, please check the database connection!")

    def update_realvalue_quality(self, table_name: str, quality_real: pl.DataFrame) -> None:
        """
        更新质检库中的真实值
        """
        # 如果是str格式,说明真实数据是从质检库中获取的，需要先将str转换为datetime格式
        # 然后查询这一个小时所有的数据，都更新为data_real
        columns = quality_real.columns
        time_column = columns[0]
        value_column = columns[1]
        update_sql = f"UPDATE {table_name} SET 真实值 = ? WHERE DateTime BETWEEN ? AND ?"
        for i in range(quality_real.height):
            # 先判断输出表名中是否带有原料或者生料，若存在则将真实值覆盖时间修改为2个小时
            update_time = datetime.datetime.strptime(str(int(quality_real[i][time_column].item()) - 1), '%Y%m%d%H')
            update_value = quality_real[i][value_column].item()
            if "原料" in table_name or "生料" in table_name:
                # print("当前更新的是原料磨的质检表数据，2小时一次！！！")
                try:
                    self.cursor.execute(update_sql, (
                        update_value, update_time - datetime.timedelta(hours=1),
                        update_time + datetime.timedelta(hours=1)))
                    self.connection.commit()
                except Exception as e:
                    print("更新质检库的真实值失败", e)
            else:
                try:
                    # print("当前更新的是正常一小时一次的之间数据！！！")
                    self.cursor.execute(update_sql,
                                        (update_value, update_time, update_time + datetime.timedelta(hours=1)))
                    self.connection.commit()
                except Exception as e:
                    print("更新质检库的真实值失败", e)

    def update_predictvalue(self, table_name: str, predictvalue: float, time_predict: str, 
                            pred_len_str: str) -> None:
        """write predict value into realtime predict database
        Args:
            table_name (str): table name to insert predict value 
            predictvalue (float): predict value gotten from model
            time_predict (str): time to insert predict value
            pred_len_str (str): predict length string
        """
        if pred_len_str == "0分钟预测值":
            column_name = "软测量预测值"
        else:
            column_name = pred_len_str

        pred_len = int(pred_len_str.replace("分钟预测值", ""))
        if predictvalue == 0:
            data_predict = 0
        else:
            match pred_len:
                case 0:
                    data_predict = predictvalue
                case 3 | 5:
                    # 根据预测查询过去的预测值然后均值滤波最后写入数据库
                    # 先查询过去的预测值
                    history_sql = f"""
                    SELECT TOP ({pred_len}) [{column_name}] FROM {table_name} 
                    WHERE DateTime < ? ORDER BY DateTime DESC
                    """
                    self.cursor.execute(history_sql, time_predict)
                    history_predict = self.cursor.fetchall()
                    # 将查询到的结果和预测值拼接，然后求均值
                    history_predict = np.array(history_predict)
                    history_predict = history_predict[~np.equal(history_predict, None)]
                    history_predict = np.append(history_predict, predictvalue)
                    data_predict = np.mean(history_predict)
                case 30:
                    # 根据预测查询过去的预测值然后均值滤波最后写入数据库
                    # 先查询过去的预测值
                    history_sql = f"""
                    SELECT TOP (5) [{column_name}] FROM {table_name} 
                    WHERE DateTime < ? ORDER BY DateTime DESC
                    """
                    self.cursor.execute(history_sql, time_predict)
                    history_predict = self.cursor.fetchall()
                    # 将查询到的结果和预测值拼接，然后求均值
                    history_predict = np.array(history_predict)
                    history_predict = history_predict[~np.equal(history_predict, None)]
                    history_predict = np.append(history_predict, predictvalue)
                    data_predict = np.mean(history_predict)
                case _:
                    data_predict = predictvalue
                    self.logger.warning(f"Unsupported predict length: {pred_len_str}")
        # 判断time_predict是否存在，存在则update，不存在则insert
        time_query = f"""
        SELECT COUNT(*) FROM [dbo].[{table_name}] WHERE DateTime = ?
        """
        self.cursor.execute(time_query, time_predict)
        time_exist = self.cursor.fetchone()[0]
        if time_exist:
            try:
                sql = f"UPDATE [dbo].[{table_name}] SET [{column_name}] = ? WHERE DateTime = ?"
                self.cursor.execute(sql, (data_predict, time_predict))
                self.connection.commit()
                # self.logger.info(f"update sql: {sql}, data_predict: {data_predict}, time_predict: {time_predict}")
            except Exception as e:
                self.logger.warning(f"Update predict value error {e}, please try insert it")
        else:
            try:
                # 日期不存在,INSERT
                sql = f"INSERT INTO [dbo].[{table_name}] (DateTime, [{column_name}]) VALUES (?, ?)"
                self.cursor.execute(sql, (time_predict, data_predict))
                self.connection.commit()
                # self.logger.info(f"insert sql: {sql}, data_predict: {data_predict}, time_predict: {time_predict}")
            except Exception as e:
                self.logger.error(f"Insert predict value failed {e}, please check the database connection!")

    # 为实时预测表添加AI预测值和AI预测指标列
    def add_ai_predict_column(self, table_name: str) -> None:
        self.add_column(table_name, "AI预测值", "REAL")
        self.add_column(table_name, "AI预测指标", "REAL")
        self.logger.info(f"为{table_name}表添加AI预测值和AI预测指标列成功!!!")

    def update_ai_predict_value(self, table_name: str, ai_predict_value: pl.DataFrame) -> None:
        """
        根据table_name和ai_predict_value更新数据库中的AI预测值
        Args:
            table_name: Name of the target database table
            ai_predict_value: Polars DataFrame containing DateTime in first column and AI predictions in second column
        """
        # Iterate through DataFrame rows using iter_rows()
        for row in ai_predict_value.iter_rows():
            datetime_val, predict_val = row[0], row[1]
            self.cursor.execute(f"""UPDATE {table_name} 
                        SET [AI预测值] = ? 
                        WHERE DateTime = ?
                        """,
                        (predict_val, datetime_val)
                        )
            self.connection.commit()
            
    def update_ai_predict_index(self, table_name: str, index_time: datetime.datetime, 
                                ai_predict_index: float) -> None:
        """
        根据table_name和ai_predict_index更新数据库中的AI预测指标
        """
        self.execute(f"""UPDATE {table_name} 
                     SET [AI预测指标] = '{ai_predict_index}' 
                     WHERE DateTime = '{index_time}'
                     """)

    def query_latest_predict_value(self, table_name: str) -> pl.DataFrame:
        """
        查询数据库中最新的AI预测值
        """
        sql = f"SELECT TOP 60 * FROM {table_name} ORDER BY DateTime DESC"
        return self.query(sql)
    
    def predict_settle(self, table_name: str) -> None:
        """
        实时预测数据库处理, 将每一张实时预测表的软测量值和预测值进行拼接, 并计算AI预测指标
        """
        latest_predict_value = self.query_latest_predict_value(table_name)

        # 遍历数据，根据时间窗口整合预测值
        # 从polars.DataFrame中选取列然后去除null
        soft_measurement_notnull = latest_predict_value.select(["DateTime", "软测量预测值"]).drop_nulls()
        three_minute_notnull = latest_predict_value.select(["DateTime", "3分钟预测值"]).drop_nulls()
        five_minute_notnull = latest_predict_value.select(["DateTime", "5分钟预测值"]).drop_nulls()
        thirty_minute_notnull = latest_predict_value.select(["DateTime", "30分钟预测值"]).drop_nulls()

        # 获取Top N数据
        soft_measurement_top = soft_measurement_notnull  # 软测量预测值
        three_minute_top = three_minute_notnull.head(3)  # 3分钟预测值的Top 3
        five_minute_top = five_minute_notnull.head(2)  # 5分钟预测值的Top 2
        thirty_minute_top = thirty_minute_notnull.head(25)  # 30分钟预测值的Top 25

        soft_measurement_top.columns = [""] * len(soft_measurement_top.columns)
        three_minute_top.columns = [""] * len(three_minute_top.columns)
        five_minute_top.columns = [""] * len(five_minute_top.columns)
        thirty_minute_top.columns = [""] * len(thirty_minute_top.columns)

        # 将数据拼接
        new_df = pl.concat([soft_measurement_top, three_minute_top, five_minute_top, thirty_minute_top], how="vertical")
        new_df.columns = ["DateTime", "AI预测值"]
        # moving average
        new_df = exponential_moving_average(new_df, 0.2)

        # 将计算结果根据DateTime写入到数据库
        self.update_ai_predict_value(table_name, new_df)

        # 计算AI预测指标
        try:
            index_df = latest_predict_value.select(["DateTime", "真实值", "AI预测值"]).drop_nulls()
            index_time, predict_index = calculate_predict_index(index_df)
            self.update_ai_predict_index(table_name, index_time, predict_index)
            self.logger.info(f"为{table_name}表计算AI预测指标成功!!!")
        except Exception as e:
            self.logger.error(f"Calculate AI predict index failed {e}!")


class MSSQLRealtimePredictSequence(MSSQLRealtimePredict):
    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self.logger = get_logger("MSSQLRealtimePredictSequence", "database")

    def create_sequence_table(self, table_name: str, name_list: list) -> None:
        """
        根据name_list创建sequence表
        创建规则:第一列DateTime作为主键,然后name_list中的元素添加后缀`_true`和`_predict`分别作为列名按顺序排列

        Args:
            table_name (str): 表名
            name_list (list): 元素名列表
        Returns:
            None
        """
        # 构建 SQL 语句
        columns = ["[DateTime] DATETIME PRIMARY KEY"]
        for name in name_list:
            columns.append(f"[{name}_true] FLOAT")
            columns.append(f"[{name}_predict] FLOAT")

        # 拼接最终的 SQL 语句
        create_table_sql = f"CREATE TABLE {table_name} ({', '.join(columns)});"
        self.execute(create_table_sql)
        self.logger.info(f"为{table_name}创建sequence表成功!!!")
    
    def create_sequence_predict_table(self, table_name: str, name_list: list) -> None:
        """
        根据name_list创建sequence预测表
        创建规则:第一列DateTime作为主键,然后name_list中的元素作为后续列名

        Args:
            table_name (str): 表名
            name_list (list): 元素名列表
        Returns:
            None
        """
        # 构建 SQL 语句
        columns = ["[DateTime] DATETIME PRIMARY KEY"]
        for name in name_list:
            columns.append(f"[{name}] FLOAT")

        # 拼接最终的 SQL 语句
        create_table_sql = f"CREATE TABLE {table_name} ({', '.join(columns)});"
        self.execute(create_table_sql)
        self.logger.info(f"为{table_name}创建sequence预测表成功!!!")

    def check_sequence_table(self, table_name: str, name_list: list) -> None:
        """
        检查数据库中是否存在table_name表,如果不存在则创建

        Args:
            table_name (str): 表名
            name_list (list): 元素名列表
        Returns:
            None
        """
        sql = f"SELECT COUNT(*) FROM sys.tables WHERE name = '{table_name}'"
        self.cursor.execute(sql)
        results = self.cursor.fetchall()[0][0]
        if results == 0:
            self.create_sequence_predict_table(table_name, name_list)
        else:
            self.logger.info(f"sequence预测表{table_name}已存在!!!")

    def update_realvalue(self, table_name: str, realvalue: pl.DataFrame, 
                         time_real: str | datetime.datetime) -> None:
        """
        write real value into realtime predict database of sequence

        Args:
            table_name (str): table name to insert real value 
            realvalue (pl.DataFrame): real value gotten from controller database or quality database
            time_real (str): time to insert real value, datatime.datetime
        """
        var_name_list = realvalue.columns

        var_true_list = [f"{var_name}_true" for var_name in var_name_list]

        time_real = time_real.replace(second=0,microsecond=0)
        try:
            self.update_list(table_name, time_real, var_true_list, list(realvalue.rows(0)))
        except pyodbc.Error as e:
            self.logger.warning(f"Update real value error {e}, try insert it!!!")
            self.insert_list(table_name, time_real, var_true_list, list(realvalue.rows(0)))
        except Exception as e:
            self.logger.error(f"Update real value failed {e}, please check the database connection!")
            raise f"Update real value failed {e}, please check the database connection!"
        
    def update_predictvalue(self, table_name: str, predictvalue: pl.DataFrame, 
                            time_predict: datetime.datetime) -> None:
        """write predict value into realtime predict database of sequence
        Args:
            table_name (str): table name to insert predict value 
            predictvalue (pl.DataFrame): predict value gotten from model
            time_predict (datetime.datetime): time to insert predict value
        """
        var_name_list = predictvalue.columns
        time_predict = time_predict.replace(second=0,microsecond=0)

        # 根据pred_len和time_predict创建DateTime列表
        date_time_list = [time_predict + datetime.timedelta(minutes=i+1) for i in range(len(predictvalue))]
        var_predict_list = [f"{var_name}_predict" for var_name in var_name_list]

        i = 0
        # 根据DateTime更新数据库
        for datetime_predict in date_time_list:
            # 先尝试
            try:
                self.update_list(table_name, datetime_predict, var_predict_list, list(predictvalue.rows(i)))
            except pyodbc.Error as e:
                self.logger.warning(f"Update predict value error {e}, try insert it!!!")
                self.insert_list(table_name, datetime_predict, var_predict_list, list(predictvalue.rows(i)))
            except Exception as e:
                self.logger.error(f"Update predict value failed {e}, please check the database connection!")
                raise f"Update predict value failed {e}, please check the database connection!"
            i += 1
    
    def delete_sequence_predict_value(self, table_name: str) -> None:
        """
        删除sequence预测表中的数据
        """
        sql = f"DELETE FROM {table_name}"
        self.execute(sql)
    
    def update_sequence_predict_table(
            self, table_name: str, predictvalue: pl.DataFrame, 
            time_predict: datetime.datetime
        ) -> None:
        """
        更新sequence预测表
        """
        # 首先检查表是否存在
        var_name_list = predictvalue.columns
        time_predict = time_predict.replace(second=0,microsecond=0)

        # try:
        #     self.check_sequence_table(table_name, var_name_list)
        # except Exception as e:
        #     self.logger.error(f"Check sequence table failed {e}, please check the database connection!")
            # raise f"Check sequence table failed {e}, please check the database connection!"

        # 根据pred_len和time_predict创建DateTime列表
        date_time_list = [time_predict + datetime.timedelta(minutes=i+1) for i in range(len(predictvalue))]
        
        # 先将table_name表中的数据清理干净
        self.truncate_table(table_name)

        i = 0
        # 根据DateTime更新数据库
        for row in predictvalue.iter_rows():
            # 先尝试
            try:
                self.insert_sequence_value(table_name, date_time_list[i], var_name_list, list(row))
            except Exception as e:
                self.logger.error(f"Update predict value failed {e}, please check the database connection!")
            i += 1
    
    def update_sequence_real_value_table(
            self, table_name: str, realvalue: pl.DataFrame, 
            time_real: datetime.datetime
        ) -> None:
        """
        更新sequence真实值表
        """
        # 首先检查表是否存在
        var_name_list = realvalue.columns
        time_real = time_real.replace(second=0,microsecond=0)

        # try:
        #     self.check_sequence_table(table_name, var_name_list)
        # except Exception as e:
        #     self.logger.error(f"Check sequence table failed {e}, please check the database connection!")
            # raise f"Check sequence table failed {e}, please check the database connection!"

        # 根据pred_len和time_predict创建DateTime列表
        date_time_list = [time_real - datetime.timedelta(minutes=i) for i in range(len(realvalue))]
        # 按照时间正序排列
        date_time_list.reverse()
        
        # 先将table_name表中的数据清理干净
        # self.truncate_table(table_name)

        i = 0
        # 根据DateTime更新数据库
        for row in realvalue.iter_rows():
            # 先尝试
            try:
                self.insert_sequence_value(table_name, date_time_list[i], var_name_list, list(row))
            except Exception as e:
                self.logger.error(f"Update predict value failed {e}, please check the database connection!")
            i += 1


class MSSQLRealtimePredictAlter(MSSQLRealtimePredict):
    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self.logger = get_logger("MSSQLRealtimePredictAlter", "database")

    def check_table(self, project_name: str) -> None:
        """
        检查数据库中是否存在table_name表,如果不存在则创建
        
        Args:
            project_name: Name of the table to check/create
        Returns:
            None
        Examples:
            >>> self.check_table("窑fcao样本_窑fcao样本_CNN")
        """
        # First check if table exists
        check_sql = f"""
        SELECT COUNT(*) 
        FROM INFORMATION_SCHEMA.TABLES 
        WHERE TABLE_NAME = '{project_name}'
        """
        self.cursor.execute(check_sql)
        exists = self.cursor.fetchone()[0]
        
        if not exists:
            self.logger.info(f"Table {project_name} not exists, create it")
            create_sql = f"""
            CREATE TABLE {project_name} (
                [DateTime] DATETIME PRIMARY KEY,
                [真实值] REAL,
                [AI预测值] REAL,
                [AI预测指标] REAL
            )
            """
            self.execute(create_sql)
            self.logger.info(f"Created table {project_name}")
        else:
            self.logger.info(f"Table {project_name} already exists")

        self.clean_table()

    def update_predictvalue(
            self, table_name: str, 
            predictvalue: float, time_predict: str
        ) -> None:
        """
        write predict value into realtime predict database
        Args:
            table_name (str): table name to insert predict value 
            predictvalue (float): predict value gotten from model
            time_predict (str): time to insert predict value
        Returns:
            None
        Examples:
            >>> self.update_predictvalue("窑fcao样本_窑fcao样本_CNN", 1.0, "2024-11-27 10:00:00")
        """
        # 判断time_predict是否存在，存在则update，不存在则insert
        time_query = f"""
        SELECT COUNT(*) FROM [dbo].[{table_name}] WHERE DateTime = ?
        """
        self.cursor.execute(time_query, time_predict)
        time_exist = self.cursor.fetchone()[0]
        if time_exist:
            try:
                sql = f"UPDATE [dbo].[{table_name}] SET [AI预测值] = ? WHERE DateTime = ?"
                self.cursor.execute(sql, (predictvalue, time_predict))
                self.connection.commit()
                # self.logger.info(f"update sql: {sql}, data_predict: {data_predict}, time_predict: {time_predict}")
            except Exception as e:
                self.logger.warning(f"Update predict value error {e}, please try insert it")
        else:
            try:
                # 日期不存在,INSERT
                sql = f"INSERT INTO [dbo].[{table_name}] (DateTime, [AI预测值]) VALUES (?, ?)"
                self.cursor.execute(sql, (time_predict, predictvalue))
                self.connection.commit()
                # self.logger.info(f"insert sql: {sql}, data_predict: {data_predict}, time_predict: {time_predict}")
            except Exception as e:
                self.logger.error(f"Insert predict value failed {e}, please check the database connection!")

    # 为实时预测表添加AI预测值和AI预测指标列
    def add_ai_predict_column(self, table_name: str) -> None:
        self.add_column(table_name, "AI预测值", "REAL")
        self.add_column(table_name, "AI预测指标", "REAL")
        self.logger.info(f"为{table_name}表添加AI预测值和AI预测指标列成功!!!")

    def get_predict_data_by_table_name(self, table_name: str) -> pl.DataFrame:
        """
        根据表名从预测表中读取数据,用于质量数据未来值的预测
        Args:
            table_name: 预测表名
        Returns:
            predict_df: 预测数据
        Examples:
            >>> predict_df = self.get_predict_data_by_table_name("二线窑长序列预测样本_二线窑长序列预测样本_informer")
            >>> print(predict_df)
        """
        query_sql = f"SELECT * FROM {table_name}"
        predict_df = self.query(query_sql)
        return predict_df
    