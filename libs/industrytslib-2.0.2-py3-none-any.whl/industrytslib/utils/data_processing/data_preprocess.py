"""
数据预处理库
"""
import numpy as np
import pandas as pd
import polars as pl

from typing import Tuple

from industrytslib.utils.data_processing.polarsoperation import (
    calculate_minute_average,
    smooth_filter, weighted_moving_average, exponential_moving_average,
    duplicate_filter
)


FILTER_TYPE_LIST = ["smooth_filter", "weighted_moving_average", "exponential_moving_average"]
filter_type = FILTER_TYPE_LIST[0]
match filter_type:
    case "smooth_filter":
        data_filter = smooth_filter
    case "weighted_moving_average":
        data_filter = weighted_moving_average
    case "exponential_moving_average":
        data_filter = exponential_moving_average


def replace_empty_with_null(df: pl.DataFrame) -> pl.DataFrame:
    """
    Replace all empty strings with null in a Polars DataFrame.

    Args:
        df (pl.DataFrame): Input DataFrame.

    Returns:
        pl.DataFrame: DataFrame with empty strings replaced by null.
    """
    def map_empty_to_null(col: pl.Series) -> pl.Series:
        if col.dtype == pl.Utf8:
            return col.map_elements(lambda x: None if x == "" else x, return_dtype=pl.Utf8)
        elif col.dtype in [pl.Float32, pl.Float64]:
            return col.map_elements(lambda x: None if x == "" else x, return_dtype=col.dtype)
        elif col.dtype in [pl.Int8, pl.Int16, pl.Int32, pl.Int64, pl.UInt8, pl.UInt16, pl.UInt32, pl.UInt64]:
            return col.map_elements(lambda x: None if x == "" else x, return_dtype=col.dtype)
        else:
            # For other data types, return the column as is
            return col

    return df.select([
        map_empty_to_null(df[col_name]).alias(col_name)
        for col_name in df.columns
    ])


# 用于数据预处理的类
class DataFramePreprocess:
    def __init__(self, input_data: pl.DataFrame, output_data: pl.DataFrame):
        """
        数据预处理类,主要包含输入、输出数据

        Args:
            input_data (pl.DataFrame): _description_
            output_data (pl.DataFrame): _description_
        """
        self.input_data = input_data
        self.output_data = output_data
        self.output_column = self.output_data.columns[-1]

    # 缺失值处理
    def missed_data_handle(self) -> None:
        """
        缺失值处理,主要包含输入、输出数据
        """
        # 将""转换为null
        self.input_data = replace_empty_with_null(self.input_data)
        self.output_data = replace_empty_with_null(self.output_data)
        # 去除输入输出数据中的缺失值,直接将行删掉
        self.input_data = self.input_data.drop_nulls()
        self.output_data = self.output_data.drop_nulls()

        # TODO 将缺失的时间行使用多重插补填值

        # 将除了第一列都转换为float类型
        self.input_data = self.input_data.with_columns(pl.col(self.input_data.columns[1:]).cast(pl.Float64))
        self.output_data = self.output_data.with_columns(pl.col(self.output_data.columns[1:]).cast(pl.Float64))

    # 异常数据处理
    def abnormal_data_handle(self) -> None:
        """
        异常数据处理,主要包含输入、输出数据
        TODO 添加读取上下限范围的机制
        """
        # 转换为float类型去除异常值
        try:
            self.output_data = self.output_data.with_columns(pl.col(self.output_column).cast(pl.Float64))
        except Exception as e:
            print(f"输出数据转换为float类型失败:{e}")
        # Replace empty strings with None, then cast to Float64
        self.output_data = self.output_data.with_columns(
            pl.col(self.output_column)
            .map_elements(lambda x: None if x == "" else x, return_dtype=pl.Float64)
            .cast(pl.Float64)
        )

        for col in self.output_data.columns[1:]:
            # # 根据上下分位数去除异常值
            # c = self.output_data.select(self.output_data.columns[col])
            # a = c.quantile(0.75).item()
            # b = c.quantile(0.25).item()
            # # 定义下限和上限
            # iqr = a - b
            # print(f"上分位数:{a}, 下分位数:{b}, IQR:{iqr}")
            # lower_bound = b - 1.5 * iqr
            # upper_bound = a + 1.5 * iqr
            # print(f"下限:{lower_bound}, 上限:{upper_bound}")
            # if lower_bound < 0:
            #     lower_bound = 0

            lower_bound = -999999
            upper_bound = 999999
            
            if "电耗" in col:
                if "水泥" in col and "磨" in col:
                    lower_bound = 15
                    upper_bound = 40
                elif "窑" in col or "熟料" in col:
                    lower_bound = 15
                    upper_bound = 40
                elif "生料" in col or "原料" in col:
                    lower_bound = 5
                    upper_bound = 30
                elif "煤磨" in col:
                    lower_bound = 20
                    upper_bound = 80
                else:
                    lower_bound = 10
                    upper_bound = 50
            if "煤耗" in col:
                lower_bound = 90
                upper_bound = 160
            if "分解炉出口温度" in col:
                lower_bound = 500
                upper_bound = 1200
            if "bbmj" in col:
                lower_bound = 300
                upper_bound = 440
            if "xd" in col:
                lower_bound = 1
                upper_bound = 30

            # 过滤异常值
            self.output_data = self.output_data.filter(
                (self.output_data[col] >= lower_bound) & (self.output_data[col] <= upper_bound))
            self.output_data = self.output_data.drop_nulls()

        # # 去除连续相同的序列数据
        # self.output_data = self.remove_consecutive_duplicates(self.output_data)

        # 输入数据处理
        for col in self.input_data.columns[1:]:
            if "煤耗" in col:
                coal_lower_bound = 90
                coal_upper_bound = 160
                self.input_data = self.input_data.with_columns(
                    pl.col(col).map_elements(lambda x: coal_lower_bound if x < coal_lower_bound else (coal_upper_bound if x > coal_upper_bound else x), return_dtype=pl.Float64)
                )
            if "电耗" in col:
                if "水泥" in col and "磨" in col:
                    elec_lower_bound = 15
                    elec_upper_bound = 40
                elif "窑" in col or "熟料" in col:
                    elec_lower_bound = 15
                    elec_upper_bound = 40
                elif "生料" in col or "原料" in col:
                    elec_lower_bound = 5
                    elec_upper_bound = 30
                elif "煤磨" in col:
                    elec_lower_bound = 20
                    elec_upper_bound = 80
                else:
                    elec_lower_bound = 10
                    elec_upper_bound = 50
                self.input_data = self.input_data.with_columns(
                    pl.col(col).map_elements(lambda x: elec_lower_bound if x < elec_lower_bound else (elec_upper_bound if x > elec_upper_bound else x), return_dtype=pl.Float64)
                )

    @staticmethod
    def remove_consecutive_duplicates(df: pl.DataFrame, threshold: int = 10) -> pl.DataFrame:
        # 将 Polars DataFrame 转换为 Pandas DataFrame
        pdf = df.to_pandas()

        # 获取最后一列的名称
        last_column = pdf.columns[-1]

        # 创建一个布尔掩码，标记连续重复值
        mask = pd.Series(pdf[last_column].values).groupby(
            (pdf[last_column] != pdf[last_column].shift()).cumsum()
        ).transform('count').lt(threshold)

        # 应用掩码来过滤数据
        pdf_cleaned = pdf[mask]

        # 将处理后的 Pandas DataFrame 转回 Polars DataFrame
        return pl.from_pandas(pdf_cleaned)

    # 滑动平均 
    def moving_average(self) -> None:
        """滑动平均,主要包含输入、输出数据
        Returns:
            pl.DataFrame: 滑动平均数据
        """
        # 如果data_in和data_out数量级一致,则data_out也做滑动平均
        if 0.1 < len(self.input_data) / len(self.output_data) < 10:
            try:
                self.output_data = self.output_data.with_columns(pl.col("DateTime").str.strptime(pl.Datetime, format="%Y-%m-%dT%H:%M:%S%.f"))
            except Exception as e:
                print(f"不需要处理时间格式:{e}")
            # self.output_data = calculate_minute_average(self.output_data)
            # self.output_data.drop_nulls()
            # self.output_data = smooth_filter(self.output_data, window_size=5)
            # self.output_data = exponential_moving_average(self.output_data, alpha=0.2)
            self.output_data = data_filter(self.output_data)

        try:
            self.input_data = self.input_data.with_columns(pl.col("DateTime").str.strptime(pl.Datetime, format="%Y-%m-%dT%H:%M:%S%.f"))
        except Exception as e:
            print(f"不需要处理时间格式:{e}")
        
        # self.input_data.drop_nulls()
        # self.input_data = smooth_filter(self.input_data, window_size=5)
        # self.input_data = exponential_moving_average(self.input_data, alpha=0.2)
        self.input_data = data_filter(self.input_data)

    def match_data_control(self) -> None:
        """
        匹配控制器数据库的数据.由于时间上的问题,导出的视图多个变量和单个变量的数量不一致,需要重新匹配数据
        param data_input: 输入数据,pl.DataFrame
        param data_output: 输出数据,pl.DataFrame
        return: 匹配好的输入数据和输出数据,pl.DataFrame、pl.DataFrame
        通常输入的行数会少于输出的行数
        根据DateTime匹配数据
        """
        # 根据DateTime匹配数据
        self.input_data = self.input_data.filter(pl.col("DateTime").is_in(self.output_data["DateTime"]))
        self.output_data = self.output_data.filter(pl.col("DateTime").is_in(self.input_data["DateTime"]))
        print("控制器数据库数据匹配成功!!!")

    # def match_data_quality(self, match_type: str = "1 hour", x_length: int = 60) -> None:
    #     """
    #     匹配控制器数据库和质检表的数据
    #     :param match_type: 匹配类型,根据匹配类型选择时间匹配的长度,可选项有:'1 hour','2 hours'
    #     :param x_length: 模型中x的长度
    #     :return: 匹配好的输入数据和输出数据,pl.DataFrame、pl.DataFrame
    #     """
    #     # 第1步,获取输入输出数据的列名
    #     name_list1 = self.input_data.columns
    #     name_list2 = self.output_data.columns

    #     # 第2步,数据类型转换
    #     self.input_data = self.input_data.with_columns(
    #         pl.col("DateTime").dt.hour().alias("Hour"),
    #         pl.col("DateTime").dt.date().alias("Date")
    #     )

    #     grouped = self.input_data.group_by(["Date", "Hour"]).count().filter(pl.col("count") == x_length)
    #     filtered_data = self.input_data.join(grouped, on=["Date", "Hour"]).select(name_list1)

    #     # 时间范围匹配
    #     input_data_matched = pl.DataFrame()
    #     output_data_matched = pl.DataFrame()

    #     self.output_data = self.output_data.with_columns(
    #         (pl.col("tagTime").cast(pl.Int64) - 1).cast(pl.Utf8)
    #     ).with_columns(
    #         pl.col("tagTime").str.slice(0, 8) + " " + pl.col("tagTime").str.slice(8, 2) + ":00:00"
    #     ).with_columns(
    #         pl.col("tagTime").str.strptime(pl.Datetime, format="%Y%m%d %H:%M:%S")
    #     )

    #     time_delta = timedelta(hours=int(match_type.split()[0]))

    #     for row in self.output_data.iter_rows(named=True):
    #         tag_time = row["tagTime"]
    #         start_time = tag_time
    #         end_time = tag_time + time_delta

    #         controller_data_match = filtered_data.filter(
    #             (pl.col("DateTime") >= start_time) & (pl.col("DateTime") < end_time)
    #         )

    #         if controller_data_match.shape[0] != x_length:
    #             continue

    #         input_data_matched = pl.concat([input_data_matched, controller_data_match], how="vertical")
    #         output_data_matched = pl.concat([output_data_matched, pl.DataFrame([row])], how="vertical")

    #     self.input_data = input_data_matched
    #     self.output_data = output_data_matched
    #     print("质检表数据匹配成功!!!")

    # 填充匹配数据中的缺失数据
    @staticmethod
    def fill_missing_minutes(
        df: pd.DataFrame,
        datetime_col: str = "DateTime"
    ) -> pd.DataFrame:
        """
        填充缺失的分钟数据，使用其他行的均值进行补全。

        Args:
            df: 输入的DataFrame，第一列为DateTime
            datetime_col: 时间列的列名，默认为'DateTime'

        Returns:
            pd.DataFrame: 补全后的DataFrame
        """
        # 创建DataFrame的副本以避免SettingWithCopyWarning
        df = df.copy()
        
        # 确保DateTime列为datetime类型
        df[datetime_col] = pd.to_datetime(df[datetime_col])

        # 生成完整的时间序列（一小时内的60个分钟）
        start_time = df[datetime_col].min().floor('h')  # 向下取整到小时
        complete_times = pd.date_range(
            start=start_time,
            periods=60,
            freq='min'
        )

        # 创建完整时间序列的DataFrame
        complete_df = pd.DataFrame({datetime_col: complete_times})

        # 与原始数据合并，使用外连接
        merged_df = pd.merge(
            complete_df,
            df,
            on=datetime_col,
            how='left'
        )

        # 分别处理日期列和数值列
        numeric_cols = merged_df.select_dtypes(include=[np.number]).columns
        
        # 只对数值列进行均值填充
        if len(numeric_cols) > 0:
            merged_df[numeric_cols] = merged_df[numeric_cols].fillna(df[numeric_cols].mean())
        
        # 对非数值列（除了datetime_col）使用前向填充
        non_numeric_cols = [
            col for col in merged_df.columns 
            if col not in numeric_cols and col != datetime_col
        ]
        if len(non_numeric_cols) > 0:
            merged_df[non_numeric_cols] = merged_df[non_numeric_cols].ffill()
            # 如果还有缺失值，使用后向填充
            merged_df[non_numeric_cols] = merged_df[non_numeric_cols].bfill()

        return merged_df

    def match_data_quality(self, match_type: str = "1 hour", x_length: int = 60) -> None:
        """
        匹配控制器数据库和质检表的数据
        :param match_type: 匹配类型,根据匹配类型选择时间匹配的长度,可选项有:'1 hour','2 hours'
        :param x_length: 模型中x的长度
        :return: 匹配好的输入数据和输出数据,pl.DataFrame、pl.DataFrame
        """
        # 将pl.dataframe转换为pd.dataframe
        control_data = self.input_data.to_pandas()
        quality_data = self.output_data.to_pandas()

        # 检查是否有重复的 DateTime 值
        duplicates = control_data[control_data.duplicated('DateTime', keep=False)]
        print(f"重复的DateTime值: {duplicates}")
        # 将control_data中的DateTime列转换为datetime类型
        control_data['DateTime'] = pd.to_datetime(control_data['DateTime'])

        # 第0步，获取输入输出数据的列名
        name_list1 = control_data.columns.values.tolist()
        name_list2 = quality_data.columns.values.tolist()

        # 第1步，数据预处理，处理空值、零值和重复值
        # to_nan_list = [np.nan, None, "null", "", 0]
        to_nan_list = [np.nan, None, "null", ""]
        # 控制器数据处理
        control_data = control_data.fillna(0)
        control_data.replace(to_nan_list, np.nan, inplace=True)
        control_data.dropna(axis=0, how='any', inplace=True)
        print(f"control_data: {control_data}")

        # 查询质检表的数据
        quality_data = quality_data.fillna(0)
        quality_data.replace(to_nan_list, np.nan, regex=True, inplace=True)
        quality_data.dropna(axis=0, how='any', inplace=True)
        print(f"quality_data: {quality_data}")

        # 第2步，数据类型转换
        # control_data = control_data.astype(str)
        # control_data['date_only'] = control_data['DateTime'].str[:10]
        # duplicated_groups = control_data.groupby('date_only').filter(lambda group: len(group) == 360)
        # control_data = duplicated_groups.loc[:, name_list1]
        # control_data.reset_index(inplace=True)
        control_data['Date'] = control_data['DateTime'].dt.date
        control_data['Hour'] = control_data['DateTime'].dt.hour
        grouped = control_data.groupby(['Date', 'Hour']).size().reset_index(name='counts')
        filtered = grouped[grouped['counts'] == x_length]
        filtered_data = control_data.merge(filtered[['Date', 'Hour']], on=['Date', 'Hour'])  # noqa: F841
        # name_list1.insert(0, 'DateTime')
        # control_data = filtered_data.loc[:, name_list1]

        # 提取在时间范围内的所有行并将其添加到 combined_result 中
        input_data_matched = pd.DataFrame()  # input的拼接结果
        output_data_matched = pd.DataFrame()  # output的拼接结果
        # control_data["DateTime"] = control_data["DateTime"].str.replace(" ", "")
        time_format1 = "%Y%m%d%H%M%S"  # noqa: F841
        time_format2 = "%Y%m%d%H"
        # control_data["DateTime"] = pd.to_datetime(control_data["DateTime"], format=time_format1)
        # 先将quality_data中的tagTime列转换为int类型，然后再转换为datetime类型
        quality_data["tagTime"] = quality_data["tagTime"].astype(int)
        quality_data["tagTime"] -= 1
        quality_data["tagTime"] = pd.to_datetime(quality_data["tagTime"].astype(str), format=time_format2)
        # 提取 tagTime 前若干个小时的时间
        # tag_times = quality_data["tagTime"].unique()
        # 定义时间段长度
        time_delta = pd.to_timedelta(match_type)

        # 将每一个TagTime和DateTime时间戳进行匹配
        for i in range(len(quality_data)):
            # 提取quality_data中的tagTime和质量指标
            data = quality_data.iloc[i, :]
            tagTime = data["tagTime"]
            quality_value = data.iloc[-1]  # noqa: F841

            start_time = tagTime
            end_time = tagTime + time_delta
            # 提取时间段内的质量指标
            mask = (control_data["DateTime"] >= start_time) & (control_data["DateTime"] < end_time)
            try:
                controller_data_match = control_data.loc[mask]
            except Exception as e:
                print(f"控制器数据库中没有与质检表中时间戳{tagTime}对应的数据:{e}")
                continue

            # 判断匹配的数据量是否符合要求，不符合要求则补全
            if len(controller_data_match) != x_length:
                if len(controller_data_match) >= x_length * 0.8:
                    controller_data_match = self.fill_missing_minutes(controller_data_match)
                else:
                    continue

            input_data_matched = pd.concat([input_data_matched, controller_data_match], ignore_index=True)
            data = pd.DataFrame([data.to_dict()])  # 将data从series转换为dataframe
            output_data_matched = pd.concat([output_data_matched, data], axis=0, ignore_index=True)

        # 将input_data_matched和output_data_matched转换为pl.DataFrame
        self.input_data = pl.from_pandas(input_data_matched)
        # 选择name_list1中的列
        self.input_data = self.input_data.select(name_list1)
        self.output_data = pl.from_pandas(output_data_matched)
        # 选择name_list2中的列
        self.output_data = self.output_data.select(name_list2)

        # 打印输入样本表
        print("Input Sample Table is:")
        print(self.input_data)
        # 打印输出样本表
        print("Output Sample Table is:")
        print(self.output_data)
        print("质检表数据匹配成功!!!")

    @staticmethod
    def delete_time(df: pl.dataframe) -> pl.dataframe:
        """
        删除时间列
        """
        if "DateTime" in df.columns:
            df = df.drop("DateTime")
        if "tagTime" in df.columns:
            df = df.drop("tagTime")
        return df

    # 数据分析 TODO
    def data_analysis(self) -> None:
        """
        数据分析,分析中位数等数据并绘制图表
        """
        print("开始进行数据分析并绘图!!!")
        # 记录数据集中的数据分布情况
        print("输入数据集中的数据分布情况:")
        print(self.input_data.describe())
        print("输出数据集中的数据分布情况:")
        print(self.output_data.describe())

    def run(self) -> Tuple[pl.dataframe, pl.dataframe]:
        """
        运行数据预处理主程序
        """
        preprocess_flag = True
        # preprocess_flag = False
        if preprocess_flag:
            self.missed_data_handle()
            self.abnormal_data_handle()
            self.moving_average()
            if "tagTime" in self.output_data.columns:
                self.match_data_quality()
            else:
                self.match_data_control()
        else:
            pass
        self.input_data = self.delete_time(self.input_data)
        self.output_data = self.delete_time(self.output_data)
        self.data_analysis()
        return self.input_data, self.output_data

    # def run(self) -> Tuple[pl.dataframe, pl.dataframe]:
    #     """
    #     运行数据预处理主程序
    #     """
    #     self.missed_data_handle()
    #     self.abnormal_data_handle()

    #     if "tagTime" in self.output_data.columns:
    #         self.match_data_quality()
    #     else:
    #         self.match_data_control()

    #     self.moving_average()
    #     self.input_data = self.delete_time(self.input_data)
    #     self.output_data = self.delete_time(self.output_data)
    #     self.data_analysis()
    #     return self.input_data, self.output_data


# 异常数据处理
# def abnormal_data_handle(df: pl.DataFrame, abnormal_data_list: list) -> pl.DataFrame:
#     """
#     异常数据处理
#     Args:
#         df (pl.DataFrame): 原始数据
#         abnormal_data_list (list): 异常数据列表
#     Returns:
#         pl.DataFrame: 处理后的数据
#     """
#     for data in abnormal_data_list:
#         if len(data) == 2:
#             df = df[~df[data[0]].isin([data[1]])]
#         elif len(data) == 3:
#             df = df[~(df[data[0]] > data[1]) & ~(df[data[0]] < data[2])]
#     return df


class TransformerDataFramePreprocess(DataFramePreprocess):
    def __init__(self, input_data: pl.DataFrame, output_data: pl.DataFrame):
        """
        数据预处理类,主要包含输入、输出数据

        Args:
            input_data (pl.DataFrame): _description_
            output_data (pl.DataFrame): _description_
        """
        super().__init__(input_data, output_data)

    def run(self) -> Tuple[pl.DataFrame, pl.DataFrame]:
        """
        运行数据预处理主程序
        和常规的区别不删除时间列！！！
        """
        self.missed_data_handle()
        self.abnormal_data_handle()
        self.moving_average()
        try:
            self.match_data_control()
        except Exception as e:
            print(f"匹配数据失败:{e},原始数据不需要进行数据匹配")
        self.data_analysis()
        return self.input_data, self.output_data


class ClassicDataFrameProcess(DataFramePreprocess):
    def __init__(self, input_data: pl.DataFrame, output_data: pl.DataFrame):
        """
        数据预处理类,主要包含输入、输出数据

        Args:
            input_data (pl.DataFrame): _description_
            output_data (pl.DataFrame): _description_
        """
        super().__init__(input_data, output_data)

    def run(self) -> Tuple[pl.DataFrame, pl.DataFrame]:
        """
        运行数据预处理主程序
        """
        self.missed_data_handle()
        self.abnormal_data_handle()

        # 计算每分钟平均值
        self.input_data = calculate_minute_average(self.input_data)

        # 删除连续重复的数据
        self.input_data = duplicate_filter(self.input_data)
        self.output_data = duplicate_filter(self.output_data)

        self.moving_average()
        
        if "tagTime" in self.output_data.columns:
            self.match_data_quality()
        else:
            self.match_data_control()

        self.input_data = self.delete_time(self.input_data)
        self.output_data = self.delete_time(self.output_data)
        self.data_analysis()
        return self.input_data, self.output_data

    def run_flag(self, preprocess_flag: bool = True) -> Tuple[pl.DataFrame, pl.DataFrame]:
        if preprocess_flag:
            self.missed_data_handle()
            self.abnormal_data_handle()

            # 计算每分钟平均值
            self.input_data = calculate_minute_average(self.input_data)
            # 删除连续重复的数据
            self.input_data = duplicate_filter(self.input_data)
            self.output_data = duplicate_filter(self.output_data)

            self.moving_average()

            if "tagTime" in self.output_data.columns:
                self.match_data_quality()
            else:
                self.match_data_control()
        else:
            pass

        self.input_data = self.delete_time(self.input_data)
        self.output_data = self.delete_time(self.output_data)

        self.data_analysis()
        return self.input_data, self.output_data

class SequenceDataFrameProcess(DataFramePreprocess):
    def __init__(self, input_data: pl.DataFrame, output_data: pl.DataFrame):
        """
        数据预处理类,主要包含输入、输出数据

        Args:
            input_data (pl.DataFrame): _description_
            output_data (pl.DataFrame): _description_
        """
        super().__init__(input_data, output_data)

    def run(self) -> Tuple[pl.DataFrame, pl.DataFrame]:
        """
        运行数据预处理主程序
        和常规的区别不删除时间列！！！
        """
        self.missed_data_handle()
        self.abnormal_data_handle()

        # 计算每分钟平均值
        self.input_data = calculate_minute_average(self.input_data)
        if "tagTime" in self.output_data.columns:
            pass
        elif "DateTime" in self.output_data.columns:
            self.output_data = calculate_minute_average(self.output_data)
        else:
            pass

        # 删除连续重复的数据
        self.input_data = duplicate_filter(self.input_data)
        self.output_data = duplicate_filter(self.output_data)

        self.moving_average()

        self.match_data_control()
        self.data_analysis()
        
        return self.input_data, self.output_data

