from .core import (
    get_trainer, get_realtime_predictor, get_decision_agent, build_background_tasks
)
from .utils.logutils import get_logger
from .utils.readconfig import read_config_toml
from .utils.database import database_builder
from .version import VERSION


def hello() -> str:
    return "Welcome to use industrytslib!"


__all__ = ["get_trainer", "get_realtime_predictor", "get_decision_agent", "build_background_tasks",
           "get_logger", "read_config_toml", "database_builder"]


hello()


__version__ = VERSION
