from .model_trainers import (
    TransformerTrainer, 
    SequenceTrainer, 
    ClassicTrainer, 
    ClassicTrainerAlter, 
    ClassicOnlineTrainer,
    GANTrainer,
    RLTrainer
)
from industrytslib.core.base import ScheduledTask, AsyncScheduledTask


def get_trainer(
        project_name: str, 
        dbconfig: dict, 
        model_type: str
    ) -> ScheduledTask|AsyncScheduledTask:
    """
    获取训练器,包括序列预测、GAN、RL等,返回一个ScheduledTask或AsyncScheduledTask对象
    Args:
        project_name: 项目名称
        dbconfig: 数据库配置
        model_type: 模型类型
    Returns:
        ScheduledTask|AsyncScheduledTask
    Examples:
        >>> from industrytslib.utils.readconfig import read_config_toml
        >>> config = read_config_toml("config/dbconfig.toml")
        >>> get_trainer("二线回转窑电耗样本_二线回转窑电耗样本_CNN", config, "classic_alter")
    """
    match model_type:
        case "transformer":
            return TransformerTrainer(project_name, dbconfig)
        case "sequence":
            return SequenceTrainer(project_name, dbconfig)
        case "classic":
            return ClassicTrainer(project_name, dbconfig)
        case "classic_alter":
            return ClassicTrainerAlter(project_name, dbconfig)
        case "classic_online":
            return ClassicOnlineTrainer(project_name, dbconfig)
        case "gan":
            return GANTrainer(project_name, dbconfig)
        case "rl":
            return RLTrainer(project_name, dbconfig)
        case _:
            raise ValueError(f"Unknown model type: {model_type}")
    