from .base import Database
from .mssql import (
    MSSQLWeb, MSSQLTimeSeries, MSSQLQuality, MSSQLOnlineTrainer,
    MSSQLRealtimePredict, MSSQLRealtimePredictAlter, MSSQLRealtimePredictSequence, 
    MSSQLDecisonHistory,
    MSSQLPredictionTransactionSource, MSSQLPredictionTransactionTarget,
    
    AsyncMSSQLQuality,
    AsyncMSSQLRealtimePredict, AsyncMSSQLRealtimePredictSequence,
    AsyncMSSQLTimeSeries, AsyncMSSQLWeb,
    AsyncMSSQLDecisionHistory, AsyncMSSQLPredictionTransactionSource, AsyncMSSQLPredictionTransactionTarget
)
from .sqlite import ModelParameterSqlite
from .influxdb import InfluxDB, InfluxdbSequence
from .postgresql import PostgreSQLConnection, PostgreSQLTimeseries, PostgreSQLWeb


def database_builder(config: dict) -> Database:
    """
    Build a database based on the provided configuration.

    Args:
        config (dict): Configuration dictionary containing database-specific parameters.

    Returns:
        Database: An instance of the database class based on the configuration.
    """
    match config["type"]:
        case "mssql":
            match config["target"]:
                case "web":
                    return MSSQLWeb(config)
                case "online_trainer":
                    return MSSQLOnlineTrainer(config)
                case "timeseries":
                    return MSSQLTimeSeries(config)
                case "quality":
                    return MSSQLQuality(config)
                case "realtime_predict":
                    return MSSQLRealtimePredict(config)
                case "realtime_predict_alter":
                    return MSSQLRealtimePredictAlter(config)
                case "realtime_predict_sequence":
                    return MSSQLRealtimePredictSequence(config)
                case "decision_history":
                    return MSSQLDecisonHistory(config)
                case "predict_transaction_source":
                    return MSSQLPredictionTransactionSource(config)
                case "predict_transaction_target":
                    return MSSQLPredictionTransactionTarget(config)
                case _:
                    raise ValueError(f"Unsupported database target: {config['target']}")
        case "async_mssql":
            match config["target"]:
                case "web":
                    return AsyncMSSQLWeb(config)
                case "timeseries":
                    return AsyncMSSQLTimeSeries(config)
                case "quality":
                    return AsyncMSSQLQuality(config)
                case "realtime_predict":
                    return AsyncMSSQLRealtimePredict(config)
                case "realtime_predict_sequence":
                    return AsyncMSSQLRealtimePredictSequence(config)
                case "decision_history":
                    return AsyncMSSQLDecisionHistory(config)
                case "predict_transaction_source":
                    return AsyncMSSQLPredictionTransactionSource(config)
                case "predict_transaction_target":
                    return AsyncMSSQLPredictionTransactionTarget(config)
                case _:
                    raise ValueError(f"Unsupported database target: {config['target']}")
        case "mongo":
            pass
        case "postgres":
            match config["target"]:
                case "base":
                    return PostgreSQLConnection(config)
                case "timeseries":
                    return PostgreSQLTimeseries(config)
                case "web":
                    return PostgreSQLWeb(config)
                case _:
                    raise ValueError(f"Unsupported database target: {config['target']}")
        case "sqlite":
            match config["target"]:
                case "model_info":
                    return ModelParameterSqlite(config)
                case _:
                    raise ValueError(f"Unsupported database target: {config['target']}")        
        case "influxdb":
            match config["target"]:
                case "sequence":
                    return InfluxdbSequence(config)
                case _:
                    return InfluxDB(config)
        case _:
            raise ValueError(f"Unsupported database type: {config['type']}")
        