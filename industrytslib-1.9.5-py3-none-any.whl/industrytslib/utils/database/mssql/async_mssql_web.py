import re
import polars as pl
from typing import Tuple, List

from .async_mssql_base import AsyncMSSQLConnection
from industrytslib.utils.logutils import get_logger
from industrytslib.utils.basefunc import prediction_parameter_parser, name_list_parser


class AsyncMSSQLWeb(AsyncMSSQLConnection):
    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self.logger = get_logger("AsyncMSSQLWeb", "database")

    async def get_prediction_info(self, project_name: str) -> Tuple[str, str]:
        """
        Get the prediction info of project name in table yunxing
        
        Args:
            project_name (str): Name of the project
            
        Returns:
            Tuple[str, str]: (sample_name, algorithm_name)
        """
        sql_prediction_info = f"SELECT * FROM yunxing WHERE sampletable_name = '{project_name}'"
        rows = await self.query(sql_prediction_info)
        sample_name = rows["yangben"].item()
        model_name = rows["moxing"].item()
        self.logger.info(f"Sample name: {sample_name}, algorithm name: {model_name}")
        return sample_name, model_name 

    async def get_model_parameter(self, model_name: str) -> Tuple[str, dict]:
        """
        Get the parameter of the model

        Args:
            model_name (str): model name

        Returns:
            Tuple[str, dict]: (algorithm_name, parameter_dict)
        """
        sql = f"SELECT * FROM algoone WHERE project_name = '{model_name}'"
        rows = await self.query(sql)
        algorithm_name = rows["model_name"].item()
        parameter_str = rows["parameter"].item()
        parameter = prediction_parameter_parser(parameter_str)
        self.logger.info(f"The parameter of model {model_name} is: {parameter}")
        return algorithm_name, parameter
    
    async def get_sample_table_information(self, sample_name: str) -> pl.DataFrame:
        """
        从Web数据库获取样本表信息。

        Args:
            sample_name (str): 样本名称，用于查询对应的样本表信息。

        Returns:
            pl.DataFrame: 包含样本数据时间范围信息的polars DataFrame对象。
        """
        sql_time_range = f"SELECT * FROM [dbo].[sampletablezong] WHERE sample_table = '{sample_name}'"
        sample_table_info = await self.query(sql_time_range)
        self.logger.info(f"sample table information of {sample_name}: {sample_table_info}")
        return sample_table_info
    
    async def _get_sample_table_input_name(self, sample_name: str) -> List[str]:
        """
        Get the input name of sample table.
        
        Args:
            sample_name (str): Sample name.
            
        Returns:
            List[str]: Input names of sample table.
        """
        sample_table_info = await self.get_sample_table_information(sample_name)
        input_name_str = sample_table_info["column_namein"][0]
        input_name_list = name_list_parser(input_name_str)
        return input_name_list

    async def get_optimization_info(self, project_name: str) -> Tuple[pl.DataFrame, pl.DataFrame, List[str], List[str], List[List[str]]]:
        """
        Get the optimization information of project name in table optimization
        
        Args:
            project_name (str): Name of the project
            
        Returns:
            Tuple containing:
                optimization_arguments (pl.DataFrame): 优化模型使用的参数
                optimization_constraints (pl.DataFrame): 优化模型使用的约束
                prediction_model_table_list (List[str]): 预测模型的样本表名列表
                prediction_model_list (List[str]): 预测模型名列表
                input_name_list (List[List[str]]): 优化模型使用的输入变量列表
        """
        # 1. get optimization arguments
        sql_optimization_arguments = f"""
            SELECT * FROM [dbo].[optimization] 
            WHERE optimization_project_name = '{project_name}'
        """
        optimization_arguments = await self.query(sql_optimization_arguments)
        self.logger.info(f"optimization arguments of {project_name}: {optimization_arguments}")

        # 2. get optimization constraints
        sql_constraints = f"""
            SELECT bianliang FROM [dbo].[optimization] 
            WHERE optimization_project_name = '{project_name}'
        """
        constraints_rows = await self.query(sql_constraints)
        constraints_str = constraints_rows["bianliang"].to_list()[0]
        
        # 使用正则表达式提取数据
        pattern = re.compile(r'([^, ]+?): min: (-?\d+\.?\d*) max: (-?\d+\.?\d*)', re.UNICODE)
        constraint_data = []
        for match in pattern.finditer(constraints_str):
            name, min_val, max_val = match.groups()
            constraint_data.append({
                'variable': name,
                'min': float(min_val),
                'max': float(max_val)
            })
        optimization_constraints = pl.DataFrame(constraint_data)
        self.logger.info(f"optimization constraints of {project_name}: {optimization_constraints}")

        # get prediction model used by optimization 
        optimization_prediction_model = optimization_arguments["prediction_model"].to_list()[0].split(',')
        prediction_model_table_list = []  # 预测模型的样本表名
        prediction_model_list = []  # 预测模型的模型名
        
        for model_info in optimization_prediction_model:
            parts = model_info.strip().split('_')
            prediction_model_table_list.append(parts[0])
            prediction_model_list.append('_'.join(parts[1:3]))

        # 根据预测模型的样本表名获取要用到的变量名
        input_name_list = []
        for sample_name in prediction_model_table_list:
            input_name = await self._get_sample_table_input_name(sample_name)
            input_name_list.append(input_name)

        self.logger.info(f"input name of {project_name}: {input_name_list}")
        return (optimization_arguments, optimization_constraints, prediction_model_table_list, 
                prediction_model_list, input_name_list)
    