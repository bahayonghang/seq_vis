import numpy as np
import polars as pl
import torch
import pickle

from pathlib import Path

from pymoo.core.problem import ElementwiseProblem

from industrytslib.utils.data_processing.polarsoperation import data_joint_decision


# 目标函数范式，根据function_type选择函数模式并输入x
def objective_function(function_type: int, x: list, *args):
    """
    函数定义这一块添加每一个多目标的物理意义
    param: function_type: 选择目标函数的种类 int
    param: x: 输入目标函数的变量(预测值) list
    return: y: 目标函数的输出值 list
    """
    y = []
    # y = x
    if function_type == "1":
        # 双目标的基本函数
        y.append(np.float64(x[0]))
        # y = |x - quality|
        y.append(abs(np.float64(x[1]) - args[0][0]))
    elif function_type == "2":
        # y = |x - quality|
        y.append(abs(np.float64(x[1]) - args[0][0]))
        y.append(np.float64(x[0]))
    elif function_type == "3":
        # 三目标：电耗、煤耗、质量
        y.append(np.float64(x[0]))
        y.append(np.float64(x[1]))
        # y = |x - quality|
        y.append(abs(np.float64(x[2]) - args[0][0]))
    else:
        y.append(0)
        print("目标函数类型错误，请检查输入！！！")
        pass
    return y


# 单目标优化目标函数
def single_objective_function(function_type, x, *args):
    if function_type == "1":
        y = np.float64(x[0])
    else:
        y = 0
        print("目标函数类型错误，请检查输入！！！")
        pass
    return y


def multi_optimization_objective_function(function_type: int, x: dict, *args):
    """
    函数定义这一块添加每一个多目标的物理意义
    param: function_type: 选择目标函数的种类 int
    param: x: 输入目标函数的变量(预测值) list
    return: y: 目标函数的输出值 list
    """ 
    assert type(function_type) is int and type(x) is dict, "function_type必须是int类型,x必须是dict类型"
    y = []
    match function_type:
        case 1:
            # 双目标的基本函数
            # 先判断字典x中有哪些key
            if "电耗" in x:
                y.append(x["电耗"])
            elif "煤耗" in x:
                y.append(x["煤耗"])
            elif "产量" in x:
                y.append(x["产量"])
            else:
                y.append(0)
                print("目标函数中没有电耗、煤耗、产量的预测值，请检查输入！！！")
            y.append(abs(np.float64(x["质量"]) - args[0][0]))
        case 2:
            # 回转窑三目标目标函数
            # 先判断字典x中有哪些key
            y.append(x["电耗"])
            y.append(x["煤耗"])
            y.append(abs(np.float64(x["质量"]) - args[0][0]))
        case 3:
            # 水泥磨三目标函数：电耗、细度、比表
            y.append(x["电耗"])
            # y.append(abs(np.float64(x["水泥细度"]) - 5.25))
            y.append(abs(np.float64(x["水泥细度"]) - args[0][1]))
            y.append(abs(np.float64(x["质量"]) - args[0][0]))
        case _:
            raise ValueError("目标函数类型错误，请检查输入！！！")
    return y


class DoubleProblemWithConstraint(ElementwiseProblem):
    def __init__(self, *args, n_var: int, n_obj: int, n_constr: int, xl: np.ndarray, xu: np.ndarray, 
                 model_name_list: list, model_list: list, x_length: list, decision_length: list, history_data_table_list: list, name_list: list,
                 input_name_list: list, function_type: int, history_data: list):
        """
        流程工业双目标优化问题的基类,约束为上下界定值约束
        参数说明：
        n_var: 变量的个数
        n_obj: 目标函数的个数
        n_constr: 约束的个数
        n_ieq_constr: 不等式约束的个数
        xl: 变量的下界
        xu: 变量的上界
        model_name_list: 预测模型名称列表
        model_list: 预测模型列表
        x_length: 预测用到的历史数据的长度（从预测数据库中读取）
        decision_length: 决策的长度（从优化数据库中读取）
        history_data_table: 历史数据表名（从优化数据库中读取）
        time_query: 历史数据的时间间隔
        name_list: 优化求解时从数据库中取出历史数据的列名,理论上name_list应该等于input_name_list的每一个列表项合并后去除重复项后的结果
        input_name_list: 优化求解时不同预测模型用到的输入列名
        """
        super().__init__(n_var=n_var, n_obj=n_obj, n_constr=n_constr, xl=xl, xu=xu)
        self.model_name_list = model_name_list
        self.scaler_x_path = []
        self.scaler_y_path = []
        for i in range(len(self.model_name_list)):
            self.scaler_x_path.append(Path("resource/scaler", self.model_name_list[i], "scaler_x.pkl"))
            self.scaler_y_path.append(Path("resource/scaler", self.model_name_list[i], "scaler_y.pkl"))
        self._get_scaler()

        self.model_list = model_list
        self.x_length = x_length
        self.decision_length = decision_length  # 决策长度暂时是用分钟来计算
        self.history_length = []  # 优化求解时从数据库中取出的历史数据的长度
        for i in range(len(self.x_length)):
            self.history_length.append(self.x_length[i] - self.decision_length)
        self.history_data_table_list = history_data_table_list  # 优化求解时从数据库中取出历史数据
        self.name_list = name_list  # 优化求解时从数据库中取出历史数据的变量名列表
        self.input_name_list = input_name_list
        self.function_type = function_type  # 目标函数的类型
        self.args = args  # 目标函数的其他参数

        self.history_data = history_data

        # 目标值字典初始化
        self.obj_dict = {}
        for item in self.model_name_list:
            for keyword in ["电耗", "煤耗", "产量"]:
                if keyword in item:
                    self.obj_dict[keyword] = 0
            if any(keyword in item for keyword in ["fcao", "比表面积", "生料细度"]):
                self.obj_dict["质量"] = 0

    # 获取归一化用到的scaler
    def _get_scaler(self):
        self.scaler_x = []
        self.scaler_y = []
        for i in range(len(self.model_name_list)):
            with open(self.scaler_x_path[i], 'rb') as f:
                self.scaler_x.append(pickle.load(f))
            with open(self.scaler_y_path[i], 'rb') as f:
                self.scaler_y.append(pickle.load(f))

    def _evaluate(self, x, out, *args, **kwargs):
        # 将x转换成dataframe格式，方便通过列名取值
        x = pl.DataFrame(x[np.newaxis, :])
        x.columns = self.name_list
        # 将历史数据和新生成的随机数据x拼接，历史数据是一个length*n_var的dataframe格式的数据，表示过去时长为length的n_var个变量的历史数据，拼接随机生成的10min的数据
        # x是一个predict_length*n_var的ndarray格式的数据
        # length + predict_length = x_length(预测时用到的历史数据的长度)
        # self.history_data = []
        # for i in range(len(self.model_name_list)):
        #     self.history_data.append(query_history_data_by_name(self.history_data_table_list[i], self.history_length[i]))

        # 输入归一化
        prediction_data = []
        for i in range(len(self.model_name_list)):
            data_joint = data_joint_decision(self.history_data[i], x, self.decision_length)
            # 按照input_name_list重新排序
            data_joint = data_joint.select(self.input_name_list[i])
            prediction_data.append(self.scaler_x[i].transform(data_joint))

        # 将输入数据送到预测模型后得到的预测值
        # TODO 设计多步预测的评价模型
        prediction = []
        for i in range(len(self.model_name_list)):
            # prediction.append(
            #     self.model_list[i](torch.tensor(prediction_data[i]).to(torch.float32)).detach().numpy().reshape(-1, 1))
            prediction.append(self.model_list[i](torch.tensor(prediction_data[i]).unsqueeze(0).float()))

        # 输出反归一化
        for i in range(len(self.model_name_list)):
            try:
                prediction[i] = self.scaler_y[i].inverse_transform(prediction[i].detach().numpy()[0][0])
            except ValueError:
                prediction[i] = self.scaler_y[i].inverse_transform(prediction[i].detach().numpy())
        try:
            prediction = [item[0][0] for item in prediction]  # 去除prediction列表中多余的括号（嵌套列表）
        except IndexError:
            print("prediction列表中没有多余的括号(嵌套列表)")
        # 目标函数方程，f1为电耗，f2为比表
        # f1 = prediction1.item()
        # f2 = abs(prediction2-350).item()
        # f1 = np.float64(prediction1[0])
        # f2 = abs(np.float64(prediction2[0])-350)
        # 自动识别机制，自动匹配电耗、煤耗、质量、产量的预测值
        for i in range(len(prediction)):
            for keyword in ["电耗", "煤耗", "产量"]:
                if keyword in self.model_name_list[i]:
                    self.obj_dict[keyword] = prediction[i]
            if any(keyword in self.model_name_list[i] for keyword in ["fcao", "比表面积", "生料细度", "煤粉细度", "煤磨细度"]):
                self.obj_dict["质量"] = prediction[i]
            if "水泥A磨细度" or "水泥B磨细度" in self.model_name_list[i]:
                self.obj_dict["水泥细度"] = prediction[i]

        # obj_value = objective_function(self.function_type, prediction, self.args)
        obj_value = multi_optimization_objective_function(self.function_type, self.obj_dict, self.args)
        # TODO 添加不等式约束
        # TODO 在优化算法中添加数字孪生模型，确保求出来的解符合实际工况
        out["F"] = obj_value


# 单目标优化问题
class SingleProblemWithConstraint(ElementwiseProblem):
    def __init__(self, *args, n_var: int, n_obj: int, n_constr: int, xl: np.ndarray, xu: np.ndarray, model_name_list: list,
                 model_list: list, x_length: list, decision_length: list, history_data_table_list: list, name_list: list,
                 input_name_list: list, function_type: int, history_data: list):
        """
        流程工业单目标优化问题的基类,约束为上下界定值约束
        参数说明：
        n_var: 变量的个数
        n_obj: 目标函数的个数
        n_constr: 约束的个数
        n_ieq_constr: 不等式约束的个数
        xl: 变量的下界
        xu: 变量的上界
        model_name_list: 预测模型名称列表
        model_list: 预测模型列表
        x_length: 预测用到的历史数据的长度（从预测数据库中读取）
        decision_length: 决策的长度（从优化数据库中读取）
        history_data_table: 历史数据表名（从优化数据库中读取）
        time_query: 历史数据的时间间隔
        name_list: 优化求解时从数据库中取出历史数据的列名,理论上name_list应该等于input_name_list的每一个列表项合并后去除重复项后的结果
        input_name_list: 优化求解时不同预测模型用到的输入列名
        """
        super().__init__(n_var=n_var, n_obj=n_obj, n_constr=n_constr, xl=xl, xu=xu)
        self.model_name_list = model_name_list
        self.scaler_x_path = []
        self.scaler_y_path = []
        for i in range(len(self.model_name_list)):
            self.scaler_x_path.append(Path("resource/scaler", self.model_name_list[i], "scaler_x.pkl"))
            self.scaler_y_path.append(Path("resource/scaler", self.model_name_list[i], "scaler_y.pkl"))
        self._get_scaler()

        self.model_list = model_list
        self.x_length = x_length
        self.decision_length = decision_length  # 决策长度暂时是用分钟来计算
        self.history_length = []  # 优化求解时从数据库中取出的历史数据的长度
        for i in range(len(self.x_length)):
            self.history_length.append(self.x_length[i] - self.decision_length)
        self.history_data_table_list = history_data_table_list  # 优化求解时从数据库中取出历史数据
        self.name_list = name_list  # 优化求解时从数据库中取出历史数据的变量名列表
        self.input_name_list = input_name_list
        self.function_type = function_type  # 目标函数的类型
        self.args = args  # 目标函数的其他参数

        self.history_data = history_data

    # 获取归一化用到的scaler
    def _get_scaler(self):
        self.scaler_x = []
        self.scaler_y = []
        for i in range(len(self.model_name_list)):
            with open(self.scaler_x_path[i], 'rb') as f:
                self.scaler_x.append(pickle.load(f))
            with open(self.scaler_y_path[i], 'rb') as f:
                self.scaler_y.append(pickle.load(f))

    def _evaluate(self, x, out, *args, **kwargs):
        # 将x转换成dataframe格式，方便通过列名取值
        x = pl.DataFrame(x[np.newaxis, :])
        x.columns = self.name_list
        # 将历史数据和新生成的随机数据x拼接，历史数据是一个length*n_var的dataframe格式的数据，表示过去时长为length的n_var个变量的历史数据，拼接随机生成的10min的数据
        # x是一个predict_length*n_var的ndarray格式的数据
        # length + predict_length = x_length(预测时用到的历史数据的长度)
        # self.history_data = []
        # for i in range(len(self.model_name_list)):
        #     self.history_data.append(query_history_data_by_name(self.history_data_table_list[i], self.history_length[i]))

        # 输入归一化
        prediction_data = []
        for i in range(len(self.model_name_list)):
            data_joint = data_joint_decision(self.history_data[i], x, self.decision_length)
            # 按照input_name_list重新排序
            data_joint = data_joint.select(self.input_name_list[i])
            prediction_data.append(self.scaler_x[i].transform(data_joint))

        # 将输入数据送到预测模型后得到的预测值
        # TODO 设计多步预测的评价模型
        prediction = []
        for i in range(len(self.model_name_list)):
            # prediction.append(
            #     self.model_list[i](torch.tensor(prediction_data[i]).to(torch.float32)).detach().numpy().reshape(-1, 1))
            prediction.append(self.model_list[i](torch.tensor(prediction_data[i]).unsqueeze(0).float()))

        # 输出反归一化
        for i in range(len(self.model_name_list)):
            try:
                prediction[i] = self.scaler_y[i].inverse_transform(prediction[i].detach().numpy()[0][0])
            except ValueError:
                prediction[i] = self.scaler_y[i].inverse_transform(prediction[i].detach().numpy())
        try:
            prediction = [item[0][0] for item in prediction]  # 去除prediction列表中多余的括号（嵌套列表）
        except IndexError:
            print("prediction列表中没有多余的括号(嵌套列表)")

        # obj_value = objective_function(self.function_type, prediction, self.args)
        obj_value = single_objective_function(self.function_type, prediction, self.args)
        # TODO 添加不等式约束
        # TODO 在优化算法中添加数字孪生模型，确保求出来的解符合实际工况
        out["F"] = obj_value


class ThreeObjCementProblem(ElementwiseProblem):
    def __init__(self, *args, n_var: int, n_obj: int, n_constr: int, xl: np.ndarray, xu: np.ndarray,
                 model_name_list: list, model_list: list, x_length: list, decision_length: list, history_data_table_list: list, name_list: list,
                 input_name_list: list, function_type: int, history_data: list):
        """
        流程工业双目标优化问题的基类,约束为上下界定值约束
        参数说明：
        n_var: 变量的个数
        n_obj: 目标函数的个数
        n_constr: 约束的个数
        n_ieq_constr: 不等式约束的个数
        xl: 变量的下界
        xu: 变量的上界
        model_name_list: 预测模型名称列表
        model_list: 预测模型列表
        x_length: 预测用到的历史数据的长度（从预测数据库中读取）
        decision_length: 决策的长度（从优化数据库中读取）
        history_data_table: 历史数据表名（从优化数据库中读取）
        time_query: 历史数据的时间间隔
        name_list: 优化求解时从数据库中取出历史数据的列名,理论上name_list应该等于input_name_list的每一个列表项合并后去除重复项后的结果
        input_name_list: 优化求解时不同预测模型用到的输入列名
        """
        super().__init__(n_var=n_var, n_obj=n_obj, n_constr=n_constr, xl=xl, xu=xu)
        self.model_name_list = model_name_list
        self.scaler_x_path = []
        self.scaler_y_path = []
        for i in range(len(self.model_name_list)):
            self.scaler_x_path.append(Path("resource/scaler", self.model_name_list[i], "scaler_x.pkl"))
            self.scaler_y_path.append(Path("resource/scaler", self.model_name_list[i], "scaler_y.pkl"))
        self._get_scaler()

        self.model_list = model_list
        self.x_length = x_length
        self.decision_length = decision_length  # 决策长度暂时是用分钟来计算
        self.history_length = []  # 优化求解时从数据库中取出的历史数据的长度
        for i in range(len(self.x_length)):
            self.history_length.append(self.x_length[i] - self.decision_length)
        self.history_data_table_list = history_data_table_list  # 优化求解时从数据库中取出历史数据
        self.name_list = name_list  # 优化求解时从数据库中取出历史数据的变量名列表
        self.input_name_list = input_name_list
        self.function_type = function_type  # 目标函数的类型
        self.args = args  # 目标函数的其他参数

        self.history_data = history_data

        # 目标值字典初始化
        self.obj_dict = {}
        for item in self.model_name_list:
            for keyword in ["电耗", "煤耗", "产量"]:
                if keyword in item:
                    self.obj_dict[keyword] = 0
            if any(keyword in item for keyword in ["fcao", "比表面积", "生料细度", "煤磨细度"]):
                self.obj_dict["质量"] = 0

    # 获取归一化用到的scaler
    def _get_scaler(self):
        self.scaler_x = []
        self.scaler_y = []
        for i in range(len(self.model_name_list)):
            with open(self.scaler_x_path[i], 'rb') as f:
                self.scaler_x.append(pickle.load(f))
            with open(self.scaler_y_path[i], 'rb') as f:
                self.scaler_y.append(pickle.load(f))

    def _evaluate(self, x, out, *args, **kwargs):
        # 将x转换成dataframe格式，方便通过列名取值
        x = pl.DataFrame(x[np.newaxis, :])
        x.columns = self.name_list
        # 将历史数据和新生成的随机数据x拼接，历史数据是一个length*n_var的dataframe格式的数据，表示过去时长为length的n_var个变量的历史数据，拼接随机生成的10min的数据
        # x是一个predict_length*n_var的ndarray格式的数据
        # length + predict_length = x_length(预测时用到的历史数据的长度)
        # self.history_data = []
        # for i in range(len(self.model_name_list)):
        #     self.history_data.append(query_history_data_by_name(self.history_data_table_list[i], self.history_length[i]))

        # 输入归一化
        prediction_data = []
        for i in range(len(self.model_name_list)):
            data_joint = data_joint_decision(self.history_data[i], x, self.decision_length)
            # 按照input_name_list重新排序
            data_joint = data_joint.select(self.input_name_list[i])
            prediction_data.append(self.scaler_x[i].transform(data_joint))

        # 将输入数据送到预测模型后得到的预测值
        # TODO 设计多步预测的评价模型
        prediction = []
        for i in range(len(self.model_name_list)):
            # prediction.append(
            #     self.model_list[i](torch.tensor(prediction_data[i]).to(torch.float32)).detach().numpy().reshape(-1, 1))
            prediction.append(self.model_list[i](torch.tensor(prediction_data[i]).unsqueeze(0).float()))

        # 输出反归一化
        for i in range(len(self.model_name_list)):
            try:
                prediction[i] = self.scaler_y[i].inverse_transform(prediction[i].detach().numpy()[0][0])
            except ValueError:
                prediction[i] = self.scaler_y[i].inverse_transform(prediction[i].detach().numpy())
        try:
            prediction = [item[0][0] for item in prediction]  # 去除prediction列表中多余的括号（嵌套列表）
        except IndexError:
            print("prediction列表中没有多余的括号(嵌套列表)")
        # 目标函数方程，f1为电耗，f2为比表
        # f1 = prediction1.item()
        # f2 = abs(prediction2-350).item()
        # f1 = np.float64(prediction1[0])
        # f2 = abs(np.float64(prediction2[0])-350)
        # 自动识别机制，自动匹配电耗、煤耗、质量、产量的预测值
        for i in range(len(prediction)):
            for keyword in ["电耗", "煤耗", "产量"]:
                if keyword in self.model_name_list[i]:
                    self.obj_dict[keyword] = prediction[i]
            if any(keyword in self.model_name_list[i] for keyword in ["fcao", "比表面积", "生料细度", "煤粉细度", "煤磨细度"]):
                self.obj_dict["质量"] = prediction[i]
            if "水泥A磨细度" or "水泥B磨细度" in self.model_name_list[i]:
                self.obj_dict["水泥细度"] = prediction[i]

        # obj_value = objective_function(self.function_type, prediction, self.args)
        obj_value = multi_optimization_objective_function(self.function_type, self.obj_dict, self.args)
        # TODO 添加不等式约束
        # TODO 在优化算法中添加数字孪生模型，确保求出来的解符合实际工况
        out["F"] = obj_value
