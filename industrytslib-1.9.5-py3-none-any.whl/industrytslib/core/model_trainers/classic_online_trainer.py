import pickle
import progressbar
import time
import torch

import numpy as np

from pathlib import Path
from typing import Tuple
from tqdm import trange
from torch.utils.data import DataLoader, Dataset
from torchinfo import summary

from .basic_trainer import ModelTrainer
from industrytslib.utils.basefunc import get_current_time
from industrytslib.utils.data_processing.data_provider import data_provider_builder
from industrytslib.models.aimodels.utils.metrics import metric_classic
from industrytslib.utils.data_processing.data_preprocess import ClassicDataFrameProcess
from industrytslib.utils.database import database_builder
from industrytslib.utils.basefunc import split_sample_and_model


class ClassicOnlineTrainer(ModelTrainer):
    """
    Trainer for classic models, including lstm, gru, etc.
    """
    def __init__(self, project_name: str, dbconfig: dict) -> None:
        super().__init__(project_name, dbconfig)
    
    def database_connection(self) -> None:
        # Database connection(if you need train offline, just comment thre follow 2 lines)
        if self.run_mode == "online":
            self.web_mssql_client = database_builder(self.dbconfig["mssql"]["web"])
            self.ts_mssql_client = database_builder(self.dbconfig["mssql"]["timeseries"])
            self.online_trainer_mssql_client = database_builder(self.dbconfig["mssql"]["online_trainer"])
        else:
            pass

        try:
            self.sample_name, self.model_name = self.web_mssql_client.get_prediction_info(self.project_name)
            self.logger.info(f"Get sample name and model name from project name {self.project_name} successfully!!!")
            self.logger.info(f"Sample name: {self.sample_name}, model name: {self.model_name}!!!")
        except Exception as e:
            self.logger.error(f"Get prediction info from web mssql database failed: {e}")
            self.logger.error(f"Please check the project name {self.project_name} in web mssql database!!!")
            self.sample_name, self.model_name = split_sample_and_model(self.project_name)
            self.logger.info(f"Get sample name and model name from project name {self.project_name} successfully!!!")
            self.logger.info(f"Sample name: {self.sample_name}, model name: {self.model_name}!!!")
            # raise e

        self.sample_table_in_name = self.sample_name + "_in"  # input table(view) name
        self.sample_table_out_name = self.sample_name + "_out"  # output table(view) name
    
    def _get_data(self, flag) -> Tuple[Dataset, DataLoader, Dataset, DataLoader]:
        data_set, data_loader = data_provider_builder(self.project_name, [self.data_input, self.data_output], 
                                                      self.output_flag,self.model_parameter, flag)
        return data_set, data_loader

    def vali(self, vali_loader: DataLoader, criterion: torch.nn.Module) -> float:
        """
        验证模型。

        Args:
            vali_loader (DataLoader): 验证集的数据
            criterion (torch.nn.Module): 损失函数

        Returns:
            float: 验证集损失
        """
        vali_loss_list = []
        self.model.eval()
        with torch.no_grad():
            for i, (batch_x, batch_y) in enumerate(vali_loader):
                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.float().to(self.device)
                y_pred = self.model(batch_x)
                loss = criterion(y_pred, batch_y)
                vali_loss_list.append(loss.item())
        vali_loss = np.average(vali_loss_list)
        return vali_loss

    def train(self):
        """
        train model
        """
        # self.model加载历史模型
        self.model.load_state_dict(
            torch.load(
                Path(f"resource/models/{self.project_name}").joinpath("checkpoint.pth"), 
                weights_only=True
            )
        )

        # split data into train, vali and test
        train_data, train_loader = self._get_data("train")
        vali_data, vali_loader = self._get_data("val")

        # 先测试当前模型对当前数据的损失
        test_loss = self.test()
        self.logger.info(f"当前模型对当前数据的损失为: {test_loss:.4f}")

        self.logger.debug(f"Get train, vali and test data of {self.project_name} successfully!!!")

        with open(self.scaler_y_path, "rb") as f:
            self.scaler_y = pickle.load(f)
        
         # # 检查当前操作系统是否为Linux
        # is_linux = platform.system() == 'Linux'
        # # 在Linux上使用torch.compile优化模型
        # if is_linux:
        #     self.model = torch.compile(self.model, mode="max-autotune")
        #     self.logger.info("在Linux上使用torch.compile优化模型成功!")
        # set the criterion and optimizer
        self.criterion = self._set_criterion(self.model_parameter)
        self.optimizer = self._set_optimizer(self.model_parameter)

        # path for saving trained model
        trained_model_path = Path(f"resource/models/{self.project_name}")
        # judge if the trained model exists, if not then create the folder
        if not trained_model_path.exists():
            trained_model_path.mkdir(parents=True, exist_ok=True)

        train_bar = progressbar.ProgressBar(maxval=self.model_parameter["num_epochs"]).start()

        time_train_start = time.time()  # 开始训练的时间,用于计算训练所用的时间

        train_steps = len(train_loader)  # 计算训练用的步数

        train_loss_total_list = []  # 记录训练损失的列表,后续用于绘制训练损失曲线
        vali_loss_total_list = []  # 记录验证损失的列表,后续用于绘制验证损失曲线

        for epoch in trange(self.model_parameter["num_epochs"]):
            iter_count = 0  # 记录迭代次数
            train_loss_list = []  # 记录训练损失

            # true_train_list = []  # 记录真实值的列表
            # pred_train_list = []  # 记录预测值的列表

            self.model.train()
            epoch_time_start = time.time()  # 记录每个epoch开始的时间

            for i, (batch_x, batch_y) in enumerate(train_loader):
                iter_count +=1

                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.float().to(self.device)

                y_pred = self.model(batch_x)


                loss = self.criterion(y_pred, batch_y)
                # loss.requires_grad_(True)
                train_loss_list.append(loss.item())

                # true_train_list += (batch_y.detach().cpu().numpy().reshape(-1, 1).reshape(-1).tolist())
                # pred_train_list += (y_pred.detach().cpu().numpy().reshape(-1, 1).reshape(-1).tolist())

                self.optimizer.zero_grad()

                if iter_count % 100 == 0:
                    self.logger.debug(f"""
                        Epoch {epoch + 1} / {self.model_parameter['num_epochs']} 
                        Iteration {iter_count} / {train_steps}, 
                        Loss: {loss.item():.4f}
                    """)

                loss.backward()
                self.optimizer.step()

                # 休眠机制，用于多个模型同时训练时降低服务器压力
                time.sleep(5)
            
            # self.epoch_scheduler.step()

            train_bar.update(epoch + 1)
            # 训练到最后一个epoch则绘制训练结果图
            self.logger.debug(
                f"""
                    {self.project_name}:Epoch {epoch + 1} / {self.model_parameter['num_epochs']} 
                    cost time: {time.time() - epoch_time_start:.2f}
                """
            )

            epoch_time_end = time.time()  # 记录每个epoch结束的时间
            epoch_cost_time = epoch_time_end - epoch_time_start  # 计算每个epoch所用的时间
            self.logger.debug(f"Epoch {epoch + 1} / {self.model_parameter['num_epochs']} cost time: {epoch_cost_time:.2f}")

            train_loss = np.average(train_loss_list)  # 计算训练损失
            vali_loss = self.vali(vali_loader =vali_loader, criterion=self.criterion)  # 计算验证损失

            self.logger.debug(f"""
                            Epoch {epoch + 1} / {self.model_parameter['num_epochs']} 
                            train_loss: {train_loss:.4f}, vali_loss: {vali_loss:.4f}
                        """)

            self.writer.add_scalar("Loss/train", train_loss, epoch)
            self.writer.add_scalar("Loss/vali", vali_loss, epoch)

            train_loss_total_list.append(train_loss)  # 将训练损失加入到列表中
            vali_loss_total_list.append(vali_loss)  # 将验证损失加入到列表中

            # 判断loss比历史最低loss低，则保存模型
            # if vali_loss < test_loss:
            #     torch.save(self.model.state_dict(), trained_model_path.joinpath("checkpoint.pth"))

            # if (epoch + 1) % (self.model_parameter["num_epochs"] // 10) == 0:
            #     current_time = get_current_time()
            #     torch.save(self.model.state_dict(), 
            #                trained_model_path.joinpath(f"checkpoint_{epoch + 1}_{vali_loss:.4f}_{current_time}.pth"))\

        # 判断loss比历史最低loss低，则保存模型
        new_test_loss = self.test()
        # TODO 将loss保存到数据库中
        
        if new_test_loss < test_loss:
            torch.save(self.model.state_dict(), trained_model_path.joinpath(f"checkpoint_{get_current_time()}_{new_test_loss:.4f}.pth"))
        time_train_end = time.time()  # 结束训练的时间
        time_train = time_train_end - time_train_start  # 计算训练所用的时间
        self.logger.info(f"训练{self.project_name}模型成功,用时{time_train}s!")

        train_bar.finish()

        self.plotter.plot_loss(
            time_now=get_current_time(), 
            train_loss_list=train_loss_total_list, 
            vali_loss_list=vali_loss_total_list,
            save_path=self.train_result_path
        )
        self.logger.info(f"成功绘制{self.project_name}训练、验证损失曲线图！")

        torch.cuda.empty_cache()  # 清理cuda缓存

        self.online_trainer_mssql_client.insert_online_trainer_info(
            time_now=get_current_time(),
            project_name=self.project_name,
            epoch=self.model_parameter["num_epochs"],
            train_loss=train_loss,
            test_loss=vali_loss
        )

        return 
        
    def test(self, test=0) -> float:
        """
        test model
        """
        test_data, test_loader = self._get_data("test")
        self.logger.info(f"开始测试{self.project_name}模型！")

        if test == 1:
            self.logger.info("loading existing model!")
            self.model.load_state_dict(
                torch.load(
                    Path(f"resource/models/{self.project_name}").joinpath("checkpoint.pth"), 
                    weights_only=True
                )
            )

        with open(self.scaler_y_path, "rb") as f:
            self.scaler_y = pickle.load(f)

        self.model.eval()

        pred_test_list = []
        true_test_list = []

        with torch.no_grad():
            for i, (batch_x, batch_y) in enumerate(test_loader):
                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.float().to(self.device)
                y_pred = self.model(batch_x)
                true_test_list += (batch_y.detach().cpu().numpy().reshape(-1).tolist())
                pred_test_list += (y_pred.detach().cpu().numpy().reshape(-1).tolist())

        pred_test_array = np.array(pred_test_list)
        true_test_array = np.array(true_test_list)
        self.logger.info(f"true_test_array: {true_test_array} with shape: {true_test_array.shape}")
        self.logger.info(f"pred_test_array: {pred_test_array} with shape: {pred_test_array.shape}")
        pred_test_array = self.scaler_y.inverse_transform(pred_test_array.reshape(1, -1))
        true_test_array = self.scaler_y.inverse_transform(true_test_array.reshape(1, -1))

        time_now = get_current_time()
        self.plotter.plot_test_result(time_now=time_now,true_list=true_test_array.tolist()[0],
                                       pred_list=pred_test_array.tolist()[0], save_path=self.test_result_path)
        self.logger.info(f"绘制{self.project_name}测试结果图成功！")

        # 计算测试结果（误差）
        mae, mse, rmse, mape, mspe, r2 = metric_classic(
            torch.from_numpy(pred_test_array), 
            torch.from_numpy(true_test_array)
        )
        self.logger.info(
            f"""
            测试{self.project_name}模型得到的误差:
            mae={mae:.4f}, mse={mse:.4f}, rmse={rmse:.4f}, mape={mape:.4f}, 
            mspe={mspe:.4f}, r2={r2:.4f}
            """
        )
        
        # 保存测试结果,使用append模式,同时保存model_parameter
        with open(self.test_result_path.joinpath("test_result.txt"), "a") as f:
            f.write("="*50+"\n")
            f.write(f"{self.project_name}, {time_now}\n")
            f.write(f"model_parameter: {self.model_parameter}\n")
            f.write(f"mae={mae:.4f}, mse={mse:.4f}, rmse={rmse:.4f}, mape={mape:.4f}, mspe={mspe:.4f}, r2={r2:.4f}\n")
            f.write(f"checkpoint_path: {self.train_result_path.joinpath(f'checkpoint_{time_now}_mae_{mae:.4f}.pth')}\n")
            f.write("="*50+"\n")

        torch.cuda.empty_cache()  # 释放显存

        return mae

    def test_train(self, test=0) -> None:
        """
        test model
        """
        test_data, test_loader = self._get_data("train")
        self.logger.info(f"开始测试{self.project_name}模型！")

        if test == 1:
            self.logger.info("loading existing model!")
            self.model.load_state_dict(
                torch.load(
                    Path(f"resource/models/{self.project_name}").joinpath("checkpoint.pth"), 
                    weights_only=True
                )
            )

        with open(self.scaler_y_path, "rb") as f:
            self.scaler_y = pickle.load(f)

        self.model.eval()

        pred_test_list = []
        true_test_list = []

        with torch.no_grad():
            for i, (batch_x, batch_y) in enumerate(test_loader):
                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.float().to(self.device)
                y_pred = self.model(batch_x)
                true_test_list += (batch_y.detach().cpu().numpy().reshape(-1).tolist())
                pred_test_list += (y_pred.detach().cpu().numpy().reshape(-1).tolist())

        pred_test_array = np.array(pred_test_list)
        true_test_array = np.array(true_test_list)
        pred_test_array = self.scaler_y.inverse_transform(pred_test_array.reshape(1, -1))
        true_test_array = self.scaler_y.inverse_transform(true_test_array.reshape(1, -1))

        time_now = get_current_time()
        self.plotter.plot_test_result(time_now=time_now,true_list=true_test_array.tolist()[0], 
                                      pred_list=pred_test_array.tolist()[0], save_path=self.test_train_result_path)
        self.logger.info(f"绘制{self.project_name}测试结果图成功！")

                # 计算测试结果（误差）
        mae, mse, rmse, mape, mspe, r2 = metric_classic(
            torch.from_numpy(pred_test_array), 
            torch.from_numpy(true_test_array)
        )

        self.logger.info(
            f"""
                使用训练数据测试{self.project_name}模型得到的误差:
                mae={mae:.4f}, mse={mse:.4f}, rmse={rmse:.4f}, mape={mape:.4f}, 
                mspe={mspe:.4f}, r2={r2:.4f}
            """
        )
        
        # 保存测试结果,使用append模式,同时保存model_parameter
        with open(self.test_train_result_path.joinpath("test_train_result.txt"), "a") as f:
            f.write(f"{self.project_name}, {time_now}\n")
            f.write(f"model_parameter: {self.model_parameter}\n")
            f.write(f"mae={mae:.4f}, mse={mse:.4f}, rmse={rmse:.4f}, mape={mape:.4f}, mspe={mspe:.4f}, r2={r2:.4f}\n")

        torch.cuda.empty_cache()  # 释放显存
    
    def print_model_info_classic(self):
        input_size = (self.model_parameter['batch_size'], self.model_parameter['x_length'],
                       self.model_parameter['in_channels'])
        self.logger.info(f"input_size: {input_size}")
        summary(self.model, input_size=input_size)

    def plot_data_analysis(self) -> None:
        """
        绘制数据分析图表
        """
        # 绘制输入输出曲线
        self.plotter.plot_input_curve(input_df=self.data_input, save_path=self.train_result_path)
        self.plotter.plot_output_curve(output_df=self.data_output, save_path=self.train_result_path)
        self.logger.info(f"{self.project_name}的输入数据为：{self.data_input}")
        self.logger.info(f"{self.project_name}的输出数据为：{self.data_output}")

        # 绘制输入输出箱线图
        self.plotter.plot_input_boxplot(input_df=self.data_input, save_path=self.train_result_path)
        self.plotter.plot_output_boxplot(output_df=self.data_output, save_path=self.train_result_path)


    def main(self) -> None:
        # connect to database and get trainer information
        self.database_connection()
        self.get_trainer_information()
        self.ensure_path()
        self.build_model()

        # print model info
        self.print_model_info_classic()

        # Get data from database or local csv files
        self.data_input, self.data_output = self.get_online_tune_data()
        # data_process_client = DataFramePreprocess(self.data_input, self.data_output)
        data_process_client = ClassicDataFrameProcess(self.data_input, self.data_output)
        self.data_input, self.data_output = data_process_client.run()

        # 绘制输入输出曲线等
        self.plot_data_analysis()

        self.train()

    