import time
import torch
import pyodbc
import pymoo
import numpy as np
import polars as pl
import re

from pymoo.optimize import minimize

from industrytslib.core.base import ScheduledTask
# from industrytslib.models.model_builder import build_model
from industrytslib.models.aimodels import build_model
from industrytslib.utils.database import database_builder
from industrytslib.utils.data_processing.polarsoperation import check_device_status
from industrytslib.models.optmodels.problems import DoubleProblemWithConstraint, ThreeObjCementProblem
from industrytslib.models.optmodels.utils import (
    solution_selection, select_multi_objective_optimization_algorithm, select_single_objective_optimization_algorithm,
    set_termination,
)
from industrytslib.utils.logutils import get_logger


class DecisionMaking(ScheduledTask):
    def __init__(self, project_name: str, dbconfig: dict) -> None:
        super().__init__(project_name, dbconfig)
        self.task_type = "decision_making"
        self.logger = get_logger(self.project_name, self.task_type)

        self.optimization_mode_keywords = ['均衡', '产量', '能耗', '质量']  # 当前优化模式只有均衡、产量、能耗、质量四种  
        self.optimization_variable_name_list = []  # 优化用到的变量名称列表

        self.web_db_client = database_builder(dbconfig["mssql"]["web"])
        self.ts_db_client = database_builder(dbconfig["mssql"]["timeseries"])
        
        # 查询优化配置信息
        # self.optimization_arguments格式为pl.Series表示优化参数，self.optimization_constraints格式为pl.DataFrame表示优化约束
        # self.prediction_model_list格式为list表示预测模型列表，self.input_name_list格式为list表示输入变量名称列表
        self.optimization_arguments, self.optimization_constraints, self.prediction_model_table_list, 
        self.prediction_model_list, self.input_name_list = self.web_db_client.get_optimization_info(self.project_name)

        self._get_optimization_arguments()

        self.function_parameter = None
        self.fineness_target = None
        self.feed_col = self.ts_db_client.get_feed_amount_column_name(self.history_data_table_list[0])

     # 根据self.optimization_arguments获取优化参数
    def _get_optimization_arguments(self) -> None:
        """
        获取优化参数
        """
        self.optimization_procedure = self.optimization_arguments["gongxu"].item()  # 需要优化的工序:原料磨、煤磨、窑、水泥磨
        self.optimization_function_type = self.optimization_arguments["optimization_function_type"].item()  # 优化函数类型,自定义程度较高,然后给定名称进行选择
        self.optimization_model = self.optimization_arguments["optimization_model"].item()  # 优化模型,可以是NSGA2或者custom,默认为NSGA2
        self.optimization_solution_type = self.optimization_arguments["optimization_solution_type"].item()  # 优化选解的种类,可以是均衡或者偏好,默认为均衡
        self.optimization_interval = self.optimization_arguments["optimization_interval"].item()  # 优化求解的时间间隔,可以选择1min到60min,默认为3min
        self.optimization_stop_condition = self.optimization_arguments["optimization_stop_condition"].item()  # 优化求解的停止条件,选择quick则降低收敛标准,默认为quick
        self.optimization_history_ref = self.optimization_arguments["history_ref"].item()  # 优化求解的历史数据参考,选择x分钟
        self.decision_length = self.optimization_arguments["decision_length"].item()  # 决策长度,默认为1
        self.function_parameter = self.optimization_arguments["function_parameter"].item()  # 优化目标函数参数

        # 使用正则解析x分钟,将x转换为整数
        self.optimization_history_ref = self.extract_number(self.optimization_history_ref)

        # 从TagDatabase中获取优化模式
        self.optimization_solution_type = self.ts_db_client.get_optimization_mode(self.optimization_procedure)
        # 根据self.optimization_model实例化优化算法
        self._get_optimization_model()
        # 根据self.optimization_interval获取优化间隔
        self._get_optimization_interval()
        # 根据self.optimization_stop_condition获取优化停止条件
        self._get_termination()

        # 预测模型相关变量
        self.model_name_list = []
        self.prediction_model_parameter_list = []
        self.model_list = []  # 根据模型参数列表实例化的训练好的模型列表

        self.x_length_list = []  # 存储输入长度的列表,从预测模型的字典中获取
        self.predict_length_list = []  # 存储预测长度的列表,从预测模型的字典中获取
        self.history_length_list = []  # 从数据库中查询历史数据长度的列表

        self._get_model_data()

        # 优化上下限约束
        self.constraint_table_realtime = None
        self.xl = []
        self.xu = []

    def _get_optimization_model(self) -> None:
        """
        根据前台选择的优化模型给self.optimization_model赋值
        """
        match self.optimization_model:
            case "NSGA2" | "NSGA3" | "MOEA/D":
                self.optimization_algorithm = select_multi_objective_optimization_algorithm(self.optimization_model, self.optimization_arguments)
            case "DE" | "PSO" | "GA":
                self.optimization_algorithm = select_single_objective_optimization_algorithm(self.optimization_model, self.optimization_arguments)
            case "custom":
                self.logger.info(f"项目{self.project_name}使用自定义优化模型!!!")
            case _:
                self.logger.error(f"项目{self.project_name}选择优化模型不在已知的模式当中,请检查!!!")
                raise ValueError("选择优化模型不在已知的模式当中,请检查!!!")

    def _get_optimization_interval(self) -> None:
        """
        根据前台选择的优化间隔给self.optimization_interval_time赋值
        """
        # 使用正则表达式提取出字符串中的数字
        num = int(re.search(r'\d+', self.optimization_interval).group())
        # 将提取出的数字转换成整数
        num = int(num)
        # 根据提取出的数字给self.optimization_interval_time赋值
        self.optimization_interval_time = num * 60
        self.logger.info(f"当前优化项目{self.project_name}的优化间隔为{num}min,即:{self.optimization_interval_time}s!")

    def _get_termination(self) -> None:
        """
        根据前台选择的优化停止条件给self.termination赋值
        """
        self.termination = set_termination(self.optimization_stop_condition)

    def _get_model_data(self) -> None:
        """
        从数据库中获取模型名和参数列表,并实例化预测模型
        """
        self.algo_name_list = []
        # 模型参数列表
        for i in self.prediction_model_list:
            algo_name, algo_parameter = self.web_db_client.get_model_parameter(i)
            self.algo_name_list.append(algo_name)
            self.prediction_model_parameter_list.append(algo_parameter)
            self.x_length_list.append(algo_parameter["x_length"])
            self.predict_length_list.append(algo_parameter["pred_len"])
            self.history_length_list.append(algo_parameter["x_length"] - self.decision_length)

        # 根据读取到的模型名和参数实例化预测模型
        for i in range(len(self.prediction_model_list)):
            model_name = self.prediction_model_table_list[i] + "_" + self.prediction_model_list[i]
            self.model_name_list.append(model_name)
            algo_name = self.algo_name_list[i]
            model = build_model(algo_name)(self.prediction_model_parameter_list[i])
            model.load_state_dict(torch.load(f"resource/models/{model_name}/checkpoint.pth", map_location=self.device, weights_only=True))
            self.model_list.append(model)

        # 优化时读取输入变量的视图
        self.history_data_table_list = []
        for i in self.prediction_model_table_list:
            history_table = i.split("_")[0] + "_in"
            self.history_data_table_list.append(history_table)

    def _get_decision_history_data(self) -> list:
        """
        获取历史数据,并存入数据库中
        """
        # 获取历史数据
        history_data_list = []
        for i in range(len(self.model_name_list)):
            history_data_list.append(self.ts_db_client.query_decision_history_data(self.history_data_table_list[i], self.history_length_list[i]))
        return history_data_list

    def _update_constraint_table(self, history_data_list: list) -> None:
        """
        根据实时数据更新约束表
        """
        # 重新从数据库查询最新的约束条件 TODO 将get_optimization_info方法中关于约束表的查询拆分出来
        _, self.constraint_table_realtime, _, _, _ = self.web_db_client.get_optimization_info(self.project_name)
        for i in range(len(self.model_name_list)):
            if self.optimization_history_ref == 0:
                latest_values = history_data_list[i].tail(1)
            else:
                latest_values = history_data_list[i].tail(self.optimization_history_ref).mean()
                # 遍历 latest_values 中的列名和值
            column_names = latest_values.columns
            for column_name in column_names:
                latest_value = latest_values[column_name].item()
                original_min = self.constraint_table_realtime.filter(pl.col("variable") == column_name)["min"].item()
                original_max = self.constraint_table_realtime.filter(pl.col("variable") == column_name)["max"].item()
                if latest_value < 0:
                    new_min = latest_value * 1.01
                    new_max = latest_value * 0.99
                else:
                    new_min = latest_value * 0.99
                    new_max = latest_value * 1.01
                if new_min < original_min:
                    new_min = original_min
                if new_max > original_max:
                    new_max = original_max
                # 检查交集是否为空
                if new_min >= new_max:
                    new_min = original_min
                    new_max = original_max
                self.constraint_table_realtime.with_columns([
                    pl.when(pl.col("variable") == column_name).then(new_min).otherwise(pl.col("min")).alias("min"),
                    pl.when(pl.col("variable") == column_name).then(new_max).otherwise(pl.col("max")).alias("max")
                ])
                # 优化求解问题的变量上下限设定
            self.xl = self.constraint_table_realtime["min"].to_list()
            self.xu = self.constraint_table_realtime["max"].to_list()

    def _set_optimization_problem(self, history_data: list[pl.DataFrame]) -> pymoo.core.problem.Problem:
        """
        设置优化问题
        """
        match self.optimization_function_type:
            case "1" | "2":
                problem = DoubleProblemWithConstraint(self.function_parameter,
                                                      n_var=self.optimization_arguments["variable_count"].item(),
                                                      n_obj=self.optimization_arguments["object_count"].item(),
                                                      n_constr=0, xl=np.array(self.xl), xu=np.array(self.xu),
                                                      model_name_list=self.model_name_list, model_list=self.model_list,
                                                      x_length=self.x_length_list, decision_length=self.decision_length,
                                                      history_data_table_list=self.history_data_table_list,
                                                      name_list=self.optimization_variable_name_list,
                                                      input_name_list=self.input_name_list,
                                                      function_type=self.optimization_function_type,
                                                      history_data=history_data)
            case "3":
                problem = ThreeObjCementProblem(self.function_parameter, self.fineness_target,
                                                n_var=self.optimization_arguments["variable_count"].item(),
                                                n_obj=self.optimization_arguments["object_count"].item(),
                                                n_constr=0, xl=np.array(self.xl), xu=np.array(self.xu),
                                                model_name_list=self.model_name_list, model_list=self.model_list,
                                                x_length=self.x_length_list, decision_length=self.decision_length,
                                                history_data_table_list=self.history_data_table_list,
                                                name_list=self.optimization_variable_name_list,
                                                input_name_list=self.input_name_list,
                                                function_type=self.optimization_function_type,
                                                history_data=history_data)
            case _:
                self.logger.error(f"项目{self.project_name}选择的优化函数类型不在已知的模式当中,请检查!!!")
                problem = DoubleProblemWithConstraint(self.function_parameter,
                                                      n_var=self.optimization_arguments["variable_count"].item(),
                                                      n_obj=self.optimization_arguments["object_count"].item(),
                                                      n_constr=0, xl=np.array(self.xl), xu=np.array(self.xu),
                                                      model_name_list=self.model_name_list, model_list=self.model_list,
                                                      x_length=self.x_length_list, decision_length=self.decision_length,
                                                      history_data_table_list=self.history_data_table_list,
                                                      name_list=self.optimization_variable_name_list,
                                                      input_name_list=self.input_name_list,
                                                      function_type=self.optimization_function_type,
                                                      history_data=history_data)
        return problem

    def _solve_optimization_problem(self, history_data_list: list) -> list:
        """求解优化问题

        Args:
            history_data_list (list): _description_

        Returns:
            list: _description_
        """
        problem = self._set_optimization_problem(history_data_list)

        res = minimize(
            problem,
            self.optimization_algorithm,
            self.termination,
            seed=1,
            save_history=True,
            verbose=False
        )

        optimization_procedure_mode = self.ts_db_client.get_optimization_mode(self.optimization_procedure)
        best_solution = solution_selection(optimization_procedure_mode, res)
        self.logger.info(f"{self.project_name}的最优解为:{best_solution}!")
        return best_solution

    # def main(self):
    #     """
    #     优化决策主程序
    #     """
    #     while True:
    #         time_start_optimization = time.time()
    #         # 判断是否需要停止优化
    #         if self.event.is_set():
    #             # 在此添加退出前要做的工作,如保存文件等
    #             self.logger.info(f"项目{self.project_name}手动中止决策!!!")
    #             break

    #         # 从数据库中读取历史数据
    #         try:
    #             history_data_list = self._get_decision_history_data()
    #         except pyodbc.Error as e:
    #             self.logger.error(f"-------------------------读取历史数据时出现数据库错误：{e}!!!请检查数据库连接!!!-------------------------")
    #             self.ts_db_client.reconnect_db()
    #             time.sleep(60)
    #             continue
    #         except Exception as e:
    #             self.logger.error(f"-------------------------读取历史数据时出现错误!!!{e}-------------------------")
    #             time.sleep(60)
    #             continue

    #         try:
    #             # 根据喂料量的值来判断是否需要进行优化,如果喂料量小于10则不进行优化
    #             is_greater = check_device_status(history_data_list[0], self.feed_col, 5)
    #         except Exception as e:
    #             self.logger.error(f"判断是否需要进行优化时出现错误!!!{e}")
    #             time.sleep(60)
    #             continue

    #         if is_greater:
    #             # 如果均值大于10,说明当前设备正在正常运行,可以进行优化决策

    #             # 首先修改约束
    #             try:
    #                 self._update_constraint_table(history_data_list)
    #             except pyodbc.Error as e:
    #                 self.logger.error(f"修改约束时出现数据库错误：{e}!!!正在尝试重新连接Web数据库。")
    #                 time.sleep(60)
    #                 continue
    #             except Exception as e:
    #                 self.logger.error(f"修改约束时出现错误!!!{e}")
    #                 time.sleep(60)
    #                 continue

    #             # 实例化优化问题
    #             self.logger.info(f"当前优化的工序为{self.optimization_procedure}!")
    #             # 如果优化的工序为水泥磨,则每次优化都需要从TagDatabase中读取比表面积目标值
    #             if self.optimization_procedure == '水泥磨':
    #                 self.logger.info(f"当前优化项目{self.project_name}的工序为水泥磨,需要从TagDatabase中读取相应的比表面积目标值作为function_parameter!")
    #                 # 从TagDatabase中读取比表面积目标值
    #                 try:
    #                     self.function_parameter, self.fineness_target = self.ts_db_client.get_cement_mill_target()
    #                 except Exception as e:
    #                     self.logger.error(f"当前生产的是道路水泥,不进行优化决策!!!{e}")
    #                     time.sleep(self.optimization_interval_time)
    #                     continue
    #                 self.logger.info(f"当前优化项目{self.project_name}的比表面积目标值为{self.function_parameter}!!!")

    #             try:
    #                 self._solve_optimization_problem(history_data_list)
    #             except Exception as e:
    #                 self.logger.error(f"项目{self.project_name}优化求决策解时出现错误！！！{e}")
    #                 time.sleep(self.optimization_interval_time)
    #                 continue
    #         else:
    #             self.logger.info("当前设备正在停机状态,不进行优化决策!!!")
    #             time.sleep(self.optimization_interval_time)
    #         time_end_optimization = time.time()
    #         self.logger.info(f"项目{self.project_name}的优化决策耗时为{time_end_optimization - time_start_optimization}秒!!!")

    def main(self):
        """
        优化决策主程序
        """
        
        time_start_optimization = time.time()

        # 从数据库中读取历史数据
        try:
            history_data_list = self._get_decision_history_data()
        except pyodbc.Error as e:
            self.logger.error(f"-------------------------读取历史数据时出现数据库错误：{e}!!!请检查数据库连接!!!-------------------------")
            self.ts_db_client.reconnect_db()
        except Exception as e:
            self.logger.error(f"-------------------------读取历史数据时出现错误!!!{e}-------------------------")
        try:
            # 根据喂料量的值来判断是否需要进行优化,如果喂料量小于10则不进行优化
            is_greater = check_device_status(history_data_list[0], self.feed_col, 5)
        except Exception as e:
            self.logger.error(f"判断是否需要进行优化时出现错误!!!{e}")


        if is_greater:
            # 如果均值大于10,说明当前设备正在正常运行,可以进行优化决策
            # 首先修改约束
            try:
                self._update_constraint_table(history_data_list)
            except pyodbc.Error as e:
                self.logger.error(f"修改约束时出现数据库错误：{e}!!!正在尝试重新连接Web数据库。")
            except Exception as e:
                self.logger.error(f"修改约束时出现错误!!!{e}")

            # 实例化优化问题
            self.logger.info(f"当前优化的工序为{self.optimization_procedure}!")
            # 如果优化的工序为水泥磨,则每次优化都需要从TagDatabase中读取比表面积目标值
            if self.optimization_procedure == '水泥磨':
                self.logger.info(f"当前优化项目{self.project_name}的工序为水泥磨,需要从TagDatabase中读取相应的比表面积目标值作为function_parameter!")
                # 从TagDatabase中读取比表面积目标值
                try:
                    self.function_parameter, self.fineness_target = self.ts_db_client.get_cement_mill_target()
                except Exception as e:
                    self.logger.error(f"当前生产的是道路水泥,不进行优化决策!!!{e}")
                self.logger.info(f"当前优化项目{self.project_name}的比表面积目标值为{self.function_parameter}!!!")

            try:
                self._solve_optimization_problem(history_data_list)
            except Exception as e:
                self.logger.error(f"项目{self.project_name}优化求决策解时出现错误！！！{e}")
        else:
            self.logger.info("当前设备正在停机状态,不进行优化决策!!!")
            time.sleep(self.optimization_interval_time)
        time_end_optimization = time.time()
        self.logger.info(f"项目{self.project_name}的优化决策耗时为{time_end_optimization - time_start_optimization}秒!!!")
