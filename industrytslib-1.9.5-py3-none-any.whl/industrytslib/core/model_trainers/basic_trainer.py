import torch

import polars as pl
# import platform

# from datetime import datetime
from pathlib import Path
from typing import Tuple
from torch import optim
from torch.utils.data import DataLoader, Dataset
from torch.utils.tensorboard import SummaryWriter


from industrytslib.core.base import ScheduledTask
from industrytslib.utils.basefunc import (name_list_parser, get_current_time, 
                                          split_sample_and_model, ping_address)
from industrytslib.utils.database import database_builder
from industrytslib.utils.data_processing.polarsoperation import filter_feed_columns
from industrytslib.utils.data_processing.data_provider import data_provider_builder
# from industrytslib.models.model_builder import build_model
from industrytslib.models.aimodels import build_model

from industrytslib.utils.visualization import plotter_builder

from industrytslib.utils.readconfig import read_model_parameter_toml
from industrytslib.utils.gpu import select_least_used_gpu
from industrytslib.utils.logutils import get_logger


def get_device() -> torch.device:
    if torch.cuda.is_available():
        return select_least_used_gpu()
    else:
        return torch.device("cpu")


class ModelTrainer(ScheduledTask):
    """
    ModelTrainer is a basic class for training models.
    """
    def __init__(self, project_name: str, dbconfig: dict) -> None:
        super().__init__(project_name, dbconfig)
        self.task_type = "train"
        self.logger = get_logger(self.project_name, self.task_type)
        self.decide_run_mode() # 运行模式, 默认是online需要连接数据库，如果设置为local则不需要连接数据库

        self.device = get_device()
        self.logger.info(f"Using device: {self.device}")
        self.scaler_y_path = Path(f"resource/scaler/{self.project_name}/scaler_y.pkl")

        self.writer = SummaryWriter(log_dir=f"resource/tensorboard/{self.project_name}/{get_current_time()}")  # tensorboard writer
        self.plotter = plotter_builder(plotter_type="plotly", project_name=self.project_name)
        self.plotter_matplotlib = plotter_builder(plotter_type="matplotlib", project_name=self.project_name)

        # init 
        self.input_name_list = None
        self.output_name_list = None
    
    def decide_run_mode(self) -> None:
        """
        决定运行模式
        """
        address = self.dbconfig["mssql"]["timeseries"]['server']
        self.logger.info(f"Trying to ping address: {address}...")
        if ping_address(address):
            self.run_mode = "online"
            self.logger.info(f"===================Run mode: {self.run_mode}===================")
        else:
            self.run_mode = "local"
            self.logger.info(f"===================Run mode: {self.run_mode}===================")

    def database_connection(self) -> None:
        # Database connection(if you need train offline, just comment thre follow 2 lines)
        if self.run_mode == "online":
            self.web_mssql_client = database_builder(self.dbconfig["mssql"]["web"])
            self.ts_mssql_client = database_builder(self.dbconfig["mssql"]["timeseries"])
        else:
            pass

        try:
            self.sample_name, self.model_name = self.web_mssql_client.get_prediction_info(self.project_name)
            self.logger.info(f"Get sample name and model name from project name {self.project_name} successfully!!!")
            self.logger.info(f"Sample name: {self.sample_name}, model name: {self.model_name}!!!")
        except Exception as e:
            self.logger.error(f"Get prediction info from web mssql database failed: {e}")
            self.logger.error(f"Please check the project name {self.project_name} in web mssql database!!!")
            self.sample_name, self.model_name = split_sample_and_model(self.project_name)
            self.logger.info(f"Get sample name and model name from project name {self.project_name} successfully!!!")
            self.logger.info(f"Sample name: {self.sample_name}, model name: {self.model_name}!!!")
            # raise e

        self.sample_table_in_name = self.sample_name + "_in"  # input table(view) name
        self.sample_table_out_name = self.sample_name + "_out"  # output table(view) name

    def get_trainer_information(self) -> None:
        """
        Get trainer information from web database,including sample table information, algorithm information, model parameter, input name list
        """
        try:
            self.sample_table_information = self.web_mssql_client.get_sample_table_information(self.sample_name)
            self.logger.info(f"Get sample table information from web mssql database successfully:{self.sample_table_information}")
        except Exception as e:
            self.logger.error(f"Get sample table information from web mssql database failed: {e}")
            self.logger.error("Please check the sample name in web mssql database!!!")
        
        # get input name list(input variable name list)  
        try:
            input_name_str = self.sample_table_information["column_namein"][0]
            self.input_name_list = name_list_parser(input_name_str)
            self.logger.info(f"Get input name list from sample table information successfully:{self.input_name_list}")
        except Exception as e:
            self.logger.error(f"Get input name list from sample table information failed: {e}")
            self.logger.error("Please check the sample table information!!!")
        
        # get output name list(output variable name list)
        try:
            output_name_str = self.sample_table_information["column_nameout"][0]
            self.output_name_list = name_list_parser(output_name_str)
            self.logger.info(f"Get output name list from sample table information successfully:{self.output_name_list}")
        except Exception as e:
            self.logger.error(f"Get output name list from sample table information failed: {e}")
            self.logger.error("Please check the sample table information!!!")

        self.get_model_parameter()
    
    def get_model_parameter(self) -> None:
        """
        Get model prarameter based on config
        """
        match self.dbconfig["model_info_location"]["location"]:
            case "sqlite":
                sqlite_model_info_client = database_builder(self.dbconfig["sqlite"]["model_info"])
                self.model_parameter = sqlite_model_info_client.get_model_parameter(self.model_name)
                self.algorithm_name = self.model_parameter["algorithm_name"]
            case "mssql":
                self.algorithm_name, self.model_parameter = self.web_mssql_client.get_model_parameter(self.model_name)
            case "toml":
                model_parameter_path = Path(f"resource/model_parameter/{self.model_name}/model_config.toml")
                self.model_parameter = read_model_parameter_toml(model_parameter_path)
                self.algorithm_name = self.model_parameter["algorithm_name"]
            case _:
                self.logger.error(f"No such model info location: {self.dbconfig['model_info_location']}")
                raise ValueError(f"No such model info location: {self.dbconfig['model_info_location']}")
        self.logger.info(f"Get model parameter from {self.dbconfig['model_info_location']['location']} successfully!!!")
        self.logger.info(f"Model parameter: {self.model_parameter}")

        # build output database depend on model_parameter["output_flag"]
        # if output_flag in model_parameter, then use the output_flag to build the output database
        # else use the default output database
        if self.run_mode == "online":
            if "output_flag" in self.model_parameter:
                match self.model_parameter["output_flag"]:
                    case "control":
                        self.output_flag = "control"
                        self.out_db_client = self.ts_mssql_client
                        self.logger.info("Output database is timeseries database!!!")
                    case "quality":
                        self.output_flag = "quality"
                        self.out_db_client = database_builder(self.dbconfig["mssql"]["quality"])
                        self.logger.info("Output database is quality database!!!")
                    case "quality_random":
                        self.output_flag = "quality_random"
                        self.out_db_client = database_builder(self.dbconfig["mssql"]["quality"])
                        self.logger.info("Output database is quality database!!!")
                    case _:
                        self.logger.error(f"No such output flag: {self.model_parameter['output_flag']}")
                        raise ValueError(f"No such output flag: {self.model_parameter['output_flag']}")
            else:
                self.output_flag = "control"
                self.out_db_client = self.ts_mssql_client
                self.logger.info("Output database is timeseries database!!!")
        else:
            if "output_flag" in self.model_parameter:
                match self.model_parameter["output_flag"]:
                    case "control":
                        self.output_flag = "control"
                        self.logger.info("Output database is timeseries database!!!")
                    case "quality":
                        self.output_flag = "quality"
                        self.logger.info("Output database is quality database!!!")
                    case "quality_random":
                        self.output_flag = "quality_random"
                        self.logger.info("Output database is quality database!!!")
                    case _:
                        self.logger.error(f"No such output flag: {self.model_parameter['output_flag']}")
                        raise ValueError(f"No such output flag: {self.model_parameter['output_flag']}")
            else:
                self.output_flag = "control"
                self.out_db_client = self.ts_mssql_client
                self.logger.info("Output database is timeseries database!!!")
          
    def get_train_data(self) -> Tuple[pl.DataFrame, pl.DataFrame]:
        """
        获取训练数据。

        Args:
            无参数。

        Returns:
            Tuple[pl.DataFrame, pl.DataFrame]: 包含两个元素的元组,每个元素都是polars DataFrame类型。
            第一个DataFrame包含特征数据,第二个DataFrame包含标签数据。
        """
        self.input_csv_path = f"resource/datasets/{self.sample_name}/data_in.csv"
        self.output_csv_path = f"resource/datasets/{self.sample_name}/data_out.csv"
        # 如果self.input_csv_path存在，则直接读取csv文件作为训练数据
        if Path(self.input_csv_path).exists() and Path(self.output_csv_path).exists():
            self.logger.info(f"Get training data from local csv file {self.input_csv_path} and {self.output_csv_path}.")
            data_input = pl.read_csv(self.input_csv_path)
            data_output = pl.read_csv(self.output_csv_path)  
        else:
            # 先创建文件夹
            sample_path = Path(self.input_csv_path).parent
            if sample_path.exists() is False:
                sample_path.mkdir(parents=True, exist_ok=True)
            begin_time, end_time = self.sample_table_information["begin_time"][0], self.sample_table_information["end_time"][0]
            self.logger.info(f"Get training data from table {self.sample_table_in_name} between time {begin_time} and {end_time}.")

            # query input data from ts database
            self.logger.info(f"trying to get input data from {self.ts_mssql_client}!!!")
            # data_input = self.ts_mssql_client.get_input_data_train(self.sample_table_in_name, begin_time, end_time)
            data_input = self.ts_mssql_client.get_input_data_history(self.input_name_list, begin_time, end_time)  # 从历史表中获取数据,然后拼接
            # filter the train_data_input according to feed_amount column, which is bigger than 10
            data_input = filter_feed_columns(data_input)
            # save input data to local
            data_input.write_csv(self.input_csv_path)
            self.logger.info(f"Get input training data from table {self.sample_table_in_name} successfully!!!")

            # query output data from self.out_db_client
            self.logger.info(f"trying to get output data from {self.out_db_client}!!!")
            match self.output_flag:
                case "control":
                    data_output = self.out_db_client.get_output_data_history(self.output_name_list, begin_time, end_time)
                case "quality":
                    data_output = self.out_db_client.get_output_data_history(self.sample_table_out_name, begin_time, end_time)
                case _:
                    self.logger.error(f"No such output flag: {self.output_flag}")
                    raise ValueError(f"No such output flag: {self.output_flag}")
            data_output.write_csv(self.output_csv_path)
            # save output data to local
            self.logger.info(f"Get output training data of {self.project_name} successfully!!!")
        
        # 如果self.input_name_list和self.output_name_list为空，则从data_input和data_output的列名中获取
        if self.input_name_list is None or self.output_name_list is None:
            self.input_name_list = data_input.columns
            self.output_name_list = data_output.columns

        self.logger.info("==================================================")
        self.logger.info(f"original input data: {data_input}")
        self.logger.info(f"original output data: {data_output}")
        self.logger.info("==================================================")
        return data_input, data_output
    
    def get_online_train_data(self) -> Tuple[pl.DataFrame, pl.DataFrame]:
        """
        获取训练数据。

        Args:
            无参数。

        Returns:
            Tuple[pl.DataFrame, pl.DataFrame]: 包含两个元素的元组,每个元素都是polars DataFrame类型。
            第一个DataFrame包含特征数据,第二个DataFrame包含标签数据。
        """
        self.input_csv_path = f"resource/datasets/{self.sample_name}/data_in.csv"
        self.output_csv_path = f"resource/datasets/{self.sample_name}/data_out.csv"
        # 如果self.input_csv_path存在，则直接读取csv文件作为训练数据
        if Path(self.input_csv_path).exists() and Path(self.output_csv_path).exists():
            self.logger.info(f"Get training data from local csv file {self.input_csv_path} and {self.output_csv_path}.")
            data_input = pl.read_csv(self.input_csv_path)
            data_output = pl.read_csv(self.output_csv_path)
            
            # 检查data_input和data_output最新的时间是否与最新的时间一致
            latest_time_input = data_input.select(pl.col("DateTime").max())
            latest_time_output = data_output.select(pl.col("DateTime").max())

            # 获取数据库中样本时间
            begin_time, end_time = self.sample_table_information["begin_time"][0], self.sample_table_information["end_time"][0]

            # 如果latest_time_input和latest_time_output与begin_time和end_time不一致，则从数据库中获取数据
            if latest_time_input != begin_time or latest_time_output != end_time:
                self.logger.info("The latest time of data_input and data_output is not the same as the sample time in database!!!")
                self.logger.info(f"Get training data from table {self.sample_table_in_name} between time {begin_time} and {end_time}.")
            # query input data from ts database
            self.logger.info(f"trying to get input data from {self.ts_mssql_client}!!!")
            # data_input = self.ts_mssql_client.get_input_data_train(self.sample_table_in_name, begin_time, end_time)
            data_input = self.ts_mssql_client.get_input_data_history(self.input_name_list, begin_time, end_time)  # 从历史表中获取数据,然后拼接
            # filter the train_data_input according to feed_amount column, which is bigger than 10
            data_input = filter_feed_columns(data_input)
            # save input data to local
            data_input.write_csv(self.input_csv_path)
            self.logger.info(f"Get input training data from table {self.sample_table_in_name} successfully!!!")

            # query output data from self.out_db_client
            self.logger.info(f"trying to get output data from {self.out_db_client}!!!")
            match self.output_flag:
                case "control":
                    data_output = self.out_db_client.get_output_data_history(self.output_name_list, begin_time, end_time)
                case "quality":
                    data_output = self.out_db_client.get_output_data_history(self.sample_table_out_name, begin_time, end_time)
                case _:
                    self.logger.error(f"No such output flag: {self.output_flag}")
                    raise ValueError(f"No such output flag: {self.output_flag}")
            data_output.write_csv(self.output_csv_path)
            # save output data to local
            self.logger.info(f"Get output training data of {self.project_name} successfully!!!")
        
        else:
            # 先创建文件夹
            sample_path = Path(self.input_csv_path).parent
            if sample_path.exists() is False:
                sample_path.mkdir(parents=True, exist_ok=True)
            begin_time, end_time = self.sample_table_information["begin_time"][0], self.sample_table_information["end_time"][0]
            self.logger.info(f"Get training data from table {self.sample_table_in_name} between time {begin_time} and {end_time}.")

            # query input data from ts database
            self.logger.info(f"trying to get input data from {self.ts_mssql_client}!!!")
            # data_input = self.ts_mssql_client.get_input_data_train(self.sample_table_in_name, begin_time, end_time)
            data_input = self.ts_mssql_client.get_input_data_history(self.input_name_list, begin_time, end_time)  # 从历史表中获取数据,然后拼接
            # filter the train_data_input according to feed_amount column, which is bigger than 10
            data_input = filter_feed_columns(data_input)
            # save input data to local
            data_input.write_csv(self.input_csv_path)
            self.logger.info(f"Get input training data from table {self.sample_table_in_name} successfully!!!")

            # query output data from self.out_db_client
            self.logger.info(f"trying to get output data from {self.out_db_client}!!!")
            match self.output_flag:
                case "control":
                    data_output = self.out_db_client.get_output_data_history(self.output_name_list, begin_time, end_time)
                case "quality":
                    data_output = self.out_db_client.get_output_data_history(self.sample_table_out_name, begin_time, end_time)
                case _:
                    self.logger.error(f"No such output flag: {self.output_flag}")
                    raise ValueError(f"No such output flag: {self.output_flag}")
            data_output.write_csv(self.output_csv_path)
            # save output data to local
            self.logger.info(f"Get output training data of {self.project_name} successfully!!!")
        
        # 如果self.input_name_list和self.output_name_list为空，则从data_input和data_output的列名中获取
        if self.input_name_list is None or self.output_name_list is None:
            self.input_name_list = data_input.columns
            self.output_name_list = data_output.columns

        self.logger.info("==================================================")
        self.logger.info(f"original input data: {data_input}")
        self.logger.info(f"original output data: {data_output}")
        self.logger.info("==================================================")
        return data_input, data_output
    
    def get_online_tune_data(self) -> Tuple[pl.DataFrame, pl.DataFrame]:
        """
        从数据库中查询最近一段时间的数据
        Args:
            无参数
        Returns:
            Tuple[pl.DataFrame, pl.DataFrame]: 包含两个元素的元组,每个元素都是polars DataFrame类型。
            第一个DataFrame包含特征数据,第二个DataFrame包含标签数据。
        """
        # query input data from ts database
        self.logger.info(f"trying to get input data from {self.ts_mssql_client}!!!")
        # data_input = self.ts_mssql_client.get_input_data_train(self.sample_table_in_name, begin_time, end_time)
        data_input = self.ts_mssql_client.get_input_data_online(self.input_name_list)  # 从历史表中获取数据,然后拼接
        # filter the train_data_input according to feed_amount column, which is bigger than 10
        data_input = filter_feed_columns(data_input)

        self.logger.info(f"Get input training data from table {self.sample_table_in_name} successfully!!!")

        # query output data from self.out_db_client
        self.logger.info(f"trying to get output data from {self.out_db_client}!!!")
        match self.output_flag:
            case "control":
                data_output = self.out_db_client.get_output_data_online(self.output_name_list)
            case "quality":
                data_output = self.out_db_client.get_output_data_online(self.sample_table_out_name)
            case _:
                self.logger.error(f"No such output flag: {self.output_flag}")
                raise ValueError(f"No such output flag: {self.output_flag}")
        # save output data to local
        self.logger.info(f"Get output training data of {self.project_name} successfully!!!")
        
        self.logger.info("="*100+"\n")
        self.logger.info(f"original input data: {data_input}")
        self.logger.info(f"original output data: {data_output}")
        self.logger.info("="*100+"\n")
        return data_input, data_output
 
    def build_model(self) -> None:
        """
        Build model according to the model parameter.
        """
        self.model = build_model(self.algorithm_name, self.model_parameter).to(self.device)
        self.logger.info(f"Build model {self.algorithm_name} | {self.model_parameter} | {self.device} successfully!!!")
    
    def _set_optimizer(self, model_parameter: dict) -> optim.Optimizer:
        """
        Set optimizer according to the model parameter.
        Args:
            model_parameter (dict): Model parameter from web database.
        Returns:
            torch.optim.Optimizer: Optimizer object.
        """
        # config optimizer
        if "optimizer" in model_parameter:
            match model_parameter["optimizer"]:
                case "Adam":
                    optimizer = optim.Adam(
                        self.model.parameters(), 
                        lr=self.model_parameter["learning_rate"], 
                        betas=(0.5, 0.999), 
                        eps=1e-8
                    )
                case "SGD":
                    optimizer = optim.SGD(self.model.parameters(), lr=self.model_parameter["learning_rate"])
                case "Adamax":
                    optimizer = optim.Adamax(self.model.parameters(), lr=self.model_parameter["learning_rate"])
                case "AdamW":
                    optimizer = optim.AdamW(
                        self.model.parameters(), 
                        lr=self.model_parameter["learning_rate"], 
                        betas=(0.0, 0.95),
                        weight_decay=0.05
                    )
                case "AdaBelief":
                    from adabelief_pytorch import AdaBelief
                    optimizer = AdaBelief(self.model.parameters(), lr=self.model_parameter["learning_rate"], eps=1e-16, betas=(0.9,0.999), weight_decouple = True, rectify = False)
                case _:
                    self.logger.warning("No such optimizer Name.Please check the optimizer name in model parameter!!!")
                    optimizer = optim.Adam(self.model.parameters(), lr=self.model_parameter["learning_rate"], betas=(0.5, 0.999), eps=1e-8)
        else:
            self.logger.warning(f"{self.project_name}参数中没有:optimizer!!!")
            optimizer = optim.Adam(self.model.parameters(), lr=self.model_parameter["learning_rate"])

        # config epoch scheduler
        if "step_size" in model_parameter and "gamma" in model_parameter:
            self.epoch_scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=model_parameter["step_size"], gamma=model_parameter["gamma"])
        else:
            self.logger.warning(f"{self.project_name}参数中没有:step_size和gamma!!!")
            self.epoch_scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=5000, gamma=0.5)
        return optimizer

    def _set_criterion(self, model_parameter: dict) -> torch.nn.Module:
        """
        Set criterion according to the model parameter.
        Args:
            model_parameter (dict): Model parameter from web database.
        Returns:
            torch.nn.modules.loss._Loss: Criterion object.
        """
        # 如果model_parameter中存在criterion，则根据criterion设置损失函数，否则设置为MSE
        if "criterion" in model_parameter:
            match model_parameter["criterion"]:
                case "MSE":
                    criterion = torch.nn.MSELoss()
                case _:
                    self.logger.warning("No such criterion.Please check the criterion name in model parameter!!!")
                    criterion = torch.nn.MSELoss()
        else:
            self.logger.warning(f"{self.project_name}参数中没有:criterion!!!")
            criterion = torch.nn.MSELoss()
        return criterion
    
    def _get_data(self, flag) -> Tuple[Dataset, DataLoader]:
        data_set, data_loader = data_provider_builder(self.project_name, self.data_input, self.model_parameter["data_type"], 
                                              self.model_parameter, flag)
        return data_set, data_loader
    
    def ensure_path(self) -> None:
        """
        init path object and ensure the path exists
        """
        self.train_result_path = Path(f"resource/results/train_results/{self.project_name}")  # 存放训练结果绘图的路径
        # 判断训练结果路径是否存在,如果不存在则创建文件夹
        if not self.train_result_path.exists():
            self.train_result_path.mkdir(parents=True, exist_ok=True)

         # 存放测试训练结果绘图的路径
        self.test_train_result_path = Path(f"resource/results/test_train_results/{self.project_name}")
        # 判断测试和训练结果路径是否存在,如果不存在则创建文件夹
        if not self.test_train_result_path.exists():
            self.test_train_result_path.mkdir(parents=True, exist_ok=True)

        self.test_result_path = Path(f"resource/results/test_results/{self.project_name}")  # 存放测试结果绘图的路径
        # 判断测试结果路径是否存在,如果不存在则创建文件夹
        if not self.test_result_path.exists():
            self.test_result_path.mkdir(parents=True, exist_ok=True)
    
    def main(self) -> None:
        self.database_connection()
        self.get_trainer_information()
    