# Big version of industrytslib
VERSION = '1.0'
