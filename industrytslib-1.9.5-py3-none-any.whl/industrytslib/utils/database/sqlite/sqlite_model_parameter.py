import json

from .sqlite_base import SqliteConnection


class ModelParameterSqlite(SqliteConnection):
    def __init__(self, config: dict):
        super().__init__(config)

    def create_model_parameter_table(self) -> None:
        """
        create the model parameter table
        """
        # 检查模型参数表是否存在
        if self.check_table_exists("model_parameters"):
            self.logger.error("Model Parameter Table Already Exists!")
            return
        # 如果模型参数表不存在，则创建表
        create_table_sql = """
        CREATE TABLE IF NOT EXISTS model_parameters (
            model_name TEXT PRIMARY KEY,
            algorithm_name TEXT,
            model_parameter TEXT
        )
        """
        self.cursor.execute(create_table_sql)
        self.conn.commit()
        self.logger.info("Model Parameter Table Created Successfully!")

    def insert_model_parameter(self, model_name: str, algorithm_name: str, model_parameter: dict) -> None:
        """
        insert the model parameter into the database
        """
        # 检查模型名称是否已存在
        if self.get_model_parameter(model_name):
            self.logger.error(f"Model Parameter {model_name} Already Exists!")
            return
        # 如果模型名称不存在，则插入数据
        insert_sql = """
        INSERT INTO model_parameters (model_name, algorithm_name, model_parameter)
        VALUES (?, ?, ?)
        """
        self.cursor.execute(insert_sql, (model_name, algorithm_name, json.dumps(model_parameter)))
        self.conn.commit()
        self.logger.info(f"Model Parameter {model_name} Inserted Successfully!")

    def get_model_parameter(self, model_name: str) -> dict:
        """
        get the model parameter from the database
        """
        query_sql = """
        SELECT model_parameter FROM model_parameters WHERE model_name = ?
        """
        self.cursor.execute(query_sql, (model_name,))
        row = self.cursor.fetchone()
        if row:
            return json.loads(row[0])
        else:
            return None
    
    def update_model_parameter(self, model_name: str, key: str, value: float | str) -> None:
        """
        update the model parameter in the database
        """
        query_sql = """
        SELECT model_parameter FROM model_parameters WHERE model_name = ?
        """
        self.cursor.execute(query_sql, (model_name,))
        row = self.cursor.fetchone()
        if row:
            model_parameter = json.loads(row[0])
            model_parameter[key] = value
            update_sql = """
            UPDATE model_parameters SET model_parameter = ? WHERE model_name = ?
            """
            self.cursor.execute(update_sql, (json.dumps(model_parameter), model_name))
            self.conn.commit()
            self.logger.info(f"Model Parameter {model_name} Updated Successfully!")
        else:
            self.logger.error(f"Model Parameter {model_name} Not Found!")

    def delete_model_parameter(self, model_name: str) -> None:
        """
        delete the model parameter from the database
        """
        delete_sql = """
        DELETE FROM model_parameters WHERE model_name = ?
        """
        self.cursor.execute(delete_sql, (model_name,))
        self.conn.commit()
        self.logger.info(f"Model Parameter {model_name} Deleted Successfully!")
    