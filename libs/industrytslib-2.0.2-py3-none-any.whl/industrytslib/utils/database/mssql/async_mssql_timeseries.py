import datetime
import polars as pl
from typing import Tuple, List

from .async_mssql_base import AsyncMSSQLConnection
from industrytslib.utils.logutils import get_logger
from industrytslib.utils.data_processing.polarsoperation import optimization_data_process, calculate_minute_average

class AsyncMSSQLTimeSeries(AsyncMSSQLConnection):
    """
    Async MSSQL Library for Get realtime data and history data from controller database
    """
    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self.logger = get_logger("AsyncMSSQLTimeSeries", "database")

    async def get_feed_amount_column_name(self, table_name: str) -> str:
        """
        Get feed amount column name asynchronously

        Args:
            table_name (str): table name

        Returns:
            str: feed amount column name
        """
        sql = f"SELECT TOP (1) * FROM {table_name} " \
              f"WHERE (DateTime BETWEEN SUBSTRING(CONVERT(varchar, DATEADD(hour, - 2, GETDATE()), 120), 1, 16) AND " \
              f"SUBSTRING(CONVERT(varchar, DATEADD(hour, +1, GETDATE()), 120), 1, 16))" \
              f"ORDER BY DateTime DESC"
        await self.cursor.execute(sql)
        columns = [column[0] for column in self.cursor.description]
        self.logger.info(f"Columns: {columns}")
        
        # Find column name containing '喂料量' or '给料机'
        target_column = None
        for col in columns:
            if '喂料量' in col or '给料机' in col:
                target_column = col
                self.logger.info(f"找到包含 '喂料量' 或 '给料机' 的列名: {target_column}")
                break

        if not target_column:
            raise ValueError("DataFrame 中未找到包含 '喂料量' 或 '给料机' 的列名")

        return target_column
    
    async def get_latest_input_data(self, table_name: str) -> pl.DataFrame:
        """
        Get realtime data of latest 1 hour asynchronously

        Args:
            table_name (str): table name

        Returns:
            pl.DataFrame: realtime data
        """
        sql = f"SELECT TOP 360 * FROM {table_name} " \
              f"WHERE (DateTime BETWEEN SUBSTRING(CONVERT(varchar, DATEADD(hour, - 2, GETDATE()), 120), 1, 16) AND " \
              f"SUBSTRING(CONVERT(varchar, DATEADD(hour, +1, GETDATE()), 120), 1, 16))" \
              f"ORDER BY DateTime DESC"
        rows = await self.query(sql)
        return rows

    async def get_latest_input_data_by_column(self, input_name_list: List[str]) -> pl.DataFrame:
        """
        Get realtime data of latest 1 hour by column name list from 历史表 asynchronously
        Args:
            input_name_list (List[str]): column name list
        Returns:
            pl.DataFrame: realtime data
        """
        name_list = input_name_list.copy()
        sql = f'''
            SELECT DateTime, TagName, TagVal
            FROM 历史表
            WHERE DateTime BETWEEN DATEADD(HOUR, -6, GETDATE()) AND GETDATE()
            AND TagName IN ('{"', '".join(name_list)}')
            '''
        rows = await self.query(sql)

        # Data processing
        # Remove null values
        rows = rows.drop_nulls()
        # Convert DateTime column to datetime format
        if not rows.select(pl.col("DateTime")).dtypes[0] == pl.Datetime:    
            try:
                rows = rows.with_columns(pl.col("DateTime").cast(pl.Datetime))
            except pl.exceptions.SchemaError as e:
                self.logger.warning(f"DateTime列已经是datetime格式:{e}")
        # Truncate DateTime to seconds
        rows = rows.with_columns(pl.col("DateTime").dt.truncate('1s'))
        # Remove null values again
        rows = rows.drop_nulls()
        
        rows_pivot = rows.pivot(
            index="DateTime",
            on="TagName",
            values="TagVal",
            aggregate_function="first"
        )
        rows_pivot = self._remove_column_space(rows_pivot)
        # Add DateTime to beginning of input_name_list
        name_list.insert(0, "DateTime")
        rows_pivot = rows_pivot[name_list]

        return rows_pivot.tail(360)

    @staticmethod
    def _remove_column_space(df: pl.DataFrame) -> pl.DataFrame:
        """
        Remove spaces from DataFrame column names
        Args:
            df (pl.DataFrame): DataFrame
        Returns:
            pl.DataFrame: DataFrame with spaces removed from column names
        """
        df.columns = [col.replace(" ", "") for col in df.columns]
        return df

    async def get_latest_input_data_by_column_time(self, input_name_list: List[str], time_length: int) -> pl.DataFrame:
        """
        Get realtime data of latest time_length by column name list from 历史表 asynchronously
        Args:
            input_name_list (List[str]): column name list
            time_length (int): time length: x_length, seq_len, label_len
        Returns:
            pl.DataFrame: realtime data
        """
        name_list = input_name_list.copy()
        sql = f'''
            SELECT DateTime, TagName, TagVal
            FROM 历史表
            WHERE DateTime BETWEEN DATEADD(HOUR, -6, GETDATE()) AND GETDATE()
            AND TagName IN ('{"', '".join(name_list)}')
            '''
        rows = await self.query(sql)

        # Remove null values
        rows = rows.drop_nulls()
        # Convert DateTime column to datetime format
        if not rows.select(pl.col("DateTime")).dtypes[0] == pl.Datetime:
            try:
                rows = rows.with_columns(pl.col("DateTime").cast(pl.Datetime))
            except pl.exceptions.SchemaError as e:
                self.logger.warning(f"DateTime列已经是datetime格式:{e}")
        # Truncate DateTime to seconds
        rows = rows.with_columns(pl.col("DateTime").dt.truncate('1s'))
        # Remove null values again
        rows = rows.drop_nulls()

        rows_pivot = rows.pivot(
            index="DateTime",
            on="TagName",
            values="TagVal",
            aggregate_function="first"
        )
        rows_pivot = self._remove_column_space(rows_pivot)
        # Add DateTime to beginning of input_name_list
        name_list.insert(0, "DateTime")
        rows_pivot = rows_pivot[name_list]

        # Calculate minute average
        rows_pivot = calculate_minute_average(rows_pivot)
        
        return rows_pivot.tail(time_length)

    async def get_latest_true_value(self, table_name: str) -> pl.DataFrame:
        """
        Get true value of latest 1 hour asynchronously
        
        Args:
            table_name (str): table name

        Returns:
            pl.DataFrame: true value
        """
        sql = f"SELECT TOP (1) * FROM {table_name} " \
              f"WHERE (DateTime BETWEEN SUBSTRING(CONVERT(varchar, DATEADD(hour, - 2, GETDATE()), 120), 1, 16) AND " \
              f"SUBSTRING(CONVERT(varchar, DATEADD(hour, +1, GETDATE()), 120), 1, 16))" \
              f"ORDER BY DateTime DESC"
        rows = await self.query(sql)
        return rows
    
    async def get_latest_true_value_by_column(self, column_name: str) -> pl.DataFrame:
        """
        Get latest true value by column name asynchronously
        Args:
            column_name (str): column name
        Returns:
            pl.DataFrame: true value
        """
        sql = f'''
            SELECT TOP (1) TagVal
            FROM 历史表
            WHERE DateTime BETWEEN DATEADD(HOUR, -1, GETDATE()) AND GETDATE()
            AND TagName = '{column_name}'
            '''
        rows = await self.query(sql)
        return rows

    async def get_input_data_train(self, input_table_name: str, begin_time: datetime.datetime, 
                                 end_time: datetime.datetime) -> pl.DataFrame:
        """
        Get input data for specified time range asynchronously

        Args:
            input_table_name (str): table name
            begin_time (datetime.datetime): start time
            end_time (datetime.datetime): end time

        Returns:
            pl.DataFrame: input data
        """
        sql = f"""
            SELECT * FROM {input_table_name} 
            WHERE DateTime BETWEEN '{begin_time}' AND '{end_time}' order by DateTime
        """
        rows = await self.query(sql)
        return rows

    async def get_input_data_history(self, name_list: list, begin_time: str | datetime.datetime, 
                                   end_time: str | datetime.datetime) -> pl.DataFrame:
        """
        Get input data for specified time range by name list asynchronously
        Args:
            name_list (list): table name list
            begin_time (str | datetime.datetime): start time
            end_time (str | datetime.datetime): end time
        Returns:
            pl.DataFrame: input data
        """
        input_name_list = name_list.copy()
        self.logger.info(f"name_list: {input_name_list}")
        sql = f"""
            select * from [历史表] 
            where TagName in ('{"', '".join(input_name_list)}') 
            and DateTime between '{begin_time}' and '{end_time}' order by DateTime
        """
        self.logger.info(f"query history data sql: {sql}")
        rows = await self.query(sql)

        # Remove null values
        rows = rows.drop_nulls()
        # Convert DateTime column to datetime format
        if not rows.select(pl.col("DateTime")).dtypes[0] == pl.Datetime:
            try:
                rows = rows.with_columns(pl.col("DateTime").cast(pl.Datetime))
            except pl.exceptions.SchemaError as e:
                self.logger.error(f"DateTime列已经是datetime格式:{e}")
        # Truncate DateTime to seconds
        rows = rows.with_columns(pl.col("DateTime").dt.truncate('1s'))
        # Remove null values again
        rows = rows.drop_nulls()

        # Transform rows into standard input table
        df_pivot = rows.pivot(index="DateTime", on="TagName", values="TagVal", aggregate_function="first")
        df_pivot = self._remove_column_space(df_pivot)

        # Add DateTime to beginning of name_list and order DataFrame columns
        input_name_list.insert(0, "DateTime")
        df_pivot = df_pivot[input_name_list]

        self.logger.info(f"transform rows to standard input table successfully: {df_pivot}")
        return df_pivot

    async def get_output_data_train(self, output_table_name: str, begin_time: str, end_time: str) -> pl.DataFrame:
        """
        Get output data for specified time range asynchronously
        Args:
            output_table_name (str): table name
            begin_time (str): start time
            end_time (str): end time
        Returns:
            pl.DataFrame: output data
        """
        sql = f"""
            SELECT * FROM {output_table_name} WHERE DateTime 
            BETWEEN '{begin_time}' AND '{end_time}' order by DateTime
        """
        rows = await self.query(sql)
        return rows
    
    async def get_output_data_history(self, name_list: list, begin_time: str, end_time: str) -> pl.DataFrame:
        """
        Get output data for specified time range by name list asynchronously
        Args:
            name_list (list): variable name list
            begin_time (str): start time
            end_time (str): end time
        Returns:
            pl.DataFrame: output data
        """
        input_name_list = name_list.copy()
        sql = f"""
            select * from [历史表] 
            where TagName in ('{"', '".join(input_name_list)}') 
            and DateTime between '{begin_time}' and '{end_time}' order by DateTime
        """
        rows = await self.query(sql)
        
        # Convert DateTime column to datetime format
        if not rows.select(pl.col("DateTime")).dtypes[0] == pl.Datetime:
            try:
                rows = rows.with_columns(pl.col("DateTime").cast(pl.Datetime))
            except pl.exceptions.SchemaError as e:
                self.logger.error(f"DateTime列已经是datetime格式:{e}")
        # Truncate DateTime to seconds
        rows = rows.with_columns(pl.col("DateTime").dt.truncate('1s'))

        # Transform rows into standard input table
        df_pivot = rows.pivot(index="DateTime", on="TagName", values="TagVal", aggregate_function="first")
        df_pivot = self._remove_column_space(df_pivot)
        
        # Add DateTime to beginning of name_list and order DataFrame columns
        input_name_list.insert(0, "DateTime")
        df_pivot = df_pivot[input_name_list]

        self.logger.info(f"transform rows to standard output table successfully: {df_pivot}")
        return df_pivot

    # Optimization module
    async def get_optimization_mode(self, optimization_procedure: str) -> str:
        """Get optimization mode from TagDatabase asynchronously
        Args:
            optimization_procedure (str): optimization procedure
        Returns:
            str: optimization mode
        """
        match optimization_procedure:
            case "水泥磨":
                mode_sql = """
                            SELECT Top 1 TagName FROM TagDatabase 
                            WHERE TagName LIKE N'%水泥A%' 
                            and (TagName LIKE N'%优先%' or TagName LIKE N'%均衡模式%') AND TagVal = 1 
                            ORDER BY DataTime DESC
                """
            case "原料磨":
                mode_sql = """
                            SELECT Top 1 TagName FROM TagDatabase 
                            WHERE TagName LIKE N'%原料%' 
                            and (TagName LIKE N'%优先%' or TagName LIKE N'%均衡模式%') AND TagVal = 1 
                            ORDER BY DataTime DESC
                """
            case "煤磨":
                mode_sql = """
                            SELECT Top 1 TagName FROM TagDatabase 
                            WHERE TagName LIKE N'%煤磨%' 
                            and (TagName LIKE N'%优先%' or TagName LIKE N'%均衡模式%') AND TagVal = 1 
                            ORDER BY DataTime DESC
                """
            case "窑":
                mode_sql = """
                            SELECT Top 1 TagName FROM TagDatabase 
                            WHERE TagName LIKE N'%窑%' 
                            and (TagName LIKE N'%优先%' or TagName LIKE N'%均衡模式%') AND TagVal = 1
                            ORDER BY DataTime DESC
                """
            case _:
                mode_sql = None
        try:
            optimization_mode = await self.query(mode_sql)["TagName"].item()
            self.logger.info(f"当前{optimization_procedure}的优化模式为{optimization_mode}")
            optimization_mode = "均衡"
        except Exception as e:
            self.logger.error(f"当前优化的工序不在优化范围内！！！{e}, 已将优化模式设置为均衡模式!!!")
            optimization_mode = "均衡"
        return optimization_mode
    
    async def get_cement_mill_target(self) -> Tuple[int, float]:
        """
        从TagDatabase中读取并计算水泥磨的比表面积目标值和细度目标值
        :return: 比表面积目标值
        """
        cement_variety_sql = """SELECT tagName FROM [TagDataBase] WHERE tagName IN (
                                    '水泥APO425管装水泥',
                                    '水泥APO425D',
                                    '水泥APO425普通水泥',
                                    '水泥APO525',
                                    '水泥A道路水泥',
                                    '水泥A铁标水泥',
                                    'SA_325',
                                    'SA_PO425',
                                    'SA_PC425'
                                ) AND tagVal = 1;
                            """
        cement_variety = await self.query(cement_variety_sql)["tagName"].item()
        self.logger.info(f"当前水泥品种为{cement_variety}")

        # 根据水泥品种选择比表面积、细度目标值
        match cement_variety:
            case '水泥APO425管装水泥':
                sql_lower_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种1低限'"
                sql_upper_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种1高限'"
                sql_fineness_lower_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种细度1低限'"
                sql_fineness_upper_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种细度1高限'"
            case '水泥APO425D':
                sql_lower_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种2低限'"
                sql_upper_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种2高限'"
                sql_fineness_lower_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种细度2低限'"
                sql_fineness_upper_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种细度2高限'"
            case '水泥APO425普通水泥':
                sql_lower_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种3低限'"
                sql_upper_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种3高限'"
                sql_fineness_lower_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种细度3低限'"
                sql_fineness_upper_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种细度3高限'"
            case '水泥APO525':
                sql_lower_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种4低限'"
                sql_upper_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种4高限'"
                sql_fineness_lower_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种细度4低限'"
                sql_fineness_upper_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种细度4高限'"
            case '水泥A道路水泥':
                sql_lower_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种5低限'"
                sql_upper_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种5高限'"
                sql_fineness_lower_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种细度5低限'"
                sql_fineness_upper_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种细度5高限'"
            case '水泥A铁标水泥':
                sql_lower_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种6低限'"
                sql_upper_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种6高限'"
                sql_fineness_lower_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种细度6低限'"
                sql_fineness_upper_limit = "SELECT Top 1 TagVal FROM TagDatabase WHERE TagName='水泥A磨品种细度6高限'"
            case _:
                self.logger.warning(f"当前水泥品种{cement_variety}不在已知的范围内！！！")
                surface_area_target = 350
                fineness_target = 5.25
                return surface_area_target, fineness_target

        surface_area_lower_limit = await self.query(sql_lower_limit)["TagVal"].item()
        surface_area_upper_limit = await self.query(sql_upper_limit)["TagVal"].item()

        fineness_lower_limit = await self.query(sql_fineness_lower_limit)["TagVal"].item()
        fineness_upper_limit = await self.query(sql_fineness_upper_limit)["TagVal"].item()

        surface_area_target = (surface_area_lower_limit + surface_area_upper_limit) / 2
        fineness_target = (fineness_lower_limit + fineness_upper_limit) / 2
        # 如果细度目标均值为0，则将细度目标值设为5.25
        if fineness_target == 0:
            fineness_target = 5.25
        self.logger.info(f"当前优化的水泥品种为{cement_variety}，其比表面积目标值为{surface_area_target}, "
                       f"细度目标值为{fineness_target}!")

        # 再将目标值写入TagDatabase中，方便前台查看回显
        target_sql = f"UPDATE TagDatabase SET TagVal = {surface_area_target} WHERE TagName = '水泥A比表面积目标寄存'"
        await self.cursor.execute(target_sql)
        await self.connection.commit()
        self.logger.info(f"将比表面积目标值{surface_area_target}写入TagDatabase成功!")
        return surface_area_target, fineness_target
    
    async def get_cement_millA_target(self) -> Tuple[int, float]:
        """
        从TagDatabase中读取并计算水泥A磨的比表面积目标值和细度目标值
        :return: 比表面积目标值, 细度目标值
        """
        cement_variety_sql = """SELECT tagName FROM [TagDataBase] WHERE tagName IN (
                                    'SA_325',
                                    'SA_PO425',
                                    'SA_PC425'
                                ) AND tagVal = 1;
                            """
        cement_variety = await self.query(cement_variety_sql)["tagName"].item()
        self.logger.info(f"当前水泥品种为{cement_variety}")

        # 根据水泥品种选择比表面积、细度目标值
        match cement_variety:
            case 'SA_325':
                surface_area_target = 325
                fineness_target = 5.25
            case 'SA_PO425':
                surface_area_target = 425
                fineness_target = 5.25
            case 'SA_PC425':
                surface_area_target = 425
                fineness_target = 5.25
            case _:
                self.logger.warning(f"当前水泥品种{cement_variety}不在已知的范围内！！！")
                surface_area_target = 350
                fineness_target = 5.25
                return surface_area_target, fineness_target

        # 如果细度目标均值为0，则将细度目标值设为5.25
        if fineness_target == 0:
            fineness_target = 5.25
        self.logger.info(f"当前优化的水泥品种为{cement_variety}，其比表面积目标值为{surface_area_target}, "
                       f"细度目标值为{fineness_target}!")
        return surface_area_target, fineness_target
    
    async def get_cement_millB_target(self) -> Tuple[int, float]:
        """
        从TagDatabase中读取并计算水泥B磨的比表面积目标值和细度目标值
        :return: 比表面积目标值, 细度目标值
        """
        cement_variety_sql = """SELECT tagName FROM [TagDataBase] WHERE tagName IN (
                                    'SB_325',
                                    'SB_PO425',
                                    'SB_PC425'
                                ) AND tagVal = 1;
                            """
        cement_variety = await self.query(cement_variety_sql)["tagName"].item()
        self.logger.info(f"当前水泥品种为{cement_variety}")

        # 根据水泥品种选择比表面积、细度目标值
        match cement_variety:
            case 'SB_325':
                surface_area_target = 325
                fineness_target = 5.25
            case 'SB_PO425':
                surface_area_target = 425
                fineness_target = 5.25
            case 'SA_PC425':
                surface_area_target = 425
                fineness_target = 5.25
            case _:
                self.logger.warning(f"当前水泥品种{cement_variety}不在已知的范围内！！！")
                surface_area_target = 350
                fineness_target = 5.25
                return surface_area_target, fineness_target

        # 如果细度目标均值为0，则将细度目标值设为5.25
        if fineness_target == 0:
            fineness_target = 5.25
        self.logger.info(f"当前优化的水泥品种为{cement_variety}，其比表面积目标值为{surface_area_target}, "
                       f"细度目标值为{fineness_target}!")
        return surface_area_target, fineness_target
    
        

    async def query_decision_history_data(self, table_name: str, time_query: int) -> pl.DataFrame:
        """
        查询用于决策的历史数据
        Args:
            table_name (str): 表名
            time_query (int): 查询时间
        Returns:
            pl.DataFrame: 历史数据
        """
        # 从视图中查询给定长度的数据
        time_query = time_query * 6  # 默认的查询时间为分钟，1min控制器数据库中有6个数，查询的时候需要转换一下
        sql_sentence = f"""
                SELECT Top {time_query} * FROM {table_name} 
                WHERE DateTime BETWEEN SUBSTRING(CONVERT(varchar, DATEADD(hour, - 2, GETDATE()), 120), 1, 16) 
                AND SUBSTRING(CONVERT(varchar, DATEADD(hour, +1, GETDATE()), 120), 1, 16)
                ORDER BY DateTime DESC
            """
        rows = await self.query(sql_sentence)
        # 计算分钟均值和平滑滤波
        decision_history_data = optimization_data_process(rows, int(time_query / 6))
        return decision_history_data
    
    async def query_decision_history_data_by_name(self, input_name_list: list, time_query: int) -> pl.DataFrame:
        """
        根据变量名列表从历史表中查询历史数据
        Args:
            input_name_list (list): 变量名列表
            time_query (int): 查询时间
        Returns:
            pl.DataFrame: 历史数据
        """
        name_list = input_name_list.copy()
        sql = f'''
            SELECT DateTime, TagName, TagVal
            FROM 历史表
            WHERE DateTime BETWEEN DATEADD(HOUR, -6, GETDATE()) AND GETDATE()
            AND TagName IN ('{"', '".join(name_list)}')
            '''
        rows = await self.query(sql)

        # 去除null值
        rows = rows.drop_nulls()
        # 先将DateTime列转换为datetime格式
        if not rows.select(pl.col("DateTime")).dtypes[0] == pl.Datetime:
            try:
                rows = rows.with_columns(pl.col("DateTime").cast(pl.Datetime))
            except pl.exceptions.SchemaError as e:
                self.logger.warning(f"DateTime列已经是datetime格式:{e}")
        # 将第一列DateTime约束到秒
        rows = rows.with_columns(pl.col("DateTime").dt.truncate('1s'))
        # print(rows)
        # 去除null值
        rows = rows.drop_nulls()

        rows_pivot = rows.pivot(
            index="DateTime",
            on="TagName",
            values="TagVal",
            aggregate_function="first"
        )
        rows_pivot = self._remove_column_space(rows_pivot)
        # 先在input_name_list首位加入DateTime
        name_list.insert(0, "DateTime")
        rows_pivot = rows_pivot[name_list]

        # 计算分钟均值
        rows_pivot = calculate_minute_average(rows_pivot)
        
        return rows_pivot.tail(time_query)

    async def write_decision_result(self, optimization_project_name: str, optimization_name_list: list, 
                              optimization_solution_results: list, optimization_type: str) -> None:
        """
        将优化求解的结果写入SQL server数据库,按行写入
        Args:
            optimization_project_name (str): 项目名称
            optimization_name_list (list): 变量名列表
            optimization_solution_results (list): 优化求解的结果
            optimization_type (str): 优化类型
        Returns:
            None
        """
        time_now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # 先将决策值限制到小数点后一位
        optimization_solution_results = [round(num, 2) for num in optimization_solution_results]
        # 按照optimization_name_list的顺序，将优化决策得到的结果按行写入数据库
        for name in optimization_name_list:
            # 先判断需要写入的数据是否存在，若存在则更新，否则插入
            sql_sentence = f"""SELECT COUNT(*) FROM decision WHERE optimization_type = '{optimization_type}' 
                            AND variable_name = '{name}'
                            AND optimization_project_name = '{optimization_project_name}'"""
            row_count = await self.cursor.execute(sql_sentence)
            row_count_result = await self.cursor.fetchone()
            row_count = row_count_result[0]
            if row_count > 0:
                # print(
                #     f"------------------{optimization_project_name}优化项目的{optimization_type}类型的{name}数据已存在，更新数据！------------------")
                # 更新数据
                sql_sentence = f"""
                    UPDATE decision SET decision_value = 
                    '{optimization_solution_results[optimization_name_list.index(name)]}',DateTime = '{time_now}' 
                    WHERE optimization_type = '{optimization_type}' AND variable_name = '{name}' 
                    AND optimization_project_name = '{optimization_project_name}'
                """
                await self.cursor.execute(sql_sentence)
                await self.connection.commit()
            else:
                print(
                    f"------------------{optimization_project_name}优化项目的{optimization_type}类型的{name}数据不存在，插入数据！------------------")
                # 插入数据
                sql_sentence = f"INSERT INTO decision(DateTime,optimization_project_name, variable_name, decision_value, optimization_type) " \
                               f"VALUES('{time_now}','{optimization_project_name}','{name}',{optimization_solution_results[optimization_name_list.index(name)]},'{optimization_type}')"
                await self.cursor.execute(sql_sentence)
                await self.connection.commit()
        # print(f'------------------当前时刻{time_now}写入decision表数据成功！------------------')
