import polars as pl

# from .shared_data import get_global_df
from industrytslib.utils.data_processing.polarsoperation import calculate_minute_average
from .shared_dataframe import SharedDataFrame

# def read_dataframe(name_list: list[str] = None) -> pl.DataFrame:
#     """读取全局 DataFrame 的函数

#     Args:
#         name_list (list[str], optional): 需要读取的列名列表. Defaults to None.
#     """
#     assert name_list is not None, "name_list 不能为空"

#     time_start = time.time()
#     df = get_global_df()
#     assert not df.is_empty(), ValueError("全局 DataFrame 为空")

#     # 选择df中name_list中的列
#     df = df.select(name_list)
#     time_end = time.time()
#     print(f"读取数据耗时: {time_end - time_start:.4f} 秒")

#     # 统计 df 占用的内存大小
#     memory_usage = df.estimated_size() / 1024 / 1024  # 转换为 MB
#     print(f"df 占用的内存大小: {memory_usage:.4f} MB")
#     return df


# def read_dataframe_history(name_list: list[str] = None, time_length: int = 60) -> pl.DataFrame:
#     """读取全局 DataFrame 的函数

#     Args:
#         name_list (list[str], optional): 需要读取的列名列表. Defaults to None.
#     """
#     assert name_list is not None, "name_list 不能为空"

#     time_start = time.time()
#     df = get_global_df()
#     if df.is_empty():
#         raise ValueError("全局 DataFrame 为空")

#     # 选择df中name_list中的列
#     df = df.select(name_list)
#     time_end = time.time()
#     print(f"读取数据耗时: {time_end - time_start:.4f} 秒")

#     # 统计 df 占用的内存大小
#     df = calculate_minute_average(df)
#     return df.tail(time_length)

class ReadDataframe:
    def __init__(self):
        self.shared_df = SharedDataFrame()
        self.current_df = self.shared_df.read_dataframe()

    def read_dataframe(
            self, 
            name_list: list[str] = None, 
            time_length: int = 60
        ) -> pl.DataFrame:
        """
        Read dataframe

        Args:
            name_list (list[str], optional): name list. Defaults to None.
            time_length (int, optional): time length. Defaults to 60.
        Returns:
            pl.DataFrame: dataframe
        """
        input_name_list = ["DateTime"] + name_list
        self.current_df = self.shared_df.read_dataframe()
        # print(f"current_df readed: {self.current_df}")
        if self.current_df.is_empty():
            # print("全局 DataFrame 为空")
            return pl.DataFrame()
        # 选择df中name_list中的列
        df = self.current_df.select(input_name_list)
        df = calculate_minute_average(df)
        return df.tail(time_length)
    
    def read_dataframe_latest(self) -> pl.DataFrame:
        """
        Read latest dataframe
        """
        self.current_df = self.shared_df.read_dataframe()
        # print(f"current_df readed: {self.current_df}")
        if self.current_df.is_empty():
            # print("全局 DataFrame 为空")
            return pl.DataFrame()
        df = calculate_minute_average(self.current_df)
        print(f"latest_df: {df}")
        return df
    
    def check_device_status(self, device_operation_flag: str) -> bool:
        """
        在共享dataframe中查询设备运行标志位

        Args:
            device_operation_flag (str): device operation flag
        Returns:
            bool: device status
        """
        self.current_df = self.shared_df.read_dataframe()
        # 选择df中name_list中的列
        df = self.current_df.sort("DateTime", descending=True).select(device_operation_flag).head(1)
        return df.item() == 1

